#!/usr/bin/env python3
from __future__ import annotations

import argparse
import importlib
import json
import subprocess
import sys
from pathlib import Path
from typing import Any, Callable, Optional, Sequence

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ucs_oodid.io import load_json, save_json


class MethodSpec:
    def __init__(self, name: str, display_name: str, category: str, extra_args: Sequence[object] = ()) -> None:
        self.name = str(name)
        self.display_name = str(display_name)
        self.category = str(category)
        self.extra_args = tuple(extra_args)


METHOD_SPECS = [
    MethodSpec("svm", "SVM", "sklearn"),
    MethodSpec("random_forest", "Random Forest", "sklearn"),
    MethodSpec("xgboost", "XGBoost", "sklearn"),
    MethodSpec("mlp", "MLP", "sklearn"),
    MethodSpec("gcn_only", "GCN-only", "neural", ("--encoder_ablation", "gcn_only", "--fusion", "mean", "--ood_threshold_mode", "global")),
    MethodSpec("random_graph", "Random Graph", "neural", ("--encoder_ablation", "random_graph", "--fusion", "mean", "--ood_threshold_mode", "global")),
    MethodSpec("transformer_gcn", "Transformer+GCN", "neural", ("--encoder_ablation", "full", "--fusion", "mean", "--ood_threshold_mode", "global")),
    MethodSpec(
        "transformer_only_mean",
        "Transformer-only + Mean OOD Fusion",
        "neural",
        ("--encoder_ablation", "transformer_only", "--fusion", "mean", "--ood_threshold_mode", "global"),
    ),
    MethodSpec(
        "ucs_oodid",
        "UCS-OODID",
        "neural",
        (
            "--encoder_ablation",
            "transformer_only",
            "--fusion",
            "correlation_aware",
            "--ood_threshold_mode",
            "group",
            "--group_threshold_strategy",
            "conservative",
            "--group_threshold_min_ratio",
            "1.0",
            "--use_group_embedding",
            "--group_embedding_dim",
            "16",
        ),
    ),
]
METHOD_BY_NAME = {spec.name: spec for spec in METHOD_SPECS}

KNOWN_COLUMNS = ["Method", "Micro-F1", "Macro-F1", "mAP", "Hamming Loss", "Subset Acc."]
OOD_COLUMNS = ["Method", "AUROC", "AUPR-Out", "FPR95", "Precision", "Recall", "OOD-F1", "FPR@theta"]
BASELINE_CONFIG_COLUMNS = ["Method", "Input", "Classifier/Encoder", "OOD Score", "Threshold Calibration", "Notes"]
KNOWN_CAPTION = "Known-attack multi-label detection comparison under the same metadata-window protocol."
OOD_CAPTION = "OOD identification comparison under the same metadata-window protocol."
BASELINE_CONFIG_CAPTION = "Baseline configuration summary under the same metadata-window protocol."
BASELINE_CONFIG_ROWS = {
    "svm": {
        "Method": "SVM",
        "Input": "Flattened metadata window",
        "Classifier/Encoder": "RBF SVM + MultiOutput",
        "OOD Score": "Uncertainty",
        "Threshold Calibration": "ID validation quantile",
        "Notes": "Classical margin baseline",
    },
    "random_forest": {
        "Method": "Random Forest",
        "Input": "Flattened metadata window",
        "Classifier/Encoder": "200 trees + MultiOutput",
        "OOD Score": "Uncertainty",
        "Threshold Calibration": "ID validation quantile",
        "Notes": "Tree ensemble baseline",
    },
    "xgboost": {
        "Method": "XGBoost",
        "Input": "Flattened metadata window",
        "Classifier/Encoder": "XGBClassifier + MultiOutput",
        "OOD Score": "Uncertainty",
        "Threshold Calibration": "ID validation quantile",
        "Notes": "Boosted tree baseline",
    },
    "mlp": {
        "Method": "MLP",
        "Input": "Flattened metadata window",
        "Classifier/Encoder": "MLP + MultiOutput",
        "OOD Score": "Energy",
        "Threshold Calibration": "ID validation quantile",
        "Notes": "Non-temporal neural baseline",
    },
    "gcn_only": {
        "Method": "GCN-only",
        "Input": "Metadata window + behavior graph",
        "Classifier/Encoder": "Dense GCN",
        "OOD Score": "Mean fusion",
        "Threshold Calibration": "Global ID validation quantile",
        "Notes": "Graph-only ablation",
    },
    "random_graph": {
        "Method": "Random Graph",
        "Input": "Metadata window + random behavior graph",
        "Classifier/Encoder": "Transformer + random graph",
        "OOD Score": "Mean fusion",
        "Threshold Calibration": "Global ID validation quantile",
        "Notes": "Random-graph ablation",
    },
    "transformer_gcn": {
        "Method": "Transformer+GCN",
        "Input": "Metadata window + behavior graph",
        "Classifier/Encoder": "Transformer + GCN",
        "OOD Score": "Mean fusion",
        "Threshold Calibration": "Global ID validation quantile",
        "Notes": "Temporal-graph ablation",
    },
    "transformer_only_mean": {
        "Method": "Transformer-only + Mean",
        "Input": "Metadata window",
        "Classifier/Encoder": "Lightweight Transformer",
        "OOD Score": "Mean fusion",
        "Threshold Calibration": "Global ID validation quantile",
        "Notes": "Temporal baseline",
    },
    "ucs_oodid": {
        "Method": "UCS-OODID",
        "Input": "Metadata window + UAV group",
        "Classifier/Encoder": "Lightweight Transformer + group embedding",
        "OOD Score": "Correlation-aware fusion",
        "Threshold Calibration": "Group conservative ID-only threshold",
        "Notes": "Proposed method",
    },
}


def get_output_root(args) -> Path:
    return Path(getattr(args, "output_root", getattr(args, "output_dir", "runs/comparison_experiments")))


def run_subprocess(cmd: Sequence[object]) -> subprocess.CompletedProcess[str]:
    cmd_list = [str(part) for part in cmd]
    print("RUN", " ".join(cmd_list), flush=True)
    result = subprocess.run(
        cmd_list,
        cwd=str(ROOT),
        check=False,
        capture_output=True,
        text=True,
    )
    if result.stdout:
        print(result.stdout, end="" if result.stdout.endswith("\n") else "\n")
    if result.stderr:
        print(result.stderr, end="" if result.stderr.endswith("\n") else "\n", file=sys.stderr)
    return result


def latex_escape(text: str) -> str:
    replacements = {
        "\\": r"\textbackslash{}",
        "&": r"\&",
        "%": r"\%",
        "$": r"\$",
        "#": r"\#",
        "_": r"\_",
        "{": r"\{",
        "}": r"\}",
        "~": r"\textasciitilde{}",
        "^": r"\textasciicircum{}",
    }
    return "".join(replacements.get(ch, ch) for ch in text)


def _tail_text(text: str | None, max_lines: int = 40, max_chars: int = 4000) -> str:
    raw = str(text or "")
    lines = raw.splitlines()
    clipped = "\n".join(lines[-max_lines:])
    return clipped[-max_chars:]


def _report_note(report: dict) -> str:
    if report.get("skip_reason"):
        return str(report["skip_reason"])
    if report.get("error_message"):
        return str(report["error_message"])
    return ""


def _normalize_report(spec: MethodSpec, report: dict) -> dict:
    normalized = dict(report)
    normalized.setdefault("method", spec.name)
    normalized.setdefault("method_name", spec.name)
    normalized.setdefault("display_name", spec.display_name)
    normalized.setdefault("category", spec.category)
    normalized.setdefault("status", "success")
    return normalized


def _skipped_report(spec: MethodSpec, reason: str) -> dict:
    return _normalize_report(
        spec,
        {
            "status": "skipped",
            "skip_reason": str(reason),
        },
    )


def _failed_report(spec: MethodSpec, message: str) -> dict:
    return _normalize_report(
        spec,
        {
            "status": "failed",
            "error_message": str(message),
        },
    )


def _is_xgboost_available() -> tuple[bool, Optional[str]]:
    try:
        module = importlib.import_module("xgboost")
        getattr(module, "XGBClassifier")
    except ModuleNotFoundError:
        return False, "xgboost is not installed. Install xgboost to use the xgboost baseline."
    except AttributeError:
        return False, "xgboost.XGBClassifier is unavailable in this xgboost installation."
    return True, None


def _shared_dataset_args(args) -> list[object]:
    return [
        "--input",
        getattr(args, "input"),
        "--label_col",
        getattr(args, "label_col", "label"),
        "--timestamp_col",
        getattr(args, "timestamp_col", "timestamp"),
        "--record_id_col",
        getattr(args, "record_id_col", "record_id"),
        "--group_col",
        getattr(args, "group_col", "uav_id"),
        "--id_classes",
        getattr(args, "id_classes", ""),
        "--ood_classes",
        getattr(args, "ood_classes", ""),
        "--window_mode",
        getattr(args, "window_mode", "count"),
        "--window_size",
        str(getattr(args, "window_size", 16)),
        "--stride",
        str(getattr(args, "stride", 8)),
        "--time_window_seconds",
        str(getattr(args, "time_window_seconds", 2.0)),
        "--adaptive_min_size",
        str(getattr(args, "adaptive_min_size", 8)),
        "--adaptive_max_size",
        str(getattr(args, "adaptive_max_size", 64)),
        "--normalization_mode",
        getattr(args, "normalization_mode", "group"),
        "--q_ood",
        str(getattr(args, "q_ood", 0.90)),
        "--seed",
        str(getattr(args, "seed", 42)),
    ]


def build_sklearn_command(args, spec: MethodSpec, output_root: Path) -> list[object]:
    cmd: list[object] = [
        sys.executable,
        Path(__file__).with_name("train_sklearn_baselines.py"),
        *_shared_dataset_args(args),
        "--output_dir",
        output_root,
        "--benign_label",
        getattr(args, "benign_label", "benign"),
        "--baseline",
        spec.name,
    ]
    if bool(getattr(args, "allow_ports", False)):
        cmd.append("--allow_ports")
    return cmd


def build_neural_command(args, spec: MethodSpec, output_root: Path) -> list[object]:
    cmd: list[object] = [
        sys.executable,
        Path(__file__).with_name("train.py"),
        *_shared_dataset_args(args),
        "--output_dir",
        output_root / spec.name,
        "--epochs",
        str(getattr(args, "epochs", 10)),
        *list(spec.extra_args),
    ]
    device = str(getattr(args, "device", "auto") or "").strip()
    if device and device.lower() != "auto":
        cmd.extend(["--device", device])
    if bool(getattr(args, "allow_ports", False)):
        cmd.append("--allow_ports")
    return cmd


def _resolve_methods(methods: str | None, skip_sklearn: bool, skip_neural: bool) -> list[MethodSpec]:
    if methods is None or str(methods).strip() == "":
        requested_names = [spec.name for spec in METHOD_SPECS]
    else:
        requested_names = [item.strip().lower() for item in str(methods).split(",") if item.strip()]
    seen = set()
    selected: list[MethodSpec] = []
    for name in requested_names:
        if name in seen:
            continue
        if name not in METHOD_BY_NAME:
            raise ValueError(f"Unsupported comparison method: {name}")
        seen.add(name)
    for spec in METHOD_SPECS:
        if spec.name not in seen:
            continue
        if skip_sklearn and spec.category == "sklearn":
            continue
        if skip_neural and spec.category == "neural":
            continue
        selected.append(spec)
    if not selected:
        raise ValueError("No methods selected after applying --methods / --skip_sklearn / --skip_neural filters.")
    return selected


def _load_or_fail_report(spec: MethodSpec, report_path: Path, message: str) -> dict:
    if report_path.exists():
        return _normalize_report(spec, load_json(report_path))
    report = _failed_report(spec, message)
    save_json(report, report_path)
    return report


def _execute_method(
    args,
    spec: MethodSpec,
    output_root: Path,
    runner: Callable[[Sequence[object]], Any],
    failed_methods: list[dict],
    xgboost_availability: Callable[[], tuple[bool, Optional[str]]],
) -> dict:
    method_dir = output_root / spec.name
    method_dir.mkdir(parents=True, exist_ok=True)
    report_path = method_dir / "eval_report.json"

    if spec.category == "sklearn" and spec.name == "xgboost":
        available, reason = xgboost_availability()
        if not available:
            report = _skipped_report(spec, reason or "xgboost is unavailable")
            save_json(report, report_path)
            return report

    cmd = build_sklearn_command(args, spec, output_root) if spec.category == "sklearn" else build_neural_command(args, spec, output_root)
    try:
        result = runner(cmd)
    except Exception as exc:
        message = f"{type(exc).__name__}: {exc}"
        failed_methods.append(
            {
                "method": spec.name,
                "command": [str(part) for part in cmd],
                "return_code": None,
                "stdout_tail": "",
                "stderr_tail": message,
            }
        )
        report = _failed_report(spec, message)
        save_json(report, report_path)
        return report

    return_code = int(getattr(result, "returncode", 0))
    stdout = getattr(result, "stdout", "")
    stderr = getattr(result, "stderr", "")
    if return_code != 0:
        failed_methods.append(
            {
                "method": spec.name,
                "command": [str(part) for part in cmd],
                "return_code": return_code,
                "stdout_tail": _tail_text(stdout),
                "stderr_tail": _tail_text(stderr),
            }
        )
        report = _load_or_fail_report(spec, report_path, f"Subprocess exited with return code {return_code}")
        report["status"] = "failed"
        report.setdefault("error_message", f"Subprocess exited with return code {return_code}")
        save_json(report, report_path)
        return report

    if not report_path.exists():
        failed_methods.append(
            {
                "method": spec.name,
                "command": [str(part) for part in cmd],
                "return_code": 0,
                "stdout_tail": _tail_text(stdout),
                "stderr_tail": _tail_text(stderr),
            }
        )
        report = _failed_report(spec, "eval_report.json was not produced by the child process.")
        save_json(report, report_path)
        return report

    report = _normalize_report(spec, load_json(report_path))
    save_json(report, report_path)
    return report


def _round_metric_frame(frame: pd.DataFrame, *, round_numeric: bool) -> pd.DataFrame:
    prepared = frame.copy()
    if not round_numeric:
        return prepared
    for column in prepared.columns:
        if column == "Method":
            continue
        prepared[column] = pd.to_numeric(prepared[column], errors="coerce").round(4)
    return prepared


def _format_latex_value(value: Any) -> str:
    if value is None or pd.isna(value):
        return ""
    if isinstance(value, (int, float)):
        return f"{float(value):.4f}"
    return latex_escape(str(value))


def _latex_row(values: Sequence[Any], highlight: bool = False) -> str:
    cells = []
    for value in values:
        text = _format_latex_value(value)
        if highlight and text:
            text = rf"\textbf{{{text}}}"
        cells.append(text)
    return " & ".join(cells) + r" \\"


def _write_tables(
    rows: list[dict],
    columns: list[str],
    output_csv: Path,
    output_tex: Path,
    caption: str,
    *,
    round_numeric: bool = True,
    aligns: Optional[str] = None,
) -> None:
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    frame = pd.DataFrame(rows).reindex(columns=columns)
    rounded = _round_metric_frame(frame, round_numeric=round_numeric)
    rounded.to_csv(output_csv, index=False)

    table_aligns = aligns or ("l" + "r" * (len(columns) - 1))
    lines = [
        r"\begin{table}[t]",
        r"\centering",
        rf"\caption{{{caption}}}",
        r"\begin{tabular}{" + table_aligns + "}",
        r"\toprule",
        " & ".join(latex_escape(str(column)) for column in columns) + r" \\",
        r"\midrule",
    ]
    for row in rounded.itertuples(index=False, name=None):
        highlight = str(row[0]) == "UCS-OODID"
        lines.append(_latex_row(row, highlight=highlight))
    lines.extend([r"\bottomrule", r"\end{tabular}", r"\end{table}"])
    output_tex.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _known_row(spec: MethodSpec, report: dict) -> dict:
    metrics = report.get("id_test", {})
    return {
        "Method": spec.display_name,
        "Micro-F1": metrics.get("micro_f1"),
        "Macro-F1": metrics.get("macro_f1"),
        "mAP": metrics.get("mAP"),
        "Hamming Loss": metrics.get("hamming_loss"),
        "Subset Acc.": metrics.get("subset_accuracy"),
    }


def _ood_row(spec: MethodSpec, report: dict) -> dict:
    metrics = report.get("ood_test", {})
    return {
        "Method": spec.display_name,
        "AUROC": metrics.get("auroc"),
        "AUPR-Out": metrics.get("aupr_out"),
        "FPR95": metrics.get("fpr95"),
        "Precision": metrics.get("precision"),
        "Recall": metrics.get("recall", metrics.get("tpr")),
        "OOD-F1": metrics.get("ood_f1"),
        "FPR@theta": metrics.get("fpr_at_threshold"),
    }


def _baseline_config_row(spec: MethodSpec) -> dict:
    row = BASELINE_CONFIG_ROWS.get(spec.name)
    if row is not None:
        return dict(row)
    return {
        "Method": spec.display_name,
        "Input": "",
        "Classifier/Encoder": "",
        "OOD Score": "",
        "Threshold Calibration": "",
        "Notes": "",
    }


def _method_summary(spec: MethodSpec, report: dict, output_root: Path) -> dict:
    return {
        "method_name": spec.name,
        "display_name": spec.display_name,
        "category": spec.category,
        "status": report.get("status", "success"),
        "note": _report_note(report),
        "output_dir": str(output_root / spec.name),
        "eval_report": str(output_root / spec.name / "eval_report.json"),
        "known_detection": report.get("id_test", {}),
        "ood_detection": report.get("ood_test", {}),
    }


def _cleanup_child_sklearn_outputs(output_root: Path) -> None:
    for filename in ("sklearn_baseline_summary.json", "skipped_baselines.json"):
        path = output_root / filename
        if path.exists():
            path.unlink()


def run_comparison_experiments(
    args,
    runner: Callable[[Sequence[object]], Any] = run_subprocess,
    tabular_evaluator=None,
    xgboost_availability: Callable[[], tuple[bool, Optional[str]]] = _is_xgboost_available,
) -> dict:
    del tabular_evaluator

    output_root = get_output_root(args)
    output_root.mkdir(parents=True, exist_ok=True)
    selected_methods = _resolve_methods(
        getattr(args, "methods", ""),
        bool(getattr(args, "skip_sklearn", False)),
        bool(getattr(args, "skip_neural", False)),
    )

    failed_method_records: list[dict] = []
    for spec in selected_methods:
        _execute_method(
            args,
            spec,
            output_root,
            runner=runner,
            failed_methods=failed_method_records,
            xgboost_availability=xgboost_availability,
        )

    _cleanup_child_sklearn_outputs(output_root)

    reports_by_name = {
        spec.name: _normalize_report(spec, load_json(output_root / spec.name / "eval_report.json"))
        for spec in selected_methods
    }
    method_summaries = [_method_summary(spec, reports_by_name[spec.name], output_root) for spec in selected_methods]

    known_rows = [_known_row(spec, reports_by_name[spec.name]) for spec in selected_methods]
    ood_rows = [_ood_row(spec, reports_by_name[spec.name]) for spec in selected_methods]
    baseline_config_rows = [_baseline_config_row(spec) for spec in selected_methods]

    known_csv = output_root / "known_detection_table.csv"
    known_tex = output_root / "known_detection_table.tex"
    ood_csv = output_root / "ood_detection_table.csv"
    ood_tex = output_root / "ood_detection_table.tex"
    baseline_config_csv = output_root / "baseline_config_table.csv"
    baseline_config_tex = output_root / "baseline_config_table.tex"
    failed_json = output_root / "failed_methods.json"
    _write_tables(known_rows, KNOWN_COLUMNS, known_csv, known_tex, KNOWN_CAPTION)
    _write_tables(ood_rows, OOD_COLUMNS, ood_csv, ood_tex, OOD_CAPTION)
    _write_tables(
        baseline_config_rows,
        BASELINE_CONFIG_COLUMNS,
        baseline_config_csv,
        baseline_config_tex,
        BASELINE_CONFIG_CAPTION,
        round_numeric=False,
        aligns="llllll",
    )
    save_json(failed_method_records, failed_json)

    skipped_methods = [item["method_name"] for item in method_summaries if item["status"] == "skipped"]
    failed_methods = [item["method_name"] for item in method_summaries if item["status"] == "failed"]
    successful_methods = [item["method_name"] for item in method_summaries if item["status"] == "success"]
    summary = {
        "input": str(getattr(args, "input")),
        "output_root": str(output_root),
        "output_dir": str(output_root),
        "selected_methods": [spec.name for spec in selected_methods],
        "successful_methods": successful_methods,
        "skipped_methods": skipped_methods,
        "failed_methods": failed_methods,
        "methods": method_summaries,
        "tables": {
            "known_detection_csv": str(known_csv),
            "known_detection_tex": str(known_tex),
            "ood_detection_csv": str(ood_csv),
            "ood_detection_tex": str(ood_tex),
            "baseline_config_csv": str(baseline_config_csv),
            "baseline_config_tex": str(baseline_config_tex),
        },
        "failed_methods_file": str(failed_json),
    }
    save_json(summary, output_root / "comparison_summary.json")
    return summary


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run all paper comparison baselines with a shared metadata-window protocol.")
    parser.add_argument("--input", required=True)
    parser.add_argument("--output_root", default="runs/comparison_experiments")
    parser.add_argument("--output_dir", dest="output_root", help=argparse.SUPPRESS)
    parser.add_argument("--label_col", default="label")
    parser.add_argument("--timestamp_col", default="timestamp")
    parser.add_argument("--record_id_col", default="record_id")
    parser.add_argument("--group_col", default="uav_id")
    parser.add_argument("--id_classes", required=True)
    parser.add_argument("--ood_classes", required=True)
    parser.add_argument("--window_mode", default="count", choices=["count", "time", "adaptive"])
    parser.add_argument("--window_size", type=int, default=16)
    parser.add_argument("--stride", type=int, default=8)
    parser.add_argument("--time_window_seconds", type=float, default=2.0)
    parser.add_argument("--adaptive_min_size", type=int, default=8)
    parser.add_argument("--adaptive_max_size", type=int, default=64)
    parser.add_argument("--normalization_mode", default="group", choices=["global", "group"])
    parser.add_argument("--q_ood", type=float, default=0.90)
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--device", default="auto")
    parser.add_argument("--skip_sklearn", action="store_true")
    parser.add_argument("--skip_neural", action="store_true")
    parser.add_argument("--methods", default="", help="Optional comma-separated subset of methods to run.")
    parser.add_argument("--benign_label", default="benign")
    parser.add_argument("--allow_ports", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    summary = run_comparison_experiments(args)
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
