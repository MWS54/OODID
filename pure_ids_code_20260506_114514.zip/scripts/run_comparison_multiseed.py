#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path
from typing import Any, Callable, Optional, Sequence

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ucs_oodid.utils import parse_csv_list

KNOWN_COLUMNS = ["Method", "Micro-F1", "Macro-F1", "mAP", "Hamming Loss", "Subset Acc."]
OOD_COLUMNS = ["Method", "AUROC", "AUPR-Out", "FPR95", "Precision", "Recall", "OOD-F1", "FPR@theta"]
KNOWN_CAPTION = r"Known-attack multi-label detection comparison under the same metadata-window protocol (mean $\pm$ std over random seeds)."
OOD_CAPTION = r"OOD identification comparison under the same metadata-window protocol (mean $\pm$ std over random seeds)."


def run_subprocess(cmd: Sequence[object]) -> subprocess.CompletedProcess[str]:
    cmd_list = [str(part) for part in cmd]
    print("RUN", " ".join(cmd_list), flush=True)
    result = subprocess.run(
        cmd_list,
        cwd=str(ROOT),
        check=False,
        capture_output=True,
        text=True,
    )
    if result.stdout:
        print(result.stdout, end="" if result.stdout.endswith("\n") else "\n")
    if result.stderr:
        print(result.stderr, end="" if result.stderr.endswith("\n") else "\n", file=sys.stderr)
    return result


def latex_escape(text: str) -> str:
    replacements = {
        "\\": r"\textbackslash{}",
        "&": r"\&",
        "%": r"\%",
        "$": r"\$",
        "#": r"\#",
        "_": r"\_",
        "{": r"\{",
        "}": r"\}",
        "~": r"\textasciitilde{}",
        "^": r"\textasciicircum{}",
    }
    return "".join(replacements.get(ch, ch) for ch in text)


def _tail_text(text: str | None, max_lines: int = 40, max_chars: int = 4000) -> str:
    raw = str(text or "")
    lines = raw.splitlines()
    clipped = "\n".join(lines[-max_lines:])
    return clipped[-max_chars:]


def parse_seeds(value: str) -> list[int]:
    items = parse_csv_list(value)
    if not items:
        raise ValueError("At least one seed must be provided via --seeds")
    seeds: list[int] = []
    seen = set()
    for item in items:
        seed = int(item)
        if seed in seen:
            continue
        seen.add(seed)
        seeds.append(seed)
    return seeds


def build_seed_command(args, seed: int, seed_output_root: Path) -> list[object]:
    cmd: list[object] = [
        sys.executable,
        Path(__file__).with_name("run_comparison_experiments.py"),
        "--input",
        getattr(args, "input"),
        "--output_root",
        seed_output_root,
        "--label_col",
        getattr(args, "label_col", "label"),
        "--timestamp_col",
        getattr(args, "timestamp_col", "timestamp"),
        "--record_id_col",
        getattr(args, "record_id_col", "record_id"),
        "--group_col",
        getattr(args, "group_col", "uav_id"),
        "--id_classes",
        getattr(args, "id_classes", ""),
        "--ood_classes",
        getattr(args, "ood_classes", ""),
        "--window_mode",
        getattr(args, "window_mode", "count"),
        "--window_size",
        str(getattr(args, "window_size", 16)),
        "--stride",
        str(getattr(args, "stride", 8)),
        "--time_window_seconds",
        str(getattr(args, "time_window_seconds", 2.0)),
        "--adaptive_min_size",
        str(getattr(args, "adaptive_min_size", 8)),
        "--adaptive_max_size",
        str(getattr(args, "adaptive_max_size", 64)),
        "--normalization_mode",
        getattr(args, "normalization_mode", "group"),
        "--q_ood",
        str(getattr(args, "q_ood", 0.90)),
        "--epochs",
        str(getattr(args, "epochs", 10)),
        "--seed",
        str(seed),
    ]
    methods = str(getattr(args, "methods", "") or "").strip()
    if methods:
        cmd.extend(["--methods", methods])
    if bool(getattr(args, "skip_sklearn", False)):
        cmd.append("--skip_sklearn")
    if bool(getattr(args, "skip_neural", False)):
        cmd.append("--skip_neural")
    device = str(getattr(args, "device", "auto") or "").strip()
    if device:
        cmd.extend(["--device", device])
    if hasattr(args, "benign_label"):
        cmd.extend(["--benign_label", getattr(args, "benign_label")])
    if bool(getattr(args, "allow_ports", False)):
        cmd.append("--allow_ports")
    return cmd


def _ordered_methods_from_tables(table_paths: Sequence[Path]) -> list[str]:
    ordered: list[str] = []
    seen = set()
    for path in table_paths:
        frame = pd.read_csv(path)
        for method in frame["Method"].tolist():
            name = str(method)
            if name in seen:
                continue
            seen.add(name)
            ordered.append(name)
    return ordered


def _mean_std_text(values: Sequence[float]) -> str:
    arr = np.asarray(list(values), dtype=np.float64)
    if arr.size == 0:
        return ""
    mean = float(np.mean(arr))
    std = float(np.std(arr))
    return f"{mean:.4f} ± {std:.4f}"


def aggregate_mean_std_table(table_paths: Sequence[Path], columns: Sequence[str]) -> pd.DataFrame:
    if not table_paths:
        raise ValueError("No per-seed tables were available for aggregation.")
    ordered_methods = _ordered_methods_from_tables(table_paths)
    seed_frames = [pd.read_csv(path) for path in table_paths]
    rows: list[dict[str, str]] = []
    metric_columns = [column for column in columns if column != "Method"]
    for method in ordered_methods:
        row: dict[str, str] = {"Method": method}
        for column in metric_columns:
            collected: list[float] = []
            for frame in seed_frames:
                subset = frame.loc[frame["Method"] == method, column]
                if subset.empty:
                    continue
                numeric = pd.to_numeric(subset, errors="coerce").dropna().tolist()
                collected.extend(float(value) for value in numeric)
            row[column] = _mean_std_text(collected)
        rows.append(row)
    return pd.DataFrame(rows).reindex(columns=list(columns))


def _format_mean_std_tex_cell(value: Any, highlight: bool = False) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    if " ± " in text:
        mean, std = text.split(" ± ", 1)
        mean_text = latex_escape(mean)
        std_text = latex_escape(std)
        if highlight:
            return rf"\textbf{{{mean_text}}} $\pm$ \textbf{{{std_text}}}"
        return rf"{mean_text} $\pm$ {std_text}"
    escaped = latex_escape(text)
    if highlight:
        return rf"\textbf{{{escaped}}}"
    return escaped


def write_mean_std_outputs(frame: pd.DataFrame, output_csv: Path, output_tex: Path, caption: str) -> None:
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(output_csv, index=False)

    aligns = "l" + "c" * (len(frame.columns) - 1)
    lines = [
        r"\begin{table}[t]",
        r"\centering",
        rf"\caption{{{caption}}}",
        r"\begin{tabular}{" + aligns + "}",
        r"\toprule",
        " & ".join(latex_escape(str(column)) for column in frame.columns) + r" \\",
        r"\midrule",
    ]
    for row in frame.itertuples(index=False, name=None):
        highlight = str(row[0]) == "UCS-OODID"
        cells = [_format_mean_std_tex_cell(row[0], highlight=highlight)]
        cells.extend(_format_mean_std_tex_cell(value, highlight=highlight) for value in row[1:])
        lines.append(" & ".join(cells) + r" \\")
    lines.extend([r"\bottomrule", r"\end{tabular}", r"\end{table}"])
    output_tex.write_text("\n".join(lines) + "\n", encoding="utf-8")


def run_comparison_multiseed(
    args,
    runner: Callable[[Sequence[object]], Any] = run_subprocess,
) -> dict:
    output_root = Path(getattr(args, "output_root", "runs/comparison_experiments"))
    output_root.mkdir(parents=True, exist_ok=True)
    seeds = parse_seeds(getattr(args, "seeds", "1,2,3"))

    successful_seed_dirs: list[Path] = []
    failed_seeds: list[dict[str, Any]] = []
    for seed in seeds:
        seed_dir = output_root / f"seed_{seed}"
        seed_dir.mkdir(parents=True, exist_ok=True)
        cmd = build_seed_command(args, seed, seed_dir)
        try:
            result = runner(cmd)
        except Exception as exc:
            failed_seeds.append(
                {
                    "seed": seed,
                    "output_dir": str(seed_dir),
                    "return_code": None,
                    "stdout_tail": "",
                    "stderr_tail": f"{type(exc).__name__}: {exc}",
                }
            )
            continue
        if int(getattr(result, "returncode", 0)) != 0:
            failed_seeds.append(
                {
                    "seed": seed,
                    "output_dir": str(seed_dir),
                    "return_code": int(getattr(result, "returncode", 0)),
                    "stdout_tail": _tail_text(getattr(result, "stdout", "")),
                    "stderr_tail": _tail_text(getattr(result, "stderr", "")),
                }
            )
            continue
        known_csv = seed_dir / "known_detection_table.csv"
        ood_csv = seed_dir / "ood_detection_table.csv"
        if not known_csv.exists() or not ood_csv.exists():
            failed_seeds.append(
                {
                    "seed": seed,
                    "output_dir": str(seed_dir),
                    "return_code": 0,
                    "stdout_tail": _tail_text(getattr(result, "stdout", "")),
                    "stderr_tail": "known_detection_table.csv or ood_detection_table.csv was not produced.",
                }
            )
            continue
        successful_seed_dirs.append(seed_dir)

    if not successful_seed_dirs:
        raise ValueError("No successful seed runs produced comparison tables.")

    known_seed_tables = [seed_dir / "known_detection_table.csv" for seed_dir in successful_seed_dirs]
    ood_seed_tables = [seed_dir / "ood_detection_table.csv" for seed_dir in successful_seed_dirs]
    known_frame = aggregate_mean_std_table(known_seed_tables, KNOWN_COLUMNS)
    ood_frame = aggregate_mean_std_table(ood_seed_tables, OOD_COLUMNS)

    known_csv = output_root / "known_detection_table_mean_std.csv"
    known_tex = output_root / "known_detection_table_mean_std.tex"
    ood_csv = output_root / "ood_detection_table_mean_std.csv"
    ood_tex = output_root / "ood_detection_table_mean_std.tex"
    write_mean_std_outputs(known_frame, known_csv, known_tex, KNOWN_CAPTION)
    write_mean_std_outputs(ood_frame, ood_csv, ood_tex, OOD_CAPTION)

    return {
        "output_root": str(output_root),
        "seeds": seeds,
        "successful_seed_dirs": [str(path) for path in successful_seed_dirs],
        "failed_seeds": failed_seeds,
        "tables": {
            "known_detection_mean_std_csv": str(known_csv),
            "known_detection_mean_std_tex": str(known_tex),
            "ood_detection_mean_std_csv": str(ood_csv),
            "ood_detection_mean_std_tex": str(ood_tex),
        },
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run paper comparison experiments across multiple random seeds.")
    parser.add_argument("--input", required=True)
    parser.add_argument("--output_root", default="runs/comparison_experiments")
    parser.add_argument("--label_col", default="label")
    parser.add_argument("--timestamp_col", default="timestamp")
    parser.add_argument("--record_id_col", default="record_id")
    parser.add_argument("--group_col", default="uav_id")
    parser.add_argument("--id_classes", required=True)
    parser.add_argument("--ood_classes", required=True)
    parser.add_argument("--window_mode", default="count", choices=["count", "time", "adaptive"])
    parser.add_argument("--window_size", type=int, default=16)
    parser.add_argument("--stride", type=int, default=8)
    parser.add_argument("--time_window_seconds", type=float, default=2.0)
    parser.add_argument("--adaptive_min_size", type=int, default=8)
    parser.add_argument("--adaptive_max_size", type=int, default=64)
    parser.add_argument("--normalization_mode", default="group", choices=["global", "group"])
    parser.add_argument("--q_ood", type=float, default=0.90)
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--device", default="auto")
    parser.add_argument("--skip_sklearn", action="store_true")
    parser.add_argument("--skip_neural", action="store_true")
    parser.add_argument("--methods", default="", help="Optional comma-separated subset of methods to run.")
    parser.add_argument("--seeds", default="1,2,3")
    parser.add_argument("--benign_label", default="benign")
    parser.add_argument("--allow_ports", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    summary = run_comparison_multiseed(args)
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
