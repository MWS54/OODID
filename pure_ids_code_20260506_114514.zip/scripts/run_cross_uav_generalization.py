#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path
from typing import Sequence

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.prepare_multi_uav_hetero import (
    align_feature_union,
    attach_dataset_identity,
    build_non_feature_columns,
    candidate_feature_columns,
    grouped_value_counts,
    ordered_unique,
    require_columns,
    resolve_existing_path,
    resolve_output_path,
    value_counts_dict,
)
from ucs_oodid.io import load_json, load_records, save_json

DEFAULT_ID_CLASSES = "benign,icmp_flooding,udp_flooding,dos,ddos,bruteforce,mitm,deauthentication,jamming,recon_scanning"
DEFAULT_OOD_CLASSES = "replay,fake_landing,evil"


def run(cmd: Sequence[object]) -> None:
    print("RUN", " ".join(map(str, cmd)), flush=True)
    subprocess.run(list(map(str, cmd)), check=True)


def normalize_split_values(df: pd.DataFrame, split_col: str) -> pd.Series:
    if split_col not in df.columns:
        raise ValueError(f"Missing split column: {split_col}")
    return df[split_col].fillna("").astype(str).str.strip().str.lower()


def select_cross_uav_rows(
    source_df: pd.DataFrame,
    target_df: pd.DataFrame,
    split_col: str = "split",
) -> tuple[pd.DataFrame, pd.DataFrame, dict]:
    source_split = normalize_split_values(source_df, split_col)
    target_split = normalize_split_values(target_df, split_col)

    source_train = source_df[source_split == "train"].copy()
    if len(source_train) == 0:
        raise ValueError("source dataset must contain split == 'train'")

    source_val = source_df[source_split == "val"].copy()
    source_val_source = "val"
    if len(source_val) == 0:
        source_val = source_df[source_split == "test_id"].copy()
        source_val_source = "test_id_fallback"
    if len(source_val) == 0:
        raise ValueError("source dataset must contain split == 'val' or fallback split == 'test_id'")

    target_test_id = target_df[target_split == "test_id"].copy()
    target_test_ood = target_df[target_split == "test_ood"].copy()
    if len(target_test_id) == 0:
        raise ValueError("target dataset must contain split == 'test_id'")
    if len(target_test_ood) == 0:
        raise ValueError("target dataset must contain split == 'test_ood'")

    source_selected = pd.concat(
        [
            source_train.assign(**{split_col: "train"}),
            source_val.assign(**{split_col: "val"}),
        ],
        ignore_index=True,
    )
    target_selected = pd.concat(
        [
            target_test_id.assign(**{split_col: "test_id"}),
            target_test_ood.assign(**{split_col: "test_ood"}),
        ],
        ignore_index=True,
    )
    split_summary = {
        "source_train": int(len(source_train)),
        "source_val": int(len(source_val)),
        "source_val_source": source_val_source,
        "target_test_id": int(len(target_test_id)),
        "target_test_ood": int(len(target_test_ood)),
    }
    return source_selected, target_selected, split_summary


def merge_cross_uav_frames(
    source_df: pd.DataFrame,
    target_df: pd.DataFrame,
    source_uav_id: str = "uav_source",
    target_uav_id: str = "uav_target",
    label_col: str = "label",
    split_col: str = "split",
    timestamp_col: str = "timestamp",
    record_id_col: str = "record_id",
) -> tuple[pd.DataFrame, dict]:
    require_columns(source_df, [label_col, split_col], "source")
    require_columns(target_df, [label_col, split_col], "target")

    selected_source, selected_target, split_summary = select_cross_uav_rows(
        source_df,
        target_df,
        split_col=split_col,
    )

    non_feature_columns = build_non_feature_columns(label_col, split_col, timestamp_col, record_id_col)
    source_features = candidate_feature_columns(source_df, non_feature_columns)
    target_features = candidate_feature_columns(target_df, non_feature_columns)
    feature_union = ordered_unique(source_features + target_features)
    if not feature_union:
        raise ValueError("No numeric feature columns were found across source and target UAV CSV files.")

    source_ready = attach_dataset_identity(
        selected_source,
        uav_id=source_uav_id,
        dataset_name="source",
        record_id_col=record_id_col,
    )
    target_ready = attach_dataset_identity(
        selected_target,
        uav_id=target_uav_id,
        dataset_name="target",
        record_id_col=record_id_col,
    )

    source_aligned, source_missing = align_feature_union(source_ready, feature_union)
    target_aligned, target_missing = align_feature_union(target_ready, feature_union)

    merged = pd.concat([source_aligned, target_aligned], ignore_index=True)
    metadata_columns = ordered_unique(
        [
            label_col,
            "source_label",
            "recommended_partition",
            split_col,
            timestamp_col,
            record_id_col,
            "uav_id",
            "dataset_name",
        ]
    )
    output_columns = list(feature_union) + [column for column in metadata_columns if column in merged.columns]
    merged = merged.loc[:, output_columns]
    if record_id_col in merged.columns and merged[record_id_col].astype(str).duplicated().any():
        raise ValueError("record_id values are not unique after source/target prefixing.")

    summary = {
        "source_uav": str(source_uav_id),
        "target_uav": str(target_uav_id),
        "source_rows": int(len(source_df)),
        "target_rows": int(len(target_df)),
        "used_rows": split_summary,
        "feature_count": int(len(feature_union)),
        "feature_columns": list(feature_union),
        "missing_features_filled": {
            "source": list(source_missing),
            "target": list(target_missing),
        },
        "split_distribution_by_uav": grouped_value_counts(merged, "uav_id", split_col),
        "label_distribution_by_uav": grouped_value_counts(merged, "uav_id", label_col),
        "global_split_distribution": value_counts_dict(merged, split_col),
        "global_label_distribution": value_counts_dict(merged, label_col),
    }
    return merged, summary


def build_train_command(args, aligned_path: Path, train_dir: Path) -> list[object]:
    train_py = Path(__file__).with_name("train.py")
    cmd: list[object] = [
        sys.executable,
        train_py,
        "--input",
        aligned_path,
        "--output_dir",
        train_dir,
        "--label_col",
        args.label_col,
        "--timestamp_col",
        args.timestamp_col,
        "--record_id_col",
        args.record_id_col,
        "--group_col",
        "uav_id",
        "--id_classes",
        args.id_classes,
        "--ood_classes",
        args.ood_classes,
        "--window_mode",
        args.window_mode,
        "--window_size",
        str(args.window_size),
        "--stride",
        str(args.stride),
        "--epochs",
        str(args.epochs),
        "--normalization_mode",
        args.normalization_mode,
        "--ood_threshold_mode",
        args.ood_threshold_mode,
        "--present_class_min_support",
        str(getattr(args, "present_class_min_support", 1)),
    ]
    if args.device and str(args.device).strip().lower() != "auto":
        cmd.extend(["--device", args.device])
    return cmd


def build_detect_command(args, target_eval_path: Path, artifact_path: Path, train_dir: Path) -> list[object]:
    detect_py = Path(__file__).with_name("detect.py")
    cmd: list[object] = [
        sys.executable,
        detect_py,
        "--input",
        target_eval_path,
        "--artifact",
        artifact_path,
        "--output_jsonl",
        train_dir / "detections.jsonl",
        "--record_scores_json",
        train_dir / "record_scores.json",
        "--summary_json",
        train_dir / "group_detection_summary.json",
        "--group_col",
        "uav_id",
        "--label_col",
        args.label_col,
        "--timestamp_col",
        args.timestamp_col,
        "--record_id_col",
        args.record_id_col,
        "--present_class_min_support",
        str(getattr(args, "present_class_min_support", 1)),
    ]
    if args.device and str(args.device).strip().lower() != "auto":
        cmd.extend(["--device", args.device])
    return cmd


def build_cross_uav_summary(
    source_uav: str,
    target_uav: str,
    dataset_summary: dict,
    eval_report: dict,
    group_detection_summary: dict,
) -> dict:
    return {
        "source_uav": str(source_uav),
        "target_uav": str(target_uav),
        "source_rows": int(dataset_summary.get("source_rows", 0)),
        "target_rows": int(dataset_summary.get("target_rows", 0)),
        "used_rows": dict(dataset_summary.get("used_rows", {})),
        "target_id_metrics": dict(eval_report.get("id_test", {})),
        "target_ood_metrics": dict(eval_report.get("ood_test", {})),
        "target_group_metrics": {
            "id_test": dict(eval_report.get("id_test_by_group", {}).get(str(target_uav), {})),
            "ood_test": dict(eval_report.get("ood_test_by_group", {}).get(str(target_uav), {})),
            "detection_summary": dict(group_detection_summary.get("groups", {}).get(str(target_uav), {})),
        },
    }


def save_cross_uav_summary(
    output_path: Path,
    source_uav: str,
    target_uav: str,
    dataset_summary: dict,
    eval_report: dict,
    group_detection_summary: dict,
) -> dict:
    summary = build_cross_uav_summary(
        source_uav=source_uav,
        target_uav=target_uav,
        dataset_summary=dataset_summary,
        eval_report=eval_report,
        group_detection_summary=group_detection_summary,
    )
    save_json(summary, output_path)
    return summary


def run_cross_uav_generalization(args) -> dict:
    script_dir = Path(__file__).resolve().parent
    project_root = script_dir.parent
    workspace_root = project_root.parent
    base_candidates = [script_dir, project_root, workspace_root]

    source_path = resolve_existing_path(base_candidates, args.source_csv)
    target_path = resolve_existing_path(base_candidates, args.target_csv)
    output_dir = resolve_output_path(project_root, args.output_dir)
    if output_dir is None:
        raise ValueError("output_dir must be provided")
    output_dir.mkdir(parents=True, exist_ok=True)

    source_df = load_records(source_path)
    target_df = load_records(target_path)
    aligned_df, dataset_summary = merge_cross_uav_frames(
        source_df,
        target_df,
        source_uav_id=args.source_uav_id,
        target_uav_id=args.target_uav_id,
        label_col=args.label_col,
        split_col="split",
        timestamp_col=args.timestamp_col,
        record_id_col=args.record_id_col,
    )

    aligned_path = output_dir / "aligned_cross_uav_dataset.csv"
    aligned_df.to_csv(aligned_path, index=False)
    target_eval_path = output_dir / "target_eval_dataset.csv"
    aligned_df[aligned_df["split"].isin(["test_id", "test_ood"])].to_csv(target_eval_path, index=False)

    config = {
        "source_csv": str(source_path),
        "target_csv": str(target_path),
        "source_uav_id": str(args.source_uav_id),
        "target_uav_id": str(args.target_uav_id),
        "output_dir": str(output_dir),
        "aligned_cross_uav_dataset": str(aligned_path),
        "target_eval_dataset": str(target_eval_path),
        "label_col": args.label_col,
        "timestamp_col": args.timestamp_col,
        "record_id_col": args.record_id_col,
        "id_classes": args.id_classes,
        "ood_classes": args.ood_classes,
        "window_mode": args.window_mode,
        "window_size": int(args.window_size),
        "stride": int(args.stride),
        "epochs": int(args.epochs),
        "present_class_min_support": int(getattr(args, "present_class_min_support", 1)),
        "device": args.device,
        "normalization_mode": args.normalization_mode,
        "ood_threshold_mode": args.ood_threshold_mode,
        "dataset_summary": dataset_summary,
    }
    save_json(config, output_dir / "cross_uav_config.json")

    train_dir = output_dir / "train"
    run(build_train_command(args, aligned_path=aligned_path, train_dir=train_dir))
    run(build_detect_command(args, target_eval_path=target_eval_path, artifact_path=train_dir / "artifact.pt", train_dir=train_dir))

    eval_report = load_json(train_dir / "eval_report.json")
    group_detection_summary = load_json(train_dir / "group_detection_summary.json")
    summary = save_cross_uav_summary(
        output_path=output_dir / "cross_uav_summary.json",
        source_uav=args.source_uav_id,
        target_uav=args.target_uav_id,
        dataset_summary=dataset_summary,
        eval_report=eval_report,
        group_detection_summary=group_detection_summary,
    )
    print(json.dumps(summary, indent=2, ensure_ascii=False))
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description="Train on one UAV and directly test on another UAV to measure cross-UAV generalization.")
    parser.add_argument("--source_csv", required=True, help="Prepared CSV for the source UAV.")
    parser.add_argument("--target_csv", required=True, help="Prepared CSV for the target UAV.")
    parser.add_argument("--source_uav_id", default="uav_source")
    parser.add_argument("--target_uav_id", default="uav_target")
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--label_col", default="label")
    parser.add_argument("--timestamp_col", default="timestamp")
    parser.add_argument("--record_id_col", default="record_id")
    parser.add_argument("--id_classes", default=DEFAULT_ID_CLASSES)
    parser.add_argument("--ood_classes", default=DEFAULT_OOD_CLASSES)
    parser.add_argument("--window_mode", default="count", choices=["count", "time", "adaptive"])
    parser.add_argument("--window_size", type=int, default=16)
    parser.add_argument("--stride", type=int, default=8)
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--present_class_min_support", type=int, default=1)
    parser.add_argument("--device", default="auto")
    parser.add_argument("--normalization_mode", default="global", choices=["global", "group"])
    parser.add_argument("--ood_threshold_mode", default="global", choices=["global", "group"])
    args = parser.parse_args()
    run_cross_uav_generalization(args)


if __name__ == "__main__":
    main()
