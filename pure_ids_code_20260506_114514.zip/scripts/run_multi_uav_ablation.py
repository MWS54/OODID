#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import math
import subprocess
import sys
from pathlib import Path
from typing import Callable, Sequence

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ucs_oodid.io import load_json, save_json

DEFAULT_GROUP_THRESHOLD_CONFIG = {
    "group_threshold_strategy": "raw",
    "group_threshold_shrink_k": 1000.0,
    "group_threshold_min_ratio": 1.0,
    "group_threshold_min_samples": 10,
}


def with_group_threshold_defaults(config: dict) -> dict:
    merged = dict(DEFAULT_GROUP_THRESHOLD_CONFIG)
    merged.update(config)
    return merged


ABLATION_CONFIGS = [
    with_group_threshold_defaults({
        "experiment_name": "base",
        "normalization_mode": "global",
        "ood_threshold_mode": "global",
        "use_group_embedding": False,
    }),
    with_group_threshold_defaults({
        "experiment_name": "group_threshold",
        "normalization_mode": "global",
        "ood_threshold_mode": "group",
        "use_group_embedding": False,
    }),
    with_group_threshold_defaults({
        "experiment_name": "group_threshold_conservative",
        "normalization_mode": "global",
        "ood_threshold_mode": "group",
        "group_threshold_strategy": "conservative",
        "group_threshold_min_ratio": 1.0,
        "use_group_embedding": False,
    }),
    with_group_threshold_defaults({
        "experiment_name": "group_norm",
        "normalization_mode": "group",
        "ood_threshold_mode": "global",
        "use_group_embedding": False,
    }),
    with_group_threshold_defaults({
        "experiment_name": "group_norm_group_threshold",
        "normalization_mode": "group",
        "ood_threshold_mode": "group",
        "use_group_embedding": False,
    }),
    with_group_threshold_defaults({
        "experiment_name": "group_embedding",
        "normalization_mode": "global",
        "ood_threshold_mode": "global",
        "use_group_embedding": True,
    }),
    with_group_threshold_defaults({
        "experiment_name": "full",
        "normalization_mode": "group",
        "ood_threshold_mode": "group",
        "use_group_embedding": True,
    }),
    with_group_threshold_defaults({
        "experiment_name": "full_conservative",
        "normalization_mode": "group",
        "ood_threshold_mode": "group",
        "group_threshold_strategy": "conservative",
        "group_threshold_min_ratio": 1.0,
        "use_group_embedding": True,
    }),
]


def run(cmd: Sequence[object]) -> None:
    print("RUN", " ".join(map(str, cmd)), flush=True)
    subprocess.run(list(map(str, cmd)), check=True)


def build_train_command(args, config: dict, output_dir: Path) -> list[object]:
    train_py = Path(__file__).with_name("train.py")
    cmd: list[object] = [
        sys.executable,
        train_py,
        "--input",
        args.input,
        "--output_dir",
        output_dir,
        "--label_col",
        args.label_col,
        "--timestamp_col",
        args.timestamp_col,
        "--record_id_col",
        args.record_id_col,
        "--group_col",
        args.group_col,
        "--id_classes",
        args.id_classes,
        "--ood_classes",
        args.ood_classes,
        "--window_mode",
        args.window_mode,
        "--window_size",
        str(args.window_size),
        "--stride",
        str(args.stride),
        "--epochs",
        str(args.epochs),
        "--normalization_mode",
        config["normalization_mode"],
        "--ood_threshold_mode",
        config["ood_threshold_mode"],
        "--group_threshold_strategy",
        config["group_threshold_strategy"],
        "--group_threshold_shrink_k",
        str(config["group_threshold_shrink_k"]),
        "--group_threshold_min_ratio",
        str(config["group_threshold_min_ratio"]),
        "--group_threshold_min_samples",
        str(config["group_threshold_min_samples"]),
        "--present_class_min_support",
        str(getattr(args, "present_class_min_support", 1)),
    ]
    if config["use_group_embedding"]:
        cmd.append("--use_group_embedding")
    if args.device and str(args.device).strip().lower() != "auto":
        cmd.extend(["--device", args.device])
    return cmd


def build_detect_command(args, output_dir: Path) -> list[object]:
    detect_py = Path(__file__).with_name("detect.py")
    cmd: list[object] = [
        sys.executable,
        detect_py,
        "--input",
        args.input,
        "--artifact",
        output_dir / "artifact.pt",
        "--output_jsonl",
        output_dir / "detections.jsonl",
        "--record_scores_json",
        output_dir / "record_scores.json",
        "--summary_json",
        output_dir / "group_detection_summary.json",
        "--group_col",
        args.group_col,
        "--label_col",
        args.label_col,
        "--timestamp_col",
        args.timestamp_col,
        "--record_id_col",
        args.record_id_col,
        "--present_class_min_support",
        str(getattr(args, "present_class_min_support", 1)),
    ]
    if args.device and str(args.device).strip().lower() != "auto":
        cmd.extend(["--device", args.device])
    return cmd


def safe_load_json(path: Path) -> dict:
    if not path.exists():
        return {}
    return load_json(path)


def clear_known_outputs(output_dir: Path) -> None:
    for filename in [
        "artifact.pt",
        "eval_report.json",
        "leakage_report.json",
        "detections.jsonl",
        "record_scores.json",
        "group_detection_summary.json",
    ]:
        path = output_dir / filename
        if path.exists():
            path.unlink()


def _group_metric(payload: dict, group: str, metric: str):
    return payload.get(group, {}).get(metric)


def _valid_group_metric_values(payload: dict, metric: str) -> list[float]:
    values = []
    for item in payload.values():
        value = item.get(metric)
        if value is None:
            continue
        try:
            value = float(value)
        except (TypeError, ValueError):
            continue
        if math.isnan(value):
            continue
        values.append(value)
    return values


def _sorted_group_names(*payloads: dict) -> list[str]:
    groups: set[str] = set()
    for payload in payloads:
        for group in payload:
            name = str(group).strip()
            if name:
                groups.add(name)
    return sorted(groups)


def _mean_or_none(values: list[float]) -> float | None:
    if not values:
        return None
    return float(sum(values) / len(values))


def build_ablation_summary_row(
    config: dict,
    eval_report: dict | None = None,
    group_detection_summary: dict | None = None,
    status: str = "success",
    error_message: str | None = None,
) -> dict:
    eval_report = eval_report or {}
    group_detection_summary = group_detection_summary or {}
    id_test = eval_report.get("id_test", {})
    ood_test = eval_report.get("ood_test", {})
    id_test_by_group = eval_report.get("id_test_by_group", {})
    ood_test_by_group = eval_report.get("ood_test_by_group", {})
    group_detection_groups = group_detection_summary.get("groups", {})
    group_detection_global = group_detection_summary.get("global", {})
    group_names = _sorted_group_names(id_test_by_group, ood_test_by_group, group_detection_groups)
    id_group_micro_f1_values = _valid_group_metric_values(id_test_by_group, "micro_f1")
    ood_group_f1_values = _valid_group_metric_values(ood_test_by_group, "ood_f1")
    alert_rate_values = _valid_group_metric_values(group_detection_groups, "alert_rate")
    row = {
        "experiment_name": config["experiment_name"],
        "normalization_mode": config["normalization_mode"],
        "ood_threshold_mode": config["ood_threshold_mode"],
        "group_threshold_strategy": config["group_threshold_strategy"],
        "group_threshold_min_ratio": config["group_threshold_min_ratio"],
        "group_threshold_shrink_k": config["group_threshold_shrink_k"],
        "group_threshold_min_samples": config["group_threshold_min_samples"],
        "use_group_embedding": bool(config["use_group_embedding"]),
        "id_micro_f1": id_test.get("micro_f1"),
        "id_macro_f1": id_test.get("macro_f1"),
        "id_mAP": id_test.get("mAP"),
        "ood_auroc": ood_test.get("auroc"),
        "ood_aupr_out": ood_test.get("aupr_out"),
        "ood_fpr95": ood_test.get("fpr95"),
        "ood_f1": ood_test.get("ood_f1"),
        "uav_count": len(group_names),
        "group_names": ",".join(group_names),
        "macro_uav_id_micro_f1": _mean_or_none(id_group_micro_f1_values),
        "macro_uav_ood_f1": _mean_or_none(ood_group_f1_values),
        "worst_uav_ood_f1": min(ood_group_f1_values) if ood_group_f1_values else None,
        "global_alert_rate": group_detection_global.get("alert_rate"),
        "macro_uav_alert_rate": _mean_or_none(alert_rate_values),
        "status": status,
        "error_message": error_message,
    }
    for group in group_names:
        row[f"{group}_id_micro_f1"] = _group_metric(id_test_by_group, group, "micro_f1")
        row[f"{group}_ood_auroc"] = _group_metric(ood_test_by_group, group, "auroc")
        row[f"{group}_ood_f1"] = _group_metric(ood_test_by_group, group, "ood_f1")
        row[f"{group}_alert_rate"] = _group_metric(group_detection_groups, group, "alert_rate")
    return row


def run_single_ablation(args, config: dict, runner: Callable[[Sequence[object]], None] = run) -> dict:
    output_dir = Path(args.output_root) / config["experiment_name"]
    output_dir.mkdir(parents=True, exist_ok=True)
    clear_known_outputs(output_dir)
    status = "success"
    error_message = None
    try:
        runner(build_train_command(args, config=config, output_dir=output_dir))
        if (output_dir / "artifact.pt").exists():
            runner(build_detect_command(args, output_dir=output_dir))
        else:
            raise FileNotFoundError(f"artifact.pt was not produced for {config['experiment_name']}")
    except Exception as exc:
        status = "failed"
        error_message = f"{type(exc).__name__}: {exc}"

    eval_report = safe_load_json(output_dir / "eval_report.json")
    group_detection_summary = safe_load_json(output_dir / "group_detection_summary.json")
    row = build_ablation_summary_row(
        config=config,
        eval_report=eval_report,
        group_detection_summary=group_detection_summary,
        status=status,
        error_message=error_message,
    )
    row["output_dir"] = str(output_dir)
    return row


def write_ablation_summaries(rows: list[dict], output_root: Path, args) -> dict:
    output_root.mkdir(parents=True, exist_ok=True)
    df = pd.DataFrame(rows)
    csv_path = output_root / "ablation_summary.csv"
    json_path = output_root / "ablation_summary.json"
    df.to_csv(csv_path, index=False)
    failed = [row["experiment_name"] for row in rows if row.get("status") == "failed"]
    payload = {
        "input": str(args.input),
        "group_col": args.group_col,
        "window_mode": args.window_mode,
        "window_size": int(args.window_size),
        "stride": int(args.stride),
        "epochs": int(args.epochs),
        "device": args.device,
        "experiments": rows,
        "failed_experiments": failed,
    }
    save_json(payload, json_path)
    return payload


def run_multi_uav_ablation(args, runner: Callable[[Sequence[object]], None] = run) -> dict:
    rows = []
    for config in ABLATION_CONFIGS:
        rows.append(run_single_ablation(args, config=config, runner=runner))
    return write_ablation_summaries(rows, Path(args.output_root), args)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run multi-UAV heterogeneous ablations and summarize the results.")
    parser.add_argument("--input", required=True)
    parser.add_argument("--output_root", required=True)
    parser.add_argument("--id_classes", required=True)
    parser.add_argument("--ood_classes", required=True)
    parser.add_argument("--group_col", default="uav_id")
    parser.add_argument("--label_col", default="label")
    parser.add_argument("--timestamp_col", default="timestamp")
    parser.add_argument("--record_id_col", default="record_id")
    parser.add_argument("--window_mode", default="count", choices=["count", "time", "adaptive"])
    parser.add_argument("--window_size", type=int, default=16)
    parser.add_argument("--stride", type=int, default=8)
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--present_class_min_support", type=int, default=1)
    parser.add_argument("--device", default="auto")
    args = parser.parse_args()
    summary = run_multi_uav_ablation(args)
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
