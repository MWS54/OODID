#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import numpy as np

from ucs_oodid.baselines import (
    OptionalDependencyUnavailable,
    apply_threshold,
    calibrate_binary_threshold_from_id_scores,
    compute_baseline_uncertainty_scores,
    fit_isolation_forest_ood,
    flatten_windows,
    isolation_forest_scores,
    make_baseline,
)
from ucs_oodid.experiment_utils import PreparedWindowDataset, prepare_window_dataset
from ucs_oodid.io import save_json
from ucs_oodid.metrics import multilabel_metrics, ood_metrics
from ucs_oodid.ood import calibrate_class_thresholds
from ucs_oodid.utils import ensure_dir, set_seed

BASELINE_ORDER = ("svm", "random_forest", "xgboost", "mlp")
DEFAULT_OOD_SCORE_BY_BASELINE = {
    "svm": "uncertainty",
    "random_forest": "uncertainty",
    "xgboost": "uncertainty",
    "mlp": "energy",
}


def _ensure_prob_matrix(probs: np.ndarray) -> np.ndarray:
    arr = np.asarray(probs, dtype=np.float32)
    if arr.ndim == 1:
        return arr[:, None].astype(np.float32)
    if arr.ndim != 2:
        raise ValueError(f"Expected probability matrix with 1 or 2 dimensions, got shape {arr.shape}")
    return arr.astype(np.float32)


def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Train sklearn/tabular baselines for UCS-OODID windowed metadata.")
    p.add_argument("--input", required=True)
    p.add_argument("--output_dir", required=True)
    p.add_argument("--label_col", default="label")
    p.add_argument("--timestamp_col", default="timestamp")
    p.add_argument("--record_id_col", default="record_id")
    p.add_argument("--group_col", default="")
    p.add_argument("--id_classes", default="", help="Comma-separated ID classes. If omitted, all labels except --ood_classes are ID.")
    p.add_argument("--ood_classes", default="", help="Comma-separated OOD classes used only for testing.")
    p.add_argument("--benign_label", default="benign")
    p.add_argument("--allow_ports", action="store_true")
    p.add_argument("--window_mode", choices=["count", "time", "adaptive"], default="count")
    p.add_argument("--window_size", type=int, default=16)
    p.add_argument("--stride", type=int, default=8)
    p.add_argument("--time_window_seconds", type=float, default=2.0)
    p.add_argument("--adaptive_min_size", type=int, default=8)
    p.add_argument("--adaptive_max_size", type=int, default=64)
    p.add_argument("--normalization_mode", default="global", choices=["global", "group"])
    p.add_argument("--baseline", default="all", choices=[*BASELINE_ORDER, "all"])
    p.add_argument("--q_ood", type=float, default=0.90)
    p.add_argument("--seed", type=int, default=42)
    return p


def _resolve_requested_baselines(name: str) -> list[str]:
    key = str(name).strip().lower()
    if key == "all":
        return list(BASELINE_ORDER)
    if key not in BASELINE_ORDER:
        raise ValueError(f"Unsupported baseline: {name}")
    return [key]


def _compute_iforest_score_splits(bundle: PreparedWindowDataset, random_state: int) -> dict[str, np.ndarray]:
    train_w = bundle.split_windows["train"]
    val_w = bundle.split_windows["val"]
    test_id_w = bundle.split_windows["test_id"]
    test_ood_w = bundle.split_windows["test_ood"]
    model = fit_isolation_forest_ood(flatten_windows(train_w.x), random_state=random_state)
    return {
        "val": isolation_forest_scores(model, flatten_windows(val_w.x)),
        "test_id": isolation_forest_scores(model, flatten_windows(test_id_w.x)),
        "test_ood": isolation_forest_scores(model, flatten_windows(test_ood_w.x)),
    }


def _compute_probability_score_splits(
    val_probs: np.ndarray,
    test_id_probs: np.ndarray,
    test_ood_probs: np.ndarray,
) -> dict[str, dict[str, np.ndarray]]:
    val_scores = compute_baseline_uncertainty_scores(val_probs)
    test_id_scores = compute_baseline_uncertainty_scores(test_id_probs)
    test_ood_scores = compute_baseline_uncertainty_scores(test_ood_probs)
    return {
        "uncertainty": {
            "val": val_scores["conf"],
            "test_id": test_id_scores["conf"],
            "test_ood": test_ood_scores["conf"],
        },
        "energy": {
            "val": val_scores["energy"],
            "test_id": test_id_scores["energy"],
            "test_ood": test_ood_scores["energy"],
        },
    }


def _evaluate_ood_from_scores(
    score_name: str,
    score_splits: dict[str, dict[str, np.ndarray]],
    q_ood: float,
) -> tuple[dict, float]:
    selected = score_splits[score_name]
    val_scores = np.asarray(selected["val"], dtype=np.float32)
    test_id_scores = np.asarray(selected["test_id"], dtype=np.float32)
    test_ood_scores = np.asarray(selected["test_ood"], dtype=np.float32)
    threshold = calibrate_binary_threshold_from_id_scores(val_scores, q=q_ood)
    combo_scores = np.concatenate([test_id_scores, test_ood_scores], axis=0)
    y_true_ood = np.concatenate(
        [np.zeros(len(test_id_scores), dtype=np.int64), np.ones(len(test_ood_scores), dtype=np.int64)],
        axis=0,
    )
    decisions = apply_threshold(combo_scores, threshold)
    metrics = ood_metrics(y_true_ood, combo_scores, decisions.astype(int))
    false_positives = int(np.sum(decisions[: len(test_id_scores)]))
    metrics["fpr_at_threshold"] = float(false_positives / max(len(test_id_scores), 1))
    return metrics, float(threshold)


def run_single_baseline(
    bundle: PreparedWindowDataset,
    args,
    baseline_name: str,
    iforest_score_splits: dict[str, np.ndarray],
) -> dict:
    baseline = make_baseline(baseline_name, random_state=args.seed)
    train_w = bundle.split_windows["train"]
    val_w = bundle.split_windows["val"]
    test_id_w = bundle.split_windows["test_id"]
    test_ood_w = bundle.split_windows["test_ood"]

    baseline.fit(train_w.x, train_w.y)

    val_probs = _ensure_prob_matrix(baseline.predict_proba(val_w.x))
    test_id_probs = _ensure_prob_matrix(baseline.predict_proba(test_id_w.x))
    test_ood_probs = _ensure_prob_matrix(baseline.predict_proba(test_ood_w.x))

    class_thresholds = calibrate_class_thresholds(val_probs, val_w.y)
    id_test = multilabel_metrics(test_id_w.y, test_id_probs, class_thresholds)

    score_splits = _compute_probability_score_splits(val_probs, test_id_probs, test_ood_probs)
    score_splits["iforest"] = {
        "val": np.asarray(iforest_score_splits["val"], dtype=np.float32),
        "test_id": np.asarray(iforest_score_splits["test_id"], dtype=np.float32),
        "test_ood": np.asarray(iforest_score_splits["test_ood"], dtype=np.float32),
    }
    ood_score_name = DEFAULT_OOD_SCORE_BY_BASELINE[baseline_name]
    ood_test, ood_threshold = _evaluate_ood_from_scores(ood_score_name, score_splits, q_ood=args.q_ood)

    return {
        "status": "success",
        "method": baseline_name,
        "baseline_name": baseline.name,
        "id_test": id_test,
        "ood_test": ood_test,
        "class_thresholds": np.asarray(class_thresholds, dtype=np.float32).tolist(),
        "ood_threshold": float(ood_threshold),
        "ood_score_name": ood_score_name,
        "available_ood_scores": ["uncertainty", "energy", "iforest"],
        "window_counts": bundle.window_counts(),
        "split_source": bundle.split_source,
        "id_classes": list(bundle.id_classes),
        "ood_classes": list(bundle.ood_classes),
        "feature_cols": list(bundle.preprocessor.feature_cols),
        "normalization": bundle.normalization_summary,
    }


def run_selected_baselines(args) -> dict:
    set_seed(args.seed)
    output_dir = ensure_dir(args.output_dir)
    bundle = prepare_window_dataset(args, require_test_ood=True)
    iforest_score_splits = _compute_iforest_score_splits(bundle, random_state=args.seed)
    requested = _resolve_requested_baselines(args.baseline)

    results = {}
    skipped = []
    for baseline_name in requested:
        baseline_dir = ensure_dir(output_dir / baseline_name)
        try:
            report = run_single_baseline(bundle, args, baseline_name, iforest_score_splits)
        except OptionalDependencyUnavailable as exc:
            if str(args.baseline).strip().lower() != "all":
                raise
            reason = str(exc)
            skipped.append({"baseline": baseline_name, "reason": reason})
            print(json.dumps({"baseline": baseline_name, "status": "skipped", "reason": reason}, ensure_ascii=False))
            continue

        save_json(report, baseline_dir / "eval_report.json")
        results[baseline_name] = report
        print(
            json.dumps(
                {
                    "baseline": baseline_name,
                    "status": "success",
                    "id_micro_f1": report["id_test"]["micro_f1"],
                    "ood_auroc": report["ood_test"]["auroc"],
                    "ood_score_name": report["ood_score_name"],
                },
                ensure_ascii=False,
            )
        )

    skipped_path = output_dir / "skipped_baselines.json"
    if skipped:
        save_json(skipped, skipped_path)
    elif skipped_path.exists():
        skipped_path.unlink()

    summary = {
        "requested_baselines": requested,
        "successful_baselines": list(results.keys()),
        "skipped_baselines": skipped,
        "split_source": bundle.split_source,
        "window_counts": bundle.window_counts(),
        "results": results,
    }
    save_json(summary, output_dir / "sklearn_baseline_summary.json")
    return summary


def main() -> None:
    args = build_arg_parser().parse_args()
    summary = run_selected_baselines(args)
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
