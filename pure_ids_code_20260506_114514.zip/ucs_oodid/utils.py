from __future__ import annotations

import os
import random
from pathlib import Path
from typing import Iterable, List, Sequence

import numpy as np


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    try:
        import torch
        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = False
        torch.backends.cudnn.benchmark = True
    except Exception:
        pass


def parse_csv_list(value: str | None) -> List[str]:
    if value is None or value == "":
        return []
    return [x.strip() for x in value.split(",") if x.strip()]


def parse_label_cell(value) -> List[str]:
    if value is None:
        return []
    if isinstance(value, float) and np.isnan(value):
        return []
    if isinstance(value, (list, tuple, set)):
        return [str(x) for x in value]
    text = str(value)
    for sep in [";", "|", ","]:
        if sep in text:
            return [x.strip() for x in text.split(sep) if x.strip()]
    return [text.strip()] if text.strip() else []


def make_class_mapping(labels: Iterable[str]) -> dict[str, int]:
    return {name: idx for idx, name in enumerate(sorted(set(labels)))}


def ensure_dir(path: str | Path) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def safe_float(x, default=0.0):
    try:
        v = float(x)
        if np.isnan(v) or np.isinf(v):
            return default
        return v
    except Exception:
        return default


def choose_device(device: str | None = None) -> str:
    if device:
        return device
    try:
        import torch
        return "cuda" if torch.cuda.is_available() else "cpu"
    except Exception:
        return "cpu"
