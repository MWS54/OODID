#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ucs_oodid.io import load_records
from ucs_oodid.windowing import attach_parsed_labels, infer_all_labels


def run(cmd):
    print("RUN", " ".join(map(str, cmd)), flush=True)
    subprocess.run(list(map(str, cmd)), check=True)


def main():
    p = argparse.ArgumentParser(description="RQ2/RQ5 cross-dataset unknown protocol: train on source ID data and run OOD detection on target dataset.")
    p.add_argument("--source", required=True)
    p.add_argument("--target", required=True)
    p.add_argument("--output_dir", required=True)
    p.add_argument("--source_label_col", default="label")
    p.add_argument("--target_label_col", default="label")
    p.add_argument("--id_classes", default="", help="Comma-separated source ID classes. If empty, all source labels are ID.")
    p.add_argument("--train_args", default="")
    p.add_argument("--present_class_min_support", type=int, default=1)
    args = p.parse_args()
    out = Path(args.output_dir); out.mkdir(parents=True, exist_ok=True)
    src_df = attach_parsed_labels(load_records(args.source), args.source_label_col)
    id_classes = [x.strip() for x in args.id_classes.split(',') if x.strip()] or infer_all_labels(src_df, args.source_label_col)
    train_py = Path(__file__).with_name("train.py")
    detect_py = Path(__file__).with_name("detect.py")
    offline_py = Path(__file__).with_name("offline_triage.py")
    train_dir = out / "source_train"
    cmd = [
        sys.executable,
        train_py,
        "--input",
        args.source,
        "--output_dir",
        train_dir,
        "--label_col",
        args.source_label_col,
        "--id_classes",
        ",".join(id_classes),
        "--present_class_min_support",
        args.present_class_min_support,
    ]
    if args.train_args:
        cmd += args.train_args.split()
    run(cmd)
    run(
        [
            sys.executable,
            detect_py,
            "--input",
            args.target,
            "--artifact",
            train_dir / "artifact.pt",
            "--output_jsonl",
            out / "target_detections.jsonl",
            "--record_scores_json",
            out / "target_record_scores.json",
            "--label_col",
            args.target_label_col,
            "--present_class_min_support",
            args.present_class_min_support,
        ]
    )
    run([sys.executable, offline_py, "--detections", out / "target_detections.jsonl", "--output_dir", out / "offline_triage"])
    manifest = {"source": args.source, "target": args.target, "id_classes": id_classes, "artifact": str(train_dir / "artifact.pt"), "detections": str(out / "target_detections.jsonl")}
    (out / "cross_dataset_manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(manifest, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()
