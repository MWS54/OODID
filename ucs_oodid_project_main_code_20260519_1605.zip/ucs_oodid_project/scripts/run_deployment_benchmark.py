#!/usr/bin/env python3
"""Normalized deployment benchmark wrapper around benchmark_onboard.py."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Run benchmark_onboard with unified output schema.")
    p.add_argument("--method", required=True)
    p.add_argument("--artifact", required=True)
    p.add_argument("--input", required=True, help="Training/replay CSV (use same as online replay for split_filter).")
    p.add_argument("--output_json", required=True)
    p.add_argument("--output_csv", required=True)
    p.add_argument("--window_size", type=int, default=32)
    p.add_argument("--stride", type=int, default=16)
    p.add_argument(
        "--split_filter",
        default="test_id,test_ood",
        help="Subset rows before windowing; use same as replay to match window_count.",
    )
    p.add_argument("--label_col", default="label")
    p.add_argument("--timestamp_col", default="timestamp")
    p.add_argument("--record_id_col", default="record_id")
    p.add_argument("--group_col", default="uav_id")
    p.add_argument("--batch_size", type=int, default=256)
    p.add_argument("--warmup_runs", type=int, default=5)
    p.add_argument("--repeat_runs", type=int, default=20)
    p.add_argument("--device", default="auto")
    p.add_argument(
        "--device_power_watt",
        type=float,
        default=None,
        help="If set, add estimated energy fields (not real power measurement).",
    )
    p.add_argument(
        "--replay_metrics_json",
        default="",
        help="Optional online replay JSON path for predicted_alert_window_count (energy_per_alert_mwh).",
    )
    return p.parse_args()


def main() -> None:
    args = parse_args()
    out_path = Path(args.output_json)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    cmd = [
        sys.executable,
        str(ROOT / "scripts" / "benchmark_onboard.py"),
        "--artifact",
        args.artifact,
        "--input",
        args.input,
        "--output_json",
        str(out_path),
        "--label_col",
        args.label_col,
        "--timestamp_col",
        args.timestamp_col,
        "--record_id_col",
        args.record_id_col,
        "--group_col",
        args.group_col,
        "--split_filter",
        args.split_filter,
        "--batch_size",
        str(args.batch_size),
        "--warmup_runs",
        str(args.warmup_runs),
        "--repeat_runs",
        str(args.repeat_runs),
        "--device",
        str(args.device),
    ]
    print("RUN", " ".join(cmd), flush=True)
    subprocess.run(cmd, check=True, cwd=str(ROOT))
    report = json.loads(out_path.read_text(encoding="utf-8"))
    nwin = int(report.get("benchmark_window_count", report.get("num_windows", 0)) or 0)
    predicted_alerts = None
    replay_path = str(args.replay_metrics_json or "").strip()
    if replay_path:
        rep_f = Path(replay_path)
        if rep_f.exists():
            rep = json.loads(rep_f.read_text(encoding="utf-8"))
            nested = rep.get("normalized_online_replay_metrics") if isinstance(rep, dict) else None
            if isinstance(nested, dict):
                predicted_alerts = int(nested.get("predicted_alert_window_count", 0) or 0)
            elif isinstance(rep, dict):
                predicted_alerts = int(rep.get("predicted_alert_window_count", rep.get("alert_count", 0)) or 0)

    normalized = {
        "method": args.method,
        "device": str(report.get("device", "")),
        "artifact_path": str(Path(args.artifact).as_posix()),
        "window_size": int(report.get("window_size", args.window_size)),
        "stride": int(report.get("stride", args.stride)),
        "parameter_count": int(report.get("parameter_count", 0) or 0),
        "model_size_mb": float(report.get("model_size_mb", 0.0) or 0.0),
        "average_inference_time_ms_per_window": float(
            report.get("average_inference_time_ms_per_window", report.get("average_window_inference_ms", 0.0)) or 0.0
        ),
        "throughput_windows_per_second": float(
            report.get("throughput_windows_per_second", report.get("throughput_windows_per_sec", 0.0)) or 0.0
        ),
        "memory_usage_mb": report.get("memory_usage_mb"),
        "cpu_usage_percent": report.get("cpu_usage_percent"),
        "gpu_memory_usage_mb": report.get("gpu_memory_usage_mb"),
        "benchmark_window_count": nwin,
        "split_filter": str(args.split_filter or ""),
    }
    if args.device_power_watt is not None and nwin > 0:
        avg_ms = float(normalized["average_inference_time_ms_per_window"] or 0.0)
        p_w = float(args.device_power_watt)
        total_s = float(avg_ms * nwin / 1000.0)
        e_wh = float(p_w * total_s / 3600.0)
        e_per_w = float(e_wh * 1000.0 / nwin)
        e_alert = None
        if predicted_alerts and predicted_alerts > 0:
            e_alert = float(e_wh * 1000.0 / float(predicted_alerts))
        normalized["energy_source"] = "estimated_by_power_model"
        normalized["device_power_watt"] = p_w
        normalized["total_inference_time_seconds"] = total_s
        normalized["ids_inference_energy_wh"] = e_wh
        normalized["energy_per_window_mwh"] = e_per_w
        normalized["energy_per_alert_mwh"] = e_alert

    merged = dict(report)
    merged["normalized_deployment_benchmark"] = normalized
    merged["method"] = args.method
    out_path.write_text(json.dumps(merged, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    import csv

    csv_path = Path(args.output_csv)
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    with csv_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(normalized.keys()))
        writer.writeheader()
        writer.writerow(normalized)
    print(json.dumps(normalized, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
