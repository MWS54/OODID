#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import math
import subprocess
import sys
from pathlib import Path
from typing import Callable, Sequence

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ucs_oodid.io import load_json, save_json

ENCODER_ABLATION_CONFIGS = [
    {"experiment_name": "transformer_only", "encoder_ablation": "transformer_only"},
    {"experiment_name": "gcn_only", "encoder_ablation": "gcn_only"},
    {"experiment_name": "mlp_only", "encoder_ablation": "mlp_only"},
    {"experiment_name": "random_graph", "encoder_ablation": "random_graph"},
    {"experiment_name": "full", "encoder_ablation": "full"},
]


def run(cmd: Sequence[object]) -> None:
    print("RUN", " ".join(map(str, cmd)), flush=True)
    subprocess.run(list(map(str, cmd)), check=True)


def safe_load_json(path: Path) -> dict:
    if not path.exists():
        return {}
    return load_json(path)


def clear_known_outputs(output_dir: Path) -> None:
    for filename in ["artifact.pt", "eval_report.json", "leakage_report.json"]:
        path = output_dir / filename
        if path.exists():
            path.unlink()


def _group_metric(payload: dict, group: str, metric: str):
    return payload.get(group, {}).get(metric)


def _valid_group_metric_values(payload: dict, metric: str) -> list[float]:
    values = []
    for item in payload.values():
        value = item.get(metric)
        if value is None:
            continue
        try:
            value = float(value)
        except (TypeError, ValueError):
            continue
        if math.isnan(value):
            continue
        values.append(value)
    return values


def _sorted_group_names(*payloads: dict) -> list[str]:
    groups: set[str] = set()
    for payload in payloads:
        for group in payload:
            name = str(group).strip()
            if name:
                groups.add(name)
    return sorted(groups)


def _mean_or_none(values: list[float]) -> float | None:
    if not values:
        return None
    return float(sum(values) / len(values))


def build_train_command(args, config: dict, output_dir: Path) -> list[object]:
    train_py = Path(__file__).with_name("train.py")
    cmd: list[object] = [
        sys.executable,
        train_py,
        "--input",
        args.input,
        "--output_dir",
        output_dir,
        "--label_col",
        args.label_col,
        "--timestamp_col",
        args.timestamp_col,
        "--record_id_col",
        args.record_id_col,
        "--group_col",
        args.group_col,
        "--id_classes",
        args.id_classes,
        "--ood_classes",
        args.ood_classes,
        "--benign_label",
        args.benign_label,
        "--window_mode",
        args.window_mode,
        "--window_size",
        str(args.window_size),
        "--stride",
        str(args.stride),
        "--time_window_seconds",
        str(args.time_window_seconds),
        "--adaptive_min_size",
        str(args.adaptive_min_size),
        "--adaptive_max_size",
        str(args.adaptive_max_size),
        "--graph_k",
        str(args.graph_k),
        "--graph_tau",
        str(args.graph_tau),
        "--graph_metric",
        args.graph_metric,
        "--graph_variant",
        args.graph_variant,
        "--encoder_ablation",
        config["encoder_ablation"],
        "--hidden_dim",
        str(args.hidden_dim),
        "--num_heads",
        str(args.num_heads),
        "--num_layers",
        str(args.num_layers),
        "--gcn_layers",
        str(args.gcn_layers),
        "--dropout",
        str(args.dropout),
        "--gate",
        args.gate,
        "--epochs",
        str(args.epochs),
        "--batch_size",
        str(args.batch_size),
        "--lr",
        str(args.lr),
        "--weight_decay",
        str(args.weight_decay),
        "--lambda_record",
        str(args.lambda_record),
        "--q_ood",
        str(args.q_ood),
        "--bank_k",
        str(args.bank_k),
        "--fusion",
        args.fusion,
        "--ood_direction_calibration",
        args.ood_direction_calibration,
        "--ood_threshold_mode",
        args.ood_threshold_mode,
        "--group_threshold_strategy",
        args.group_threshold_strategy,
        "--group_threshold_shrink_k",
        str(args.group_threshold_shrink_k),
        "--group_threshold_min_ratio",
        str(args.group_threshold_min_ratio),
        "--group_threshold_min_samples",
        str(args.group_threshold_min_samples),
        "--present_class_min_support",
        str(getattr(args, "present_class_min_support", 1)),
        "--normalization_mode",
        args.normalization_mode,
        "--group_embedding_dim",
        str(args.group_embedding_dim),
        "--seed",
        str(args.seed),
    ]
    if args.allow_ports:
        cmd.append("--allow_ports")
    if args.use_group_embedding:
        cmd.append("--use_group_embedding")
    if args.record_head:
        cmd.append("--record_head")
    if args.phase_aware_threshold:
        cmd.extend(
            [
                "--phase_aware_threshold",
                "--phase_column",
                args.phase_column,
                "--phase_threshold_min_samples",
                str(args.phase_threshold_min_samples),
                "--phase_threshold_fallback",
                args.phase_threshold_fallback,
            ]
        )
        if args.phase_threshold_quantile is not None:
            cmd.extend(["--phase_threshold_quantile", str(args.phase_threshold_quantile)])
    if args.device and str(args.device).strip().lower() != "auto":
        cmd.extend(["--device", args.device])
    return cmd


def build_encoder_ablation_summary_row(
    config: dict,
    eval_report: dict | None = None,
    status: str = "success",
    error_message: str | None = None,
) -> dict:
    eval_report = eval_report or {}
    id_test = eval_report.get("id_test", {})
    id_test_by_group = eval_report.get("id_test_by_group", {})
    ood_test = eval_report.get("ood_test", {})
    ood_test_by_group = eval_report.get("ood_test_by_group", {})
    group_names = _sorted_group_names(id_test_by_group, ood_test_by_group)
    id_group_micro_f1_values = _valid_group_metric_values(id_test_by_group, "micro_f1")
    group_ood_f1_values = _valid_group_metric_values(ood_test_by_group, "ood_f1")
    row = {
        "experiment_name": config["experiment_name"],
        "encoder_ablation": config["encoder_ablation"],
        "id_micro_f1": id_test.get("micro_f1"),
        "id_macro_f1": id_test.get("macro_f1"),
        "id_mAP": id_test.get("mAP"),
        "ood_auroc": ood_test.get("auroc"),
        "ood_f1": ood_test.get("ood_f1"),
        "ood_fpr95": ood_test.get("fpr95"),
        "uav_count": len(group_names),
        "group_names": ",".join(group_names),
        "macro_uav_id_micro_f1": _mean_or_none(id_group_micro_f1_values),
        "macro_uav_ood_f1": _mean_or_none(group_ood_f1_values),
        "worst_uav_ood_f1": min(group_ood_f1_values) if group_ood_f1_values else None,
        "status": status,
        "error_message": error_message,
    }
    for group in group_names:
        row[f"{group}_id_micro_f1"] = _group_metric(id_test_by_group, group, "micro_f1")
        row[f"{group}_ood_auroc"] = _group_metric(ood_test_by_group, group, "auroc")
        row[f"{group}_ood_f1"] = _group_metric(ood_test_by_group, group, "ood_f1")
    return row


def run_single_encoder_ablation(args, config: dict, runner: Callable[[Sequence[object]], None] = run) -> dict:
    output_dir = Path(args.output_root) / config["experiment_name"]
    output_dir.mkdir(parents=True, exist_ok=True)
    clear_known_outputs(output_dir)
    status = "success"
    error_message = None
    try:
        runner(build_train_command(args, config=config, output_dir=output_dir))
        if not (output_dir / "eval_report.json").exists():
            raise FileNotFoundError(f"eval_report.json was not produced for {config['experiment_name']}")
    except Exception as exc:
        status = "failed"
        error_message = f"{type(exc).__name__}: {exc}"

    eval_report = safe_load_json(output_dir / "eval_report.json")
    row = build_encoder_ablation_summary_row(
        config=config,
        eval_report=eval_report,
        status=status,
        error_message=error_message,
    )
    row["output_dir"] = str(output_dir)
    return row


def write_encoder_ablation_summaries(rows: list[dict], output_root: Path, args) -> dict:
    output_root.mkdir(parents=True, exist_ok=True)
    df = pd.DataFrame(rows)
    csv_path = output_root / "encoder_ablation_summary.csv"
    json_path = output_root / "encoder_ablation_summary.json"
    df.to_csv(csv_path, index=False)
    failed = [row["experiment_name"] for row in rows if row.get("status") == "failed"]
    payload = {
        "input": str(args.input),
        "group_col": args.group_col,
        "seed": int(args.seed),
        "epochs": int(args.epochs),
        "batch_size": int(args.batch_size),
        "window_mode": args.window_mode,
        "window_size": int(args.window_size),
        "stride": int(args.stride),
        "device": args.device,
        "normalization_mode": args.normalization_mode,
        "ood_threshold_mode": args.ood_threshold_mode,
        "group_threshold_strategy": args.group_threshold_strategy,
        "group_threshold_min_ratio": float(args.group_threshold_min_ratio),
        "group_threshold_shrink_k": float(args.group_threshold_shrink_k),
        "group_threshold_min_samples": int(args.group_threshold_min_samples),
        "use_group_embedding": bool(args.use_group_embedding),
        "group_embedding_dim": int(args.group_embedding_dim),
        "graph_metric": args.graph_metric,
        "graph_variant": args.graph_variant,
        "gate": args.gate,
        "experiments": rows,
        "failed_experiments": failed,
    }
    save_json(payload, json_path)
    return payload


def run_encoder_ablation(args, runner: Callable[[Sequence[object]], None] = run) -> dict:
    rows = []
    for config in ENCODER_ABLATION_CONFIGS:
        rows.append(run_single_encoder_ablation(args, config=config, runner=runner))
    return write_encoder_ablation_summaries(rows, Path(args.output_root), args)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run encoder ablations for Transformer/GCN/UCS-OODID and summarize the results.")
    parser.add_argument("--input", required=True)
    parser.add_argument("--output_root", required=True)
    parser.add_argument("--id_classes", required=True)
    parser.add_argument("--ood_classes", required=True)
    parser.add_argument("--label_col", default="label")
    parser.add_argument("--timestamp_col", default="timestamp")
    parser.add_argument("--record_id_col", default="record_id")
    parser.add_argument("--group_col", default="uav_id")
    parser.add_argument("--benign_label", default="benign")
    parser.add_argument("--allow_ports", action="store_true")
    parser.add_argument("--window_mode", default="count", choices=["count", "time", "adaptive"])
    parser.add_argument("--window_size", type=int, default=32)
    parser.add_argument("--stride", type=int, default=16)
    parser.add_argument("--time_window_seconds", type=float, default=2.0)
    parser.add_argument("--adaptive_min_size", type=int, default=8)
    parser.add_argument("--adaptive_max_size", type=int, default=64)
    parser.add_argument("--graph_k", type=int, default=8)
    parser.add_argument("--graph_tau", type=float, default=0.5)
    parser.add_argument("--graph_metric", default="cosine", choices=["cosine", "rbf", "euclidean"])
    parser.add_argument("--graph_variant", default="sym_weighted", choices=["sym_weighted", "directed", "mutual", "binary", "identity_graph", "no_graph"])
    parser.add_argument("--hidden_dim", type=int, default=128)
    parser.add_argument("--num_heads", type=int, default=4)
    parser.add_argument("--num_layers", type=int, default=2)
    parser.add_argument("--gcn_layers", type=int, default=2)
    parser.add_argument("--dropout", type=float, default=0.1)
    parser.add_argument("--gate", default="learned", choices=["learned", "temporal_only", "graph_only", "mean"])
    parser.add_argument("--record_head", action="store_true")
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--batch_size", type=int, default=128)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--lambda_record", type=float, default=0.0)
    parser.add_argument("--q_ood", type=float, default=0.95)
    parser.add_argument("--bank_k", type=int, default=5)
    parser.add_argument("--fusion", default="correlation_aware", choices=["correlation_aware", "mean", "hard_voting", "variance_weighted", "validation_weighted", "conf", "energy", "proto", "knn"])
    parser.add_argument("--ood_direction_calibration", default="none", choices=["none", "pseudo_ood", "test_ood_diagnostic"])
    parser.add_argument("--phase_aware_threshold", action="store_true")
    parser.add_argument("--phase_column", default="mission_phase_proxy")
    parser.add_argument("--phase_threshold_min_samples", type=int, default=32)
    parser.add_argument("--phase_threshold_quantile", type=float, default=None)
    parser.add_argument("--phase_threshold_fallback", default="global", choices=["global"])
    parser.add_argument("--normalization_mode", default="group", choices=["global", "group"])
    parser.add_argument("--ood_threshold_mode", default="group", choices=["global", "group"])
    parser.add_argument("--group_threshold_strategy", default="conservative", choices=["raw", "shrink", "conservative", "global_floor"])
    parser.add_argument("--group_threshold_shrink_k", type=float, default=1000.0)
    parser.add_argument("--group_threshold_min_ratio", type=float, default=1.0)
    parser.add_argument("--group_threshold_min_samples", type=int, default=10)
    parser.add_argument("--present_class_min_support", type=int, default=1)
    parser.add_argument("--group_embedding_dim", type=int, default=16)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--device", default="auto")
    parser.add_argument("--use_group_embedding", dest="use_group_embedding", action="store_true")
    parser.add_argument("--no_group_embedding", dest="use_group_embedding", action="store_false")
    parser.set_defaults(use_group_embedding=True)
    args = parser.parse_args()
    summary = run_encoder_ablation(args)
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
