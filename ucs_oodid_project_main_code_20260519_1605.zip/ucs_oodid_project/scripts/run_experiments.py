#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path


def run(cmd):
    print("RUN", " ".join(map(str, cmd)))
    subprocess.run(list(map(str, cmd)), check=True)


def main():
    p = argparse.ArgumentParser(description="Paper-style RQ1--RQ7 experiment driver.")
    p.add_argument("--input", required=True, help="Metadata-only dataset path")
    p.add_argument("--output_dir", required=True)
    p.add_argument("--id_classes", default="")
    p.add_argument("--ood_classes", default="")
    p.add_argument("--common_train_args", default="")
    p.add_argument("--epochs", type=int, default=10)
    p.add_argument("--present_class_min_support", type=int, default=1)
    args = p.parse_args()
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    train_py = Path(__file__).with_name("train.py")
    detect_py = Path(__file__).with_name("detect.py")
    offline_py = Path(__file__).with_name("offline_triage.py")

    base = [
        sys.executable,
        train_py,
        "--input",
        args.input,
        "--epochs",
        args.epochs,
        "--present_class_min_support",
        args.present_class_min_support,
    ]
    if args.id_classes:
        base += ["--id_classes", args.id_classes]
    if args.ood_classes:
        base += ["--ood_classes", args.ood_classes]
    if args.common_train_args:
        base += args.common_train_args.split()

    # RQ1/RQ2/RQ3/RQ6/RQ7 default end-to-end run.
    main_dir = out / "ucs_oodid_default"
    run(base + ["--output_dir", main_dir])
    run(
        [
            sys.executable,
            detect_py,
            "--input",
            args.input,
            "--artifact",
            main_dir / "artifact.pt",
            "--output_jsonl",
            main_dir / "detections.jsonl",
            "--record_scores_json",
            main_dir / "record_scores.json",
            "--present_class_min_support",
            args.present_class_min_support,
        ]
    )
    run([sys.executable, offline_py, "--detections", main_dir / "detections.jsonl", "--output_dir", main_dir / "offline_triage"])

    # RQ3 fusion ablation.
    run(
        [
            sys.executable,
            Path(__file__).with_name("fusion_ablation.py"),
            "--input",
            args.input,
            "--output_dir",
            out / "rq3_fusion",
            "--train_args",
            (
                f"--epochs {args.epochs} --id_classes {args.id_classes} --ood_classes {args.ood_classes} "
                f"--present_class_min_support {args.present_class_min_support} {args.common_train_args}"
            ).strip(),
        ]
    )

    # RQ4 graph ablation.
    run(
        [
            sys.executable,
            Path(__file__).with_name("graph_ablation.py"),
            "--input",
            args.input,
            "--output_dir",
            out / "rq4_graph",
            "--train_args",
            (
                f"--epochs {args.epochs} --id_classes {args.id_classes} --ood_classes {args.ood_classes} "
                f"--present_class_min_support {args.present_class_min_support} {args.common_train_args}"
            ).strip(),
        ]
    )

    summary = {
        "default_run": str(main_dir),
        "rq3_fusion": str(out / "rq3_fusion"),
        "rq4_graph": str(out / "rq4_graph"),
        "notes": "RQ1 mixed-window ratios and RQ5 LOCO/family hold-out require dataset-specific split scripts when labels/families differ. The train.py interface supports the exact ID/OOD class lists for each split.",
    }
    (out / "experiment_manifest.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
