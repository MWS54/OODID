#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ucs_oodid.io import load_records
from ucs_oodid.windowing import attach_parsed_labels, infer_all_labels


def run(cmd):
    print("RUN", " ".join(map(str, cmd)), flush=True)
    subprocess.run(list(map(str, cmd)), check=True)


def main():
    p = argparse.ArgumentParser(description="RQ5 attack-family hold-out protocol.")
    p.add_argument("--input", required=True)
    p.add_argument("--output_dir", required=True)
    p.add_argument("--label_col", default="label")
    p.add_argument("--family_col", default="", help="Optional column containing attack family per record.")
    p.add_argument("--family_map_json", default="", help="JSON object mapping label -> family.")
    p.add_argument("--exclude_families", default="benign,normal")
    p.add_argument("--train_args", default="")
    p.add_argument("--present_class_min_support", type=int, default=1)
    args = p.parse_args()
    df = attach_parsed_labels(load_records(args.input), args.label_col)
    labels = infer_all_labels(df, args.label_col)
    family_map = {}
    if args.family_map_json:
        family_map.update(json.loads(Path(args.family_map_json).read_text(encoding="utf-8")))
    if args.family_col and args.family_col in df.columns:
        for _, row in df.iterrows():
            labs = row.get("__labels", [])
            fam = str(row[args.family_col])
            for lab in labs:
                family_map.setdefault(lab, fam)
    for lab in labels:
        family_map.setdefault(lab, lab)
    families = sorted(set(family_map.values()))
    excludes = {x.strip().lower() for x in args.exclude_families.split(',') if x.strip()}
    out = Path(args.output_dir); out.mkdir(parents=True, exist_ok=True)
    train_py = Path(__file__).with_name("train.py")
    results = []
    for fam in families:
        if str(fam).lower() in excludes:
            continue
        ood_classes = [lab for lab, f in family_map.items() if f == fam]
        id_classes = [lab for lab in labels if lab not in set(ood_classes)]
        if not ood_classes or not id_classes:
            continue
        run_dir = out / f"family_{str(fam).replace('/', '_')}"
        cmd = [
            sys.executable,
            train_py,
            "--input",
            args.input,
            "--output_dir",
            run_dir,
            "--label_col",
            args.label_col,
            "--id_classes",
            ",".join(id_classes),
            "--ood_classes",
            ",".join(ood_classes),
            "--present_class_min_support",
            args.present_class_min_support,
        ]
        if args.train_args:
            cmd += args.train_args.split()
        run(cmd)
        report_path = run_dir / "eval_report.json"
        report = json.loads(report_path.read_text(encoding="utf-8")) if report_path.exists() else {}
        results.append({"holdout_family": fam, "ood_classes": ood_classes, "id_classes": id_classes, "report": report, "run_dir": str(run_dir)})
    (out / "family_holdout_summary.json").write_text(json.dumps(results, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({"runs": len(results), "summary": str(out / "family_holdout_summary.json")}, indent=2))

if __name__ == "__main__":
    main()
