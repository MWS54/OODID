#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Callable, Optional

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts import run_comparison_experiments as comparison_runner
from ucs_oodid.io import load_json, load_records, save_json, save_records
from ucs_oodid.utils import parse_csv_list

KNOWN_METRICS = [
    ("Micro-F1", "micro_f1"),
    ("Macro-F1", "macro_f1"),
    ("mAP", "mAP"),
    ("Hamming Loss", "hamming_loss"),
    ("Subset Acc.", "subset_accuracy"),
]
OOD_METRICS = [
    ("AUROC", "auroc"),
    ("AUPR-Out", "aupr_out"),
    ("FPR95", "fpr95"),
    ("Precision", "precision"),
    ("Recall", "recall"),
    ("OOD-F1", "ood_f1"),
    ("FPR@theta", "fpr_at_threshold"),
]
VS_HETERO_COLUMNS = [
    "Method",
    "Sources",
    "Homogeneous Micro-F1",
    "Heterogeneous Micro-F1",
    "Micro-F1 Drop",
    "Homogeneous AUROC",
    "Heterogeneous AUROC",
    "AUROC Drop",
    "Homogeneous OOD-F1",
    "Heterogeneous OOD-F1",
    "OOD-F1 Drop",
    "Homogeneous FPR95",
    "Heterogeneous FPR95",
    "FPR95 Increase",
]
VS_HETERO_CAPTION = (
    "Homogeneous single-source vs. heterogeneous mixed-source comparison "
    "under the same metadata-window protocol."
)


def latex_escape(text: str) -> str:
    replacements = {
        "\\": r"\textbackslash{}",
        "&": r"\&",
        "%": r"\%",
        "$": r"\$",
        "#": r"\#",
        "_": r"\_",
        "{": r"\{",
        "}": r"\}",
        "~": r"\textasciitilde{}",
        "^": r"\textasciicircum{}",
    }
    return "".join(replacements.get(ch, ch) for ch in text)


def _safe_float(value: Any) -> Optional[float]:
    if value is None:
        return None
    if isinstance(value, str) and not value.strip():
        return None
    try:
        numeric = float(value)
    except (TypeError, ValueError):
        return None
    if pd.isna(numeric):
        return None
    return numeric


def _format_float(value: Any) -> str:
    numeric = _safe_float(value)
    return "" if numeric is None else f"{numeric:.4f}"


def _format_mean_std(mean: Optional[float], std: Optional[float], count: int) -> str:
    if count <= 0 or mean is None or std is None:
        return ""
    return f"{mean:.4f} ± {std:.4f}"


def _summarize_values(values: list[float]) -> dict[str, Any]:
    if not values:
        return {"count": 0, "mean": None, "std": None, "min": None, "max": None}
    arr = np.asarray(values, dtype=np.float64)
    return {
        "count": int(arr.size),
        "mean": float(np.mean(arr)),
        "std": float(np.std(arr)),
        "min": float(np.min(arr)),
        "max": float(np.max(arr)),
    }


def _format_counts(series: pd.Series) -> dict[str, int]:
    counts = series.fillna("nan").astype(str).value_counts(dropna=False)
    return {str(key): int(value) for key, value in counts.sort_index().items()}


def _sanitize_group_name(value: Any) -> str:
    text = str(value).strip()
    safe = re.sub(r"[^A-Za-z0-9._-]+", "_", text).strip("._-")
    return safe[:80] or "group"


def _method_index(summary: dict) -> dict[str, dict]:
    payload: dict[str, dict] = {}
    for item in summary.get("methods", []):
        raw_name = str(item.get("method_name") or "")
        method_name = comparison_runner.canonical_method_name(raw_name)
        if method_name:
            payload[method_name] = item
    return payload


def _ordered_method_names(*summary_lists: list[dict]) -> list[str]:
    available = set()
    for summary_list in summary_lists:
        for summary in summary_list:
            available.update(
                comparison_runner.canonical_method_name(str(item.get("method_name") or ""))
                for item in summary.get("methods", [])
                if str(item.get("method_name") or "").strip()
            )
            available.update(
                comparison_runner.canonical_method_name(str(name))
                for name in summary.get("selected_methods", [])
                if str(name).strip()
            )
    available.discard("")
    ordered: list[str] = []
    seen = set()
    for spec in comparison_runner.METHOD_SPECS:
        if spec.name in available and spec.name not in seen:
            seen.add(spec.name)
            ordered.append(spec.name)
    for name in sorted(available):
        if name and name not in seen:
            seen.add(name)
            ordered.append(name)
    return ordered


def _clone_args(args, *, input_path: Path | str, output_root: Path | str):
    payload = dict(vars(args))
    payload["input"] = str(input_path)
    payload["output_root"] = str(output_root)
    payload["output_dir"] = str(output_root)
    return SimpleNamespace(**payload)


def _load_summary_from_dir(path: Path) -> dict:
    summary_path = path / "comparison_summary.json"
    if not summary_path.exists():
        raise FileNotFoundError(f"comparison_summary.json was not found in {path}")
    return load_json(summary_path)


def _default_comparison_executor(child_args):
    return comparison_runner.run_comparison_experiments(child_args)


def _resolve_selected_groups(df: pd.DataFrame, group_col: str, groups_arg: str) -> list[Any]:
    if group_col not in df.columns:
        raise ValueError(f"group_col {group_col!r} not found in input data.")
    group_series = df[group_col]
    missing_mask = group_series.isna() | group_series.astype(str).str.strip().eq("")
    missing_count = int(missing_mask.sum())
    if missing_count:
        raise ValueError(
            f"group_col {group_col!r} contains {missing_count} missing/blank values. "
            "Homogeneous single-source experiments require a valid source ID per record."
        )

    unique_values = pd.unique(group_series).tolist()
    by_text = {str(value): value for value in unique_values}
    if groups_arg and str(groups_arg).strip():
        requested = parse_csv_list(groups_arg)
        missing = [name for name in requested if name not in by_text]
        if missing:
            raise ValueError(
                "Requested groups were not found in the input data: " + ", ".join(missing)
            )
        return [by_text[name] for name in requested]
    return sorted(unique_values, key=lambda value: str(value))


def _aggregate_metric_section(
    source_runs: list[dict],
    method_names: list[str],
    section_key: str,
    metrics: list[tuple[str, str]],
) -> tuple[list[dict], dict[str, Any]]:
    rows: list[dict] = []
    payload: dict[str, Any] = {}

    for method_name in method_names:
        spec = comparison_runner.METHOD_BY_NAME.get(method_name)
        display_name = None
        status_by_source: dict[str, str] = {}
        note_by_source: dict[str, str] = {}
        metric_payload = {}
        row = {"Method": ""}
        for source_run in source_runs:
            group_name = str(source_run["group_value"])
            method = _method_index(source_run["comparison_summary"]).get(method_name, {})
            if display_name is None:
                display_name = str(spec.display_name if spec is not None else (method.get("display_name") or method_name))
            status = str(method.get("status", "missing"))
            status_by_source[group_name] = status
            note = str(method.get("note", "") or "")
            if note:
                note_by_source[group_name] = note
        if display_name is None:
            display_name = str(method_name)
        row["Method"] = display_name

        for column_name, metric_key in metrics:
            per_source_values: dict[str, float] = {}
            values: list[float] = []
            for source_run in source_runs:
                group_name = str(source_run["group_value"])
                method = _method_index(source_run["comparison_summary"]).get(method_name, {})
                if str(method.get("status", "missing")) != "success":
                    continue
                section = method.get(section_key, {}) or {}
                numeric = _safe_float(section.get(metric_key))
                if numeric is None:
                    continue
                per_source_values[group_name] = numeric
                values.append(numeric)
            summary = _summarize_values(values)
            metric_payload[metric_key] = {
                **summary,
                "per_source": per_source_values,
            }
            row[column_name] = _format_mean_std(summary["mean"], summary["std"], summary["count"])

        payload[method_name] = {
            "display_name": display_name,
            "available_sources": sorted(
                group_name for group_name, status in status_by_source.items() if status == "success"
            ),
            "skipped_sources": sorted(
                group_name for group_name, status in status_by_source.items() if status == "skipped"
            ),
            "failed_sources": sorted(
                group_name for group_name, status in status_by_source.items() if status == "failed"
            ),
            "missing_sources": sorted(
                group_name for group_name, status in status_by_source.items() if status not in {"success", "skipped", "failed"}
            ),
            "status_by_source": status_by_source,
            "note_by_source": note_by_source,
            "metrics": metric_payload,
        }
        rows.append(row)

    return rows, payload


def _heterogeneous_metric_payload(summary: dict) -> dict[str, Any]:
    payload = {}
    for item in summary.get("methods", []):
        raw_name = str(item.get("method_name") or "")
        method_name = comparison_runner.canonical_method_name(raw_name)
        if not method_name:
            continue
        spec = comparison_runner.METHOD_BY_NAME.get(method_name)
        payload[method_name] = {
            "display_name": str(spec.display_name if spec is not None else (item.get("display_name") or method_name)),
            "status": str(item.get("status", "success")),
            "note": str(item.get("note", "") or ""),
            "known_detection": dict(item.get("known_detection", {}) or {}),
            "ood_detection": dict(item.get("ood_detection", {}) or {}),
        }
    return payload


def _compare_homogeneous_vs_heterogeneous(
    method_names: list[str],
    known_payload: dict[str, Any],
    ood_payload: dict[str, Any],
    heterogeneous_summary: dict,
) -> tuple[list[dict], dict[str, Any]]:
    hetero_payload = _heterogeneous_metric_payload(heterogeneous_summary)
    rows: list[dict] = []
    payload: dict[str, Any] = {}

    for method_name in method_names:
        display_name = (
            known_payload.get(method_name, {}).get("display_name")
            or hetero_payload.get(method_name, {}).get("display_name")
            or method_name
        )
        homo_known = known_payload.get(method_name, {}).get("metrics", {})
        homo_ood = ood_payload.get(method_name, {}).get("metrics", {})
        hetero_method = hetero_payload.get(method_name, {})
        hetero_known = hetero_method.get("known_detection", {})
        hetero_ood = hetero_method.get("ood_detection", {})

        sources = int(homo_known.get("micro_f1", {}).get("count", 0))
        homo_micro_mean = homo_known.get("micro_f1", {}).get("mean")
        homo_micro_std = homo_known.get("micro_f1", {}).get("std")
        homo_auroc_mean = homo_ood.get("auroc", {}).get("mean")
        homo_auroc_std = homo_ood.get("auroc", {}).get("std")
        homo_ood_f1_mean = homo_ood.get("ood_f1", {}).get("mean")
        homo_ood_f1_std = homo_ood.get("ood_f1", {}).get("std")
        homo_fpr95_mean = homo_ood.get("fpr95", {}).get("mean")
        homo_fpr95_std = homo_ood.get("fpr95", {}).get("std")

        hetero_micro = _safe_float(hetero_known.get("micro_f1"))
        hetero_auroc = _safe_float(hetero_ood.get("auroc"))
        hetero_ood_f1 = _safe_float(hetero_ood.get("ood_f1"))
        hetero_fpr95 = _safe_float(hetero_ood.get("fpr95"))

        micro_drop = None if homo_micro_mean is None or hetero_micro is None else float(homo_micro_mean - hetero_micro)
        auroc_drop = None if homo_auroc_mean is None or hetero_auroc is None else float(homo_auroc_mean - hetero_auroc)
        ood_f1_drop = None if homo_ood_f1_mean is None or hetero_ood_f1 is None else float(homo_ood_f1_mean - hetero_ood_f1)
        fpr95_increase = None if homo_fpr95_mean is None or hetero_fpr95 is None else float(hetero_fpr95 - homo_fpr95_mean)

        rows.append(
            {
                "Method": display_name,
                "Sources": sources,
                "Homogeneous Micro-F1": _format_mean_std(homo_micro_mean, homo_micro_std, sources),
                "Heterogeneous Micro-F1": _format_float(hetero_micro),
                "Micro-F1 Drop": _format_float(micro_drop),
                "Homogeneous AUROC": _format_mean_std(homo_auroc_mean, homo_auroc_std, sources),
                "Heterogeneous AUROC": _format_float(hetero_auroc),
                "AUROC Drop": _format_float(auroc_drop),
                "Homogeneous OOD-F1": _format_mean_std(homo_ood_f1_mean, homo_ood_f1_std, sources),
                "Heterogeneous OOD-F1": _format_float(hetero_ood_f1),
                "OOD-F1 Drop": _format_float(ood_f1_drop),
                "Homogeneous FPR95": _format_mean_std(homo_fpr95_mean, homo_fpr95_std, sources),
                "Heterogeneous FPR95": _format_float(hetero_fpr95),
                "FPR95 Increase": _format_float(fpr95_increase),
            }
        )
        payload[method_name] = {
            "display_name": display_name,
            "sources": sources,
            "homogeneous": {
                "micro_f1": {
                    "mean": homo_micro_mean,
                    "std": homo_micro_std,
                },
                "auroc": {
                    "mean": homo_auroc_mean,
                    "std": homo_auroc_std,
                },
                "ood_f1": {
                    "mean": homo_ood_f1_mean,
                    "std": homo_ood_f1_std,
                },
                "fpr95": {
                    "mean": homo_fpr95_mean,
                    "std": homo_fpr95_std,
                },
            },
            "heterogeneous": {
                "status": hetero_method.get("status", "missing"),
                "micro_f1": hetero_micro,
                "auroc": hetero_auroc,
                "ood_f1": hetero_ood_f1,
                "fpr95": hetero_fpr95,
            },
            "delta": {
                "micro_f1_drop": micro_drop,
                "auroc_drop": auroc_drop,
                "ood_f1_drop": ood_f1_drop,
                "fpr95_increase": fpr95_increase,
            },
        }

    return rows, payload


def _ranking_from_payload(
    payload: dict[str, Any],
    value_getter: Callable[[dict[str, Any]], Optional[float]],
    *,
    reverse: bool,
) -> list[dict[str, Any]]:
    items = []
    for method_name, item in payload.items():
        value = value_getter(item)
        if value is None:
            continue
        items.append(
            {
                "method_name": method_name,
                "display_name": item.get("display_name", method_name),
                "value": float(value),
            }
        )
    items.sort(key=lambda entry: entry["value"], reverse=reverse)
    for index, entry in enumerate(items, start=1):
        entry["rank"] = index
    return items


def _rank_lookup(ranking: list[dict[str, Any]]) -> dict[str, int]:
    return {str(entry["method_name"]): int(entry["rank"]) for entry in ranking}


def _paper_question_summary(
    known_payload: dict[str, Any],
    ood_payload: dict[str, Any],
    vs_payload: dict[str, Any],
) -> dict[str, Any]:
    micro_stability = _ranking_from_payload(
        known_payload,
        lambda item: item.get("metrics", {}).get("micro_f1", {}).get("std"),
        reverse=False,
    )
    auroc_stability = _ranking_from_payload(
        ood_payload,
        lambda item: item.get("metrics", {}).get("auroc", {}).get("std"),
        reverse=False,
    )
    ood_f1_stability = _ranking_from_payload(
        ood_payload,
        lambda item: item.get("metrics", {}).get("ood_f1", {}).get("std"),
        reverse=False,
    )

    micro_drop_ranking = _ranking_from_payload(
        vs_payload,
        lambda item: item.get("delta", {}).get("micro_f1_drop"),
        reverse=True,
    )
    auroc_drop_ranking = _ranking_from_payload(
        vs_payload,
        lambda item: item.get("delta", {}).get("auroc_drop"),
        reverse=True,
    )
    ood_f1_drop_ranking = _ranking_from_payload(
        vs_payload,
        lambda item: item.get("delta", {}).get("ood_f1_drop"),
        reverse=True,
    )
    fpr95_increase_ranking = _ranking_from_payload(
        vs_payload,
        lambda item: item.get("delta", {}).get("fpr95_increase"),
        reverse=True,
    )

    micro_rank_lookup = _rank_lookup(_ranking_from_payload(vs_payload, lambda item: item.get("delta", {}).get("micro_f1_drop"), reverse=False))
    auroc_rank_lookup = _rank_lookup(_ranking_from_payload(vs_payload, lambda item: item.get("delta", {}).get("auroc_drop"), reverse=False))
    ood_f1_rank_lookup = _rank_lookup(_ranking_from_payload(vs_payload, lambda item: item.get("delta", {}).get("ood_f1_drop"), reverse=False))
    fpr95_rank_lookup = _rank_lookup(_ranking_from_payload(vs_payload, lambda item: item.get("delta", {}).get("fpr95_increase"), reverse=False))

    ucs = vs_payload.get("ucs_oodid", {})
    return {
        "single_source_stability": {
            "micro_f1_std_rank_best_to_worst": micro_stability,
            "auroc_std_rank_best_to_worst": auroc_stability,
            "ood_f1_std_rank_best_to_worst": ood_f1_stability,
        },
        "heterogeneous_drop": {
            "micro_f1_drop_rank_worst_to_best": micro_drop_ranking,
            "auroc_drop_rank_worst_to_best": auroc_drop_ranking,
            "ood_f1_drop_rank_worst_to_best": ood_f1_drop_ranking,
            "fpr95_increase_rank_worst_to_best": fpr95_increase_ranking,
        },
        "ucs_oodid_robustness": {
            "method_name": "ucs_oodid",
            "display_name": ucs.get("display_name", "UCS-OODID"),
            "micro_f1_drop": ucs.get("delta", {}).get("micro_f1_drop"),
            "auroc_drop": ucs.get("delta", {}).get("auroc_drop"),
            "ood_f1_drop": ucs.get("delta", {}).get("ood_f1_drop"),
            "fpr95_increase": ucs.get("delta", {}).get("fpr95_increase"),
            "micro_f1_drop_rank_best_to_worst": micro_rank_lookup.get("ucs_oodid"),
            "auroc_drop_rank_best_to_worst": auroc_rank_lookup.get("ucs_oodid"),
            "ood_f1_drop_rank_best_to_worst": ood_f1_rank_lookup.get("ucs_oodid"),
            "fpr95_increase_rank_best_to_worst": fpr95_rank_lookup.get("ucs_oodid"),
        },
    }


def _format_vs_tex_cell(value: Any, highlight: bool = False) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    if " ± " in text:
        mean, std = text.split(" ± ", 1)
        mean_text = latex_escape(mean)
        std_text = latex_escape(std)
        if highlight:
            return rf"\textbf{{{mean_text}}} $\pm$ \textbf{{{std_text}}}"
        return rf"{mean_text} $\pm$ {std_text}"
    escaped = latex_escape(text)
    if highlight:
        return rf"\textbf{{{escaped}}}"
    return escaped


def _write_vs_table(rows: list[dict], output_csv: Path, output_tex: Path) -> None:
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    frame = pd.DataFrame(rows).reindex(columns=VS_HETERO_COLUMNS)
    frame.to_csv(output_csv, index=False)

    aligns = "l" + "c" * (len(VS_HETERO_COLUMNS) - 1)
    lines = [
        r"\begin{table*}[t]",
        r"\centering",
        rf"\caption{{{VS_HETERO_CAPTION}}}",
        r"\begin{tabular}{" + aligns + "}",
        r"\toprule",
        " & ".join(latex_escape(str(column)) for column in VS_HETERO_COLUMNS) + r" \\",
        r"\midrule",
    ]
    for row in frame.itertuples(index=False, name=None):
        highlight = str(row[0]) == "UCS-OODID"
        cells = [_format_vs_tex_cell(value, highlight=highlight) for value in row]
        lines.append(" & ".join(cells) + r" \\")
    lines.extend([r"\bottomrule", r"\end{tabular}", r"\end{table*}"])
    output_tex.write_text("\n".join(lines) + "\n", encoding="utf-8")


def run_homogeneous_comparison_experiments(
    args,
    comparison_executor: Optional[Callable[[Any], dict]] = None,
) -> dict:
    executor = comparison_executor or _default_comparison_executor
    output_root = Path(getattr(args, "output_root", "runs/homogeneous_comparison_experiments"))
    output_root.mkdir(parents=True, exist_ok=True)

    df = load_records(args.input)
    group_col = str(getattr(args, "group_col", "uav_id") or "").strip()
    if not group_col:
        raise ValueError("Homogeneous single-source experiments require --group_col.")
    selected_groups = _resolve_selected_groups(df, group_col, str(getattr(args, "groups", "") or ""))

    hetero_dir_arg = str(getattr(args, "heterogeneous_results_dir", "") or "").strip()
    if hetero_dir_arg:
        hetero_output_root = Path(hetero_dir_arg)
        heterogeneous_summary = _load_summary_from_dir(hetero_output_root)
        heterogeneous_mode = "provided"
    else:
        hetero_output_root = output_root / "heterogeneous_reference"
        hetero_output_root.mkdir(parents=True, exist_ok=True)
        heterogeneous_summary = executor(_clone_args(args, input_path=args.input, output_root=hetero_output_root))
        heterogeneous_mode = "generated"

    sources_root = output_root / "sources"
    sources_root.mkdir(parents=True, exist_ok=True)

    source_runs: list[dict] = []
    for index, group_value in enumerate(selected_groups, start=1):
        group_text = str(group_value)
        group_df = df.loc[df[group_col].eq(group_value)].copy()
        source_dir = sources_root / f"{index:02d}_{_sanitize_group_name(group_value)}"
        source_dir.mkdir(parents=True, exist_ok=True)
        filtered_input_path = source_dir / "single_source_input.csv"
        save_records(group_df, filtered_input_path)

        try:
            comparison_summary = executor(_clone_args(args, input_path=filtered_input_path, output_root=source_dir))
            source_runs.append(
                {
                    "group_value": group_text,
                    "rows": int(len(group_df)),
                    "label_distribution": _format_counts(group_df[getattr(args, "label_col", "label")]),
                    "status": "completed",
                    "filtered_input": str(filtered_input_path),
                    "output_root": str(source_dir),
                    "summary_path": str(source_dir / "comparison_summary.json"),
                    "successful_methods": list(comparison_summary.get("successful_methods", [])),
                    "skipped_methods": list(comparison_summary.get("skipped_methods", [])),
                    "failed_methods": list(comparison_summary.get("failed_methods", [])),
                    "comparison_summary": comparison_summary,
                }
            )
        except Exception as exc:
            source_runs.append(
                {
                    "group_value": group_text,
                    "rows": int(len(group_df)),
                    "label_distribution": _format_counts(group_df[getattr(args, "label_col", "label")]),
                    "status": "failed",
                    "filtered_input": str(filtered_input_path),
                    "output_root": str(source_dir),
                    "summary_path": str(source_dir / "comparison_summary.json"),
                    "error_message": f"{type(exc).__name__}: {exc}",
                }
            )

    completed_source_runs = [item for item in source_runs if item["status"] == "completed"]
    if not completed_source_runs:
        raise ValueError("No homogeneous single-source experiment completed successfully.")

    method_names = _ordered_method_names(
        [heterogeneous_summary],
        [item["comparison_summary"] for item in completed_source_runs],
    )
    homogeneous_known_rows, homogeneous_known_payload = _aggregate_metric_section(
        completed_source_runs,
        method_names,
        "known_detection",
        KNOWN_METRICS,
    )
    homogeneous_ood_rows, homogeneous_ood_payload = _aggregate_metric_section(
        completed_source_runs,
        method_names,
        "ood_detection",
        OOD_METRICS,
    )
    vs_rows, vs_payload = _compare_homogeneous_vs_heterogeneous(
        method_names,
        homogeneous_known_payload,
        homogeneous_ood_payload,
        heterogeneous_summary,
    )

    homogeneous_known_csv = output_root / "homogeneous_known_detection_table.csv"
    homogeneous_ood_csv = output_root / "homogeneous_ood_detection_table.csv"
    summary_json = output_root / "homogeneous_summary.json"
    vs_csv = output_root / "homogeneous_vs_heterogeneous_table.csv"
    vs_tex = output_root / "homogeneous_vs_heterogeneous_table.tex"

    pd.DataFrame(homogeneous_known_rows).reindex(
        columns=["Method", *[column for column, _ in KNOWN_METRICS]]
    ).to_csv(homogeneous_known_csv, index=False)
    pd.DataFrame(homogeneous_ood_rows).reindex(
        columns=["Method", *[column for column, _ in OOD_METRICS]]
    ).to_csv(homogeneous_ood_csv, index=False)
    _write_vs_table(vs_rows, vs_csv, vs_tex)

    summary = {
        "input": str(args.input),
        "output_root": str(output_root),
        "group_col": group_col,
        "config": {
            "window_mode": str(getattr(args, "window_mode", "count")),
            "window_size": int(getattr(args, "window_size", 32)),
            "stride": int(getattr(args, "stride", 16)),
            "time_window_seconds": float(getattr(args, "time_window_seconds", 2.0)),
            "adaptive_min_size": int(getattr(args, "adaptive_min_size", 8)),
            "adaptive_max_size": int(getattr(args, "adaptive_max_size", 64)),
            "normalization_mode": str(getattr(args, "normalization_mode", "group")),
            "q_ood": float(getattr(args, "q_ood", 0.90)),
            "epochs": int(getattr(args, "epochs", 10)),
            "seed": int(getattr(args, "seed", 42)),
            "device": str(getattr(args, "device", "auto")),
        },
        "selected_groups": [str(value) for value in selected_groups],
        "completed_source_count": int(len(completed_source_runs)),
        "failed_source_count": int(sum(1 for item in source_runs if item["status"] != "completed")),
        "selected_methods": method_names,
        "heterogeneous_reference": {
            "mode": heterogeneous_mode,
            "output_root": str(hetero_output_root),
            "summary_path": str(hetero_output_root / "comparison_summary.json"),
            "selected_methods": list(heterogeneous_summary.get("selected_methods", [])),
            "successful_methods": list(heterogeneous_summary.get("successful_methods", [])),
            "skipped_methods": list(heterogeneous_summary.get("skipped_methods", [])),
            "failed_methods": list(heterogeneous_summary.get("failed_methods", [])),
        },
        "source_runs": source_runs,
        "aggregated_metrics": {
            "homogeneous_known_detection": homogeneous_known_payload,
            "homogeneous_ood_detection": homogeneous_ood_payload,
            "homogeneous_vs_heterogeneous": vs_payload,
        },
        "paper_questions": _paper_question_summary(
            homogeneous_known_payload,
            homogeneous_ood_payload,
            vs_payload,
        ),
        "tables": {
            "homogeneous_known_detection_csv": str(homogeneous_known_csv),
            "homogeneous_ood_detection_csv": str(homogeneous_ood_csv),
            "homogeneous_summary_json": str(summary_json),
            "homogeneous_vs_heterogeneous_csv": str(vs_csv),
            "homogeneous_vs_heterogeneous_tex": str(vs_tex),
        },
    }
    save_json(summary, summary_json)
    return summary


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Run homogeneous single-source comparison experiments by filtering a mixed multi-UAV "
            "dataset into one group/source at a time, then compare the aggregated result to the "
            "heterogeneous mixed-source reference."
        )
    )
    parser.add_argument("--input", required=True)
    parser.add_argument("--output_root", default="runs/homogeneous_comparison_experiments")
    parser.add_argument("--output_dir", dest="output_root", help=argparse.SUPPRESS)
    parser.add_argument("--heterogeneous_results_dir", default="")
    parser.add_argument("--groups", default="", help="Optional comma-separated subset of source groups to evaluate.")
    parser.add_argument("--label_col", default="label")
    parser.add_argument("--timestamp_col", default="timestamp")
    parser.add_argument("--record_id_col", default="record_id")
    parser.add_argument("--group_col", default="uav_id")
    parser.add_argument("--id_classes", required=True)
    parser.add_argument("--ood_classes", required=True)
    parser.add_argument("--window_mode", default="count", choices=["count", "time", "adaptive"])
    parser.add_argument("--window_size", type=int, default=32)
    parser.add_argument("--stride", type=int, default=16)
    parser.add_argument("--time_window_seconds", type=float, default=2.0)
    parser.add_argument("--adaptive_min_size", type=int, default=8)
    parser.add_argument("--adaptive_max_size", type=int, default=64)
    parser.add_argument("--normalization_mode", default="group", choices=["global", "group"])
    parser.add_argument("--q_ood", type=float, default=0.90)
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--device", default="auto")
    parser.add_argument("--skip_sklearn", action="store_true")
    parser.add_argument("--skip_neural", action="store_true")
    parser.add_argument("--methods", default="", help="Optional comma-separated subset of methods to run.")
    parser.add_argument("--benign_label", default="benign")
    parser.add_argument("--allow_ports", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    summary = run_homogeneous_comparison_experiments(args)
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
