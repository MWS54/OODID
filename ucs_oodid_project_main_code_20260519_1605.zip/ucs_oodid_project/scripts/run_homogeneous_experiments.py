#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
import shutil
import sys
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Callable, Optional

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts import run_comparison_experiments as comparison_runner
from ucs_oodid.comparison import prepare_comparison_dataset
from ucs_oodid.io import load_json, load_records, save_json, save_records
from ucs_oodid.utils import parse_csv_list, parse_label_cell

KNOWN_COLUMNS = ["Group", "Method", "Micro-F1", "Macro-F1", "mAP", "Hamming Loss", "Subset Acc."]
OOD_COLUMNS = ["Group", "Method", "AUROC", "AUPR-Out", "FPR95", "Precision", "Recall", "OOD-F1", "FPR@theta"]
GROUP_STATS_COLUMNS = [
    "Group",
    "Records",
    "ID Records",
    "OOD Records",
    "Unique Labels",
    "ID Labels Present",
    "OOD Labels Present",
    "ID Classes Used",
    "OOD Classes Used",
    "Status",
    "Reason",
]
MAIN_TABLE_COLUMNS = [
    "Dataset / Group",
    "Best Baseline OOD-F1",
    "ReCDA-style OOD-F1",
    "UCS-OODID OOD-F1",
    "UCS-OODID AUROC",
    "UCS-OODID FPR@theta",
]
KNOWN_CAPTION = "Per-group known-attack results for homogeneous single-source experiments."
OOD_CAPTION = "Per-group OOD detection results for homogeneous single-source experiments."
MAIN_TABLE_CAPTION = "Single-source homogeneous OOD detection results."
NO_ID_REASON = "No ID records for this group under current --id_classes / --ood_classes."
NO_OOD_REASON = "No OOD records for this group under current --ood_classes."
NOT_ENOUGH_OOD_REASON = (
    "Not enough OOD windows for test_ood split. Comparison experiments require real OOD evaluation windows."
)
RECDA_METHOD = "recda_proxy"
UCS_OODID_METHOD = "ucs_oodid"
LATEX_PRIORITY_METHODS = {
    "RAPIER-style",
    "HyperVision-style",
    "ReCDA-style",
    "RIDS-style",
    "UCS-OODID",
}
LATEX_FULL_ROW_LIMIT = 24


def latex_escape(text: str) -> str:
    replacements = {
        "\\": r"\textbackslash{}",
        "&": r"\&",
        "%": r"\%",
        "$": r"\$",
        "#": r"\#",
        "_": r"\_",
        "{": r"\{",
        "}": r"\}",
        "~": r"\textasciitilde{}",
        "^": r"\textasciicircum{}",
    }
    return "".join(replacements.get(ch, ch) for ch in text)


def _safe_float(value: Any) -> Optional[float]:
    if value is None:
        return None
    if isinstance(value, str) and not value.strip():
        return None
    try:
        numeric = float(value)
    except (TypeError, ValueError):
        return None
    if pd.isna(numeric):
        return None
    return float(numeric)


def _format_float(value: Optional[float]) -> str:
    return "" if value is None else f"{value:.4f}"


def _sanitize_group_name(value: Any) -> str:
    text = str(value).strip()
    safe = re.sub(r"[^A-Za-z0-9._-]+", "_", text).strip("._-")
    return safe[:80] or "group"


def _resolve_selected_groups(df: pd.DataFrame, group_col: str, groups_arg: str) -> list[Any]:
    if group_col not in df.columns:
        raise ValueError(f"group_col {group_col!r} not found in input data.")
    group_series = df[group_col]
    missing_mask = group_series.isna() | group_series.astype(str).str.strip().eq("")
    missing_count = int(missing_mask.sum())
    if missing_count:
        raise ValueError(
            f"group_col {group_col!r} contains {missing_count} missing/blank values. "
            "Homogeneous experiments require a valid group ID per record."
        )
    unique_values = pd.unique(group_series).tolist()
    by_text = {str(value): value for value in unique_values}
    if groups_arg and str(groups_arg).strip():
        requested = parse_csv_list(groups_arg)
        missing = [name for name in requested if name not in by_text]
        if missing:
            raise ValueError("Requested groups were not found in the input data: " + ", ".join(missing))
        return [by_text[name] for name in requested]
    return sorted(unique_values, key=lambda value: str(value))


def _build_safe_group_names(groups: list[Any]) -> dict[str, str]:
    seen: dict[str, int] = {}
    mapping: dict[str, str] = {}
    for value in groups:
        text = str(value)
        base = _sanitize_group_name(value)
        index = seen.get(base, 0)
        safe_name = base if index == 0 else f"{base}_{index + 1}"
        seen[base] = index + 1
        mapping[text] = safe_name
    return mapping


def _normalize_class_csv(value: Any) -> str:
    return ",".join(parse_csv_list(str(value or "")))


def _load_per_group_label_config(path_arg: str) -> dict[str, dict[str, Optional[str]]]:
    text = str(path_arg or "").strip()
    if not text:
        return {}
    path = Path(text)
    payload = load_json(path)
    if not isinstance(payload, dict):
        raise ValueError("--per_group_label_config must point to a JSON object keyed by group name.")

    result: dict[str, dict[str, Optional[str]]] = {}
    for group_name, config in payload.items():
        if not isinstance(config, dict):
            raise ValueError(
                "--per_group_label_config entries must be JSON objects containing id_classes / ood_classes."
            )
        result[str(group_name)] = {
            "id_classes": _normalize_class_csv(config["id_classes"]) if "id_classes" in config else None,
            "ood_classes": _normalize_class_csv(config["ood_classes"]) if "ood_classes" in config else None,
        }
    return result


def _resolve_group_label_config(
    args,
    group: str,
    per_group_config: dict[str, dict[str, Optional[str]]],
) -> dict[str, Any]:
    global_id_classes = _normalize_class_csv(getattr(args, "id_classes", ""))
    global_ood_classes = _normalize_class_csv(getattr(args, "ood_classes", ""))
    config = per_group_config.get(str(group), {})

    id_classes_csv = (
        config["id_classes"]
        if isinstance(config, dict) and "id_classes" in config and config["id_classes"] is not None
        else global_id_classes
    )
    ood_classes_csv = (
        config["ood_classes"]
        if isinstance(config, dict) and "ood_classes" in config and config["ood_classes"] is not None
        else global_ood_classes
    )
    source = "per_group_label_config" if str(group) in per_group_config else "global_defaults"
    return {
        "id_classes_csv": str(id_classes_csv),
        "ood_classes_csv": str(ood_classes_csv),
        "id_classes": parse_csv_list(str(id_classes_csv)),
        "ood_classes": parse_csv_list(str(ood_classes_csv)),
        "source": source,
    }


def _group_args_with_label_config(args, label_config: dict[str, Any]):
    payload = dict(vars(args))
    payload["id_classes"] = str(label_config["id_classes_csv"])
    payload["ood_classes"] = str(label_config["ood_classes_csv"])
    return SimpleNamespace(**payload)


def _label_config_fields(label_config: dict[str, Any]) -> dict[str, Any]:
    return {
        "id_classes": list(label_config.get("id_classes", []) or []),
        "ood_classes": list(label_config.get("ood_classes", []) or []),
        "id_classes_csv": str(label_config.get("id_classes_csv", "") or ""),
        "ood_classes_csv": str(label_config.get("ood_classes_csv", "") or ""),
        "label_config_source": str(label_config.get("source", "global_defaults")),
    }


def _clone_args(args, *, input_path: Path | str, output_root: Path | str):
    payload = dict(vars(args))
    payload["input"] = str(input_path)
    payload["output_root"] = str(output_root)
    payload["output_dir"] = str(output_root)
    return SimpleNamespace(**payload)


def _build_precheck_args(args, *, input_path: Path | str):
    return SimpleNamespace(
        input=str(input_path),
        label_col=str(getattr(args, "label_col", "label")),
        timestamp_col=str(getattr(args, "timestamp_col", "timestamp")),
        record_id_col=str(getattr(args, "record_id_col", "record_id")),
        group_col=str(getattr(args, "group_col", "uav_id")),
        id_classes=str(getattr(args, "id_classes", "")),
        ood_classes=str(getattr(args, "ood_classes", "")),
        window_mode=str(getattr(args, "window_mode", "count")),
        window_size=int(getattr(args, "window_size", 16)),
        stride=int(getattr(args, "stride", 8)),
        time_window_seconds=2.0,
        adaptive_min_size=8,
        adaptive_max_size=64,
        normalization_mode=str(getattr(args, "normalization_mode", "global")),
        allow_ports=False,
        ood_threshold_mode="global",
    )


def _default_comparison_executor(child_args):
    return comparison_runner.run_comparison_experiments(child_args)


def _default_group_prechecker(precheck_args, output_dir: Path) -> dict[str, Any]:
    bundle = prepare_comparison_dataset(precheck_args, output_dir)
    return {
        "split_source": str(bundle.split_source),
        "window_counts": {name: int(len(windows)) for name, windows in bundle.split_windows.items()},
    }


def _join_labels(values: list[str]) -> str:
    return ", ".join(str(value) for value in values)


def _combine_reason(reason: str, warnings: list[str]) -> str:
    parts = [str(reason).strip()] if str(reason).strip() else []
    parts.extend(str(item).strip() for item in warnings if str(item).strip())
    return "; ".join(parts)


def check_group_viability(df_group: pd.DataFrame, args) -> dict[str, Any]:
    label_col = str(getattr(args, "label_col", "label"))
    if label_col not in df_group.columns:
        raise ValueError(f"label_col {label_col!r} not found in input data.")

    id_classes = set(parse_csv_list(str(getattr(args, "id_classes", "") or "")))
    ood_classes = set(parse_csv_list(str(getattr(args, "ood_classes", "") or "")))
    window_size = int(getattr(args, "window_size", 16))
    parsed_labels = [parse_label_cell(value) for value in df_group[label_col].tolist()]

    unique_labels = sorted({str(label) for labels in parsed_labels for label in labels})
    id_labels_present = sorted(
        {
            str(label)
            for label in unique_labels
            if (label in id_classes) or (label not in ood_classes)
        }
    )
    ood_labels_present = sorted({str(label) for label in unique_labels if label in ood_classes})

    id_record_count = sum(
        1
        for labels in parsed_labels
        if any((label in id_classes) or (label not in ood_classes) for label in labels)
    )
    ood_record_count = sum(1 for labels in parsed_labels if any(label in ood_classes for label in labels))

    warnings: list[str] = []
    if 0 < ood_record_count < window_size:
        warnings.append(
            f"Warning: OOD record count {ood_record_count} < window_size {window_size}; "
            "OOD windows may be insufficient."
        )

    skip_reason = ""
    if id_record_count <= 0:
        skip_reason = NO_ID_REASON
    elif ood_record_count <= 0:
        skip_reason = NO_OOD_REASON

    return {
        "records": int(len(df_group)),
        "id_records": int(id_record_count),
        "ood_records": int(ood_record_count),
        "unique_labels": unique_labels,
        "id_labels_present": id_labels_present,
        "ood_labels_present": ood_labels_present,
        "has_id_records": bool(id_record_count > 0),
        "has_ood_records": bool(ood_record_count > 0),
        "warnings": warnings,
        "skip_reason": skip_reason,
        "is_viable": not bool(skip_reason),
    }


def _dataset_stats_payload(viability: dict[str, Any]) -> dict[str, Any]:
    return {
        "records": int(viability.get("records", 0)),
        "id_records": int(viability.get("id_records", 0)),
        "ood_records": int(viability.get("ood_records", 0)),
        "unique_labels": list(viability.get("unique_labels", []) or []),
        "id_labels_present": list(viability.get("id_labels_present", []) or []),
        "ood_labels_present": list(viability.get("ood_labels_present", []) or []),
        "warnings": list(viability.get("warnings", []) or []),
    }


def _group_stats_row(
    group: str,
    viability: dict[str, Any],
    label_config: dict[str, Any],
    status: str,
    reason: str,
) -> dict[str, Any]:
    return {
        "Group": str(group),
        "Records": int(viability.get("records", 0)),
        "ID Records": int(viability.get("id_records", 0)),
        "OOD Records": int(viability.get("ood_records", 0)),
        "Unique Labels": _join_labels(list(viability.get("unique_labels", []) or [])),
        "ID Labels Present": _join_labels(list(viability.get("id_labels_present", []) or [])),
        "OOD Labels Present": _join_labels(list(viability.get("ood_labels_present", []) or [])),
        "ID Classes Used": str(label_config.get("id_classes_csv", "") or ""),
        "OOD Classes Used": str(label_config.get("ood_classes_csv", "") or ""),
        "Status": str(status),
        "Reason": _combine_reason(reason, list(viability.get("warnings", []) or [])),
    }


def _is_not_enough_ood_message(text: Any) -> bool:
    return "not enough ood windows" in str(text or "").strip().lower()


def _detect_not_enough_ood_failure(output_root: Path, comparison_summary: dict[str, Any]) -> str:
    if list(comparison_summary.get("successful_methods", []) or []):
        return ""
    for item in comparison_summary.get("methods", []):
        note = str(item.get("note", "") or "")
        if _is_not_enough_ood_message(note):
            return NOT_ENOUGH_OOD_REASON
    failed_methods_path = output_root / "failed_methods.json"
    if failed_methods_path.exists():
        for item in load_json(failed_methods_path):
            for field in ("stderr_tail", "stdout_tail"):
                if _is_not_enough_ood_message(item.get(field)):
                    return NOT_ENOUGH_OOD_REASON
    return ""


def _load_summary_from_dir(path: Path) -> dict[str, Any]:
    summary_path = path / "comparison_summary.json"
    if not summary_path.exists():
        raise FileNotFoundError(f"comparison_summary.json was not found in {path}")
    return load_json(summary_path)


def _load_table(path: Path, columns: list[str]) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(f"{path.name} was not found in {path.parent}")
    return pd.read_csv(path).reindex(columns=columns)


def _group_method_metrics(summary: dict[str, Any]) -> dict[str, dict[str, Any]]:
    payload: dict[str, dict[str, Any]] = {}
    for item in summary.get("methods", []):
        raw_method_name = str(item.get("method_name") or item.get("display_name") or "")
        method_name = comparison_runner.canonical_method_name(raw_method_name)
        if not method_name:
            continue
        spec = comparison_runner.METHOD_BY_NAME.get(method_name)
        payload[method_name] = {
            "display_name": str(spec.display_name if spec is not None else (item.get("display_name") or method_name)),
            "backend_name": item.get("backend_name", spec.backend_name if spec is not None else None),
            "heterogeneity_handling": item.get(
                "heterogeneity_handling",
                comparison_runner._heterogeneity_handling_mode(spec) if spec is not None else None,
            ),
            "heterogeneity_handling_description": item.get(
                "heterogeneity_handling_description",
                comparison_runner._heterogeneity_handling_description(spec) if spec is not None else "",
            ),
            "status": str(item.get("status", "success")),
            "note": str(item.get("note", "") or ""),
            "known_detection": dict(item.get("known_detection", {}) or {}),
            "ood_detection": dict(item.get("ood_detection", {}) or {}),
            "timing": dict(item.get("timing", {}) or {}),
        }
    return payload


def _precheck_fields(precheck_result: Optional[dict[str, Any]]) -> dict[str, Any]:
    if not precheck_result:
        return {"split_source": None, "window_counts": {}}
    return {
        "split_source": precheck_result.get("split_source"),
        "window_counts": dict(precheck_result.get("window_counts", {}) or {}),
    }


def _skip_record(
    *,
    group: str,
    safe_group: str,
    record_count: int,
    label_config: dict[str, Any],
    temp_input: Path,
    output_root: Path,
    reason: str,
    precheck_result: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    return {
        "group": group,
        "safe_group": safe_group,
        "record_count": int(record_count),
        "temp_input": str(temp_input),
        "output_root": str(output_root),
        "skip_reason": str(reason),
        **_label_config_fields(label_config),
        **_precheck_fields(precheck_result),
    }


def _failed_record(
    *,
    group: str,
    safe_group: str,
    record_count: int,
    label_config: dict[str, Any],
    temp_input: Path,
    output_root: Path,
    error_message: str,
    precheck_result: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    return {
        "group": group,
        "safe_group": safe_group,
        "record_count": int(record_count),
        "temp_input": str(temp_input),
        "output_root": str(output_root),
        "error_message": str(error_message),
        **_label_config_fields(label_config),
        **_precheck_fields(precheck_result),
    }


def _format_latex_value(value: Any) -> str:
    if value is None or pd.isna(value):
        return ""
    if isinstance(value, (int, float)):
        return f"{float(value):.4f}"
    return latex_escape(str(value))


def _latex_row(values: list[Any], highlight: bool = False) -> str:
    cells = []
    for value in values:
        text = _format_latex_value(value)
        if highlight and text:
            text = rf"\textbf{{{text}}}"
        cells.append(text)
    return " & ".join(cells) + r" \\"


def _write_tables(
    rows: list[dict[str, Any]],
    columns: list[str],
    output_csv: Path,
    output_tex: Path,
    caption: str,
) -> None:
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    frame = pd.DataFrame(rows).reindex(columns=columns)
    frame.to_csv(output_csv, index=False)

    latex_frame = frame
    filtered = False
    if len(frame) > LATEX_FULL_ROW_LIMIT:
        reduced = frame[frame["Method"].isin(LATEX_PRIORITY_METHODS)].copy()
        if not reduced.empty:
            latex_frame = reduced
            filtered = len(reduced) < len(frame)
    caption_text = caption
    if filtered:
        caption_text += " The CSV contains the full per-group results; the LaTeX table keeps the major baselines for readability."

    header = " & ".join(latex_escape(str(column)) for column in columns) + r" \\"
    aligns = "ll" + "r" * (len(columns) - 2)
    lines = [
        r"\begin{longtable}{" + aligns + "}",
        rf"\caption{{{latex_escape(caption_text)}}} \\",
        r"\toprule",
        header,
        r"\midrule",
        r"\endfirsthead",
        r"\toprule",
        header,
        r"\midrule",
        r"\endhead",
        r"\midrule",
        rf"\multicolumn{{{len(columns)}}}{{r}}{{Continued on next page}} \\",
        r"\midrule",
        r"\endfoot",
        r"\bottomrule",
        r"\endlastfoot",
    ]
    for row in latex_frame.itertuples(index=False, name=None):
        highlight = len(row) > 1 and str(row[1]) == "UCS-OODID"
        lines.append(_latex_row(list(row), highlight=highlight))
    lines.append(r"\end{longtable}")
    output_tex.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _method_ood_metric(methods: dict[str, dict[str, Any]], method_name: str, metric_key: str) -> Optional[float]:
    method = methods.get(method_name, {}) or {}
    section = method.get("ood_detection", {}) or {}
    return _safe_float(section.get(metric_key))


def _best_baseline_ood_f1(methods: dict[str, dict[str, Any]]) -> Optional[float]:
    candidates = []
    for method_name, method in methods.items():
        if method_name == UCS_OODID_METHOD:
            continue
        numeric = _safe_float((method.get("ood_detection", {}) or {}).get("ood_f1"))
        if numeric is not None:
            candidates.append(numeric)
    if not candidates:
        return None
    return float(max(candidates))


def _build_main_table_rows(successful_group_runs: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for group_run in successful_group_runs:
        methods = dict(group_run.get("methods", {}) or {})
        rows.append(
            {
                "Dataset / Group": str(group_run.get("group", "")),
                "Best Baseline OOD-F1": _format_float(_best_baseline_ood_f1(methods)),
                "ReCDA-style OOD-F1": _format_float(
                    _method_ood_metric(methods, RECDA_METHOD, "ood_f1")
                ),
                "UCS-OODID OOD-F1": _format_float(_method_ood_metric(methods, UCS_OODID_METHOD, "ood_f1")),
                "UCS-OODID AUROC": _format_float(_method_ood_metric(methods, UCS_OODID_METHOD, "auroc")),
                "UCS-OODID FPR@theta": _format_float(
                    _method_ood_metric(methods, UCS_OODID_METHOD, "fpr_at_threshold")
                ),
            }
        )
    return rows


def _write_main_table(rows: list[dict[str, Any]], output_csv: Path, output_tex: Path) -> None:
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    frame = pd.DataFrame(rows).reindex(columns=MAIN_TABLE_COLUMNS)
    frame.to_csv(output_csv, index=False)

    aligns = "l" + "c" * (len(MAIN_TABLE_COLUMNS) - 1)
    lines = [
        r"\begin{table*}[t]",
        r"\centering",
        rf"\caption{{{MAIN_TABLE_CAPTION}}}",
        r"\begin{tabular}{" + aligns + "}",
        r"\toprule",
        " & ".join(latex_escape(str(column)) for column in MAIN_TABLE_COLUMNS) + r" \\",
        r"\midrule",
    ]
    for row in frame.itertuples(index=False, name=None):
        lines.append(" & ".join(_format_latex_value(value) for value in row) + r" \\")
    lines.extend([r"\bottomrule", r"\end{tabular}", r"\end{table*}"])
    output_tex.write_text("\n".join(lines) + "\n", encoding="utf-8")


def run_homogeneous_experiments(
    args,
    comparison_executor: Optional[Callable[[Any], dict[str, Any]]] = None,
    group_prechecker: Optional[Callable[[Any, Path], dict[str, Any]]] = None,
) -> dict[str, Any]:
    executor = comparison_executor or _default_comparison_executor
    prechecker = group_prechecker or _default_group_prechecker

    output_root = Path(getattr(args, "output_root", "runs/homogeneous_experiments"))
    output_root.mkdir(parents=True, exist_ok=True)
    temp_input_root = output_root / "_temp_inputs"
    temp_precheck_root = output_root / "_temp_prechecks"
    temp_input_root.mkdir(parents=True, exist_ok=True)
    temp_precheck_root.mkdir(parents=True, exist_ok=True)

    df = load_records(args.input)
    group_col = str(getattr(args, "group_col", "uav_id") or "").strip()
    if not group_col:
        raise ValueError("Homogeneous experiments require --group_col.")
    selected_groups = _resolve_selected_groups(df, group_col, str(getattr(args, "groups", "") or ""))
    if not selected_groups:
        raise ValueError("No groups were found in the input data.")
    safe_group_names = _build_safe_group_names(selected_groups)
    per_group_label_config_path = str(getattr(args, "per_group_label_config", "") or "").strip()
    per_group_label_config = _load_per_group_label_config(per_group_label_config_path)

    min_records = int(getattr(args, "min_records", 100))
    min_test_ood_windows = int(getattr(args, "min_test_ood_windows", 5))
    keep_temp_csv = bool(getattr(args, "keep_temp_csv", False))

    successful_groups: list[str] = []
    successful_group_runs: list[dict[str, Any]] = []
    skipped_groups: list[dict[str, Any]] = []
    failed_groups: list[dict[str, Any]] = []
    group_stats_rows: list[dict[str, Any]] = []
    known_rows: list[dict[str, Any]] = []
    ood_rows: list[dict[str, Any]] = []
    resolved_group_label_configs: dict[str, dict[str, Any]] = {}

    for group_value in selected_groups:
        group_text = str(group_value)
        safe_group = safe_group_names[group_text]
        temp_input_path = temp_input_root / f"{safe_group}.csv"
        precheck_dir = temp_precheck_root / safe_group
        group_output_root = output_root / f"group_{safe_group}"
        group_df = df.loc[df[group_col].eq(group_value)].copy()
        record_count = int(len(group_df))
        label_config = _resolve_group_label_config(args, group_text, per_group_label_config)
        group_args = _group_args_with_label_config(args, label_config)
        resolved_group_label_configs[group_text] = _label_config_fields(label_config)
        viability = check_group_viability(group_df, group_args)
        precheck_result: Optional[dict[str, Any]] = None
        final_status = "failed"
        final_reason = ""

        save_records(group_df, temp_input_path)
        shutil.rmtree(precheck_dir, ignore_errors=True)
        precheck_dir.mkdir(parents=True, exist_ok=True)

        try:
            if record_count < min_records:
                final_status = "skipped"
                final_reason = f"record_count {record_count} < min_records {min_records}"
                skipped_groups.append(
                    _skip_record(
                        group=group_text,
                        safe_group=safe_group,
                        record_count=record_count,
                        label_config=label_config,
                        temp_input=temp_input_path,
                        output_root=group_output_root,
                        reason=final_reason,
                    )
                )
                continue

            if not bool(viability.get("is_viable", False)):
                final_status = "skipped"
                final_reason = str(viability.get("skip_reason", "") or "")
                skipped_groups.append(
                    _skip_record(
                        group=group_text,
                        safe_group=safe_group,
                        record_count=record_count,
                        label_config=label_config,
                        temp_input=temp_input_path,
                        output_root=group_output_root,
                        reason=final_reason,
                    )
                )
                continue

            precheck_args = _build_precheck_args(group_args, input_path=temp_input_path)
            try:
                precheck_result = prechecker(precheck_args, precheck_dir)
            except ValueError as exc:
                final_status = "skipped"
                final_reason = NOT_ENOUGH_OOD_REASON if _is_not_enough_ood_message(exc) else f"{type(exc).__name__}: {exc}"
                skipped_groups.append(
                    _skip_record(
                        group=group_text,
                        safe_group=safe_group,
                        record_count=record_count,
                        label_config=label_config,
                        temp_input=temp_input_path,
                        output_root=group_output_root,
                        reason=final_reason,
                        precheck_result=precheck_result,
                    )
                )
                continue

            test_ood_windows = int(dict(precheck_result.get("window_counts", {}) or {}).get("test_ood", 0))
            if test_ood_windows < min_test_ood_windows:
                final_status = "skipped"
                final_reason = f"test_ood windows {test_ood_windows} < min_test_ood_windows {min_test_ood_windows}"
                skipped_groups.append(
                    _skip_record(
                        group=group_text,
                        safe_group=safe_group,
                        record_count=record_count,
                        label_config=label_config,
                        temp_input=temp_input_path,
                        output_root=group_output_root,
                        reason=final_reason,
                        precheck_result=precheck_result,
                    )
                )
                continue

            executor(_clone_args(group_args, input_path=temp_input_path, output_root=group_output_root))
            comparison_summary = _load_summary_from_dir(group_output_root)
            ood_failure_reason = _detect_not_enough_ood_failure(group_output_root, comparison_summary)
            if ood_failure_reason:
                final_status = "skipped"
                final_reason = ood_failure_reason
                skipped_groups.append(
                    _skip_record(
                        group=group_text,
                        safe_group=safe_group,
                        record_count=record_count,
                        label_config=label_config,
                        temp_input=temp_input_path,
                        output_root=group_output_root,
                        reason=final_reason,
                        precheck_result=precheck_result,
                    )
                )
                continue
            known_frame = _load_table(group_output_root / "known_detection_table.csv", KNOWN_COLUMNS[1:])
            ood_frame = _load_table(group_output_root / "ood_detection_table.csv", OOD_COLUMNS[1:])

            known_frame.insert(0, "Group", group_text)
            ood_frame.insert(0, "Group", group_text)
            known_rows.extend(known_frame.to_dict("records"))
            ood_rows.extend(ood_frame.to_dict("records"))

            final_status = "success"
            final_reason = ""
            successful_groups.append(group_text)
            successful_group_runs.append(
                {
                    "group": group_text,
                    "safe_group": safe_group,
                    "record_count": record_count,
                    "temp_input": str(temp_input_path),
                    "output_root": str(group_output_root),
                    "comparison_summary_path": str(group_output_root / "comparison_summary.json"),
                    "known_detection_table": str(group_output_root / "known_detection_table.csv"),
                    "ood_detection_table": str(group_output_root / "ood_detection_table.csv"),
                    "selected_methods": list(comparison_summary.get("selected_methods", [])),
                    "successful_methods": list(comparison_summary.get("successful_methods", [])),
                    "skipped_methods": list(comparison_summary.get("skipped_methods", [])),
                    "failed_methods": list(comparison_summary.get("failed_methods", [])),
                    "dataset_stats": {
                        **_dataset_stats_payload(viability),
                        **_label_config_fields(label_config),
                    },
                    **_label_config_fields(label_config),
                    "methods": _group_method_metrics(comparison_summary),
                    **_precheck_fields(precheck_result),
                }
            )
        except Exception as exc:
            if _is_not_enough_ood_message(exc):
                final_status = "skipped"
                final_reason = NOT_ENOUGH_OOD_REASON
                skipped_groups.append(
                    _skip_record(
                        group=group_text,
                        safe_group=safe_group,
                        record_count=record_count,
                        label_config=label_config,
                        temp_input=temp_input_path,
                        output_root=group_output_root,
                        reason=final_reason,
                        precheck_result=precheck_result,
                    )
                )
            else:
                final_status = "failed"
                final_reason = f"{type(exc).__name__}: {exc}"
                failed_groups.append(
                    _failed_record(
                        group=group_text,
                        safe_group=safe_group,
                        record_count=record_count,
                        label_config=label_config,
                        temp_input=temp_input_path,
                        output_root=group_output_root,
                        error_message=final_reason,
                        precheck_result=precheck_result,
                    )
                )
        finally:
            group_stats_rows.append(_group_stats_row(group_text, viability, label_config, final_status, final_reason))
            shutil.rmtree(precheck_dir, ignore_errors=True)
            if not keep_temp_csv:
                temp_input_path.unlink(missing_ok=True)

    failed_groups_json = output_root / "failed_groups.json"
    group_dataset_stats_csv = output_root / "group_dataset_stats.csv"
    known_csv = output_root / "homogeneous_known_detection_table.csv"
    known_tex = output_root / "homogeneous_known_detection_table.tex"
    ood_csv = output_root / "homogeneous_ood_detection_table.csv"
    ood_tex = output_root / "homogeneous_ood_detection_table.tex"
    main_csv = output_root / "homogeneous_main_table.csv"
    main_tex = output_root / "homogeneous_main_table.tex"
    summary_json = output_root / "homogeneous_summary.json"

    save_json(failed_groups, failed_groups_json)
    pd.DataFrame(group_stats_rows).reindex(columns=GROUP_STATS_COLUMNS).to_csv(group_dataset_stats_csv, index=False)
    _write_tables(known_rows, KNOWN_COLUMNS, known_csv, known_tex, KNOWN_CAPTION)
    _write_tables(ood_rows, OOD_COLUMNS, ood_csv, ood_tex, OOD_CAPTION)
    _write_main_table(_build_main_table_rows(successful_group_runs), main_csv, main_tex)

    summary = {
        "input": str(args.input),
        "output_root": str(output_root),
        "group_col": group_col,
        "groups": [str(value) for value in selected_groups],
        "successful_groups": successful_groups,
        "skipped_groups": skipped_groups,
        "failed_groups": failed_groups,
        "resolved_group_label_configs": resolved_group_label_configs,
        "group_dataset_stats": group_stats_rows,
        "group_results": successful_group_runs,
        "config": {
            "label_col": str(getattr(args, "label_col", "label")),
            "timestamp_col": str(getattr(args, "timestamp_col", "timestamp")),
            "record_id_col": str(getattr(args, "record_id_col", "record_id")),
            "window_mode": str(getattr(args, "window_mode", "count")),
            "window_size": int(getattr(args, "window_size", 32)),
            "stride": int(getattr(args, "stride", 16)),
            "normalization_mode": str(getattr(args, "normalization_mode", "global")),
            "q_ood": float(getattr(args, "q_ood", 0.90)),
            "epochs": int(getattr(args, "epochs", 10)),
            "seed": int(getattr(args, "seed", 42)),
            "device": str(getattr(args, "device", "auto")),
            "methods": str(getattr(args, "methods", "")),
            "skip_sklearn": bool(getattr(args, "skip_sklearn", False)),
            "skip_neural": bool(getattr(args, "skip_neural", False)),
            "per_group_label_config": per_group_label_config_path,
            "min_records": min_records,
            "min_test_ood_windows": min_test_ood_windows,
            "keep_temp_csv": keep_temp_csv,
        },
        "tables": {
            "group_dataset_stats_csv": str(group_dataset_stats_csv),
            "homogeneous_known_detection_csv": str(known_csv),
            "homogeneous_known_detection_tex": str(known_tex),
            "homogeneous_ood_detection_csv": str(ood_csv),
            "homogeneous_ood_detection_tex": str(ood_tex),
            "homogeneous_main_table_csv": str(main_csv),
            "homogeneous_main_table_tex": str(main_tex),
        },
        "failed_groups_file": str(failed_groups_json),
    }
    save_json(summary, summary_json)

    if not keep_temp_csv:
        shutil.rmtree(temp_input_root, ignore_errors=True)
    shutil.rmtree(temp_precheck_root, ignore_errors=True)
    return summary


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run per-group homogeneous comparison experiments from a mixed input CSV.")
    parser.add_argument("--input", required=True)
    parser.add_argument("--output_root", default="runs/homogeneous_experiments")
    parser.add_argument("--output_dir", dest="output_root", help=argparse.SUPPRESS)
    parser.add_argument("--label_col", default="label")
    parser.add_argument("--timestamp_col", default="timestamp")
    parser.add_argument("--record_id_col", default="record_id")
    parser.add_argument("--group_col", default="uav_id")
    parser.add_argument("--groups", default="", help="Optional comma-separated subset of groups to evaluate.")
    parser.add_argument("--id_classes", required=True)
    parser.add_argument("--ood_classes", required=True)
    parser.add_argument("--window_mode", default="count", choices=["count", "time", "adaptive"])
    parser.add_argument("--window_size", type=int, default=32)
    parser.add_argument("--stride", type=int, default=16)
    parser.add_argument(
        "--normalization_mode",
        default="global",
        choices=["global", "group"],
        help="Homogeneous experiments default to global normalization; pass group to opt into group-wise scaling.",
    )
    parser.add_argument("--q_ood", type=float, default=0.90)
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--device", default="auto")
    parser.add_argument("--methods", default="", help="Optional comma-separated subset of methods to run.")
    parser.add_argument("--skip_sklearn", action="store_true")
    parser.add_argument("--skip_neural", action="store_true")
    parser.add_argument("--per_group_label_config", default="")
    parser.add_argument("--min_records", type=int, default=100)
    parser.add_argument("--min_test_ood_windows", type=int, default=5)
    parser.add_argument("--keep_temp_csv", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    summary = run_homogeneous_experiments(args)
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
