#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ucs_oodid.io import load_records
from ucs_oodid.windowing import attach_parsed_labels, infer_all_labels


def run(cmd):
    print("RUN", " ".join(map(str, cmd)), flush=True)
    subprocess.run(list(map(str, cmd)), check=True)


def main():
    p = argparse.ArgumentParser(description="RQ2/RQ5 leave-one-class-out open-set protocol.")
    p.add_argument("--input", required=True)
    p.add_argument("--output_dir", required=True)
    p.add_argument("--label_col", default="label")
    p.add_argument("--exclude_holdouts", default="benign")
    p.add_argument("--holdout_classes", default="", help="Comma-separated classes. If empty, all non-excluded labels are held out one by one.")
    p.add_argument("--train_args", default="")
    p.add_argument("--present_class_min_support", type=int, default=1)
    args = p.parse_args()
    df = attach_parsed_labels(load_records(args.input), args.label_col)
    labels = infer_all_labels(df, args.label_col)
    excludes = {x.strip() for x in args.exclude_holdouts.split(',') if x.strip()}
    holdouts = [x.strip() for x in args.holdout_classes.split(',') if x.strip()] or [x for x in labels if x not in excludes]
    out = Path(args.output_dir); out.mkdir(parents=True, exist_ok=True)
    train_py = Path(__file__).with_name("train.py")
    results = []
    for hold in holdouts:
        id_classes = [x for x in labels if x != hold]
        run_dir = out / f"loco_{hold}"
        cmd = [
            sys.executable,
            train_py,
            "--input",
            args.input,
            "--output_dir",
            run_dir,
            "--label_col",
            args.label_col,
            "--id_classes",
            ",".join(id_classes),
            "--ood_classes",
            hold,
            "--present_class_min_support",
            args.present_class_min_support,
        ]
        if args.train_args:
            cmd += args.train_args.split()
        run(cmd)
        report_path = run_dir / "eval_report.json"
        report = json.loads(report_path.read_text(encoding="utf-8")) if report_path.exists() else {}
        results.append({"holdout_class": hold, "id_classes": id_classes, "report": report, "run_dir": str(run_dir)})
    (out / "loco_summary.json").write_text(json.dumps(results, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({"runs": len(results), "summary": str(out / "loco_summary.json")}, indent=2))

if __name__ == "__main__":
    main()
