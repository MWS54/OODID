#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ucs_oodid.io import load_records
from ucs_oodid.synthetic import make_synthetic_uav_metadata


def run(cmd):
    print("RUN", " ".join(map(str, cmd)), flush=True)
    subprocess.run(list(map(str, cmd)), check=True)


def resample_attack_ratio(df, ratio: float, label_col: str, benign_label: str, seed: int):
    rng = np.random.default_rng(seed)
    out = df.copy()
    labels = out[label_col].astype(str).tolist()
    attack_idx = [i for i, v in enumerate(labels) if v != benign_label]
    benign_idx = [i for i, v in enumerate(labels) if v == benign_label]
    target_attack = int(round(len(out) * ratio))
    if len(attack_idx) >= target_attack:
        keep_attack = set(rng.choice(attack_idx, target_attack, replace=False).tolist()) if target_attack > 0 else set()
        for i in attack_idx:
            if i not in keep_attack:
                out.at[i, label_col] = benign_label
    else:
        promote = min(target_attack - len(attack_idx), len(benign_idx))
        non_benign = sorted({v for v in labels if v != benign_label}) or ["dos"]
        for i in rng.choice(benign_idx, promote, replace=False).tolist():
            out.at[i, label_col] = rng.choice(non_benign)
    return out


def main():
    p = argparse.ArgumentParser(description="RQ1 mixed-window attack-ratio evaluation driver.")
    p.add_argument("--input", default="", help="Optional canonical dataset. If omitted, a synthetic UAV dataset is generated.")
    p.add_argument("--output_dir", required=True)
    p.add_argument("--ratios", default="0.05,0.10,0.20,0.50")
    p.add_argument("--records", type=int, default=6000)
    p.add_argument("--label_col", default="label")
    p.add_argument("--benign_label", default="benign")
    p.add_argument("--id_classes", default="benign,dos,mitm,spoof,replay,injection,scan")
    p.add_argument("--ood_classes", default="unknown_probe,unknown_burst")
    p.add_argument("--train_args", default="")
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--present_class_min_support", type=int, default=1)
    args = p.parse_args()
    out = Path(args.output_dir); out.mkdir(parents=True, exist_ok=True)
    base_df = load_records(args.input) if args.input else make_synthetic_uav_metadata(records=args.records, seed=args.seed)
    train_py = Path(__file__).with_name("train.py")
    summary = []
    for ratio_s in [x.strip() for x in args.ratios.split(',') if x.strip()]:
        ratio = float(ratio_s)
        df = resample_attack_ratio(base_df, ratio, args.label_col, args.benign_label, args.seed + int(ratio * 1000))
        data_path = out / f"mixed_ratio_{ratio:.2f}.csv"
        df.to_csv(data_path, index=False)
        run_dir = out / f"ratio_{ratio:.2f}"
        cmd = [
            sys.executable,
            train_py,
            "--input",
            data_path,
            "--output_dir",
            run_dir,
            "--label_col",
            args.label_col,
            "--id_classes",
            args.id_classes,
            "--ood_classes",
            args.ood_classes,
            "--present_class_min_support",
            args.present_class_min_support,
        ]
        if args.train_args:
            cmd += args.train_args.split()
        run(cmd)
        report_path = run_dir / "eval_report.json"
        report = json.loads(report_path.read_text(encoding="utf-8")) if report_path.exists() else {}
        summary.append({"attack_ratio": ratio, "data": str(data_path), "run_dir": str(run_dir), "report": report})
    (out / "mixed_window_ratio_summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({"runs": len(summary), "summary": str(out / "mixed_window_ratio_summary.json")}, indent=2))

if __name__ == "__main__":
    main()
