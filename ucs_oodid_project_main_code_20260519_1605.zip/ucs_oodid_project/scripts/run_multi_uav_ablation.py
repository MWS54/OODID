#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import math
import subprocess
import sys
from pathlib import Path
from typing import Any, Callable, Sequence

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ucs_oodid.io import load_json, save_json

FIXED_ENCODER_ABLATION = "transformer_only"
FIXED_WINDOW_MODE = "count"
FIXED_EPOCHS = 10
FIXED_Q_OOD = 0.90
FIXED_BANK_K = 5
FIXED_PRESENT_CLASS_MIN_SUPPORT = 1
DEFAULT_GROUP_THRESHOLD_MIN_RATIO = 1.0
DEFAULT_GROUP_THRESHOLD_MIN_SAMPLES = 10
DEFAULT_GROUP_EMBEDDING_DIM = 16

SUMMARY_COLUMNS = [
    "experiment_name",
    "normalization_mode",
    "fusion",
    "ood_threshold_mode",
    "group_threshold_strategy",
    "use_group_embedding",
    "id_micro_f1",
    "id_macro_f1",
    "id_mAP",
    "ood_auroc",
    "ood_aupr_out",
    "ood_fpr95",
    "ood_f1",
    "fpr_at_threshold",
    "average_detection_time_ms",
    "throughput_windows_per_s",
    "macro_uav_ood_f1",
    "worst_uav_ood_f1",
    "status",
    "output_dir",
]
LATEX_COLUMNS = [
    "Variant",
    "Fusion",
    "Group Norm.",
    "Group Emb.",
    "Group Thres.",
    "Micro-F1",
    "AUROC",
    "OOD-F1",
    "FPR@theta",
    "Time(ms)",
]


def make_ablation_config(
    experiment_name: str,
    *,
    normalization_mode: str,
    fusion: str,
    ood_threshold_mode: str,
    group_threshold_strategy: str,
    use_group_embedding: bool,
    group_threshold_min_ratio: float = DEFAULT_GROUP_THRESHOLD_MIN_RATIO,
    group_threshold_min_samples: int = DEFAULT_GROUP_THRESHOLD_MIN_SAMPLES,
    group_embedding_dim: int = DEFAULT_GROUP_EMBEDDING_DIM,
) -> dict[str, Any]:
    return {
        "experiment_name": str(experiment_name),
        "normalization_mode": str(normalization_mode),
        "fusion": str(fusion),
        "ood_threshold_mode": str(ood_threshold_mode),
        "group_threshold_strategy": str(group_threshold_strategy),
        "group_threshold_min_ratio": float(group_threshold_min_ratio),
        "group_threshold_min_samples": int(group_threshold_min_samples),
        "use_group_embedding": bool(use_group_embedding),
        "group_embedding_dim": int(group_embedding_dim),
    }


ABLATION_CONFIGS = [
    make_ablation_config(
        "base_global_mean",
        normalization_mode="global",
        fusion="mean",
        ood_threshold_mode="global",
        group_threshold_strategy="raw",
        use_group_embedding=False,
    ),
    make_ablation_config(
        "corr_fusion_only",
        normalization_mode="global",
        fusion="correlation_aware",
        ood_threshold_mode="global",
        group_threshold_strategy="raw",
        use_group_embedding=False,
    ),
    make_ablation_config(
        "group_norm_only",
        normalization_mode="group",
        fusion="correlation_aware",
        ood_threshold_mode="global",
        group_threshold_strategy="raw",
        use_group_embedding=False,
    ),
    make_ablation_config(
        "group_embedding_only",
        normalization_mode="global",
        fusion="correlation_aware",
        ood_threshold_mode="global",
        group_threshold_strategy="raw",
        use_group_embedding=True,
        group_embedding_dim=16,
    ),
    make_ablation_config(
        "group_threshold_raw",
        normalization_mode="global",
        fusion="correlation_aware",
        ood_threshold_mode="group",
        group_threshold_strategy="raw",
        use_group_embedding=False,
    ),
    make_ablation_config(
        "group_threshold_conservative",
        normalization_mode="global",
        fusion="correlation_aware",
        ood_threshold_mode="group",
        group_threshold_strategy="conservative",
        group_threshold_min_ratio=1.0,
        use_group_embedding=False,
    ),
    make_ablation_config(
        "full_ucs_oodid",
        normalization_mode="group",
        fusion="correlation_aware",
        ood_threshold_mode="group",
        group_threshold_strategy="conservative",
        group_threshold_min_ratio=1.0,
        use_group_embedding=True,
        group_embedding_dim=16,
    ),
]

VARIANT_LABELS = {
    "base_global_mean": "Base Global+Mean",
    "corr_fusion_only": "Corr. Fusion Only",
    "group_norm_only": "Group Norm. Only",
    "group_embedding_only": "Group Emb. Only",
    "group_threshold_raw": "Group Thres. Raw",
    "group_threshold_conservative": "Group Thres. Cons.",
    "full_ucs_oodid": "Full UCS-OODID",
}


def run(cmd: Sequence[object]) -> None:
    print("RUN", " ".join(map(str, cmd)), flush=True)
    subprocess.run(list(map(str, cmd)), check=True)


def latex_escape(text: str) -> str:
    replacements = {
        "\\": r"\textbackslash{}",
        "&": r"\&",
        "%": r"\%",
        "$": r"\$",
        "#": r"\#",
        "_": r"\_",
        "{": r"\{",
        "}": r"\}",
        "~": r"\textasciitilde{}",
        "^": r"\textasciicircum{}",
    }
    return "".join(replacements.get(ch, ch) for ch in text)


def safe_load_json(path: Path) -> dict:
    if not path.exists():
        return {}
    return load_json(path)


def clear_known_outputs(output_dir: Path) -> None:
    for filename in [
        "artifact.pt",
        "eval_report.json",
        "leakage_report.json",
        "detections.jsonl",
        "record_scores.json",
        "group_detection_summary.json",
    ]:
        path = output_dir / filename
        if path.exists():
            path.unlink()


def _valid_group_metric_values(payload: dict, metric: str) -> list[float]:
    values = []
    for item in payload.values():
        value = item.get(metric)
        if value is None:
            continue
        try:
            value = float(value)
        except (TypeError, ValueError):
            continue
        if math.isnan(value):
            continue
        values.append(value)
    return values


def _sorted_group_names(*payloads: dict) -> list[str]:
    groups: set[str] = set()
    for payload in payloads:
        for group in payload:
            name = str(group).strip()
            if name:
                groups.add(name)
    return sorted(groups)


def _mean_or_none(values: list[float]) -> float | None:
    if not values:
        return None
    return float(sum(values) / len(values))


def _format_latex_value(value: Any) -> str:
    if value is None or pd.isna(value):
        return ""
    if isinstance(value, str):
        return latex_escape(value)
    numeric = float(value)
    if numeric.is_integer():
        return str(int(numeric))
    return f"{numeric:.4f}"


def _group_threshold_label(row: dict[str, Any]) -> str:
    if str(row.get("ood_threshold_mode", "global")) != "group":
        return "Global"
    strategy = str(row.get("group_threshold_strategy", "raw"))
    if strategy == "conservative":
        return "Group (cons.)"
    if strategy == "raw":
        return "Group (raw)"
    return f"Group ({strategy})"


def _latex_summary_frame(rows: list[dict[str, Any]]) -> pd.DataFrame:
    latex_rows = []
    for row in rows:
        latex_rows.append(
            {
                "Variant": VARIANT_LABELS.get(row["experiment_name"], row["experiment_name"]),
                "Fusion": row.get("fusion"),
                "Group Norm.": "Yes" if str(row.get("normalization_mode")) == "group" else "No",
                "Group Emb.": "Yes" if bool(row.get("use_group_embedding")) else "No",
                "Group Thres.": _group_threshold_label(row),
                "Micro-F1": row.get("id_micro_f1"),
                "AUROC": row.get("ood_auroc"),
                "OOD-F1": row.get("ood_f1"),
                "FPR@theta": row.get("fpr_at_threshold"),
                "Time(ms)": row.get("average_detection_time_ms"),
                "_highlight": row.get("experiment_name") == "full_ucs_oodid",
            }
        )
    return pd.DataFrame(latex_rows)


def write_ablation_latex(rows: list[dict[str, Any]], output_tex: Path) -> None:
    frame = _latex_summary_frame(rows)
    output_tex.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        r"\begin{table}[t]",
        r"\centering",
        r"\caption{UCS-OODID component ablation under the same metadata-window protocol.}",
        r"\begin{tabular}{llccc|rrrrr}",
        r"\toprule",
        " & ".join(latex_escape(column) for column in LATEX_COLUMNS) + r" \\",
        r"\midrule",
    ]
    for row in frame.itertuples(index=False, name=None):
        highlight = bool(row[-1])
        cells = []
        for value in row[:-1]:
            text = _format_latex_value(value)
            if highlight and text:
                text = rf"\textbf{{{text}}}"
            cells.append(text)
        lines.append(" & ".join(cells) + r" \\")
    lines.extend([r"\bottomrule", r"\end{tabular}", r"\end{table}"])
    output_tex.write_text("\n".join(lines) + "\n", encoding="utf-8")


def build_train_command(args, config: dict, output_dir: Path) -> list[object]:
    train_py = Path(__file__).with_name("train.py")
    cmd: list[object] = [
        sys.executable,
        train_py,
        "--input",
        args.input,
        "--output_dir",
        output_dir,
        "--label_col",
        args.label_col,
        "--timestamp_col",
        args.timestamp_col,
        "--record_id_col",
        args.record_id_col,
        "--group_col",
        args.group_col,
        "--id_classes",
        args.id_classes,
        "--ood_classes",
        args.ood_classes,
        "--window_mode",
        FIXED_WINDOW_MODE,
        "--window_size",
        str(args.window_size),
        "--stride",
        str(args.stride),
        "--epochs",
        str(FIXED_EPOCHS),
        "--encoder_ablation",
        FIXED_ENCODER_ABLATION,
        "--fusion",
        config["fusion"],
        "--normalization_mode",
        config["normalization_mode"],
        "--ood_threshold_mode",
        config["ood_threshold_mode"],
        "--group_threshold_strategy",
        config["group_threshold_strategy"],
        "--group_threshold_min_ratio",
        str(config["group_threshold_min_ratio"]),
        "--group_threshold_min_samples",
        str(config["group_threshold_min_samples"]),
        "--bank_k",
        str(FIXED_BANK_K),
        "--q_ood",
        str(FIXED_Q_OOD),
        "--present_class_min_support",
        str(FIXED_PRESENT_CLASS_MIN_SUPPORT),
    ]
    benign_label = str(getattr(args, "benign_label", "benign") or "benign").strip()
    if benign_label:
        cmd.extend(["--benign_label", benign_label])
    seed = getattr(args, "seed", None)
    if seed is not None:
        cmd.extend(["--seed", str(seed)])
    if config["use_group_embedding"]:
        cmd.extend(
            [
                "--use_group_embedding",
                "--group_embedding_dim",
                str(config["group_embedding_dim"]),
            ]
        )
    if args.device and str(args.device).strip().lower() != "auto":
        cmd.extend(["--device", args.device])
    if bool(getattr(args, "allow_ports", False)):
        cmd.append("--allow_ports")
    return cmd


def build_ablation_summary_row(
    config: dict,
    eval_report: dict | None = None,
    status: str = "success",
    error_message: str | None = None,
) -> dict:
    eval_report = eval_report or {}
    timing = eval_report.get("timing", {})
    id_test = eval_report.get("id_test", {})
    ood_test = eval_report.get("ood_test", {})
    id_test_by_group = eval_report.get("id_test_by_group", {})
    ood_test_by_group = eval_report.get("ood_test_by_group", {})
    group_names = _sorted_group_names(id_test_by_group, ood_test_by_group)
    id_group_micro_f1_values = _valid_group_metric_values(id_test_by_group, "micro_f1")
    ood_group_f1_values = _valid_group_metric_values(ood_test_by_group, "ood_f1")
    return {
        "experiment_name": config["experiment_name"],
        "normalization_mode": config["normalization_mode"],
        "fusion": config["fusion"],
        "ood_threshold_mode": config["ood_threshold_mode"],
        "group_threshold_strategy": config["group_threshold_strategy"],
        "group_threshold_min_ratio": config["group_threshold_min_ratio"],
        "group_threshold_min_samples": config["group_threshold_min_samples"],
        "use_group_embedding": bool(config["use_group_embedding"]),
        "group_embedding_dim": config["group_embedding_dim"] if config["use_group_embedding"] else None,
        "uav_count": len(group_names),
        "group_names": ",".join(group_names),
        "macro_uav_id_micro_f1": _mean_or_none(id_group_micro_f1_values),
        "id_micro_f1": id_test.get("micro_f1"),
        "id_macro_f1": id_test.get("macro_f1"),
        "id_mAP": id_test.get("mAP"),
        "ood_auroc": ood_test.get("auroc"),
        "ood_aupr_out": ood_test.get("aupr_out"),
        "ood_fpr95": ood_test.get("fpr95"),
        "ood_f1": ood_test.get("ood_f1"),
        "fpr_at_threshold": ood_test.get("fpr_at_threshold"),
        "average_detection_time_ms": timing.get("average_detection_time_ms"),
        "throughput_windows_per_s": timing.get("throughput_windows_per_s"),
        "test_windows": timing.get("test_windows"),
        "macro_uav_ood_f1": _mean_or_none(ood_group_f1_values),
        "worst_uav_ood_f1": min(ood_group_f1_values) if ood_group_f1_values else None,
        "status": status,
        "error_message": error_message,
    }


def run_single_ablation(args, config: dict, runner: Callable[[Sequence[object]], None] = run) -> dict:
    output_dir = Path(args.output_root) / config["experiment_name"]
    output_dir.mkdir(parents=True, exist_ok=True)
    clear_known_outputs(output_dir)
    status = "success"
    error_message = None
    try:
        runner(build_train_command(args, config=config, output_dir=output_dir))
        if not (output_dir / "eval_report.json").exists():
            raise FileNotFoundError(f"eval_report.json was not produced for {config['experiment_name']}")
    except Exception as exc:
        status = "failed"
        error_message = f"{type(exc).__name__}: {exc}"

    eval_report = safe_load_json(output_dir / "eval_report.json")
    row = build_ablation_summary_row(
        config=config,
        eval_report=eval_report,
        status=status,
        error_message=error_message,
    )
    row["output_dir"] = str(output_dir)
    return row


def write_ablation_summaries(rows: list[dict], output_root: Path, args) -> dict:
    output_root.mkdir(parents=True, exist_ok=True)
    summary_df = pd.DataFrame(rows)
    ordered_columns = SUMMARY_COLUMNS + [
        "group_threshold_min_ratio",
        "group_threshold_min_samples",
        "group_embedding_dim",
        "uav_count",
        "group_names",
        "macro_uav_id_micro_f1",
        "test_windows",
        "error_message",
    ]
    summary_df = summary_df.reindex(columns=ordered_columns)
    csv_path = output_root / "ablation_summary.csv"
    json_path = output_root / "ablation_summary.json"
    tex_path = output_root / "ablation_summary_table.tex"
    summary_df.to_csv(csv_path, index=False)
    write_ablation_latex(rows, tex_path)

    failed = [row["experiment_name"] for row in rows if row.get("status") == "failed"]
    payload = {
        "input": str(args.input),
        "output_root": str(output_root),
        "group_col": args.group_col,
        "label_col": args.label_col,
        "timestamp_col": args.timestamp_col,
        "record_id_col": args.record_id_col,
        "id_classes": args.id_classes,
        "ood_classes": args.ood_classes,
        "common_conditions": {
            "encoder_ablation": FIXED_ENCODER_ABLATION,
            "window_mode": FIXED_WINDOW_MODE,
            "window_size": int(args.window_size),
            "stride": int(args.stride),
            "epochs": FIXED_EPOCHS,
            "q_ood": FIXED_Q_OOD,
            "bank_k": FIXED_BANK_K,
            "present_class_min_support": FIXED_PRESENT_CLASS_MIN_SUPPORT,
            "seed": int(getattr(args, "seed", 42)),
        },
        "tables": {
            "ablation_summary_csv": str(csv_path),
            "ablation_summary_tex": str(tex_path),
        },
        "experiments": rows,
        "failed_experiments": failed,
    }
    save_json(payload, json_path)
    return payload


def run_multi_uav_ablation(args, runner: Callable[[Sequence[object]], None] = run) -> dict:
    rows = []
    for config in ABLATION_CONFIGS:
        rows.append(run_single_ablation(args, config=config, runner=runner))
    return write_ablation_summaries(rows, Path(args.output_root), args)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run UCS-OODID component ablations and summarize the results.")
    parser.add_argument("--input", required=True)
    parser.add_argument("--output_root", required=True)
    parser.add_argument("--id_classes", required=True)
    parser.add_argument("--ood_classes", required=True)
    parser.add_argument("--group_col", default="uav_id")
    parser.add_argument("--label_col", default="label")
    parser.add_argument("--timestamp_col", default="timestamp")
    parser.add_argument("--record_id_col", default="record_id")
    parser.add_argument("--window_size", type=int, default=32)
    parser.add_argument("--stride", type=int, default=16)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--device", default="auto")
    parser.add_argument("--benign_label", default="benign")
    parser.add_argument("--allow_ports", action="store_true")
    args = parser.parse_args()
    summary = run_multi_uav_ablation(args)
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
