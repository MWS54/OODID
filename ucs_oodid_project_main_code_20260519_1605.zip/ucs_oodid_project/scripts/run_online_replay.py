#!/usr/bin/env python3
"""Unified online replay driver: runs simulate_live_demo and writes normalized JSON/CSV metrics."""

from __future__ import annotations

import argparse
import csv
import json
import subprocess
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

DEFAULT_CFG = ROOT / "configs" / "demo_scene_default.yaml"


def _load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _fap_ratio(false_alerts: int, predicted: int) -> float | None:
    if predicted <= 0:
        return None
    return float(false_alerts) / float(predicted)


def build_simulate_command(args: argparse.Namespace) -> list[str]:
    return [
        sys.executable,
        str(ROOT / "scripts" / "simulate_live_demo.py"),
        "--config",
        str(args.config),
        "--online_detection",
        "--artifact",
        str(args.artifact),
        "--output_json",
        str(args.output_json),
        "--uav_count",
        str(args.uav_count),
        "--window_size",
        str(args.window_size),
        "--stride",
        str(args.stride),
        "--dataset_replay_mode",
        str(args.dataset_replay_mode),
        "--pure_ids_csv_path",
        str(args.replay_input),
        "--pure_ids_group_col",
        str(args.pure_ids_group_col),
        "--pure_ids_replay_records_per_uav_per_step",
        str(args.pure_ids_replay_records_per_uav_per_step),
        "--pure_ids_replay_stop_when_exhausted",
        str(args.pure_ids_replay_stop_when_exhausted).lower(),
        "--pure_ids_replay_keep_original_order",
        str(args.pure_ids_replay_keep_original_order).lower(),
        "--pure_ids_replay_no_mixing",
        str(args.pure_ids_replay_no_mixing).lower(),
        "--pure_ids_replay_split_filter",
        str(args.pure_ids_replay_split_filter),
        "--pure_ids_replay_reset_buffer_on_split_change",
        str(args.pure_ids_replay_reset_buffer_on_split_change).lower(),
        "--top_records",
        str(args.top_records),
    ]


def normalize_payload(raw: dict[str, Any], *, method: str, artifact: str, replay_input: str, window_size: int, stride: int) -> dict[str, Any]:
    diag = dict(raw.get("runtime_diagnostics") or {})
    predicted = int(raw.get("predicted_alert_window_count", raw.get("alert_count", 0)) or 0)
    false_w = int(raw.get("false_alert_window_count", raw.get("false_alert_count", 0)) or 0)
    benign_w = int(raw.get("benign_window_count", 0) or 0)
    out = {
        "method": method,
        "artifact_path": artifact,
        "replay_input": replay_input,
        "window_size": window_size,
        "stride": stride,
        "record_count": int(raw.get("record_count", 0) or 0),
        "window_count": int(raw.get("window_count", 0) or 0),
        "attack_window_count": int(raw.get("attack_window_count", diag.get("gt_attack_window_count", 0)) or 0),
        "ood_window_count": int(raw.get("ood_window_count", diag.get("gt_ood_window_count", 0)) or 0),
        "benign_window_count": benign_w,
        "predicted_alert_window_count": predicted,
        "false_alert_window_count": false_w,
        "false_alert_ratio": float(raw.get("false_alert_ratio", 0.0) or 0.0),
        "false_alerts_over_predicted_alerts": _fap_ratio(false_w, predicted),
        "response_action_count": int(raw.get("response_action_count", len(raw.get("response_events", []))) or 0),
        "average_alert_delay": float(raw.get("average_alert_delay", 0.0) or 0.0),
        "peak_ood_score": float(raw.get("peak_ood_score", 0.0) or 0.0),
        "average_ood_score": float(raw.get("average_ood_score", 0.0) or 0.0),
    }
    return out


def write_csv_row(path: Path, row: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(row.keys()))
        writer.writeheader()
        writer.writerow(row)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Run pure-IDS online replay with a selected artifact.")
    p.add_argument("--method", required=True, help="Logical method key (e.g. ucs_oodid, rapier_style).")
    p.add_argument("--artifact", required=True)
    p.add_argument("--window_size", type=int, default=32)
    p.add_argument("--stride", type=int, default=16)
    p.add_argument("--replay_input", required=True)
    p.add_argument("--output_json", required=True)
    p.add_argument("--output_csv", required=True)
    p.add_argument("--config", type=str, default=str(DEFAULT_CFG))
    p.add_argument("--uav_count", type=int, default=6)
    p.add_argument("--dataset_replay_mode", default="pure_ids_csv")
    p.add_argument("--pure_ids_group_col", default="uav_id")
    p.add_argument("--pure_ids_replay_records_per_uav_per_step", type=int, default=186)
    p.add_argument("--pure_ids_replay_stop_when_exhausted", action="store_true", default=True)
    p.add_argument("--pure_ids_replay_keep_original_order", action="store_true", default=True)
    p.add_argument("--pure_ids_replay_no_mixing", action="store_true", default=True)
    p.add_argument("--pure_ids_replay_split_filter", default="test_id,test_ood")
    p.add_argument("--pure_ids_replay_reset_buffer_on_split_change", action="store_true", default=True)
    p.add_argument("--top_records", type=int, default=5)
    return p.parse_args()


def main() -> None:
    args = parse_args()
    out_json = Path(args.output_json)
    out_json.parent.mkdir(parents=True, exist_ok=True)
    cmd = build_simulate_command(args)
    print("RUN", " ".join(cmd), flush=True)
    subprocess.run(cmd, check=True, cwd=str(ROOT))
    raw = _load_json(out_json)
    normalized = normalize_payload(
        raw,
        method=args.method,
        artifact=str(Path(args.artifact).as_posix()),
        replay_input=str(Path(args.replay_input).as_posix()),
        window_size=int(args.window_size),
        stride=int(args.stride),
    )
    merged = dict(raw)
    merged["normalized_online_replay_metrics"] = normalized
    merged["method"] = args.method
    out_json.write_text(json.dumps(merged, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    write_csv_row(Path(args.output_csv), normalized)
    print(json.dumps(normalized, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
