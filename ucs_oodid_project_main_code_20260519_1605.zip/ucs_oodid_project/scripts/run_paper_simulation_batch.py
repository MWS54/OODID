#!/usr/bin/env python3
"""Run online replay + deployment benchmark for all paper methods (window 32 / stride 16)."""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def run(cmd: list[object]) -> None:
    cmd_list = [str(part) for part in cmd]
    print("RUN", " ".join(cmd_list), flush=True)
    subprocess.run(cmd_list, check=True, cwd=str(ROOT))


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Batch replay + benchmark for paper simulation suite.")
    p.add_argument(
        "--replay_input",
        default="data/multi_uav_hetero_no_uav04_plus_uav06_uav07_experiment.csv",
    )
    p.add_argument("--deployment_dir", default="runs/paper_full_suite_6uav_window32_stride16/deployment")
    p.add_argument("--device", default="auto")
    p.add_argument(
        "--device_power_watt",
        type=float,
        default=None,
        help="Optional average device power for estimated energy fields on benchmarks.",
    )
    return p.parse_args()


def main() -> None:
    args = parse_args()
    deploy = Path(args.deployment_dir)
    deploy.mkdir(parents=True, exist_ok=True)
    replay_abs = ROOT / args.replay_input

    jobs = [
        {
            "slug": "rapier_style",
            "method": "rapier_style",
            "label": "RAPIER-style",
            "artifact": ROOT / "runs" / "final_rapier_style_window32_stride16" / "artifact.pt",
        },
        {
            "slug": "hypervision_style",
            "method": "hypervision_style",
            "label": "HyperVision-style",
            "artifact": ROOT / "runs" / "final_hypervision_style_window32_stride16" / "artifact.pt",
        },
        {
            "slug": "recda_style",
            "method": "recda_style",
            "label": "ReCDA-style",
            "artifact": ROOT / "runs" / "final_recda_style_window32_stride16" / "artifact.pt",
        },
        {
            "slug": "rids_style",
            "method": "rids_style",
            "label": "RIDS-style",
            "artifact": ROOT / "runs" / "final_rids_style_window32_stride16" / "artifact.pt",
        },
        {
            "slug": "ucs_oodid",
            "method": "ucs_oodid",
            "label": "UCS-OODID",
            "artifact": ROOT / "runs" / "final_ucs_oodid_window32_stride16" / "artifact.pt",
        },
    ]

    for job in jobs:
        if not job["artifact"].exists():
            raise FileNotFoundError(f"Missing artifact for {job['label']}: {job['artifact']}")

        replay_json = deploy / f"online_replay_{job['slug']}.json"
        replay_csv = deploy / f"online_replay_{job['slug']}.csv"
        bench_json = deploy / f"benchmark_{job['slug']}.json"
        bench_csv = deploy / f"benchmark_{job['slug']}.csv"

        run(
            [
                sys.executable,
                ROOT / "scripts" / "run_online_replay.py",
                "--method",
                job["method"],
                "--artifact",
                job["artifact"],
                "--window_size",
                "32",
                "--stride",
                "16",
                "--replay_input",
                replay_abs,
                "--output_json",
                replay_json,
                "--output_csv",
                replay_csv,
            ]
        )

        bench_cmd = [
            sys.executable,
            ROOT / "scripts" / "run_deployment_benchmark.py",
            "--method",
            job["method"],
            "--artifact",
            job["artifact"],
            "--input",
            replay_abs,
            "--output_json",
            bench_json,
            "--output_csv",
            bench_csv,
            "--split_filter",
            "test_id,test_ood",
            "--device",
            args.device,
            "--replay_metrics_json",
            replay_json,
        ]
        if args.device_power_watt is not None:
            bench_cmd.extend(["--device_power_watt", str(args.device_power_watt)])
        run(bench_cmd)

    agg_cmd = [sys.executable, ROOT / "scripts" / "simulation_aggregate.py", "--deployment_dir", deploy]
    if args.device_power_watt is not None:
        agg_cmd.append("--energy_enabled")
    run(agg_cmd)


if __name__ == "__main__":
    main()
