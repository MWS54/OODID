#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path
from typing import Sequence

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

WINDOW_SIZE = 32
STRIDE = 16
WINDOW_SENSITIVITY_SIZES = "8,16,32,64"
WINDOW_SENSITIVITY_POLICY = "half"
DEFAULT_INPUT = "data/multi_uav_hetero_no_uav04_plus_uav06_uav07_experiment.csv"
DEFAULT_ID_CLASSES = (
    "benign,icmp_flooding,udp_flooding,dos,ddos,bruteforce,mitm,"
    "deauthentication,jamming,injection,ip_spoofing,payload_manipulation,"
    "recon_scanning,generic,exploits,fuzzers,sybil"
)
DEFAULT_OOD_CLASSES = (
    "replay,reply,fake_landing,evil,video_interception,unauthorized_udp,"
    "analysis,backdoor,shellcode,wormhole,blackhole,worms"
)
DEFAULT_METHODS = "rapier_proxy,hypervision_proxy,recda_proxy,rids_lite_proxy,ucs_oodid"
DEFAULT_OUTPUT_ROOT = "runs/paper_full_suite_6uav_window32_stride16"
DEFAULT_ARTIFACT_DIR = "runs/final_ucs_oodid_window32_stride16"


def run_command(cmd: Sequence[object]) -> None:
    cmd_list = [str(part) for part in cmd]
    print("RUN", " ".join(cmd_list), flush=True)
    subprocess.run(cmd_list, check=True, cwd=str(ROOT))


def write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def append_allow_ports(cmd: list[str], allow_ports: bool) -> None:
    if allow_ports:
        cmd.append("--allow_ports")


def build_shared_flags(args: argparse.Namespace) -> list[str]:
    flags = [
        "--input",
        args.input,
        "--label_col",
        args.label_col,
        "--timestamp_col",
        args.timestamp_col,
        "--record_id_col",
        args.record_id_col,
        "--group_col",
        args.group_col,
        "--id_classes",
        args.id_classes,
        "--ood_classes",
        args.ood_classes,
        "--window_mode",
        "count",
        "--window_size",
        str(WINDOW_SIZE),
        "--stride",
        str(STRIDE),
        "--q_ood",
        str(args.q_ood),
        "--epochs",
        str(args.epochs),
        "--seed",
        str(args.seed),
        "--device",
        args.device,
        "--benign_label",
        args.benign_label,
    ]
    methods = str(args.methods or "").strip()
    if methods:
        flags.extend(["--methods", methods])
    append_allow_ports(flags, args.allow_ports)
    return flags


def run_comparison(args: argparse.Namespace, output_dir: Path) -> None:
    cmd = [
        sys.executable,
        ROOT / "scripts" / "run_comparison_experiments.py",
        "--output_root",
        output_dir,
        *build_shared_flags(args),
    ]
    run_command(cmd)


def run_homogeneous_vs_heterogeneous(
    args: argparse.Namespace,
    output_dir: Path,
    comparison_dir: Path,
) -> None:
    cmd = [
        sys.executable,
        ROOT / "scripts" / "run_homogeneous_comparison_experiments.py",
        "--output_root",
        output_dir,
        "--heterogeneous_results_dir",
        comparison_dir,
        *build_shared_flags(args),
    ]
    run_command(cmd)


def run_ablation(args: argparse.Namespace, output_dir: Path) -> None:
    cmd = [
        sys.executable,
        ROOT / "scripts" / "run_multi_uav_ablation.py",
        "--input",
        args.input,
        "--output_root",
        output_dir,
        "--group_col",
        args.group_col,
        "--label_col",
        args.label_col,
        "--timestamp_col",
        args.timestamp_col,
        "--record_id_col",
        args.record_id_col,
        "--id_classes",
        args.id_classes,
        "--ood_classes",
        args.ood_classes,
        "--window_size",
        str(WINDOW_SIZE),
        "--stride",
        str(STRIDE),
        "--seed",
        str(args.seed),
        "--device",
        args.device,
        "--benign_label",
        args.benign_label,
    ]
    append_allow_ports(cmd, args.allow_ports)
    run_command(cmd)


def run_window_sensitivity(args: argparse.Namespace, output_dir: Path) -> None:
    cmd = [
        sys.executable,
        ROOT / "scripts" / "run_window_size_experiments.py",
        "--input",
        args.input,
        "--output_root",
        output_dir,
        "--group_col",
        args.group_col,
        "--label_col",
        args.label_col,
        "--timestamp_col",
        args.timestamp_col,
        "--record_id_col",
        args.record_id_col,
        "--id_classes",
        args.id_classes,
        "--ood_classes",
        args.ood_classes,
        "--window_sizes",
        WINDOW_SENSITIVITY_SIZES,
        "--stride_policy",
        WINDOW_SENSITIVITY_POLICY,
        "--epochs",
        str(args.epochs),
        "--q_ood",
        str(args.q_ood),
        "--device",
        args.device,
        "--seed",
        str(args.seed),
        "--benign_label",
        args.benign_label,
    ]
    append_allow_ports(cmd, args.allow_ports)
    run_command(cmd)


def train_final_artifact(args: argparse.Namespace, artifact_dir: Path) -> Path:
    artifact_dir.mkdir(parents=True, exist_ok=True)
    cmd = [
        sys.executable,
        ROOT / "scripts" / "train.py",
        "--input",
        args.input,
        "--output_dir",
        artifact_dir,
        "--label_col",
        args.label_col,
        "--timestamp_col",
        args.timestamp_col,
        "--record_id_col",
        args.record_id_col,
        "--group_col",
        args.group_col,
        "--id_classes",
        args.id_classes,
        "--ood_classes",
        args.ood_classes,
        "--benign_label",
        args.benign_label,
        "--window_mode",
        "count",
        "--window_size",
        str(WINDOW_SIZE),
        "--stride",
        str(STRIDE),
        "--epochs",
        str(args.epochs),
        "--seed",
        str(args.seed),
        "--device",
        args.device,
        "--q_ood",
        str(args.q_ood),
        "--bank_k",
        "5",
        "--encoder_ablation",
        "transformer_only",
        "--fusion",
        "correlation_aware",
        "--normalization_mode",
        "group",
        "--ood_threshold_mode",
        "group",
        "--group_threshold_strategy",
        "conservative",
        "--group_threshold_min_ratio",
        "1.0",
        "--group_threshold_min_samples",
        "10",
        "--use_group_embedding",
        "--group_embedding_dim",
        "16",
        "--present_class_min_support",
        "1",
    ]
    append_allow_ports(cmd, args.allow_ports)
    run_command(cmd)
    return artifact_dir / "artifact.pt"


def run_benchmark_raw(
    args: argparse.Namespace,
    deployment_dir: Path,
    artifact_path: Path,
) -> tuple[Path, Path]:
    deployment_dir.mkdir(parents=True, exist_ok=True)
    onboard_raw = deployment_dir / "benchmark_onboard_raw.json"
    edge_raw = deployment_dir / "edge_benchmark_raw.json"

    onboard_cmd = [
        sys.executable,
        ROOT / "scripts" / "benchmark_onboard.py",
        "--artifact",
        artifact_path,
        "--input",
        args.input,
        "--output_json",
        onboard_raw,
        "--label_col",
        args.label_col,
        "--timestamp_col",
        args.timestamp_col,
        "--record_id_col",
        args.record_id_col,
        "--group_col",
        args.group_col,
        "--device",
        args.device,
        "--batch_size",
        str(args.benchmark_batch_size),
        "--warmup_runs",
        str(args.benchmark_warmup_runs),
        "--repeat_runs",
        str(args.benchmark_repeat_runs),
    ]
    run_command(onboard_cmd)

    edge_cmd = [
        sys.executable,
        ROOT / "scripts" / "edge_benchmark.py",
        "--artifact",
        artifact_path,
        "--input",
        args.input,
        "--output_json",
        edge_raw,
        "--label_col",
        args.label_col,
        "--record_id_col",
        args.record_id_col,
        "--device",
        args.device,
        "--iterations",
        str(args.edge_iterations),
        "--warmup_iterations",
        str(args.edge_warmup_iterations),
    ]
    run_command(edge_cmd)
    return onboard_raw, edge_raw


def run_online_replay(
    args: argparse.Namespace,
    deployment_dir: Path,
    artifact_path: Path,
) -> Path:
    deployment_dir.mkdir(parents=True, exist_ok=True)
    simulation_json = deployment_dir / "simulation_online.json"
    cmd = [
        sys.executable,
        ROOT / "scripts" / "simulate_live_demo.py",
        "--config",
        ROOT / "configs" / "demo_scene_default.yaml",
        "--online_detection",
        "--artifact",
        artifact_path,
        "--output_json",
        simulation_json,
        "--uav_count",
        "6",
        "--window_size",
        str(WINDOW_SIZE),
        "--stride",
        str(STRIDE),
        "--dataset_replay_mode",
        "pure_ids_csv",
        "--pure_ids_csv_path",
        args.input,
        "--pure_ids_group_col",
        args.group_col,
        "--pure_ids_replay_records_per_uav_per_step",
        str(args.replay_records_per_uav_per_step),
        "--pure_ids_replay_stop_when_exhausted",
        "true",
        "--pure_ids_replay_keep_original_order",
        "true",
        "--pure_ids_replay_no_mixing",
        "true",
        "--pure_ids_replay_split_filter",
        "test_id,test_ood",
        "--pure_ids_replay_reset_buffer_on_split_change",
        "true",
        "--top_records",
        str(args.top_records),
    ]
    run_command(cmd)
    return simulation_json


def run_generator(
    output_root: Path,
    artifact_path: Path,
    deployment_dir: Path,
) -> None:
    cmd = [
        sys.executable,
        ROOT / "scripts" / "generate_window32_outputs.py",
        "--results_root",
        output_root,
        "--artifact",
        artifact_path,
        "--deployment_dir",
        deployment_dir,
    ]
    run_command(cmd)


def run_consistency_check(output_root: Path, artifact_path: Path) -> None:
    cmd = [
        sys.executable,
        ROOT / "scripts" / "check_experiment_consistency.py",
        "--results_dir",
        output_root,
        "--artifact",
        artifact_path,
    ]
    run_command(cmd)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Run the full UCS-OODID 32/16 experiment suite: comparison, robustness, "
            "ablation, window sensitivity, final artifact, benchmark, replay, figures, and report."
        )
    )
    parser.add_argument("--input", default=DEFAULT_INPUT)
    parser.add_argument("--output_root", default=DEFAULT_OUTPUT_ROOT)
    parser.add_argument("--artifact_dir", default=DEFAULT_ARTIFACT_DIR)
    parser.add_argument("--group_col", default="uav_id")
    parser.add_argument("--label_col", default="label")
    parser.add_argument("--timestamp_col", default="timestamp")
    parser.add_argument("--record_id_col", default="record_id")
    parser.add_argument("--id_classes", default=DEFAULT_ID_CLASSES)
    parser.add_argument("--ood_classes", default=DEFAULT_OOD_CLASSES)
    parser.add_argument("--methods", default=DEFAULT_METHODS)
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--q_ood", type=float, default=0.90)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--device", default="auto")
    parser.add_argument("--benign_label", default="benign")
    parser.add_argument("--allow_ports", action="store_true")
    parser.add_argument("--benchmark_batch_size", type=int, default=256)
    parser.add_argument("--benchmark_warmup_runs", type=int, default=5)
    parser.add_argument("--benchmark_repeat_runs", type=int, default=20)
    parser.add_argument("--edge_iterations", type=int, default=100)
    parser.add_argument("--edge_warmup_iterations", type=int, default=10)
    parser.add_argument("--replay_records_per_uav_per_step", type=int, default=186)
    parser.add_argument("--top_records", type=int, default=5)
    parser.add_argument("--skip_generation", action="store_true")
    parser.add_argument("--skip_consistency_check", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    output_root = Path(args.output_root)
    output_root.mkdir(parents=True, exist_ok=True)
    comparison_dir = output_root / "comparison"
    robustness_dir = output_root / "homogeneous_vs_heterogeneous"
    ablation_dir = output_root / "ablation"
    window_dir = output_root / "window_sensitivity"
    deployment_dir = output_root / "deployment"
    artifact_dir = Path(args.artifact_dir)

    run_comparison(args, comparison_dir)
    run_homogeneous_vs_heterogeneous(args, robustness_dir, comparison_dir)
    run_ablation(args, ablation_dir)
    run_window_sensitivity(args, window_dir)
    artifact_path = train_final_artifact(args, artifact_dir)
    onboard_raw, edge_raw = run_benchmark_raw(args, deployment_dir, artifact_path)
    simulation_json = run_online_replay(args, deployment_dir, artifact_path)

    if not args.skip_generation:
        run_generator(output_root, artifact_path, deployment_dir)
    if not args.skip_consistency_check:
        run_consistency_check(output_root, artifact_path)

    manifest = {
        "results_root": str(output_root),
        "comparison_dir": str(comparison_dir),
        "homogeneous_vs_heterogeneous_dir": str(robustness_dir),
        "ablation_dir": str(ablation_dir),
        "window_sensitivity_dir": str(window_dir),
        "deployment_dir": str(deployment_dir),
        "artifact_path": str(artifact_path),
        "raw_reports": {
            "benchmark_onboard_raw": str(onboard_raw),
            "edge_benchmark_raw": str(edge_raw),
            "simulation_online": str(simulation_json),
        },
        "default_main_setting": {
            "window_size": WINDOW_SIZE,
            "stride": STRIDE,
        },
        "window_sensitivity_settings": [
            {"window": 8, "stride": 4},
            {"window": 16, "stride": 8},
            {"window": 32, "stride": 16},
            {"window": 64, "stride": 32},
        ],
    }
    write_json(output_root / "suite_manifest.json", manifest)
    print(json.dumps(manifest, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
