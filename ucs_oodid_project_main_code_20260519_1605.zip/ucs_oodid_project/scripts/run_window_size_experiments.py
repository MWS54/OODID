#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path
from typing import Any, Callable, Sequence

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ucs_oodid.io import load_json, save_json
from ucs_oodid.utils import parse_csv_list

KNOWN_COLUMNS = ["Method", "Micro-F1", "Macro-F1", "mAP", "Hamming Loss", "Subset Acc."]
OOD_COLUMNS = ["Method", "AUROC", "AUPR-Out", "FPR95", "Precision", "Recall", "OOD-F1", "FPR@theta"]
TIME_COLUMNS = ["Method", "Avg. Detection Time (ms/window)", "Throughput (windows/s)", "Test Windows"]
SUMMARY_COLUMNS = [
    "Window Size",
    "Stride",
    "Method",
    "Micro-F1",
    "Macro-F1",
    "mAP",
    "AUROC",
    "AUPR-Out",
    "FPR95",
    "OOD-F1",
    "FPR@theta",
    "Avg. Detection Time (ms/window)",
    "Throughput (windows/s)",
]
SUMMARY_TEX_COLUMNS = ["Window", "Method", "Micro-F1", "OOD-F1", "AUROC", "FPR@theta", "Time(ms)"]
SUMMARY_TEX_CAPTION = "Window-size sensitivity summary under the same metadata-window protocol."


def run_subprocess(cmd: Sequence[object]) -> subprocess.CompletedProcess[str]:
    cmd_list = [str(part) for part in cmd]
    print("RUN", " ".join(cmd_list), flush=True)
    result = subprocess.run(
        cmd_list,
        cwd=str(ROOT),
        check=False,
        capture_output=True,
        text=True,
    )
    if result.stdout:
        print(result.stdout, end="" if result.stdout.endswith("\n") else "\n")
    if result.stderr:
        print(result.stderr, end="" if result.stderr.endswith("\n") else "\n", file=sys.stderr)
    return result


def latex_escape(text: str) -> str:
    replacements = {
        "\\": r"\textbackslash{}",
        "&": r"\&",
        "%": r"\%",
        "$": r"\$",
        "#": r"\#",
        "_": r"\_",
        "{": r"\{",
        "}": r"\}",
        "~": r"\textasciitilde{}",
        "^": r"\textasciicircum{}",
    }
    return "".join(replacements.get(ch, ch) for ch in text)


def _tail_text(text: str | None, max_lines: int = 40, max_chars: int = 4000) -> str:
    raw = str(text or "")
    lines = raw.splitlines()
    clipped = "\n".join(lines[-max_lines:])
    return clipped[-max_chars:]


def parse_window_sizes(value: str) -> list[int]:
    items = parse_csv_list(value)
    if not items:
        raise ValueError("At least one window size must be provided via --window_sizes")
    sizes: list[int] = []
    seen = set()
    for item in items:
        size = int(item)
        if size <= 0:
            raise ValueError(f"Window sizes must be positive integers, got {item!r}")
        if size in seen:
            continue
        seen.add(size)
        sizes.append(size)
    return sizes


def resolve_stride(window_size: int, stride_policy: str) -> int:
    policy = str(stride_policy or "").strip().lower()
    if policy in {"", "half"}:
        return max(1, int(window_size) // 2)
    stride = int(policy)
    if stride <= 0:
        raise ValueError(f"Resolved stride must be positive, got {stride}")
    return stride


def build_window_command(args, window_size: int, stride: int, window_output_root: Path) -> list[object]:
    cmd: list[object] = [
        sys.executable,
        Path(__file__).with_name("run_comparison_experiments.py"),
        "--input",
        getattr(args, "input"),
        "--output_root",
        window_output_root,
        "--label_col",
        getattr(args, "label_col", "label"),
        "--timestamp_col",
        getattr(args, "timestamp_col", "timestamp"),
        "--record_id_col",
        getattr(args, "record_id_col", "record_id"),
        "--group_col",
        getattr(args, "group_col", "uav_id"),
        "--id_classes",
        getattr(args, "id_classes", ""),
        "--ood_classes",
        getattr(args, "ood_classes", ""),
        "--window_mode",
        "count",
        "--window_size",
        str(window_size),
        "--stride",
        str(stride),
        "--q_ood",
        str(getattr(args, "q_ood", 0.90)),
        "--epochs",
        str(getattr(args, "epochs", 10)),
    ]
    methods = str(getattr(args, "methods", "") or "").strip()
    if methods:
        cmd.extend(["--methods", methods])
    device = str(getattr(args, "device", "auto") or "").strip()
    if device:
        cmd.extend(["--device", device])
    if hasattr(args, "seed"):
        cmd.extend(["--seed", str(getattr(args, "seed"))])
    if hasattr(args, "benign_label"):
        cmd.extend(["--benign_label", str(getattr(args, "benign_label"))])
    if bool(getattr(args, "allow_ports", False)):
        cmd.append("--allow_ports")
    return cmd


def _load_metric_table(path: Path, columns: Sequence[str]) -> pd.DataFrame:
    frame = pd.read_csv(path)
    return frame.reindex(columns=list(columns))


def _annotate_window_table(frame: pd.DataFrame, window_size: int, stride: int) -> pd.DataFrame:
    annotated = frame.copy()
    annotated.insert(0, "Stride", int(stride))
    annotated.insert(0, "Window Size", int(window_size))
    return annotated


def _build_summary_frame(known_frame: pd.DataFrame, ood_frame: pd.DataFrame, time_frame: pd.DataFrame) -> pd.DataFrame:
    key = ["Window Size", "Stride", "Method"]
    summary = known_frame[key + ["Micro-F1", "Macro-F1", "mAP"]].merge(
        ood_frame[key + ["AUROC", "AUPR-Out", "FPR95", "OOD-F1", "FPR@theta"]],
        on=key,
        how="outer",
    )
    summary = summary.merge(
        time_frame[key + ["Avg. Detection Time (ms/window)", "Throughput (windows/s)"]],
        on=key,
        how="outer",
    )
    return summary.reindex(columns=SUMMARY_COLUMNS)


def _format_latex_value(value: Any) -> str:
    if value is None or pd.isna(value):
        return ""
    if isinstance(value, str):
        return latex_escape(value)
    numeric = float(value)
    if numeric.is_integer():
        return str(int(numeric))
    return f"{numeric:.4f}"


def write_summary_latex(frame: pd.DataFrame, output_tex: Path) -> None:
    output_tex.parent.mkdir(parents=True, exist_ok=True)
    tex_frame = frame.rename(
        columns={
            "Window Size": "Window",
            "Avg. Detection Time (ms/window)": "Time(ms)",
        }
    ).reindex(columns=SUMMARY_TEX_COLUMNS)
    lines = [
        r"\begin{table}[t]",
        r"\centering",
        rf"\caption{{{SUMMARY_TEX_CAPTION}}}",
        r"\begin{tabular}{rlrrrrr}",
        r"\toprule",
        " & ".join(latex_escape(str(column)) for column in tex_frame.columns) + r" \\",
        r"\midrule",
    ]
    for row in tex_frame.itertuples(index=False, name=None):
        highlight = str(row[1]) == "UCS-OODID"
        cells = []
        for value in row:
            text = _format_latex_value(value)
            if highlight and text:
                text = rf"\textbf{{{text}}}"
            cells.append(text)
        lines.append(" & ".join(cells) + r" \\")
    lines.extend([r"\bottomrule", r"\end{tabular}", r"\end{table}"])
    output_tex.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _collect_failed_method_records(window_size: int, stride: int, window_dir: Path) -> list[dict[str, Any]]:
    summary_path = window_dir / "comparison_summary.json"
    if not summary_path.exists():
        return []
    summary = load_json(summary_path)
    records: list[dict[str, Any]] = []
    for item in summary.get("methods", []):
        if item.get("status") != "failed":
            continue
        records.append(
            {
                "window_size": int(window_size),
                "stride": int(stride),
                "method_name": str(item.get("method_name", "")),
                "display_name": str(item.get("display_name", item.get("method_name", ""))),
                "status": "failed",
                "note": str(item.get("note", "")),
                "output_dir": str(item.get("output_dir", window_dir / str(item.get("method_name", "")))),
                "eval_report": str(item.get("eval_report", "")),
            }
        )
    return records


def run_window_size_experiments(
    args,
    runner: Callable[[Sequence[object]], Any] = run_subprocess,
) -> dict:
    output_root = Path(getattr(args, "output_root", "runs/window_size_experiments"))
    output_root.mkdir(parents=True, exist_ok=True)
    window_sizes = parse_window_sizes(getattr(args, "window_sizes", "8,16,32,64"))
    stride_policy = str(getattr(args, "stride_policy", "half") or "half")

    successful_runs: list[dict[str, Any]] = []
    failed_window_runs: list[dict[str, Any]] = []
    known_frames: list[pd.DataFrame] = []
    ood_frames: list[pd.DataFrame] = []
    time_frames: list[pd.DataFrame] = []

    for window_size in window_sizes:
        stride = resolve_stride(window_size, stride_policy)
        window_dir = output_root / f"window_{window_size}"
        window_dir.mkdir(parents=True, exist_ok=True)
        cmd = build_window_command(args, window_size, stride, window_dir)

        try:
            result = runner(cmd)
        except Exception as exc:
            failed_window_runs.append(
                {
                    "window_size": int(window_size),
                    "stride": int(stride),
                    "output_dir": str(window_dir),
                    "status": "failed",
                    "method_name": None,
                    "display_name": None,
                    "return_code": None,
                    "stdout_tail": "",
                    "stderr_tail": f"{type(exc).__name__}: {exc}",
                }
            )
            continue

        if int(getattr(result, "returncode", 0)) != 0:
            failed_window_runs.append(
                {
                    "window_size": int(window_size),
                    "stride": int(stride),
                    "output_dir": str(window_dir),
                    "status": "failed",
                    "method_name": None,
                    "display_name": None,
                    "return_code": int(getattr(result, "returncode", 0)),
                    "stdout_tail": _tail_text(getattr(result, "stdout", "")),
                    "stderr_tail": _tail_text(getattr(result, "stderr", "")),
                }
            )
            continue

        known_csv = window_dir / "known_detection_table.csv"
        ood_csv = window_dir / "ood_detection_table.csv"
        time_csv = window_dir / "detection_time_table.csv"
        missing = [str(path.name) for path in (known_csv, ood_csv, time_csv) if not path.exists()]
        if missing:
            failed_window_runs.append(
                {
                    "window_size": int(window_size),
                    "stride": int(stride),
                    "output_dir": str(window_dir),
                    "status": "failed",
                    "method_name": None,
                    "display_name": None,
                    "return_code": 0,
                    "stdout_tail": _tail_text(getattr(result, "stdout", "")),
                    "stderr_tail": f"Missing output tables: {', '.join(missing)}",
                }
            )
            continue

        known_frame = _annotate_window_table(_load_metric_table(known_csv, KNOWN_COLUMNS), window_size, stride)
        ood_frame = _annotate_window_table(_load_metric_table(ood_csv, OOD_COLUMNS), window_size, stride)
        time_frame = _annotate_window_table(_load_metric_table(time_csv, TIME_COLUMNS), window_size, stride)
        known_frames.append(known_frame)
        ood_frames.append(ood_frame)
        time_frames.append(time_frame)

        summary_path = window_dir / "comparison_summary.json"
        child_summary = load_json(summary_path) if summary_path.exists() else {}
        failed_window_runs.extend(_collect_failed_method_records(window_size, stride, window_dir))
        successful_runs.append(
            {
                "window_size": int(window_size),
                "stride": int(stride),
                "output_dir": str(window_dir),
                "comparison_summary_path": str(summary_path) if summary_path.exists() else "",
                "known_detection_table": str(known_csv),
                "ood_detection_table": str(ood_csv),
                "detection_time_table": str(time_csv),
                "successful_methods": list(child_summary.get("successful_methods", [])),
                "failed_methods": list(child_summary.get("failed_methods", [])),
                "skipped_methods": list(child_summary.get("skipped_methods", [])),
            }
        )

    if not successful_runs:
        raise ValueError("No successful window-size runs produced comparison tables.")

    window_known = pd.concat(known_frames, ignore_index=True)
    window_ood = pd.concat(ood_frames, ignore_index=True)
    window_time = pd.concat(time_frames, ignore_index=True)
    window_summary = _build_summary_frame(window_known, window_ood, window_time)

    known_out = output_root / "window_size_known_table.csv"
    ood_out = output_root / "window_size_ood_table.csv"
    time_out = output_root / "window_size_time_table.csv"
    summary_out = output_root / "window_size_summary.csv"
    summary_json = output_root / "window_size_summary.json"
    summary_tex = output_root / "window_size_summary_table.tex"
    failed_json = output_root / "failed_window_runs.json"

    window_known.to_csv(known_out, index=False)
    window_ood.to_csv(ood_out, index=False)
    window_time.to_csv(time_out, index=False)
    window_summary.to_csv(summary_out, index=False)
    write_summary_latex(window_summary, summary_tex)
    save_json(failed_window_runs, failed_json)

    summary = {
        "input": str(getattr(args, "input")),
        "output_root": str(output_root),
        "window_sizes": window_sizes,
        "stride_policy": stride_policy,
        "successful_window_sizes": [int(item["window_size"]) for item in successful_runs],
        "window_runs": successful_runs,
        "tables": {
            "window_size_known_csv": str(known_out),
            "window_size_ood_csv": str(ood_out),
            "window_size_time_csv": str(time_out),
            "window_size_summary_csv": str(summary_out),
            "window_size_summary_tex": str(summary_tex),
        },
        "failed_window_runs_file": str(failed_json),
        "failed_window_runs": failed_window_runs,
    }
    save_json(summary, summary_json)
    return summary


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run comparison experiments across multiple window sizes.")
    parser.add_argument("--input", required=True)
    parser.add_argument("--output_root", default="runs/window_size_experiments")
    parser.add_argument("--id_classes", required=True)
    parser.add_argument("--ood_classes", required=True)
    parser.add_argument("--group_col", default="uav_id")
    parser.add_argument("--label_col", default="label")
    parser.add_argument("--timestamp_col", default="timestamp")
    parser.add_argument("--record_id_col", default="record_id")
    parser.add_argument("--window_sizes", default="8,16,32,64")
    parser.add_argument("--stride_policy", default="half")
    parser.add_argument(
        "--methods",
        default="rapier_proxy,hypervision_proxy,recda_proxy,rids_lite_proxy,ucs_oodid",
    )
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--q_ood", type=float, default=0.90)
    parser.add_argument("--device", default="auto")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--benign_label", default="benign")
    parser.add_argument("--allow_ports", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    summary = run_window_size_experiments(args)
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
