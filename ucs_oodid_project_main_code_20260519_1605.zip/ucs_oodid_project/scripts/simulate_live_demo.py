#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import numpy as np
import pandas as pd
import torch

from ucs_oodid.artifacts import save_artifact
from ucs_oodid.dataset_registry import default_simulation_uav_ids
from ucs_oodid.inference import collect_model_outputs
from ucs_oodid.io import save_json
from ucs_oodid.model import UCSOODID
from ucs_oodid.ood import OODCalibrator, PrototypeBank, compute_raw_ood_scores
from ucs_oodid.preprocessing import GroupAwareMetadataPreprocessor
from ucs_oodid.realtime import OnlineDetector, StreamingWindowBuffer
from ucs_oodid.simulator import (
    ATTACK_REPLAY_MODES,
    SUPPORTED_RESPONSE_ACTIONS,
    AttackReplayPool,
    Attacker,
    GCS,
    SimulationConfig,
    SimulationEngine,
    build_demo_cli_defaults,
    build_fleet,
    build_scenario_attack_injector,
    default_demo_scene_config_path,
    default_scenario_profile_path,
    load_demo_scene_config,
    load_scenario_from_yaml,
)
from ucs_oodid.utils import set_seed
from ucs_oodid.windowing import attach_parsed_labels, build_grouped_windows

ATTACK_LABEL_ALIASES = {
    "jamming_proxy": "jamming",
    "flood": "udp_flooding",
    "scan": "recon_scanning",
    "command_injection": "injection",
    "replay": "replay",
    "benign": "benign",
}


def _parse_bool_arg(value: object) -> bool:
    if isinstance(value, bool):
        return value
    text = str(value or "").strip().lower()
    if text in {"1", "true", "yes", "y", "on"}:
        return True
    if text in {"0", "false", "no", "n", "off"}:
        return False
    raise argparse.ArgumentTypeError(f"Expected a boolean value, got {value!r}")


def _parse_csv_items(value: object) -> list[str]:
    if value is None:
        return []
    if isinstance(value, (list, tuple, set)):
        raw_items = list(value)
    else:
        raw_items = str(value).split(",")
    items: list[str] = []
    seen: set[str] = set()
    for item in raw_items:
        text = str(item).strip()
        if text and text not in seen:
            items.append(text)
            seen.add(text)
    return items


def _normalize_selected_uav_ids(value: object) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        candidates = value.split(",")
    elif isinstance(value, (list, tuple, set)):
        candidates = list(value)
    else:
        candidates = [value]
    selected: list[str] = []
    seen: set[str] = set()
    for item in candidates:
        text = str(item).strip()
        if text and text not in seen:
            selected.append(text)
            seen.add(text)
    return selected


def _manual_demo_scene_config() -> dict[str, object]:
    return {
        "uav_count": 1,
        "duration_s": 20.0,
        "dt_s": 1.0,
        "seed": 42,
        "scenario_profile_path": default_scenario_profile_path(),
        "attack_scenario_path": "",
        "start_spacing_s": 3.0,
        "route_length_m": 120.0,
        "hover_duration_s": 4.0,
        "cruise_altitude_m": 80.0,
        "cruise_speed_mps": 16.0,
        "battery_capacity_wh": 180.0,
        "attack_type": "jamming_proxy",
        "attack_start_s": 8.0,
        "attack_end_s": 12.0,
        "attack_intensity": 0.95,
        "attack_replay_mode": "sequential",
        "enable_online_detection": False,
        "response_strategy": "alert_only",
        "artifact_path": "",
        "bootstrap_duration_s": 48.0,
        "window_size": 32,
        "stride": 16,
        "bank_k": 5,
        "bootstrap_q_ood": 0.9,
        "bootstrap_threshold_margin": 0.05,
        "top_records": 5,
    }


def _canonicalize_demo_attack_type(value: object) -> str:
    attack_type = str(value or "benign").strip().lower()
    if attack_type == "jamming":
        return "jamming_proxy"
    return attack_type


def build_arg_parser(defaults: dict[str, object]) -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run a live mission simulation demo.")
    parser.add_argument(
        "--config",
        default=str(defaults.get("config", "")),
        help=f"Optional demo scene YAML config. The repository default scene lives at {default_demo_scene_config_path()}",
    )
    parser.add_argument("--uav_id", default=str(defaults.get("uav_id", "uav_demo_01")))
    parser.add_argument("--uav_count", type=int, default=int(defaults.get("uav_count", 1)))
    parser.add_argument("--duration_s", type=float, default=float(defaults.get("duration_s", 20.0)))
    parser.add_argument("--dt_s", type=float, default=float(defaults.get("dt_s", 1.0)))
    parser.add_argument("--seed", type=int, default=int(defaults.get("seed", 42)))
    parser.add_argument("--route_length_m", type=float, default=float(defaults.get("route_length_m", 120.0)))
    parser.add_argument("--hover_duration_s", type=float, default=float(defaults.get("hover_duration_s", 4.0)))
    parser.add_argument("--cruise_altitude_m", type=float, default=float(defaults.get("cruise_altitude_m", 80.0)))
    parser.add_argument("--cruise_speed_mps", type=float, default=float(defaults.get("cruise_speed_mps", 16.0)))
    parser.add_argument("--battery_capacity_wh", type=float, default=float(defaults.get("battery_capacity_wh", 180.0)))
    parser.add_argument("--start_spacing_s", type=float, default=float(defaults.get("start_spacing_s", 3.0)))
    parser.add_argument("--scenario_profile_path", default=str(defaults.get("scenario_profile_path", default_scenario_profile_path())))
    parser.add_argument(
        "--attack_scenario_path",
        default=str(defaults.get("attack_scenario_path", "")),
        help="Optional attack scenario YAML, e.g. configs/scenarios/mixed_attack_6datasets.yaml",
    )
    parser.add_argument(
        "--attack_type",
        default=str(defaults.get("attack_type", "jamming_proxy")),
        choices=["benign", "flood", "scan", "replay", "command_injection", "jamming", "jamming_proxy"],
    )
    parser.add_argument("--attack_start_s", type=float, default=float(defaults.get("attack_start_s", 8.0)))
    parser.add_argument("--attack_end_s", type=float, default=float(defaults.get("attack_end_s", 12.0)))
    parser.add_argument("--attack_intensity", type=float, default=float(defaults.get("attack_intensity", 0.95)))
    parser.add_argument(
        "--attack_replay_mode",
        default=str(defaults.get("attack_replay_mode", "sequential")),
        choices=list(ATTACK_REPLAY_MODES),
        help="How replayed attack rows are selected from the bound dataset.",
    )
    parser.add_argument("--head", type=int, default=int(defaults.get("head", 5)), help="Number of records to print.")
    online_group = parser.add_mutually_exclusive_group()
    online_group.add_argument(
        "--online_detection",
        dest="online_detection",
        action="store_true",
        help="Enable realtime UCS-OODID shell during simulation.",
    )
    online_group.add_argument(
        "--disable_online_detection",
        dest="online_detection",
        action="store_false",
        help="Disable realtime UCS-OODID shell even if the config enables it.",
    )
    parser.set_defaults(online_detection=bool(defaults.get("online_detection", False)))
    parser.add_argument(
        "--response_strategy",
        default=str(defaults.get("response_strategy", "alert_only")),
        choices=list(SUPPORTED_RESPONSE_ACTIONS),
        help="Response strategy applied after an online alert is triggered.",
    )
    parser.add_argument("--artifact", default=str(defaults.get("artifact", "")), help="Optional existing artifact.pt for online detection.")
    parser.add_argument("--artifact_out", default=str(defaults.get("artifact_out", "")), help="Optional path to save the bootstrapped demo artifact.")
    parser.add_argument("--output_json", default=str(defaults.get("output_json", "")), help="Optional JSON file to store the full demo payload.")
    parser.add_argument(
        "--bootstrap_duration_s",
        type=float,
        default=float(defaults.get("bootstrap_duration_s", 48.0)),
        help="Benign duration used to bootstrap the demo artifact.",
    )
    parser.add_argument("--window_size", type=int, default=int(defaults.get("window_size", 32)), help="Sliding window size for the demo artifact.")
    parser.add_argument("--stride", type=int, default=int(defaults.get("stride", 16)), help="Sliding stride for the demo artifact.")
    parser.add_argument("--dataset_replay_mode", default=str(defaults.get("dataset_replay_mode", "")))
    parser.add_argument("--pure_ids_csv_path", default=str(defaults.get("pure_ids_csv_path", "")))
    parser.add_argument("--pure_ids_group_col", default=str(defaults.get("pure_ids_group_col", "uav_id")))
    parser.add_argument(
        "--pure_ids_replay_records_per_uav_per_step",
        type=int,
        default=int(defaults.get("pure_ids_replay_records_per_uav_per_step", 186)),
    )
    parser.add_argument(
        "--pure_ids_replay_stop_when_exhausted",
        type=_parse_bool_arg,
        default=bool(defaults.get("pure_ids_replay_stop_when_exhausted", True)),
    )
    parser.add_argument(
        "--pure_ids_replay_keep_original_order",
        type=_parse_bool_arg,
        default=bool(defaults.get("pure_ids_replay_keep_original_order", True)),
    )
    parser.add_argument(
        "--pure_ids_replay_no_mixing",
        type=_parse_bool_arg,
        default=bool(defaults.get("pure_ids_replay_no_mixing", True)),
    )
    parser.add_argument(
        "--pure_ids_replay_split_filter",
        default=",".join(_parse_csv_items(defaults.get("pure_ids_replay_split_filter", ("test_id", "test_ood")))),
    )
    parser.add_argument(
        "--pure_ids_replay_reset_buffer_on_split_change",
        type=_parse_bool_arg,
        default=bool(defaults.get("pure_ids_replay_reset_buffer_on_split_change", True)),
    )
    parser.add_argument("--bank_k", type=int, default=int(defaults.get("bank_k", 5)))
    parser.add_argument("--bootstrap_q_ood", type=float, default=float(defaults.get("bootstrap_q_ood", 0.9)))
    parser.add_argument(
        "--bootstrap_threshold_margin",
        type=float,
        default=float(defaults.get("bootstrap_threshold_margin", 0.05)),
    )
    parser.add_argument("--top_records", type=int, default=int(defaults.get("top_records", 5)))
    return parser


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    bootstrap_parser = argparse.ArgumentParser(add_help=False)
    bootstrap_parser.add_argument("--config", default="")
    known, _ = bootstrap_parser.parse_known_args(argv)
    config_path = str(known.config or "").strip()
    raw_defaults = load_demo_scene_config(config_path or None)
    parser = build_arg_parser(
        {
            **build_demo_cli_defaults(raw_defaults),
            "config": config_path or default_demo_scene_config_path(),
        }
    )
    return parser.parse_args(argv)


def build_demo_engine(
    args: argparse.Namespace,
    *,
    attack_type: str | None = None,
    duration_s: float | None = None,
    enable_online_detection: bool = False,
    online_detector: OnlineDetector | None = None,
) -> SimulationEngine:
    """Build a configured live demo scenario."""

    uav_count = int(getattr(args, "uav_count", 1))
    if uav_count < 1:
        uav_count = 1
    scenario_profile_path = str(getattr(args, "scenario_profile_path", default_scenario_profile_path()))
    gcs = GCS(gcs_id="gcs_demo")
    attacker = Attacker(attacker_id="attacker_demo", x_m=220.0, y_m=60.0)
    effective_attack_type = _canonicalize_demo_attack_type(attack_type if attack_type is not None else args.attack_type)
    selected_uav_ids = _normalize_selected_uav_ids(getattr(args, "selected_uav_ids", []))
    if selected_uav_ids:
        uav_ids = selected_uav_ids
    else:
        uav_ids = [args.uav_id] if uav_count == 1 else default_simulation_uav_ids(uav_count)
    uav_count = len(uav_ids)
    runtime_config = {
        "uav_count": uav_count,
        "selected_uav_ids": list(uav_ids),
        "route_length_m": float(args.route_length_m),
        "hover_duration_s": float(args.hover_duration_s),
        "cruise_altitude_m": float(args.cruise_altitude_m),
        "cruise_speed_mps": float(args.cruise_speed_mps),
        "battery_capacity_wh": float(getattr(args, "battery_capacity_wh", 180.0)),
        "start_spacing_s": float(getattr(args, "start_spacing_s", 0.0)),
        "attack_type": str(effective_attack_type),
        "attack_start_s": float(args.attack_start_s),
        "attack_end_s": float(args.attack_end_s),
        "attack_intensity": float(args.attack_intensity),
        "scenario_profile_path": scenario_profile_path,
    }
    uavs = build_fleet(runtime_config, uav_ids=uav_ids)
    injector = build_scenario_attack_injector(runtime_config, uavs)
    if effective_attack_type == "benign":
        from ucs_oodid.simulator import AttackInjector

        injector = AttackInjector([])
    attack_replay_pool = AttackReplayPool.from_default_paths(seed=int(args.seed), allow_missing=True)
    config = SimulationConfig(
        duration_s=float(args.duration_s if duration_s is None else duration_s),
        dt_s=args.dt_s,
        seed=args.seed,
        enable_online_detection=enable_online_detection,
        response_strategy=args.response_strategy,
        scenario_profile_path=scenario_profile_path,
        attack_replay_mode=str(getattr(args, "attack_replay_mode", "sequential")),
        attack_scenario_path=str(getattr(args, "attack_scenario_path", "")),
        dataset_replay_mode=str(getattr(args, "dataset_replay_mode", "") or "").strip(),
        pure_ids_csv_path=str(getattr(args, "pure_ids_csv_path", "") or "").strip(),
        pure_ids_group_col=str(getattr(args, "pure_ids_group_col", "uav_id") or "uav_id").strip(),
        pure_ids_replay_records_per_uav_per_step=int(
            getattr(args, "pure_ids_replay_records_per_uav_per_step", 186)
        ),
        pure_ids_replay_stop_when_exhausted=bool(
            getattr(args, "pure_ids_replay_stop_when_exhausted", True)
        ),
        pure_ids_replay_keep_original_order=bool(
            getattr(args, "pure_ids_replay_keep_original_order", True)
        ),
        pure_ids_replay_no_mixing=bool(getattr(args, "pure_ids_replay_no_mixing", True)),
        pure_ids_replay_split_filter=tuple(
            _parse_csv_items(getattr(args, "pure_ids_replay_split_filter", ("test_id", "test_ood")))
        ),
        pure_ids_replay_reset_buffer_on_split_change=bool(
            getattr(args, "pure_ids_replay_reset_buffer_on_split_change", True)
        ),
    )
    return SimulationEngine(
        uavs=uavs,
        gcs=gcs,
        attacker=attacker,
        attack_injector=injector,
        config=config,
        online_detector=online_detector,
        attack_replay_pool=attack_replay_pool,
    )


def record_to_demo_row(record) -> dict[str, object]:
    row = dict(record.to_dict())
    slot_suffix = ""
    if row.get("attack_replay_slot") not in {None, ""}:
        slot_suffix = f":slot{int(row['attack_replay_slot'])}"
    if row.get("source_record_id") not in {None, ""}:
        row["record_id"] = f"{row['uav_id']}:{float(row['timestamp']):.3f}:{row['source_record_id']}{slot_suffix}"
    else:
        row["record_id"] = f"{row['uav_id']}:{float(row['timestamp']):.3f}{slot_suffix}"
    attack_active = bool(row.get("attack_active", False))
    attack_type = str(row.get("attack_type", "benign") or "benign")
    if not attack_active or attack_type == "benign":
        row["label"] = "benign"
    else:
        row["label"] = ATTACK_LABEL_ALIASES.get(attack_type, attack_type)
    return row


def records_to_frame(records) -> pd.DataFrame:
    return pd.DataFrame([record_to_demo_row(record) for record in records])


def initialize_demo_model(model: UCSOODID) -> None:
    """Use a deterministic, identity-like setup so benign prototypes stay stable."""

    hidden_dim = int(model.hidden_dim)
    input_dim = int(model.input_dim)
    diag_dim = min(hidden_dim, input_dim)
    with torch.no_grad():
        model.input_proj.weight.zero_()
        model.input_proj.bias.zero_()
        model.input_proj.weight[:diag_dim, :diag_dim] = torch.eye(diag_dim)
        if model.fused_norm.weight is not None:
            model.fused_norm.weight.fill_(1.0)
            model.fused_norm.bias.zero_()
        model.mlp_pool_proj.weight.zero_()
        model.mlp_pool_proj.bias.zero_()
        model.mlp_pool_proj.weight[:diag_dim, :diag_dim] = torch.eye(diag_dim)
        if model.mlp_pool_norm.weight is not None:
            model.mlp_pool_norm.weight.fill_(1.0)
            model.mlp_pool_norm.bias.zero_()
        model.classifier.weight.zero_()
        model.classifier.bias.fill_(2.0)


def build_bootstrap_preprocessor(df: pd.DataFrame) -> GroupAwareMetadataPreprocessor:
    """Infer non-leaking traffic features for the bootstrap detector."""

    pre = GroupAwareMetadataPreprocessor(
        label_col="label",
        timestamp_col="timestamp",
        record_id_col="record_id",
        group_col="uav_id",
    )
    pre.fit(df)
    return pre


def _normalize_bootstrap_group_id(value: object) -> str | None:
    if value is None:
        return None
    if isinstance(value, (float, np.floating)) and np.isnan(value):
        return None
    text = str(value).strip()
    return text or None


def apply_bootstrap_thresholds(
    ood_cal: OODCalibrator,
    raw_scores: dict[str, np.ndarray],
    group_ids: np.ndarray | None,
    *,
    margin: float,
) -> None:
    """Calibrate bootstrap thresholds with a per-UAV safety margin."""

    ood_cal.fit(raw_scores, label_source="bootstrap_benign_only")
    benign_fused = ood_cal.transform(raw_scores)["fused"]
    safety_margin = float(max(margin, 0.0))
    ood_cal.threshold = float(max(float(ood_cal.threshold), float(np.max(benign_fused)) + safety_margin))

    if group_ids is None:
        ood_cal.ood_threshold_mode = "global"
        return

    ood_cal.calibrate_group_thresholds(
        benign_fused,
        group_ids,
        min_samples=10,
        quantile=ood_cal.q_ood,
        strategy="conservative",
        shrink_k=1000.0,
        min_ratio=1.0,
    )

    labels = [_normalize_bootstrap_group_id(value) for value in group_ids.tolist()]
    unique_groups = sorted({label for label in labels if label is not None})
    for group_id in unique_groups:
        mask = np.asarray([label == group_id for label in labels], dtype=bool)
        if not mask.any():
            continue
        group_margin_threshold = float(np.max(benign_fused[mask])) + safety_margin
        current_threshold = float(ood_cal.group_thresholds.get(group_id, ood_cal.threshold))
        adjusted_threshold = float(max(current_threshold, group_margin_threshold))
        ood_cal.group_thresholds[group_id] = adjusted_threshold
        if adjusted_threshold > current_threshold + 1e-12:
            source = str(ood_cal.group_threshold_sources.get(group_id, "group"))
            ood_cal.group_threshold_sources[group_id] = source if source.endswith("_margin") else f"{source}_margin"

    ood_cal.ood_threshold_mode = "group"


def build_bootstrap_artifact(args: argparse.Namespace) -> dict:
    """Create a tiny self-contained artifact from benign simulation windows."""

    set_seed(int(args.seed))
    bootstrap_engine = build_demo_engine(args, attack_type="benign", duration_s=args.bootstrap_duration_s)
    bootstrap_result = bootstrap_engine.run()
    df = records_to_frame(bootstrap_result.records)
    pre = build_bootstrap_preprocessor(df)
    work = attach_parsed_labels(df, "label")
    features = pre.transform(work)
    feature_cols = list(pre.feature_cols)
    class_names = ["benign"]
    class_to_idx = {"benign": 0}
    windows = build_grouped_windows(
        features,
        work,
        class_to_idx,
        group_col="uav_id",
        mode="count",
        timestamp_col="timestamp",
        label_col="label",
        record_id_col="record_id",
        window_size=args.window_size,
        stride=args.stride,
    )
    if len(windows) == 0:
        raise ValueError("bootstrap demo did not produce any windows; increase bootstrap_duration_s")

    model_cfg = {
        "input_dim": len(feature_cols),
        "num_classes": len(class_names),
        "hidden_dim": len(feature_cols),
        "num_heads": 1,
        "num_layers": 1,
        "gcn_layers": 1,
        "dropout": 0.0,
        "gate": "mean",
        "encoder_ablation": "mlp_only",
        "record_head": False,
        "max_window_size": args.window_size,
        "num_groups": None,
        "use_group_embedding": False,
        "group_embedding_dim": 16,
        "unknown_group_index": None,
    }
    model = UCSOODID(**model_cfg)
    initialize_demo_model(model)
    model.eval()

    outputs = collect_model_outputs(model, windows, graph_cfg={}, batch_size=32, device="cpu", temperature=1.0)
    bank = PrototypeBank.fit(outputs["embeddings"], windows.y, class_names)
    raw_scores = compute_raw_ood_scores(
        outputs["logits"],
        outputs["probs"],
        outputs["embeddings"],
        bank,
        temperature=1.0,
        k_bank=args.bank_k,
    )
    ood_cal = OODCalibrator(fusion="proto", q_ood=args.bootstrap_q_ood, ood_threshold_mode="group")
    apply_bootstrap_thresholds(
        ood_cal,
        raw_scores,
        windows.group_ids,
        margin=float(args.bootstrap_threshold_margin),
    )

    artifact = {
        "model_state": model.state_dict(),
        "model_config": model_cfg,
        "graph_config": {},
        "run_config": {
            "seed": int(args.seed),
            "encoder_ablation": "mlp_only",
            "normalization_mode": "group",
            "ood_threshold_mode": "group",
        },
        "seed": int(args.seed),
        "normalization_mode": "group",
        "strict_model_feature_mode": True,
        "group_col": "uav_id",
        "feature_cols": list(pre.feature_cols),
        "feature_medians": dict(pre.feature_medians),
        "global_scaler": pre.scaler,
        "group_scalers": dict(getattr(pre, "group_scalers", {})),
        "group_normalization_fallbacks": dict(getattr(pre, "group_fallbacks", {})),
        "use_group_embedding": False,
        "group_embedding_dim": 16,
        "group_to_index": {},
        "unknown_group_index": None,
        "ood_threshold_mode": "group",
        "global_ood_threshold": float(ood_cal.threshold),
        "group_ood_thresholds": {str(group): float(value) for group, value in ood_cal.group_thresholds.items()},
        "group_raw_thresholds": {str(group): float(value) for group, value in ood_cal.group_raw_thresholds.items()},
        "group_smoothed_thresholds": {str(group): float(value) for group, value in ood_cal.group_smoothed_thresholds.items()},
        "group_threshold_sources": dict(ood_cal.group_threshold_sources),
        "group_validation_counts": {str(group): int(count) for group, count in ood_cal.group_validation_counts.items()},
        "group_ood_threshold_fallbacks": dict(ood_cal.group_threshold_fallbacks),
        "window_config": {
            "mode": "count",
            "size": int(args.window_size),
            "stride": int(args.stride),
            "time_seconds": float(args.dt_s),
            "adaptive_min_size": int(args.window_size),
            "adaptive_max_size": int(args.window_size),
        },
        "group_config": {"group_col": "uav_id"},
        "class_names": class_names,
        "class_to_idx": class_to_idx,
        "preprocessor": pre,
        "temperature": 1.0,
        "class_thresholds": np.asarray([0.5], dtype=np.float32),
        "prototype_bank": bank.to_dict(),
        "ood_calibrator": ood_cal.to_dict(),
        "calibration_config": {
            "q_ood": float(args.bootstrap_q_ood),
            "bank_k": int(args.bank_k),
            "fusion": "proto",
            "ood_threshold_mode": "group",
            "ood_direction_calibration": "bootstrap_benign_only",
            "group_threshold_strategy": str(ood_cal.group_threshold_strategy),
            "group_threshold_shrink_k": float(ood_cal.group_threshold_shrink_k),
            "group_threshold_min_ratio": float(ood_cal.group_threshold_min_ratio),
            "group_threshold_min_samples": int(ood_cal.group_threshold_min_samples),
        },
        "leakage_report": pre.leakage_report(df),
    }
    if args.artifact_out:
        save_artifact(args.artifact_out, artifact)
        save_json(list(pre.feature_cols), Path(args.artifact_out).resolve().parent / "feature_columns.json")
    return artifact


def compact_detection_trace(rows: list[dict]) -> list[dict]:
    trace = []
    for row in rows:
        truth = row.get("ground_truth", {})
        trace.append(
            {
                "simulation_time_s": float(row.get("simulation_time_s", 0.0)),
                "window_id": int(row["window_id"]),
                "ood_score": float(row["ood_score"]),
                "ood_threshold": float(row["ood_threshold"]),
                "is_ood": bool(row["is_ood"]),
                "alert_level": str(row["alert_level"]),
                "attack_active": bool(truth.get("attack_active", False)),
                "attack_types": list(truth.get("attack_types", [])),
                "record_ids": list(row.get("record_ids", [])),
            }
        )
    return trace


def summarize_trace(rows: list[dict], attack_start_s: float) -> dict:
    if not rows:
        return {
            "windows": 0,
            "max_pre_attack_ood_score": 0.0,
            "max_post_attack_ood_score": 0.0,
            "first_alert_time_s": None,
            "alerts_after_attack": 0,
        }
    pre = [row for row in rows if float(row.get("simulation_time_s", 0.0)) < attack_start_s]
    post = [row for row in rows if float(row.get("simulation_time_s", 0.0)) >= attack_start_s]
    alerts_after_attack = [
        row for row in post if bool(row.get("is_ood", False)) or str(row.get("alert_level", "")) in {"warning", "critical"}
    ]
    first_alert = next((row for row in rows if bool(row.get("is_ood", False))), None)
    return {
        "windows": len(rows),
        "max_pre_attack_ood_score": float(max((row["ood_score"] for row in pre), default=0.0)),
        "max_post_attack_ood_score": float(max((row["ood_score"] for row in post), default=0.0)),
        "first_alert_time_s": None if first_alert is None else float(first_alert.get("simulation_time_s", 0.0)),
        "alerts_after_attack": int(len(alerts_after_attack)),
    }


def effective_attack_start_s(args: argparse.Namespace) -> float:
    scenario_path = str(getattr(args, "attack_scenario_path", "") or "").strip()
    if scenario_path:
        scenario = load_scenario_from_yaml(scenario_path, set_as_active=False)
        if scenario.attack_events:
            return float(min(event.start_time for event in scenario.attack_events))
    return float(args.attack_start_s)


def main() -> None:
    """Run a no-UI single-UAV simulation demo, optionally with online detection."""

    args = parse_args()
    args.artifact = str(getattr(args, "artifact", "") or "").strip()

    if not args.online_detection:
        engine = build_demo_engine(args)
        result = engine.run()
        preview = [record.to_dict() for record in result.records[: max(args.head, 0)]]
        payload = {
            "records_preview": preview,
            "record_count": len(result.records),
            "attack_record_count": result.attack_record_count,
            "total_energy_wh": round(result.total_energy_wh, 4),
            "alert_count": result.alert_count,
            "response_count": result.response_count,
            "average_alert_delay": round(result.average_alert_delay, 4),
            "false_alert_count": result.false_alert_count,
            "mission_success": result.mission_success,
        }
        if args.output_json:
            save_json(payload, args.output_json)
        print(json.dumps(payload, indent=2, ensure_ascii=False))
        return

    if args.online_detection and not args.artifact:
        raise ValueError(
            "online_detection is enabled, but no trained artifact was provided. "
            "Please set artifact_path in configs/demo_scene_default.yaml "
            "or pass --artifact path/to/artifact.pt."
        )

    detector = OnlineDetector.from_artifact_path(
        args.artifact,
        top_records=args.top_records,
        group_col="uav_id",
    )
    artifact_window_config = dict(getattr(detector, "window_config", {}) or {})
    buffer = StreamingWindowBuffer(
        mode=str(artifact_window_config.get("mode", "count") or "count"),
        window_size=int(artifact_window_config.get("size", 32)),
        stride=int(artifact_window_config.get("stride", 16)),
        time_seconds=float(artifact_window_config.get("time_seconds", 2.0)),
        adaptive_min_size=int(artifact_window_config.get("adaptive_min_size", 8)),
        adaptive_max_size=int(artifact_window_config.get("adaptive_max_size", 64)),
        timestamp_col="timestamp",
        record_id_col="record_id",
        group_col="uav_id",
    )
    detector.use_artifact_calibrator_decision = True
    detector.score_threshold_mode = "artifact_ood_calibrator"
    if isinstance(getattr(detector, "threshold_config", None), dict):
        detector.threshold_config["threshold_mode"] = detector.score_threshold_mode
    detector.buffer = buffer
    detector.group_col = "uav_id"
    detector.pre.group_col = "uav_id"
    engine = build_demo_engine(args, enable_online_detection=True, online_detector=detector)
    result = engine.run()
    preview = [record.to_dict() for record in result.records[: max(args.head, 0)]]
    detections = list(result.online_detection_results)
    trace = compact_detection_trace(detections)
    attack_start_s = effective_attack_start_s(args)
    diagnostics = dict(getattr(result, "diagnostics", {}) or {})
    record_count = int(len(result.records))
    window_count = int(len(detections))
    attack_window_count = int(diagnostics.get("gt_attack_window_count", 0) or 0)
    ood_window_count = int(diagnostics.get("gt_ood_window_count", 0) or 0)
    benign_window_count = int(diagnostics.get("benign_window_count", max(window_count - attack_window_count - ood_window_count, 0)) or 0)
    predicted_alert_window_count = int(diagnostics.get("pred_alert_window_count", result.alert_count) or 0)
    false_alert_window_count = int(diagnostics.get("false_alert_window_count", result.false_alert_count) or 0)
    false_alert_ratio = float(false_alert_window_count / benign_window_count) if benign_window_count > 0 else 0.0
    response_action_count = int(len(result.response_events))
    ood_scores = [float(item.get("ood_score", 0.0)) for item in detections]
    average_ood_score = float(sum(ood_scores) / len(ood_scores)) if ood_scores else 0.0
    peak_ood_score = float(max(ood_scores)) if ood_scores else 0.0
    ids_inference_energy_wh = float(
        diagnostics.get(
            "summary_ids_energy_wh",
            sum(float(getattr(record, "detection_energy_wh", 0.0)) for record in result.records),
        )
        or 0.0
    )
    average_latency_ms = float(
        diagnostics.get(
            "summary_mean_latency_ms",
            (sum(float(getattr(record, "latency_ms", 0.0)) for record in result.records) / record_count) if record_count > 0 else 0.0,
        )
        or 0.0
    )
    average_cpu_load = float(
        diagnostics.get(
            "summary_mean_cpu_load",
            (sum(float(getattr(record, "cpu_load", 0.0)) for record in result.records) / record_count) if record_count > 0 else 0.0,
        )
        or 0.0
    )
    peak_temperature_c = float(
        diagnostics.get(
            "summary_peak_board_temperature_c",
            max((float(getattr(record, "board_temperature_c", 0.0)) for record in result.records), default=0.0),
        )
        or 0.0
    )
    average_packet_loss = float(
        diagnostics.get(
            "summary_mean_loss_rate",
            (sum(float(getattr(record, "loss_rate", 0.0)) for record in result.records) / record_count) if record_count > 0 else 0.0,
        )
        or 0.0
    )
    average_rssi = float(
        diagnostics.get(
            "summary_mean_rssi",
            (sum(float(getattr(record, "rssi", 0.0)) for record in result.records) / record_count) if record_count > 0 else 0.0,
        )
        or 0.0
    )
    payload = {
        "records_preview": preview,
        "artifact_path": str(args.artifact),
        "dataset_replay_mode": str(getattr(args, "dataset_replay_mode", "") or "").strip(),
        "pure_ids_csv_path": str(getattr(args, "pure_ids_csv_path", "") or "").strip(),
        "pure_ids_group_col": str(getattr(args, "pure_ids_group_col", "uav_id") or "uav_id"),
        "pure_ids_replay_split_filter": _parse_csv_items(
            getattr(args, "pure_ids_replay_split_filter", ("test_id", "test_ood"))
        ),
        "pure_ids_replay_keep_original_order": bool(
            getattr(args, "pure_ids_replay_keep_original_order", True)
        ),
        "pure_ids_replay_no_mixing": bool(getattr(args, "pure_ids_replay_no_mixing", True)),
        "window_mode": str(buffer.mode),
        "window_size": int(buffer.window_size),
        "stride": int(buffer.stride),
        "record_count": record_count,
        "window_count": window_count,
        "attack_record_count": result.attack_record_count,
        "attack_window_count": attack_window_count,
        "ood_window_count": ood_window_count,
        "benign_window_count": benign_window_count,
        "total_energy_wh": round(result.total_energy_wh, 4),
        "ids_inference_energy_wh": ids_inference_energy_wh,
        "online_detection_enabled": True,
        "alert_count": result.alert_count,
        "predicted_alert_window_count": predicted_alert_window_count,
        "response_count": result.response_count,
        "response_action_count": response_action_count,
        "average_alert_delay": round(result.average_alert_delay, 4),
        "false_alert_count": result.false_alert_count,
        "false_alert_window_count": false_alert_window_count,
        "false_alert_ratio": false_alert_ratio,
        "mission_success": result.mission_success,
        "attack_start_s": attack_start_s,
        "average_ood_score": average_ood_score,
        "peak_ood_score": peak_ood_score,
        "average_latency_ms": average_latency_ms,
        "average_cpu_load": average_cpu_load,
        "peak_temperature_c": peak_temperature_c,
        "average_packet_loss": average_packet_loss,
        "average_rssi": average_rssi,
        "trace_summary": summarize_trace(detections, attack_start_s),
        "ood_trace": trace,
        "online_detection_preview": detections[: max(args.head, 0)],
        "runtime_diagnostics": diagnostics,
        "response_events": list(result.response_events),
    }
    if args.output_json:
        save_json(payload, args.output_json)
    print(json.dumps(payload, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
