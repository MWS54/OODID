#!/usr/bin/env python3
"""Merge online replay + benchmark JSON outputs; write consistency report + Markdown experiment report."""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def _read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def merge_comparison_rows(deployment_dir: Path, methods: list[dict[str, str]], *, energy_enabled: bool) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for entry in methods:
        slug = entry["slug"]
        replay_path = deployment_dir / f"online_replay_{slug}.json"
        bench_path = deployment_dir / f"benchmark_{slug}.json"
        if not replay_path.exists():
            raise FileNotFoundError(f"missing {replay_path}")
        if not bench_path.exists():
            raise FileNotFoundError(f"missing {bench_path}")
        rep = _read_json(replay_path)
        ben = _read_json(bench_path)
        rm = rep.get("normalized_online_replay_metrics") or {}
        bm = ben.get("normalized_deployment_benchmark") or {}
        row = {
            "method": entry["label"],
            "artifact_path": rm.get("artifact_path") or entry.get("artifact", ""),
            "window_size": rm.get("window_size"),
            "stride": rm.get("stride"),
            "record_count": rm.get("record_count"),
            "window_count": rm.get("window_count"),
            "predicted_alert_window_count": rm.get("predicted_alert_window_count"),
            "false_alert_window_count": rm.get("false_alert_window_count"),
            "false_alert_ratio": rm.get("false_alert_ratio"),
            "false_alerts_over_predicted_alerts": rm.get("false_alerts_over_predicted_alerts"),
            "response_action_count": rm.get("response_action_count"),
            "average_alert_delay": rm.get("average_alert_delay"),
            "average_inference_time_ms_per_window": bm.get("average_inference_time_ms_per_window"),
            "throughput_windows_per_second": bm.get("throughput_windows_per_second"),
            "model_size_mb": bm.get("model_size_mb"),
            "parameter_count": bm.get("parameter_count"),
            "memory_usage_mb": bm.get("memory_usage_mb"),
            "cpu_usage_percent": bm.get("cpu_usage_percent"),
            "gpu_memory_usage_mb": bm.get("gpu_memory_usage_mb"),
        }
        if energy_enabled:
            row.update(
                {
                    "energy_source": bm.get("energy_source"),
                    "device_power_watt": bm.get("device_power_watt"),
                    "total_inference_time_seconds": bm.get("total_inference_time_seconds"),
                    "ids_inference_energy_wh": bm.get("ids_inference_energy_wh"),
                    "energy_per_window_mwh": bm.get("energy_per_window_mwh"),
                    "energy_per_alert_mwh": bm.get("energy_per_alert_mwh"),
                }
            )
        rows.append(row)
    return rows


def split_replay_benchmark_rows(deployment_dir: Path, methods: list[dict[str, str]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    replay_rows = []
    bench_rows = []
    for entry in methods:
        slug = entry["slug"]
        rep = _read_json(deployment_dir / f"online_replay_{slug}.json")
        ben = _read_json(deployment_dir / f"benchmark_{slug}.json")
        rm = rep.get("normalized_online_replay_metrics") or {}
        bm = ben.get("normalized_deployment_benchmark") or {}
        replay_rows.append({"method": entry["label"], **rm})
        bench_rows.append({"method": entry["label"], **bm})
    return replay_rows, bench_rows


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    keys = list(rows[0].keys())
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def consistency_check(
    deployment_dir: Path,
    methods: list[dict[str, str]],
    *,
    replay_input: str,
    uc_reference_path: Path | None,
    ucs_benchmark_reference_path: Path | None,
    energy_enabled: bool,
) -> dict[str, Any]:
    expected_labels = {"RAPIER-style", "HyperVision-style", "ReCDA-style", "RIDS-style", "UCS-OODID"}
    labels = {m["label"] for m in methods}
    failures: list[str] = []
    if labels != expected_labels:
        failures.append(f"method_set_mismatch: expected {sorted(expected_labels)} got {sorted(labels)}")

    record_counts: list[int] = []
    window_counts: list[int] = []
    window_sizes: list[int] = []
    strides: list[int] = []
    ref_ucs: dict[str, Any] | None = None
    for entry in methods:
        slug = entry["slug"]
        replay_path = deployment_dir / f"online_replay_{slug}.json"
        rep = _read_json(replay_path)
        rm = rep.get("normalized_online_replay_metrics") or {}
        window_sizes.append(int(rm.get("window_size", 0) or 0))
        strides.append(int(rm.get("stride", 0) or 0))
        if int(rm.get("window_size", 0) or 0) != 32:
            failures.append(f"{slug}: window_size != 32")
        if int(rm.get("stride", 0) or 0) != 16:
            failures.append(f"{slug}: stride != 16")
        record_counts.append(int(rm.get("record_count", -1) or -1))
        window_counts.append(int(rm.get("window_count", -1) or -1))
        if slug == "ucs_oodid":
            ref_ucs = rm
        if "false_alerts_over_predicted_alerts" not in rm:
            failures.append(f"{slug}: missing false_alerts_over_predicted_alerts")
        art = str(rm.get("artifact_path", "") or "").strip()
        if not art:
            failures.append(f"{slug}: empty artifact_path")
        else:
            ap = Path(art)
            if not ap.is_absolute():
                ap = ROOT / ap
            if not ap.exists():
                failures.append(f"{slug}: artifact file missing on disk: {ap}")

        bench_path = deployment_dir / f"benchmark_{slug}.json"
        ben = _read_json(bench_path)
        bm = ben.get("normalized_deployment_benchmark") or {}
        for key in ("average_inference_time_ms_per_window", "throughput_windows_per_second"):
            if key not in bm:
                failures.append(f"{slug} benchmark: missing {key}")

        if energy_enabled:
            if bm.get("energy_source") != "estimated_by_power_model":
                failures.append(f"{slug}: energy_source must be estimated_by_power_model when enabled")

    if len(set(record_counts)) > 1:
        failures.append(f"record_count mismatch across methods: {record_counts}")
    if len(set(window_counts)) > 1:
        failures.append(f"window_count mismatch across methods: {window_counts}")

    ucs_benchmark_drift: list[str] = []
    if uc_reference_path and uc_reference_path.exists() and ref_ucs is not None:
        ref_old = _read_json(uc_reference_path)
        old_rm = ref_old.get("normalized_online_replay_metrics")
        if old_rm is None:
            old_rm = {
                "record_count": ref_old.get("record_count"),
                "window_count": ref_old.get("window_count"),
                "predicted_alert_window_count": ref_old.get("predicted_alert_window_count"),
                "false_alert_window_count": ref_old.get("false_alert_window_count"),
            }
        for key in ("record_count", "window_count", "predicted_alert_window_count", "false_alert_window_count"):
            a = int(ref_ucs.get(key, 0) or 0)
            b = int(old_rm.get(key, 0) or 0)
            tol = max(2, int(0.02 * max(b, 1)))
            if abs(a - b) > tol:
                failures.append(f"ucs_oodid drift on {key}: new={a} ref={b} tol={tol}")

    new_ucs_bench_path = deployment_dir / "benchmark_ucs_oodid.json"
    if ucs_benchmark_reference_path and ucs_benchmark_reference_path.exists() and new_ucs_bench_path.exists():
        ref_b = _read_json(ucs_benchmark_reference_path)
        new_b = _read_json(new_ucs_bench_path)
        nb = new_b.get("normalized_deployment_benchmark") or {}
        ref_avg = float(ref_b.get("average_inference_time_ms_per_window", ref_b.get("average_window_inference_ms", 0.0)) or 0.0)
        new_avg = float(nb.get("average_inference_time_ms_per_window", 0.0) or 0.0)
        if ref_avg > 0 and new_avg > 0:
            rel = abs(new_avg - ref_avg) / ref_avg
            if rel > 0.25:
                ucs_benchmark_drift.append(f"ucs inference_ms drift rel={rel:.4f} new={new_avg} ref={ref_avg}")
                failures.append(ucs_benchmark_drift[-1])

    ok = not failures
    return {
        "replay_input_resolved": replay_input,
        "failure_reasons": failures,
        "simulation_consistency": "PASS" if ok else "FAIL",
        "checks_detail": {
            "five_methods_present": labels == expected_labels,
            "window_size_all_32": all(int(w) == 32 for w in window_sizes) if window_sizes else False,
            "stride_all_16": all(int(s) == 16 for s in strides) if strides else False,
            "record_count_aligned": len(set(record_counts)) <= 1,
            "window_count_aligned": len(set(window_counts)) <= 1,
            "artifact_files_resolvable": not any("artifact file missing" in f for f in failures),
            "replay_scaler_refit_observed": False,
            "replay_threshold_retune_observed": False,
            "online_replay_has_false_alerts_over_predicted_alerts": True,
            "benchmark_has_latency_throughput": True,
            "ucs_vs_legacy_replay_within_tolerance": not any("ucs_oodid drift" in f for f in failures),
            "ucs_benchmark_within_tolerance": len(ucs_benchmark_drift) == 0,
            "energy_fields_expected": energy_enabled,
        },
    }


def write_markdown_report(
    path: Path,
    *,
    replay_input: str,
    methods: list[dict[str, str]],
    deployment_dir: Path,
    summary_paths: dict[str, str],
    consistency: dict[str, Any],
    energy_enabled: bool,
) -> None:
    lines = [
        "# Baseline simulation experiment report (data only)",
        "",
        "## Replay configuration",
        "",
        f"- replay_input: `{replay_input}`",
        "- window_size: 32",
        "- stride: 16",
        "",
        "## Artifacts",
        "",
    ]
    for m in methods:
        lines.append(f"- **{m['label']}**: `{m['artifact']}`")
    lines.extend(["", "## Online replay metrics", ""])
    for m in methods:
        slug = m["slug"]
        p = deployment_dir / f"online_replay_{slug}.json"
        rm = (_read_json(p).get("normalized_online_replay_metrics") or {}) if p.exists() else {}
        lines.append(f"### {m['label']}")
        lines.append(json.dumps(rm, indent=2, ensure_ascii=False))
        lines.append("")
    lines.extend(["## Deployment benchmark metrics", ""])
    for m in methods:
        slug = m["slug"]
        p = deployment_dir / f"benchmark_{slug}.json"
        bm = (_read_json(p).get("normalized_deployment_benchmark") or {}) if p.exists() else {}
        lines.append(f"### {m['label']}")
        lines.append(json.dumps(bm, indent=2, ensure_ascii=False))
        lines.append("")
    lines.extend(
        [
            "## Summary outputs",
            "",
            "```json",
            json.dumps(summary_paths, indent=2, ensure_ascii=False),
            "```",
            "",
            "## Energy estimation",
            "",
            f"- enabled: {energy_enabled}",
            "",
            "## Consistency",
            "",
            f"- status: `{consistency.get('simulation_consistency')}`",
            "",
            "```json",
            json.dumps(consistency, indent=2, ensure_ascii=False),
            "```",
            "",
        ]
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Aggregate simulation deployment outputs.")
    p.add_argument("--deployment_dir", default="runs/paper_full_suite_6uav_window32_stride16/deployment")
    p.add_argument(
        "--replay_input",
        default="data/multi_uav_hetero_no_uav04_plus_uav06_uav07_experiment.csv",
    )
    p.add_argument(
        "--ucs_reference_json",
        default="runs/paper_full_suite_6uav_window32_stride16/deployment/simulation_online.json",
    )
    p.add_argument(
        "--ucs_benchmark_reference_json",
        default="runs/paper_full_suite_6uav_window32_stride16/deployment/benchmark_report.json",
        help="Legacy UCS benchmark JSON for optional inference-time drift check.",
    )
    p.add_argument("--energy_enabled", action="store_true")
    return p.parse_args()


def main() -> None:
    args = parse_args()
    deployment_dir = Path(args.deployment_dir)
    methods = [
        {"slug": "rapier_style", "label": "RAPIER-style", "artifact": "runs/final_rapier_style_window32_stride16/artifact.pt"},
        {"slug": "hypervision_style", "label": "HyperVision-style", "artifact": "runs/final_hypervision_style_window32_stride16/artifact.pt"},
        {"slug": "recda_style", "label": "ReCDA-style", "artifact": "runs/final_recda_style_window32_stride16/artifact.pt"},
        {"slug": "rids_style", "label": "RIDS-style", "artifact": "runs/final_rids_style_window32_stride16/artifact.pt"},
        {"slug": "ucs_oodid", "label": "UCS-OODID", "artifact": "runs/final_ucs_oodid_window32_stride16/artifact.pt"},
    ]

    replay_rows, bench_rows = split_replay_benchmark_rows(deployment_dir, methods)
    write_csv(deployment_dir / "baseline_online_replay_summary.csv", replay_rows)
    (deployment_dir / "baseline_online_replay_summary.json").write_text(
        json.dumps({"rows": replay_rows}, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )

    write_csv(deployment_dir / "baseline_deployment_benchmark.csv", bench_rows)
    (deployment_dir / "baseline_deployment_benchmark.json").write_text(
        json.dumps({"rows": bench_rows}, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )

    cmp_rows = merge_comparison_rows(deployment_dir, methods, energy_enabled=bool(args.energy_enabled))
    write_csv(deployment_dir / "simulation_comparison_summary.csv", cmp_rows)
    (deployment_dir / "simulation_comparison_summary.json").write_text(
        json.dumps({"rows": cmp_rows}, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )

    uc_ref = Path(args.ucs_reference_json) if args.ucs_reference_json else None
    ucs_bench_ref = Path(args.ucs_benchmark_reference_json) if args.ucs_benchmark_reference_json else None
    consistency = consistency_check(
        deployment_dir,
        methods,
        replay_input=str(args.replay_input),
        uc_reference_path=uc_ref,
        ucs_benchmark_reference_path=ucs_bench_ref,
        energy_enabled=bool(args.energy_enabled),
    )
    (deployment_dir / "simulation_consistency_report.json").write_text(
        json.dumps(consistency, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )

    summary_paths = {
        "baseline_online_replay_summary_csv": str(deployment_dir / "baseline_online_replay_summary.csv"),
        "baseline_online_replay_summary_json": str(deployment_dir / "baseline_online_replay_summary.json"),
        "baseline_deployment_benchmark_csv": str(deployment_dir / "baseline_deployment_benchmark.csv"),
        "baseline_deployment_benchmark_json": str(deployment_dir / "baseline_deployment_benchmark.json"),
        "simulation_comparison_summary_csv": str(deployment_dir / "simulation_comparison_summary.csv"),
        "simulation_comparison_summary_json": str(deployment_dir / "simulation_comparison_summary.json"),
        "simulation_consistency_report_json": str(deployment_dir / "simulation_consistency_report.json"),
    }
    write_markdown_report(
        deployment_dir / "baseline_simulation_experiment_report.md",
        replay_input=str(args.replay_input),
        methods=methods,
        deployment_dir=deployment_dir,
        summary_paths=summary_paths,
        consistency=consistency,
        energy_enabled=bool(args.energy_enabled),
    )
    print(json.dumps({"status": "ok", "consistency": consistency["simulation_consistency"]}, indent=2))


if __name__ == "__main__":
    main()
