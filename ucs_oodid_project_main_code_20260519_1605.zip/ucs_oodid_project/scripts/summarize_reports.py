#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path
from typing import Any, Iterable

NA = "NA"

COLUMN_SPECS = [
    ("experiment_name", "experiment_name"),
    ("encoder_ablation", "encoder_ablation"),
    ("graph_variant", "graph_variant"),
    ("ood_fusion", "ood_fusion"),
    ("Micro-F1", "micro_f1"),
    ("Macro-F1", "macro_f1"),
    ("mAP", "mAP"),
    ("OOD AUROC", "ood_auroc"),
    ("OOD AUPR-Out", "ood_aupr_out"),
    ("FPR95", "fpr95"),
    ("OOD Precision", "ood_precision"),
    ("OOD Recall/TPR", "ood_tpr"),
    ("OOD-F1", "ood_f1"),
    ("Top-100 record precision", "top100_precision"),
    ("Top-100 record recall", "top100_recall"),
    ("latency_ms", "latency_ms"),
    ("throughput_windows_per_sec", "throughput_windows_per_sec"),
]

FIELD_CANDIDATES = {
    "encoder_ablation": [
        "encoder_ablation",
        "run_config.encoder_ablation",
        "model_config.encoder_ablation",
    ],
    "graph_variant": [
        "graph_variant",
        "run_config.graph_variant",
        "graph_config.variant",
    ],
    "ood_fusion": [
        "ood_fusion",
        "calibration_config.fusion",
        "run_config.fusion",
        "fusion",
    ],
    "micro_f1": [
        "id_test.micro_f1",
        "micro_f1",
    ],
    "macro_f1": [
        "id_test.macro_f1",
        "macro_f1",
    ],
    "mAP": [
        "id_test.mAP",
        "mAP",
    ],
    "ood_auroc": [
        "ood_test.auroc",
        "auroc",
    ],
    "ood_aupr_out": [
        "ood_test.aupr_out",
        "aupr_out",
    ],
    "fpr95": [
        "ood_test.fpr95",
        "fpr95",
    ],
    "ood_precision": [
        "ood_test.precision",
        "precision",
        "ood_precision",
    ],
    "ood_tpr": [
        "ood_test.tpr",
        "tpr",
        "recall",
        "ood_recall",
    ],
    "ood_f1": [
        "ood_test.ood_f1",
        "ood_f1",
    ],
    "top100_precision": [
        "record_level_suspiciousness_ranking.topk_metrics.100.localization_precision",
        "record_level_suspiciousness_ranking.topk_metrics.100.precision",
        "topk_metrics.100.localization_precision",
        "topk_metrics.100.precision",
        "metrics.100.localization_precision",
        "metrics.100.precision",
    ],
    "top100_recall": [
        "record_level_suspiciousness_ranking.topk_metrics.100.localization_recall",
        "record_level_suspiciousness_ranking.topk_metrics.100.recall",
        "topk_metrics.100.localization_recall",
        "topk_metrics.100.recall",
        "metrics.100.localization_recall",
        "metrics.100.recall",
    ],
    "latency_ms": [
        "latency_ms",
        "total_ms",
    ],
    "throughput_windows_per_sec": [
        "throughput_windows_per_sec",
    ],
}


def warn(message: str) -> None:
    print(f"[summarize_reports] {message}", file=sys.stderr)


def safe_load_json(path: Path) -> dict[str, Any]:
    try:
        obj = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:  # pragma: no cover - defensive path
        warn(f"failed to read {path}: {exc}")
        return {}
    if not isinstance(obj, dict):
        warn(f"ignoring non-object JSON in {path}")
        return {}
    return obj


def get_nested(obj: dict[str, Any], dotted_key: str) -> Any:
    cur: Any = obj
    for part in dotted_key.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return None
        cur = cur[part]
    return cur


def pick_first(payloads: Iterable[dict[str, Any]], candidates: list[str]) -> Any:
    for payload in payloads:
        for key in candidates:
            value = get_nested(payload, key)
            if value is not None:
                return value
    return NA


def format_scalar(value: Any) -> str:
    if value is None:
        return NA
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        return format(value, ".4f")
    if isinstance(value, str):
        text = value.strip()
        return text if text else NA
    return json.dumps(value, ensure_ascii=False)


def candidate_priority(path: Path) -> tuple[int, int, str]:
    name = path.name.lower()
    if name == "eval_report.json":
        return (0, len(name), name)
    if name.startswith("eval_report"):
        return (1, len(name), name)
    if name == "attribution_metrics.json":
        return (2, len(name), name)
    if "ood_only" in name:
        return (3, len(name), name)
    if name.startswith("attribution_metrics"):
        return (4, len(name), name)
    if name == "edge_benchmark.json":
        return (5, len(name), name)
    if name == "edge_benchmark_eval.json":
        return (6, len(name), name)
    if name.startswith("edge_benchmark"):
        return (7, len(name), name)
    return (8, len(name), name)


def collect_related_reports(primary_path: Path) -> list[Path]:
    parent = primary_path.parent
    seen: set[Path] = set()
    ordered: list[Path] = []
    sibling_candidates: list[Path] = []
    for pattern in ("eval_report*.json", "attribution_metrics*.json", "edge_benchmark*.json"):
        sibling_candidates.extend(parent.glob(pattern))
    for path in [primary_path, *sorted(sibling_candidates, key=candidate_priority)]:
        resolved = path.resolve()
        if resolved in seen:
            continue
        seen.add(resolved)
        ordered.append(path)
    return ordered


def latex_escape(text: str) -> str:
    replacements = {
        "\\": r"\textbackslash{}",
        "&": r"\&",
        "%": r"\%",
        "$": r"\$",
        "#": r"\#",
        "_": r"\_",
        "{": r"\{",
        "}": r"\}",
        "~": r"\textasciitilde{}",
        "^": r"\textasciicircum{}",
    }
    out = []
    for ch in text:
        out.append(replacements.get(ch, ch))
    return "".join(out)


def summarize_report(path: Path) -> dict[str, str]:
    payloads = [safe_load_json(candidate) for candidate in collect_related_reports(path)]
    primary = payloads[0] if payloads else {}

    experiment_name = (
        get_nested(primary, "experiment_name")
        or get_nested(primary, "run_name")
        or path.parent.name
        or path.stem
    )

    row = {"experiment_name": format_scalar(experiment_name)}
    for _, field_key in COLUMN_SPECS[1:]:
        row[field_key] = format_scalar(pick_first(payloads, FIELD_CANDIDATES[field_key]))
    return row


def write_csv(rows: list[dict[str, str]], output_csv: Path) -> None:
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    headers = [header for header, _ in COLUMN_SPECS]
    with output_csv.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=headers)
        writer.writeheader()
        for row in rows:
            writer.writerow({header: row[field_key] for header, field_key in COLUMN_SPECS})


def write_latex(rows: list[dict[str, str]], output_latex: Path) -> None:
    output_latex.parent.mkdir(parents=True, exist_ok=True)
    headers = [header for header, _ in COLUMN_SPECS]
    aligns = "".join("l" if i < 4 else "r" for i in range(len(headers)))
    lines = [
        r"\begin{tabular}{" + aligns + "}",
        r"\toprule",
        " & ".join(latex_escape(header) for header in headers) + r" \\",
        r"\midrule",
    ]
    for row in rows:
        cells = [latex_escape(row[field_key]) for _, field_key in COLUMN_SPECS]
        lines.append(" & ".join(cells) + r" \\")
    lines.extend([r"\bottomrule", r"\end{tabular}"])
    output_latex.write_text("\n".join(lines) + "\n", encoding="utf-8")


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Summarize eval/attribution/edge benchmark JSON reports into CSV and optional LaTeX.",
        epilog=(
            "Example:\n"
            "  python scripts/summarize_reports.py "
            "--reports runs/exp1/eval_report.json runs/exp2/eval_report.json "
            "--output_csv runs/summary.csv "
            "--output_latex runs/summary.tex"
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )
    p.add_argument("--reports", nargs="+", required=True, help="One or more report JSON paths.")
    p.add_argument("--output_csv", required=True, help="Output CSV path.")
    p.add_argument("--output_latex", default="", help="Optional LaTeX output path.")
    return p.parse_args()


def main() -> None:
    args = parse_args()
    report_paths = [Path(p) for p in args.reports]
    rows = [summarize_report(path) for path in report_paths]
    write_csv(rows, Path(args.output_csv))
    if args.output_latex:
        write_latex(rows, Path(args.output_latex))
    print(json.dumps(
        {
            "reports": [str(path) for path in report_paths],
            "rows": len(rows),
            "output_csv": str(Path(args.output_csv)),
            "output_latex": str(Path(args.output_latex)) if args.output_latex else None,
        },
        indent=2,
        ensure_ascii=False,
    ))


if __name__ == "__main__":
    main()
