#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
import time
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from tqdm import tqdm

from ucs_oodid.artifacts import save_artifact
from ucs_oodid.dataset import WindowTorchDataset
from ucs_oodid.experiment_utils import prepare_window_dataset
from ucs_oodid.graph import build_behavior_graph, canonicalize_graph_variant
from ucs_oodid.inference import collect_model_outputs
from ucs_oodid.io import save_json
from ucs_oodid.metrics import compute_class_support, compute_present_class_macro_f1, multilabel_metrics, ood_metrics
from ucs_oodid.model import UCSOODID, canonicalize_encoder_ablation
from ucs_oodid.ood import (
    OODCalibrator,
    PrototypeBank,
    build_leave_one_class_out_pseudo_ood,
    calibrate_class_thresholds,
    calibrate_temperature,
    canonicalize_ood_fusion,
    compute_raw_ood_scores,
)
from ucs_oodid.utils import choose_device, ensure_dir, set_seed
from ucs_oodid.windowing import (
    UNKNOWN_GROUP_TOKEN,
    attach_group_index,
    build_group_to_index,
    window_phase_labels,
)

DEPRECATED_NO_GRAPH_MESSAGE = "`no_graph` is deprecated and mapped to `identity_graph`; it is not a strict graph-free baseline."


def maybe_build_graph(model, x, mask, graph_cfg):
    if not model.uses_graph_encoder:
        return None
    return build_behavior_graph(x, mask=mask, **graph_cfg).adj


def temporal_enabled_for_ablation(encoder_ablation: str) -> bool:
    mode = canonicalize_encoder_ablation(encoder_ablation)
    return mode in {"full", "transformer_only", "random_graph"}


def graph_enabled_for_ablation(encoder_ablation: str) -> bool:
    mode = canonicalize_encoder_ablation(encoder_ablation)
    return mode in {"full", "gcn_only", "random_graph"}


def graph_neighbor_strategy_for_ablation(encoder_ablation: str) -> str:
    return "random" if canonicalize_encoder_ablation(encoder_ablation) == "random_graph" else "knn"


def effective_graph_variant(encoder_ablation: str, graph_variant: str) -> str:
    mode = canonicalize_encoder_ablation(encoder_ablation)
    if not graph_enabled_for_ablation(mode):
        return "disabled"
    if mode == "random_graph":
        return "random_graph"
    return canonicalize_graph_variant(graph_variant)


def ordered_ood_weights(ood_cal):
    return {name: float(ood_cal.weights.get(name, 0.0)) for name in ood_cal.score_names}


def default_direction_item(score_name):
    return {
        "score_name": score_name,
        "raw_auroc": None,
        "flipped": False,
        "effective_auroc": None,
        "direction": 1.0,
    }


def ordered_direction_report(score_names, report):
    report_by_name = {item["score_name"]: item for item in report}
    return [report_by_name.get(name, default_direction_item(name)) for name in score_names]


def ordered_ood_direction_report(ood_cal):
    return ordered_direction_report(ood_cal.score_names, ood_cal.direction_report)


def ordered_ood_directions(ood_cal):
    return {name: float(ood_cal.directions.get(name, 1.0)) for name in ood_cal.score_names}


def build_direction_diagnostic_payload(score_names, report=None, label_source="none", enabled=False, note=None):
    payload = {
        "enabled": bool(enabled),
        "label_source": label_source,
        "used_for_direction_flip": False,
        "report": ordered_direction_report(score_names, report or []),
    }
    if note:
        payload["note"] = note
    return payload


def conf_energy_direction_diagnostic(ood_cal):
    report_by_name = {item["score_name"]: item for item in ordered_ood_direction_report(ood_cal)}
    out = {}
    for name in ("conf", "energy"):
        item = report_by_name.get(name, {"score_name": name, "raw_auroc": None, "flipped": False, "effective_auroc": None, "direction": 1.0})
        raw_auroc = item.get("raw_auroc")
        effective_auroc = item.get("effective_auroc")
        flipped = bool(item.get("flipped", False))
        if raw_auroc is None or effective_auroc is None:
            diagnosis = "no_labeled_direction_check"
        elif flipped and effective_auroc > 0.5:
            diagnosis = "direction_issue_detected"
        elif effective_auroc <= 0.5:
            diagnosis = "not_explained_by_sign"
        else:
            diagnosis = "direction_ok"
        out[name] = {
            "raw_auroc": raw_auroc,
            "flipped": flipped,
            "effective_auroc": effective_auroc,
            "direction": item.get("direction", 1.0),
            "diagnosis": diagnosis,
        }
    return out


def phase_threshold_summary(ood_cal):
    return {
        "enabled": bool(ood_cal.phase_aware_enabled),
        "phase_column": ood_cal.phase_column,
        "phase_threshold_min_samples": int(ood_cal.phase_threshold_min_samples),
        "phase_threshold_quantile": ood_cal.phase_threshold_quantile,
        "phase_threshold_fallback": ood_cal.phase_threshold_fallback,
        "global_threshold": float(ood_cal.threshold),
        "phase_thresholds": {phase: float(value) for phase, value in ood_cal.phase_thresholds.items()},
        "phase_validation_counts": {phase: int(value) for phase, value in ood_cal.phase_validation_counts.items()},
        "phase_threshold_sources": dict(ood_cal.phase_threshold_sources),
    }


def ood_threshold_summary(ood_cal):
    return {
        "ood_threshold_mode": ood_cal.ood_threshold_mode,
        "global_ood_threshold": float(ood_cal.threshold),
        "group_threshold_min_samples": int(ood_cal.group_threshold_min_samples),
        "group_threshold_quantile": ood_cal.group_threshold_quantile,
        "group_threshold_strategy": ood_cal.group_threshold_strategy,
        "group_threshold_shrink_k": float(ood_cal.group_threshold_shrink_k),
        "group_threshold_min_ratio": float(ood_cal.group_threshold_min_ratio),
        "group_ood_thresholds": {group: float(value) for group, value in ood_cal.group_thresholds.items()},
        "group_raw_thresholds": {group: float(value) for group, value in ood_cal.group_raw_thresholds.items()},
        "group_smoothed_thresholds": {group: float(value) for group, value in ood_cal.group_smoothed_thresholds.items()},
        "group_threshold_sources": dict(ood_cal.group_threshold_sources),
        "group_validation_counts": {group: int(value) for group, value in ood_cal.group_validation_counts.items()},
        "group_ood_threshold_fallbacks": dict(ood_cal.group_threshold_fallbacks),
    }


def group_embedding_summary(enabled, embedding_dim, group_to_index):
    known_groups = [group for group in group_to_index if group != UNKNOWN_GROUP_TOKEN]
    return {
        "enabled": bool(enabled),
        "embedding_dim": int(embedding_dim),
        "num_groups": int(len(known_groups)),
        "group_to_index": dict(group_to_index),
    }


def build_deployment_profile(args, graph_enabled):
    return {
        "deployment_target": "uav_onboard",
        "encoder": args.encoder_ablation,
        "graph_enabled": bool(graph_enabled),
        "lightweight": bool(
            args.encoder_ablation == "transformer_only"
            and int(args.hidden_dim) <= 64
            and int(args.num_heads) <= 2
            and int(args.num_layers) <= 1
        ),
    }


def infer_method_name(
    encoder_ablation: str,
    fusion: str,
    ood_threshold_mode: str,
    group_threshold_strategy: str | None = None,
) -> str:
    encoder_key = str(encoder_ablation).strip().lower()
    fusion_key = str(fusion).strip().lower()
    threshold_key = str(ood_threshold_mode).strip().lower()
    strategy_key = str(group_threshold_strategy or "").strip().lower()
    if (
        encoder_key == "transformer_only"
        and fusion_key == "correlation_aware"
        and threshold_key == "group"
        and strategy_key == "conservative"
    ):
        return "ucs_oodid"
    if encoder_key == "transformer_only" and fusion_key == "correlation_aware" and threshold_key == "global":
        return "recda_proxy"
    if encoder_key == "full" and fusion_key == "mean" and threshold_key == "global":
        return "hypervision_proxy"
    if encoder_key == "transformer_only" and fusion_key == "mean":
        return "transformer_only_mean"
    if encoder_key == "full":
        return "transformer_gcn"
    return encoder_key


def compute_phase_test_metrics(y_true_ood, scores, decisions, phases, ood_cal):
    if phases is None or not ood_cal.phase_aware_enabled or ood_cal.ood_threshold_mode != "global":
        return {}
    labels = np.asarray(phases, dtype=object)
    metrics_by_phase = {}
    for phase in sorted({str(label) for label in labels.tolist() if label is not None and str(label).strip()}):
        mask = labels == phase
        if not np.any(mask):
            continue
        metrics = ood_metrics(y_true_ood[mask].astype(int), scores[mask], decisions[mask])
        metrics_by_phase[phase] = {
            "windows": int(mask.sum()),
            "validation_count": int(ood_cal.phase_validation_counts.get(phase, 0)),
            "threshold": float(ood_cal.phase_thresholds.get(phase, ood_cal.threshold)),
            "threshold_source": ood_cal.phase_threshold_sources.get(phase, "global"),
            "alert_rate": float(np.mean(decisions[mask])) if np.any(mask) else 0.0,
            "precision": float(metrics.get("precision", float("nan"))),
            "recall": float(metrics.get("tpr", float("nan"))),
            "f1": float(metrics.get("ood_f1", float("nan"))),
            "auroc": float(metrics.get("auroc", float("nan"))),
        }
    return metrics_by_phase


def _counter_to_dict(counter):
    return {str(key): int(counter[key]) for key in sorted(counter)}


def _group_indices(group_ids):
    if group_ids is None:
        return {}
    arr = np.asarray(group_ids)
    if arr.size == 0:
        return {}
    groups = {}
    for idx, value in enumerate(arr.tolist()):
        if value is None or (isinstance(value, (float, np.floating)) and np.isnan(value)):
            key = "nan"
        else:
            key = str(value)
        groups.setdefault(key, []).append(idx)
    return {group: np.asarray(indices, dtype=np.int64) for group, indices in groups.items()}


def _group_count_dict(group_ids):
    counts = Counter()
    for group, indices in _group_indices(group_ids).items():
        counts[group] = len(indices)
    return _counter_to_dict(counts)


def compute_id_metrics_by_group(windows, probs, thresholds, label_names=None, present_class_min_support=1):
    """
    按 windows.group_ids 分组计算 ID 多标签分类指标。
    如果 windows.group_ids 不存在或为空，返回 {}。
    每个 group 输出：
    - windows
    - micro_f1
    - macro_f1
    - present_class_macro_f1
    - present_class_count
    - absent_class_count
    - hamming_loss
    - subset_accuracy
    - mAP
    - class_support
    """
    groups = _group_indices(getattr(windows, "group_ids", None))
    if not groups:
        return {}
    thresholds_array = np.asarray(thresholds, dtype=np.float32)
    preds = (np.asarray(probs) >= thresholds_array.reshape(1, -1)).astype(int)
    summary = {}
    for group, indices in groups.items():
        group_y = np.asarray(windows.y[indices])
        group_probs = np.asarray(probs[indices])
        metrics = multilabel_metrics(group_y, group_probs, thresholds_array)
        summary[group] = {
            "windows": int(len(indices)),
            **metrics,
            **compute_present_class_macro_f1(
                group_y,
                preds[indices],
                label_names=label_names,
                min_support=present_class_min_support,
            ),
            "class_support": compute_class_support(group_y, label_names=label_names),
        }
    return summary


def compute_ood_metrics_by_group(group_ids, y_true_ood, scores, decisions):
    """
    按 group_ids 分组计算 OOD 指标。
    如果 group_ids 不存在或为空，返回 {}。
    每个 group 输出：
    - windows
    - known_windows
    - ood_windows
    - alert_rate
    - auroc
    - aupr_out
    - fpr95
    - precision
    - tpr
    - ood_f1
    """
    groups = _group_indices(group_ids)
    if not groups:
        return {}
    y_true_ood = np.asarray(y_true_ood)
    scores = np.asarray(scores)
    decisions_array = None if decisions is None else np.asarray(decisions)
    summary = {}
    for group, indices in groups.items():
        group_y = y_true_ood[indices].astype(int)
        group_scores = scores[indices]
        group_decisions = None if decisions_array is None else decisions_array[indices]
        metrics = ood_metrics(group_y, group_scores, group_decisions)
        summary[group] = {
            "windows": int(len(indices)),
            "known_windows": int(np.sum(group_y == 0)),
            "ood_windows": int(np.sum(group_y == 1)),
            "alert_rate": float(np.mean(group_decisions.astype(float))) if group_decisions is not None and len(group_decisions) else float("nan"),
            **metrics,
        }
    return summary


def summarize_record_labels(df, id_classes):
    label_counts = Counter()
    ood_counts = Counter()
    id_set = {str(label) for label in id_classes}
    for labels in df.get("__labels", []):
        for label in labels:
            label = str(label)
            label_counts[label] += 1
            if label not in id_set:
                ood_counts[label] += 1
    return _counter_to_dict(label_counts), _counter_to_dict(ood_counts)


def log_split_summaries(split_source, split_frames, split_windows, id_classes, group_col=None):
    summary = {"split_source": split_source, "splits": {}}
    for split_name, split_df in split_frames.items():
        label_counts, ood_counts = summarize_record_labels(split_df, id_classes)
        windows = split_windows.get(split_name)
        split_summary = {
            "records": int(len(split_df)),
            "windows": int(len(windows)) if windows is not None else 0,
            "label_distribution": label_counts,
            "ood_class_distribution": ood_counts,
        }
        if group_col and group_col in split_df.columns:
            split_summary["group_distribution"] = _group_count_dict(split_df[group_col].to_numpy())
        if windows is not None and getattr(windows, "group_ids", None) is not None:
            split_summary["window_group_distribution"] = _group_count_dict(windows.group_ids)
        summary["splits"][split_name] = split_summary
    print(json.dumps({"dataset_split_summary": summary}, indent=2, ensure_ascii=False))


def train_one_epoch(model, loader, optimizer, graph_cfg, device, pos_weight=None, lambda_record=0.0):
    model.train()
    total = 0.0
    count = 0
    for batch in tqdm(loader, desc="train", leave=False):
        x = batch["x"].to(device)
        y = batch["y"].to(device)
        mask = batch.get("mask")
        mask = mask.to(device) if mask is not None else None
        group_index = batch.get("group_index")
        group_index = group_index.to(device) if group_index is not None else None
        adj = maybe_build_graph(model, x, mask, graph_cfg)
        out = model(x, adj, mask=mask, group_index=group_index)
        loss = F.binary_cross_entropy_with_logits(out["logits"], y, pos_weight=pos_weight)
        if lambda_record > 0 and "record_logits" in out and "record_y" in batch:
            record_y = batch["record_y"].to(device)
            record_mask = batch.get("mask")
            if record_mask is not None:
                record_mask = record_mask.to(device).unsqueeze(-1).float()
                rec_loss = F.binary_cross_entropy_with_logits(out["record_logits"], record_y, reduction="none")
                rec_loss = (rec_loss * record_mask).sum() / (record_mask.sum().clamp_min(1.0) * rec_loss.shape[-1])
            else:
                rec_loss = F.binary_cross_entropy_with_logits(out["record_logits"], record_y)
            loss = loss + lambda_record * rec_loss
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
        optimizer.step()
        total += float(loss.item()) * len(x)
        count += len(x)
    return total / max(count, 1)


def evaluate_id(model, windows, graph_cfg, batch_size, device, thresholds=None, temperature=1.0):
    outs = collect_model_outputs(model, windows, graph_cfg, batch_size=batch_size, device=device, temperature=temperature)
    return multilabel_metrics(windows.y, outs["probs"], thresholds), outs


def _build_timing_report(test_id_windows: int, test_ood_windows: int, detection_time_s: float) -> dict:
    total_windows = int(test_id_windows + test_ood_windows)
    elapsed = float(max(detection_time_s, 0.0))
    timing = {
        "test_id_windows": int(test_id_windows),
        "test_ood_windows": int(test_ood_windows),
        "test_windows": total_windows,
        "detection_time_s": elapsed,
        "average_detection_time_ms": None,
        "throughput_windows_per_s": None,
    }
    if total_windows > 0:
        timing["average_detection_time_ms"] = float(elapsed * 1000.0 / total_windows)
        timing["throughput_windows_per_s"] = float(total_windows / elapsed) if elapsed > 0.0 else None
    return timing


def main():
    p = argparse.ArgumentParser(description="Train UCS-OODID with ID-only calibration.")
    p.add_argument("--input", required=True)
    p.add_argument("--output_dir", required=True)
    p.add_argument("--label_col", default="label")
    p.add_argument("--timestamp_col", default="timestamp")
    p.add_argument("--record_id_col", default="record_id")
    p.add_argument(
        "--group_col",
        default="",
        help="Optional grouping column, e.g., uav_id. Windows are built independently inside each group.",
    )
    p.add_argument("--id_classes", default="", help="Comma-separated ID classes. If omitted, all labels except --ood_classes are ID.")
    p.add_argument("--ood_classes", default="", help="Comma-separated unknown/OOD classes used only for testing.")
    p.add_argument("--benign_label", default="benign")
    p.add_argument("--allow_ports", action="store_true")
    p.add_argument("--window_mode", choices=["count", "time", "adaptive"], default="count")
    p.add_argument("--window_size", type=int, default=32)
    p.add_argument("--stride", type=int, default=16)
    p.add_argument("--time_window_seconds", type=float, default=2.0)
    p.add_argument("--adaptive_min_size", type=int, default=8)
    p.add_argument("--adaptive_max_size", type=int, default=64)
    p.add_argument("--graph_k", type=int, default=8)
    p.add_argument("--graph_tau", type=float, default=0.5)
    p.add_argument("--graph_metric", default="cosine", choices=["cosine", "rbf", "euclidean"])
    p.add_argument(
        "--graph_variant",
        default="sym_weighted",
        choices=["sym_weighted", "directed", "mutual", "binary", "identity_graph", "no_graph"],
        help="Legacy graph variant. transformer_only mode keeps this config but does not build behavior graphs.",
    )
    p.add_argument(
        "--encoder_ablation",
        default="transformer_only",
        help="full | transformer_only | gcn_only | mlp_only | random_graph (legacy aliases: temporal_only, graph_only, identity_graph)",
    )
    p.add_argument("--hidden_dim", type=int, default=64)
    p.add_argument("--num_heads", type=int, default=2)
    p.add_argument("--num_layers", type=int, default=1)
    p.add_argument("--gcn_layers", type=int, default=2, help="Legacy GCN depth kept for historical ablations.")
    p.add_argument("--dropout", type=float, default=0.1)
    p.add_argument("--gate", default="learned", choices=["learned", "temporal_only", "graph_only", "mean"])
    p.add_argument("--record_head", action="store_true")
    p.add_argument("--epochs", type=int, default=30)
    p.add_argument("--batch_size", type=int, default=128)
    p.add_argument("--lr", type=float, default=1e-3)
    p.add_argument("--weight_decay", type=float, default=1e-4)
    p.add_argument("--lambda_record", type=float, default=0.0)
    p.add_argument("--q_ood", type=float, default=0.90)
    p.add_argument("--bank_k", type=int, default=5)
    p.add_argument("--fusion", default="correlation_aware", choices=["correlation_aware", "mean", "hard_voting", "variance_weighted", "validation_weighted", "conf", "energy", "proto", "knn"])
    p.add_argument("--ood_direction_calibration", default="none", choices=["none", "pseudo_ood", "test_ood_diagnostic"])
    p.add_argument("--phase_aware_threshold", action="store_true")
    p.add_argument("--phase_column", default="mission_phase_proxy")
    p.add_argument("--phase_threshold_min_samples", type=int, default=32)
    p.add_argument("--phase_threshold_quantile", type=float, default=None)
    p.add_argument("--phase_threshold_fallback", default="global", choices=["global"])
    p.add_argument("--ood_threshold_mode", default="global", choices=["global", "group"])
    p.add_argument("--group_threshold_strategy", default="raw", choices=["raw", "shrink", "conservative", "global_floor"])
    p.add_argument("--group_threshold_shrink_k", type=float, default=1000.0)
    p.add_argument("--group_threshold_min_ratio", type=float, default=1.0)
    p.add_argument("--group_threshold_min_samples", type=int, default=10)
    p.add_argument(
        "--present_class_min_support",
        type=int,
        default=1,
        help="Minimum y_true support required for a class to contribute to per-group present_class_macro_f1.",
    )
    p.add_argument("--normalization_mode", default="global", choices=["global", "group"])
    p.add_argument("--use_group_embedding", action="store_true")
    p.add_argument("--group_embedding_dim", type=int, default=16)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--device", default=None)
    args = p.parse_args()
    requested_encoder_ablation = args.encoder_ablation
    args.encoder_ablation = canonicalize_encoder_ablation(args.encoder_ablation)
    requested_fusion = args.fusion
    args.fusion = canonicalize_ood_fusion(requested_fusion, emit_warning=True)
    requested_graph_variant = args.graph_variant
    args.graph_variant = canonicalize_graph_variant(requested_graph_variant)
    args.group_col = (args.group_col or "").strip()
    if args.use_group_embedding and not args.group_col:
        raise ValueError("group embedding requires --group_col")
    requested_encoder_mode = str(requested_encoder_ablation).strip().lower()
    if requested_encoder_mode == "identity_graph" and args.graph_variant != "identity_graph":
        print("encoder_ablation=identity_graph forces graph_variant=identity_graph.")
        args.graph_variant = "identity_graph"
    if requested_graph_variant == "no_graph":
        print(DEPRECATED_NO_GRAPH_MESSAGE)
    if args.encoder_ablation == "random_graph" and args.graph_variant == "identity_graph":
        raise ValueError("encoder_ablation=random_graph is incompatible with graph_variant=identity_graph")
    graph_enabled = graph_enabled_for_ablation(args.encoder_ablation)
    temporal_enabled = temporal_enabled_for_ablation(args.encoder_ablation)
    graph_neighbor_strategy = graph_neighbor_strategy_for_ablation(args.encoder_ablation)
    reported_graph_variant = effective_graph_variant(args.encoder_ablation, args.graph_variant)
    effective_phase_quantile = args.q_ood if args.phase_threshold_quantile is None else float(args.phase_threshold_quantile)
    if args.encoder_ablation == "transformer_only":
        print("Transformer-only mode: graph construction and GCN branch are disabled.")
    deployment_profile = build_deployment_profile(args, graph_enabled)
    print(json.dumps({
        "encoder_ablation": args.encoder_ablation,
        "graph_enabled": graph_enabled,
        "temporal_enabled": temporal_enabled,
        "graph_variant": reported_graph_variant,
        "graph_base_variant": args.graph_variant,
        "graph_neighbor_strategy": graph_neighbor_strategy,
        "gate_mode": args.gate,
        "ood_fusion": args.fusion,
        "ood_direction_calibration": args.ood_direction_calibration,
        "ood_threshold_mode": args.ood_threshold_mode,
        "group_threshold_strategy": args.group_threshold_strategy,
        "group_threshold_shrink_k": args.group_threshold_shrink_k,
        "group_threshold_min_ratio": args.group_threshold_min_ratio,
        "group_threshold_min_samples": args.group_threshold_min_samples,
        "present_class_min_support": args.present_class_min_support,
        "normalization_mode": args.normalization_mode,
        "use_group_embedding": bool(args.use_group_embedding),
        "group_embedding_dim": args.group_embedding_dim,
        "phase_aware_threshold": bool(args.phase_aware_threshold),
        "phase_column": args.phase_column,
        "phase_threshold_quantile": effective_phase_quantile,
        "phase_threshold_min_samples": args.phase_threshold_min_samples,
        "phase_threshold_fallback": args.phase_threshold_fallback,
        "deployment_profile": deployment_profile,
    }, ensure_ascii=False))

    set_seed(args.seed)
    out_dir = ensure_dir(args.output_dir)
    device = choose_device(args.device)

    data_bundle = prepare_window_dataset(args, require_test_ood=False)
    df = data_bundle.df
    split_source = data_bundle.split_source
    train_df = data_bundle.split_frames["train"]
    val_df = data_bundle.split_frames["val"]
    test_df = data_bundle.split_frames["test_id"]
    ood_df = data_bundle.split_frames["test_ood"]
    train_w = data_bundle.split_windows["train"]
    val_w = data_bundle.split_windows["val"]
    test_w = data_bundle.split_windows["test_id"]
    ood_w = data_bundle.split_windows["test_ood"]
    id_classes = data_bundle.id_classes
    class_to_idx = data_bundle.class_to_idx
    pre = data_bundle.preprocessor
    normalization_summary = data_bundle.normalization_summary
    args.group_col = data_bundle.group_col or ""

    group_to_index = {}
    if args.use_group_embedding:
        if getattr(train_w, "group_ids", None) is None:
            raise ValueError("group embedding requires grouped windows with valid group_ids")
        group_to_index = build_group_to_index(train_w.group_ids, include_unknown=True, unknown_group=UNKNOWN_GROUP_TOKEN)
        attach_group_index(train_w, group_to_index, unknown_group=UNKNOWN_GROUP_TOKEN)
        attach_group_index(val_w, group_to_index, unknown_group=UNKNOWN_GROUP_TOKEN)
        attach_group_index(test_w, group_to_index, unknown_group=UNKNOWN_GROUP_TOKEN)
        if ood_w is not None:
            attach_group_index(ood_w, group_to_index, unknown_group=UNKNOWN_GROUP_TOKEN)
    group_embedding_info = group_embedding_summary(args.use_group_embedding, args.group_embedding_dim, group_to_index)
    unknown_group_index = group_to_index.get(UNKNOWN_GROUP_TOKEN)

    log_split_summaries(
        split_source,
        {
            "train": train_df,
            "val": val_df,
            "test_id": test_df,
            "test_ood": ood_df,
        },
        {
            "train": train_w,
            "val": val_w,
            "test_id": test_w,
            "test_ood": ood_w,
        },
        id_classes,
        group_col=args.group_col or None,
    )

    if len(train_w) == 0 or len(val_w) == 0:
        raise ValueError("Not enough ID windows for training/calibration. Reduce window size or check splits.")

    graph_cfg = {
        "k": args.graph_k,
        "tau": args.graph_tau,
        "metric": args.graph_metric,
        "variant": args.graph_variant,
        "neighbor_strategy": graph_neighbor_strategy,
    }
    model = UCSOODID(
        input_dim=len(pre.feature_cols), num_classes=len(id_classes), hidden_dim=args.hidden_dim,
        num_heads=args.num_heads, num_layers=args.num_layers, gcn_layers=args.gcn_layers,
        dropout=args.dropout, gate=args.gate, encoder_ablation=args.encoder_ablation, record_head=args.record_head,
        max_window_size=max(args.window_size, args.adaptive_max_size),
        num_groups=len(group_to_index) if args.use_group_embedding else None,
        use_group_embedding=args.use_group_embedding,
        group_embedding_dim=args.group_embedding_dim,
        unknown_group_index=unknown_group_index,
    ).to(device)

    y_train = train_w.y
    pos = y_train.sum(axis=0)
    neg = len(y_train) - pos
    pos_weight = torch.tensor(neg / np.clip(pos, 1.0, None), dtype=torch.float32, device=device)
    opt = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    loader = DataLoader(WindowTorchDataset(train_w), batch_size=args.batch_size, shuffle=True)

    history = []
    best_state = None
    best_score = -1.0
    for epoch in range(1, args.epochs + 1):
        loss = train_one_epoch(model, loader, opt, graph_cfg, device, pos_weight=pos_weight, lambda_record=args.lambda_record)
        val_metrics, _ = evaluate_id(model, val_w, graph_cfg, args.batch_size, device)
        score = val_metrics["micro_f1"]
        history.append({"epoch": epoch, "loss": loss, **val_metrics})
        print(json.dumps(history[-1], ensure_ascii=False))
        if score > best_score:
            best_score = score
            best_state = {k: v.detach().cpu() for k, v in model.state_dict().items()}
    if best_state:
        model.load_state_dict(best_state)

    val_out = collect_model_outputs(model, val_w, graph_cfg, batch_size=args.batch_size, device=device, temperature=1.0)
    temperature = calibrate_temperature(val_out["logits"], val_w.y, grid=[0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 3.0, 5.0])
    val_out = collect_model_outputs(model, val_w, graph_cfg, batch_size=args.batch_size, device=device, temperature=temperature)
    thresholds = calibrate_class_thresholds(val_out["probs"], val_w.y)
    bank = PrototypeBank.fit(val_out["embeddings"], val_w.y, id_classes)
    raw_val = compute_raw_ood_scores(val_out["logits"], val_out["probs"], val_out["embeddings"], bank, temperature=temperature, k_bank=args.bank_k)
    ood_cal = OODCalibrator(
        fusion=args.fusion,
        q_ood=args.q_ood,
        ood_threshold_mode=args.ood_threshold_mode,
        group_threshold_strategy=args.group_threshold_strategy,
        group_threshold_shrink_k=args.group_threshold_shrink_k,
        group_threshold_min_ratio=args.group_threshold_min_ratio,
    )
    ood_cal.group_threshold_min_samples = int(max(args.group_threshold_min_samples, 0))
    ood_cal.group_threshold_quantile = float(args.q_ood)
    if args.ood_direction_calibration == "pseudo_ood":
        pseudo_raw, pseudo_labels, _ = build_leave_one_class_out_pseudo_ood(
            raw_val,
            val_w.y,
            class_names=id_classes,
            score_names=ood_cal.score_names,
        )
        if len(pseudo_labels) and len(np.unique(pseudo_labels)) == 2:
            ood_cal.calibrate_directions(
                pseudo_raw,
                y_true_ood=pseudo_labels,
                label_source="pseudo_ood_leave_one_class_out_validation_windows",
            )
        else:
            print("Pseudo-OOD direction calibration was unavailable from validation windows; using predefined score directions.")
            ood_cal.set_default_directions(label_source="pseudo_ood_unavailable_fallback_to_none")
    else:
        ood_cal.set_default_directions(label_source="none")
    ood_cal.fit(raw_val)
    val_threshold_scores = ood_cal.transform(raw_val)["fused"]
    if args.ood_threshold_mode == "group":
        if getattr(val_w, "group_ids", None) is None:
            print("Group-aware OOD thresholding requested but validation windows have no group_ids; using global fallback for all windows.")
        ood_cal.calibrate_group_thresholds(
            val_threshold_scores,
            getattr(val_w, "group_ids", None),
            min_samples=args.group_threshold_min_samples,
            quantile=args.q_ood,
            strategy=args.group_threshold_strategy,
            shrink_k=args.group_threshold_shrink_k,
            min_ratio=args.group_threshold_min_ratio,
        )
    test_ood_direction_diagnostic_report = build_direction_diagnostic_payload(
        ood_cal.score_names,
        label_source="none" if args.ood_direction_calibration != "test_ood_diagnostic" else "unavailable",
        enabled=False,
        note=(
            "test_ood_diagnostic was not requested"
            if args.ood_direction_calibration != "test_ood_diagnostic"
            else "test_ood_diagnostic requested, but test_id/test_ood windows are not yet available"
        ),
    )
    val_phase_labels = None
    if args.phase_aware_threshold and args.phase_column in val_df.columns:
        val_phase_labels = window_phase_labels(val_df, val_w, args.phase_column)
        transformed_val = ood_cal.transform(raw_val)
        ood_cal.calibrate_phase_thresholds(
            transformed_val["fused"],
            val_phase_labels,
            phase_column=args.phase_column,
            min_samples=args.phase_threshold_min_samples,
            quantile=effective_phase_quantile,
            fallback=args.phase_threshold_fallback,
        )
    print(json.dumps({
        "ood_fusion": ood_cal.fusion,
        "ood_fusion_weights": ordered_ood_weights(ood_cal),
    }, ensure_ascii=False))
    print(json.dumps({
        "ood_score_direction_mode": args.ood_direction_calibration,
        "ood_score_direction_label_source": ood_cal.direction_label_source,
        "ood_score_direction_report": ordered_ood_direction_report(ood_cal),
        "direction_used_for_final_scores": ordered_ood_directions(ood_cal),
    }, ensure_ascii=False))
    print(json.dumps({"group_embedding": group_embedding_info}, ensure_ascii=False))
    print(json.dumps(ood_threshold_summary(ood_cal), ensure_ascii=False))
    print(json.dumps({
        "conf_energy_direction_diagnostic": conf_energy_direction_diagnostic(ood_cal),
    }, ensure_ascii=False))
    if ood_cal.phase_aware_enabled:
        print(json.dumps({
            "phase_aware_threshold_summary": phase_threshold_summary(ood_cal),
        }, ensure_ascii=False))
    elif args.phase_aware_threshold:
        print(f"Phase-aware thresholding requested but phase column {args.phase_column!r} was unavailable in validation windows; using global threshold only.")

    test_id_windows = int(len(test_w))
    test_ood_windows = int(len(ood_w)) if ood_w is not None else 0
    has_ood_test = test_ood_windows > 0
    detection_time_s = 0.0
    if has_ood_test:
        test_metrics, test_out = (
            evaluate_id(model, test_w, graph_cfg, args.batch_size, device, thresholds=thresholds, temperature=temperature)
            if test_id_windows
            else ({}, None)
        )
    elif test_id_windows:
        detection_started_at = time.perf_counter()
        test_metrics, test_out = evaluate_id(
            model,
            test_w,
            graph_cfg,
            args.batch_size,
            device,
            thresholds=thresholds,
            temperature=temperature,
        )
        detection_time_s = time.perf_counter() - detection_started_at
    else:
        test_metrics, test_out = ({}, None)
    id_test_by_group = (
        compute_id_metrics_by_group(
            test_w,
            test_out["probs"],
            thresholds,
            label_names=id_classes,
            present_class_min_support=args.present_class_min_support,
        )
        if len(test_w) and test_out is not None
        else {}
    )
    threshold_summary = ood_threshold_summary(ood_cal)
    inferred_method = infer_method_name(
        args.encoder_ablation,
        ood_cal.fusion,
        ood_cal.ood_threshold_mode,
        ood_cal.group_threshold_strategy,
    )
    eval_run_config = {
        "method": inferred_method,
        "seed": int(args.seed),
        "encoder_ablation": args.encoder_ablation,
        "fusion": ood_cal.fusion,
        "ood_threshold_mode": ood_cal.ood_threshold_mode,
        "group_threshold_strategy": ood_cal.group_threshold_strategy,
        "normalization_mode": args.normalization_mode,
        "use_group_embedding": bool(args.use_group_embedding),
        "group_embedding_dim": args.group_embedding_dim,
    }
    eval_report = {
        "method": inferred_method,
        "run_config": dict(eval_run_config),
        "encoder_ablation": args.encoder_ablation,
        "graph_enabled": graph_enabled,
        "temporal_enabled": temporal_enabled,
        "deployment_profile": deployment_profile,
        "graph_variant": reported_graph_variant,
        "graph_base_variant": args.graph_variant,
        "gate_mode": args.gate,
        "ood_fusion": ood_cal.fusion,
        "ood_fusion_weights": ordered_ood_weights(ood_cal),
        "ood_score_direction_mode": args.ood_direction_calibration,
        "ood_score_direction_label_source": ood_cal.direction_label_source,
        "ood_score_direction_report": ordered_ood_direction_report(ood_cal),
        "test_ood_direction_diagnostic_report": test_ood_direction_diagnostic_report,
        "direction_used_for_final_scores": ordered_ood_directions(ood_cal),
        "conf_energy_direction_diagnostic": conf_energy_direction_diagnostic(ood_cal),
        "phase_aware_threshold": phase_threshold_summary(ood_cal),
        **threshold_summary,
        "graph_config": graph_cfg,
        "group_config": {
            "group_col": args.group_col,
            "meaning": "Windows are built independently inside each UAV/group when group_col is set.",
            "present_class_min_support": int(args.present_class_min_support),
        },
        "group_embedding": group_embedding_info,
        "present_class_min_support": int(args.present_class_min_support),
        "normalization": normalization_summary,
        "calibration_config": {
            "q_ood": args.q_ood,
            "bank_k": args.bank_k,
            "fusion": ood_cal.fusion,
            "ood_direction_calibration": args.ood_direction_calibration,
            "ood_threshold_mode": args.ood_threshold_mode,
            "group_threshold_strategy": args.group_threshold_strategy,
            "group_threshold_shrink_k": args.group_threshold_shrink_k,
            "group_threshold_min_ratio": args.group_threshold_min_ratio,
            "group_threshold_min_samples": args.group_threshold_min_samples,
            "present_class_min_support": int(args.present_class_min_support),
            "use_group_embedding": bool(args.use_group_embedding),
            "group_embedding_dim": args.group_embedding_dim,
            "phase_aware_threshold": bool(args.phase_aware_threshold),
            "phase_column": args.phase_column,
            "phase_threshold_quantile": effective_phase_quantile,
            "phase_threshold_min_samples": args.phase_threshold_min_samples,
            "phase_threshold_fallback": args.phase_threshold_fallback,
        },
        "id_test": test_metrics,
        "id_test_by_group": id_test_by_group,
        "ood_test_by_group": {},
        "history": history,
        "temperature": temperature,
        "class_thresholds": thresholds.tolist(),
        "seed": int(args.seed),
    }

    # Optional OOD test if unknown classes exist in the input.
    if ood_w is not None and test_ood_windows:
        combo_x = np.concatenate([test_w.x, ood_w.x], axis=0)
        combo_y = np.concatenate([test_w.y, ood_w.y], axis=0)
        combo_ridx = np.concatenate([test_w.record_indices, ood_w.record_indices], axis=0)
        combo_rids = np.concatenate([test_w.record_ids, ood_w.record_ids], axis=0)
        combo_ood = np.concatenate([np.zeros(test_id_windows, dtype=bool), np.ones(test_ood_windows, dtype=bool)])
        combo_mask = np.concatenate([test_w.valid_mask, ood_w.valid_mask], axis=0)
        combo_group_ids = None
        if test_w.group_ids is not None and ood_w.group_ids is not None:
            combo_group_ids = np.concatenate([test_w.group_ids, ood_w.group_ids], axis=0)
        combo_group_index = None
        if test_w.group_index is not None and ood_w.group_index is not None:
            combo_group_index = np.concatenate([test_w.group_index, ood_w.group_index], axis=0)
        from ucs_oodid.windowing import WindowedData
        combo_w = WindowedData(
            combo_x,
            combo_y,
            combo_ridx,
            combo_rids,
            combo_ood,
            valid_mask=combo_mask,
            group_ids=combo_group_ids,
            group_index=combo_group_index,
        )
        combo_phase_labels = None
        if ood_cal.phase_aware_enabled and args.phase_column in test_df.columns and args.phase_column in ood_df.columns:
            phase_parts = []
            if test_id_windows:
                phase_parts.append(window_phase_labels(test_df, test_w, args.phase_column))
            if test_ood_windows:
                phase_parts.append(window_phase_labels(ood_df, ood_w, args.phase_column))
            if phase_parts:
                combo_phase_labels = np.concatenate(phase_parts, axis=0)
        detection_started_at = time.perf_counter()
        combo_out = collect_model_outputs(model, combo_w, graph_cfg, batch_size=args.batch_size, device=device, temperature=temperature)
        raw_combo = compute_raw_ood_scores(
            combo_out["logits"],
            combo_out["probs"],
            combo_out["embeddings"],
            bank,
            temperature=temperature,
            k_bank=args.bank_k,
        )
        transformed = ood_cal.transform(raw_combo, phases=combo_phase_labels, groups=combo_w.group_ids)
        detection_time_s = time.perf_counter() - detection_started_at
        if args.ood_direction_calibration == "test_ood_diagnostic":
            diagnostic_cal = OODCalibrator(score_names=list(ood_cal.score_names))
            diagnostic_cal.calibrate_directions(
                raw_combo,
                y_true_ood=combo_ood.astype(int),
                label_source="test_id_vs_test_ood_windows_diagnostic",
            )
            test_ood_direction_diagnostic_report = build_direction_diagnostic_payload(
                diagnostic_cal.score_names,
                report=diagnostic_cal.direction_report,
                label_source=diagnostic_cal.direction_label_source,
                enabled=True,
                note="Diagnostic only; final OOD score directions remain unchanged.",
            )
        if test_id_windows and test_ood_windows:
            eval_report["ood_test"] = ood_metrics(combo_ood.astype(int), transformed["fused"], transformed["decisions"])
            eval_report["test_ood_direction_diagnostic_report"] = test_ood_direction_diagnostic_report
            if combo_phase_labels is not None:
                phase_test_metrics = compute_phase_test_metrics(
                    combo_ood.astype(int),
                    transformed["fused"],
                    transformed["decisions"],
                    combo_phase_labels,
                    ood_cal,
                )
                if phase_test_metrics:
                    eval_report["phase_aware_threshold"]["test_phase_metrics"] = phase_test_metrics
            eval_report["ood_test_by_group"] = compute_ood_metrics_by_group(
                combo_w.group_ids,
                combo_ood.astype(int),
                transformed["fused"],
                transformed["decisions"],
            )
    eval_report["timing"] = _build_timing_report(test_id_windows, test_ood_windows, detection_time_s)

    artifact = {
        "model_state": model.state_dict(),
        "model_config": {
            "input_dim": len(pre.feature_cols), "num_classes": len(id_classes), "hidden_dim": args.hidden_dim,
            "num_heads": args.num_heads, "num_layers": args.num_layers, "gcn_layers": args.gcn_layers,
            "dropout": args.dropout, "gate": args.gate, "encoder_ablation": args.encoder_ablation, "record_head": args.record_head,
            "max_window_size": max(args.window_size, args.adaptive_max_size),
            "num_groups": len(group_to_index) if args.use_group_embedding else None,
            "use_group_embedding": bool(args.use_group_embedding),
            "group_embedding_dim": args.group_embedding_dim,
            "unknown_group_index": unknown_group_index,
        },
        "graph_config": graph_cfg,
        "run_config": {
            "method": inferred_method,
            "seed": int(args.seed),
            "encoder_ablation": args.encoder_ablation,
            "graph_enabled": graph_enabled,
            "temporal_enabled": temporal_enabled,
            "deployment_profile": deployment_profile,
            "graph_variant": reported_graph_variant,
            "graph_base_variant": args.graph_variant,
            "graph_neighbor_strategy": graph_neighbor_strategy,
            "gate_mode": args.gate,
            "normalization_mode": args.normalization_mode,
            "use_group_embedding": bool(args.use_group_embedding),
            "group_embedding_dim": args.group_embedding_dim,
            "ood_direction_calibration": args.ood_direction_calibration,
            "ood_threshold_mode": args.ood_threshold_mode,
            "group_threshold_strategy": args.group_threshold_strategy,
            "group_threshold_shrink_k": args.group_threshold_shrink_k,
            "group_threshold_min_ratio": args.group_threshold_min_ratio,
            "group_threshold_min_samples": args.group_threshold_min_samples,
            "present_class_min_support": int(args.present_class_min_support),
            "phase_aware_threshold": bool(args.phase_aware_threshold),
            "phase_column": args.phase_column,
            "phase_threshold_quantile": effective_phase_quantile,
            "phase_threshold_min_samples": args.phase_threshold_min_samples,
            "phase_threshold_fallback": args.phase_threshold_fallback,
        },
        "seed": int(args.seed),
        "deployment_profile": deployment_profile,
        "normalization_mode": args.normalization_mode,
        "strict_model_feature_mode": True,
        "group_col": args.group_col or None,
        "feature_cols": list(pre.feature_cols),
        "feature_medians": dict(pre.feature_medians),
        "global_scaler": pre.scaler,
        "group_scalers": dict(getattr(pre, "group_scalers", {})),
        "group_normalization_fallbacks": dict(getattr(pre, "group_fallbacks", {})),
        "normalization": normalization_summary,
        "use_group_embedding": bool(args.use_group_embedding),
        "group_embedding_dim": args.group_embedding_dim,
        "group_to_index": dict(group_to_index),
        "unknown_group_index": unknown_group_index,
        "group_embedding": group_embedding_info,
        **threshold_summary,
        "phase_threshold_config": phase_threshold_summary(ood_cal),
        "window_config": {
            "mode": args.window_mode, "size": args.window_size, "stride": args.stride,
            "time_seconds": args.time_window_seconds, "adaptive_min_size": args.adaptive_min_size,
            "adaptive_max_size": args.adaptive_max_size,
        },
        "group_config": {
            "group_col": args.group_col,
            "present_class_min_support": int(args.present_class_min_support),
        },
        "class_names": id_classes,
        "class_to_idx": class_to_idx,
        "preprocessor": pre,
        "temperature": temperature,
        "class_thresholds": thresholds,
        "prototype_bank": bank.to_dict(),
        "ood_calibrator": ood_cal.to_dict(),
        "calibration_config": {
            "q_ood": args.q_ood,
            "bank_k": args.bank_k,
            "fusion": ood_cal.fusion,
            "ood_direction_calibration": args.ood_direction_calibration,
            "ood_threshold_mode": args.ood_threshold_mode,
            "group_threshold_strategy": args.group_threshold_strategy,
            "group_threshold_shrink_k": args.group_threshold_shrink_k,
            "group_threshold_min_ratio": args.group_threshold_min_ratio,
            "group_threshold_min_samples": args.group_threshold_min_samples,
            "phase_aware_threshold": bool(args.phase_aware_threshold),
            "phase_column": args.phase_column,
            "phase_threshold_quantile": effective_phase_quantile,
            "phase_threshold_min_samples": args.phase_threshold_min_samples,
            "phase_threshold_fallback": args.phase_threshold_fallback,
        },
        "leakage_report": pre.leakage_report(df),
    }
    save_artifact(out_dir / "artifact.pt", artifact)
    save_json(eval_report, out_dir / "eval_report.json")
    save_json(artifact["leakage_report"], out_dir / "leakage_report.json")
    save_json(list(pre.feature_cols), out_dir / "feature_columns.json")
    print(f"Saved artifact to {out_dir / 'artifact.pt'}")
    print(json.dumps(eval_report, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
