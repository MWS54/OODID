#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import numpy as np

from ucs_oodid.baselines import (
    OptionalDependencyUnavailable,
    apply_threshold,
    calibrate_binary_threshold_from_id_scores,
    compute_baseline_uncertainty_scores,
    fit_isolation_forest_ood,
    flatten_windows,
    isolation_forest_scores,
    make_baseline,
)
from ucs_oodid.experiment_utils import PreparedWindowDataset, prepare_window_dataset
from ucs_oodid.io import save_json
from ucs_oodid.metrics import multilabel_metrics, ood_metrics
from ucs_oodid.ood import calibrate_class_thresholds
from ucs_oodid.utils import ensure_dir, set_seed

BASELINE_ORDER = ("svm", "random_forest", "xgboost", "mlp")
BASELINE_ALIASES = {
    "svm": "svm",
    "rids_lite_proxy": "svm",
    "random_forest": "random_forest",
    "rapier_proxy": "random_forest",
    "xgboost": "xgboost",
    "mlp": "mlp",
}
DISPLAY_NAME_BY_METHOD = {
    "svm": "SVM",
    "rids_lite_proxy": "RIDS-style",
    "random_forest": "Random Forest",
    "rapier_proxy": "RAPIER-style",
    "xgboost": "XGBoost",
    "mlp": "MLP",
}
DEFAULT_OOD_SCORE_BY_BASELINE = {
    "svm": "uncertainty",
    "random_forest": "uncertainty",
    "xgboost": "uncertainty",
    "mlp": "energy",
}


class BaselineRequest:
    def __init__(self, output_name: str, backend_name: str, display_name: str) -> None:
        self.output_name = str(output_name)
        self.backend_name = str(backend_name)
        self.display_name = str(display_name)


def _ensure_prob_matrix(probs: np.ndarray) -> np.ndarray:
    arr = np.asarray(probs, dtype=np.float32)
    if arr.ndim == 1:
        return arr[:, None].astype(np.float32)
    if arr.ndim != 2:
        raise ValueError(f"Expected probability matrix with 1 or 2 dimensions, got shape {arr.shape}")
    return arr.astype(np.float32)


def _empty_prob_matrix(num_classes: int) -> np.ndarray:
    return np.empty((0, int(num_classes)), dtype=np.float32)


def _predict_prob_matrix(baseline, x: np.ndarray, num_classes: int) -> np.ndarray:
    if len(x) == 0:
        return _empty_prob_matrix(num_classes)
    return _ensure_prob_matrix(baseline.predict_proba(x))


def _empty_ood_score_array() -> np.ndarray:
    return np.empty((0,), dtype=np.float32)


def _probability_score_key(score_name: str) -> str:
    if score_name == "uncertainty":
        return "conf"
    if score_name == "energy":
        return "energy"
    raise ValueError(f"Unsupported probability OOD score: {score_name}")


def _build_timing_report(test_id_windows: int, test_ood_windows: int, detection_time_s: float) -> dict:
    total_windows = int(test_id_windows + test_ood_windows)
    elapsed = float(max(detection_time_s, 0.0))
    timing = {
        "test_id_windows": int(test_id_windows),
        "test_ood_windows": int(test_ood_windows),
        "test_windows": total_windows,
        "detection_time_s": elapsed,
        "average_detection_time_ms": None,
        "throughput_windows_per_s": None,
    }
    if total_windows > 0:
        timing["average_detection_time_ms"] = float(elapsed * 1000.0 / total_windows)
        timing["throughput_windows_per_s"] = float(total_windows / elapsed) if elapsed > 0.0 else None
    return timing


def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Train sklearn/tabular baselines for UCS-OODID windowed metadata.")
    p.add_argument("--input", required=True)
    p.add_argument("--output_dir", required=True)
    p.add_argument("--label_col", default="label")
    p.add_argument("--timestamp_col", default="timestamp")
    p.add_argument("--record_id_col", default="record_id")
    p.add_argument("--group_col", default="")
    p.add_argument("--id_classes", default="", help="Comma-separated ID classes. If omitted, all labels except --ood_classes are ID.")
    p.add_argument("--ood_classes", default="", help="Comma-separated OOD classes used only for testing.")
    p.add_argument("--benign_label", default="benign")
    p.add_argument("--allow_ports", action="store_true")
    p.add_argument("--window_mode", choices=["count", "time", "adaptive"], default="count")
    p.add_argument("--window_size", type=int, default=32)
    p.add_argument("--stride", type=int, default=16)
    p.add_argument("--time_window_seconds", type=float, default=2.0)
    p.add_argument("--adaptive_min_size", type=int, default=8)
    p.add_argument("--adaptive_max_size", type=int, default=64)
    p.add_argument("--normalization_mode", default="global", choices=["global", "group"])
    p.add_argument("--baseline", default="all", help="Backend baseline or comparison alias such as random_forest, svm, rapier_proxy, rids_lite_proxy, or all.")
    p.add_argument("--method_name", default="", help="Optional output/report method name override for single-baseline runs.")
    p.add_argument("--display_name", default="", help="Optional display name override for single-baseline runs.")
    p.add_argument("--q_ood", type=float, default=0.90)
    p.add_argument("--seed", type=int, default=42)
    return p


def _display_name_for_method(name: str) -> str:
    key = str(name).strip().lower()
    return DISPLAY_NAME_BY_METHOD.get(key, str(name))


def _resolve_requested_baselines(name: str, *, method_name: str = "", display_name: str = "") -> list[BaselineRequest]:
    key = str(name).strip().lower()
    if key == "all":
        return [
            BaselineRequest(
                output_name=baseline_name,
                backend_name=baseline_name,
                display_name=_display_name_for_method(baseline_name),
            )
            for baseline_name in BASELINE_ORDER
        ]
    backend_name = BASELINE_ALIASES.get(key)
    if backend_name is None:
        raise ValueError(f"Unsupported baseline: {name}")
    output_name = str(method_name).strip() or key
    resolved_display_name = str(display_name).strip() or _display_name_for_method(output_name)
    return [BaselineRequest(output_name=output_name, backend_name=backend_name, display_name=resolved_display_name)]


def _compute_iforest_score_splits(bundle: PreparedWindowDataset, random_state: int) -> dict[str, np.ndarray]:
    train_w = bundle.split_windows["train"]
    val_w = bundle.split_windows["val"]
    test_id_w = bundle.split_windows["test_id"]
    test_ood_w = bundle.split_windows["test_ood"]
    model = fit_isolation_forest_ood(flatten_windows(train_w.x), random_state=random_state)
    return {
        "val": isolation_forest_scores(model, flatten_windows(val_w.x)),
        "test_id": isolation_forest_scores(model, flatten_windows(test_id_w.x)),
        "test_ood": isolation_forest_scores(model, flatten_windows(test_ood_w.x)),
    }


def _compute_probability_score_splits(
    val_probs: np.ndarray,
    test_id_probs: np.ndarray,
    test_ood_probs: np.ndarray,
) -> dict[str, dict[str, np.ndarray]]:
    val_scores = compute_baseline_uncertainty_scores(val_probs)
    test_id_scores = compute_baseline_uncertainty_scores(test_id_probs)
    test_ood_scores = compute_baseline_uncertainty_scores(test_ood_probs)
    return {
        "uncertainty": {
            "val": val_scores["conf"],
            "test_id": test_id_scores["conf"],
            "test_ood": test_ood_scores["conf"],
        },
        "energy": {
            "val": val_scores["energy"],
            "test_id": test_id_scores["energy"],
            "test_ood": test_ood_scores["energy"],
        },
    }


def _evaluate_ood_from_scores(
    score_name: str,
    score_splits: dict[str, dict[str, np.ndarray]],
    q_ood: float,
) -> tuple[dict, float]:
    selected = score_splits[score_name]
    val_scores = np.asarray(selected["val"], dtype=np.float32)
    test_id_scores = np.asarray(selected["test_id"], dtype=np.float32)
    test_ood_scores = np.asarray(selected["test_ood"], dtype=np.float32)
    threshold = calibrate_binary_threshold_from_id_scores(val_scores, q=q_ood)
    combo_scores = np.concatenate([test_id_scores, test_ood_scores], axis=0)
    y_true_ood = np.concatenate(
        [np.zeros(len(test_id_scores), dtype=np.int64), np.ones(len(test_ood_scores), dtype=np.int64)],
        axis=0,
    )
    decisions = apply_threshold(combo_scores, threshold)
    metrics = ood_metrics(y_true_ood, combo_scores, decisions.astype(int))
    false_positives = int(np.sum(decisions[: len(test_id_scores)]))
    metrics["fpr_at_threshold"] = float(false_positives / max(len(test_id_scores), 1))
    return metrics, float(threshold)


def run_single_baseline(
    bundle: PreparedWindowDataset,
    args,
    request: BaselineRequest,
    iforest_score_splits: dict[str, np.ndarray],
) -> dict:
    baseline = make_baseline(request.backend_name, random_state=args.seed)
    train_w = bundle.split_windows["train"]
    val_w = bundle.split_windows["val"]
    test_id_w = bundle.split_windows["test_id"]
    test_ood_w = bundle.split_windows["test_ood"]

    baseline.fit(train_w.x, train_w.y)

    val_probs = _ensure_prob_matrix(baseline.predict_proba(val_w.x))
    class_thresholds = calibrate_class_thresholds(val_probs, val_w.y)
    ood_score_name = DEFAULT_OOD_SCORE_BY_BASELINE[request.backend_name]
    if ood_score_name == "iforest":
        val_ood_scores = np.asarray(iforest_score_splits["val"], dtype=np.float32)
    else:
        score_key = _probability_score_key(ood_score_name)
        val_ood_scores = np.asarray(compute_baseline_uncertainty_scores(val_probs)[score_key], dtype=np.float32)
    ood_threshold = float(calibrate_binary_threshold_from_id_scores(val_ood_scores, q=args.q_ood))

    test_id_windows = int(len(test_id_w))
    test_ood_windows = int(len(test_ood_w))
    num_classes = int(val_probs.shape[1])
    if test_id_windows or test_ood_windows:
        detection_started_at = time.perf_counter()
        test_id_probs = _predict_prob_matrix(baseline, test_id_w.x, num_classes)
        test_ood_probs = _predict_prob_matrix(baseline, test_ood_w.x, num_classes)
        if ood_score_name == "iforest":
            test_id_scores = np.asarray(iforest_score_splits["test_id"], dtype=np.float32)
            test_ood_scores = np.asarray(iforest_score_splits["test_ood"], dtype=np.float32)
        else:
            score_key = _probability_score_key(ood_score_name)
            test_id_scores = (
                np.asarray(compute_baseline_uncertainty_scores(test_id_probs)[score_key], dtype=np.float32)
                if test_id_windows
                else _empty_ood_score_array()
            )
            test_ood_scores = (
                np.asarray(compute_baseline_uncertainty_scores(test_ood_probs)[score_key], dtype=np.float32)
                if test_ood_windows
                else _empty_ood_score_array()
            )
        combo_scores = np.concatenate([test_id_scores, test_ood_scores], axis=0)
        decisions = apply_threshold(combo_scores, ood_threshold)
        detection_time_s = time.perf_counter() - detection_started_at
    else:
        test_id_probs = _empty_prob_matrix(num_classes)
        test_ood_probs = _empty_prob_matrix(num_classes)
        combo_scores = _empty_ood_score_array()
        decisions = np.empty((0,), dtype=bool)
        detection_time_s = 0.0

    id_test = multilabel_metrics(test_id_w.y, test_id_probs, class_thresholds) if test_id_windows else {}
    y_true_ood = np.concatenate(
        [np.zeros(test_id_windows, dtype=np.int64), np.ones(test_ood_windows, dtype=np.int64)],
        axis=0,
    )
    ood_test = ood_metrics(y_true_ood, combo_scores, decisions.astype(int))
    false_positives = int(np.sum(decisions[:test_id_windows]))
    ood_test["fpr_at_threshold"] = float(false_positives / max(test_id_windows, 1))
    timing = _build_timing_report(test_id_windows, test_ood_windows, detection_time_s)
    run_config = {
        "method": request.output_name,
        "seed": int(args.seed),
        "backend_name": request.backend_name,
        "normalization_mode": str(getattr(args, "normalization_mode", "global")),
        "ood_threshold_mode": "global",
        "group_threshold_strategy": "raw",
        "use_group_embedding": False,
    }

    return {
        "status": "success",
        "method": request.output_name,
        "method_name": request.output_name,
        "display_name": request.display_name,
        "run_config": dict(run_config),
        "backend_name": request.backend_name,
        "baseline_name": baseline.name,
        "id_test": id_test,
        "ood_test": ood_test,
        "class_thresholds": np.asarray(class_thresholds, dtype=np.float32).tolist(),
        "ood_threshold": float(ood_threshold),
        "ood_score_name": ood_score_name,
        "available_ood_scores": ["uncertainty", "energy", "iforest"],
        "window_counts": bundle.window_counts(),
        "timing": timing,
        "split_source": bundle.split_source,
        "id_classes": list(bundle.id_classes),
        "ood_classes": list(bundle.ood_classes),
        "feature_cols": list(bundle.preprocessor.feature_cols),
        "normalization": bundle.normalization_summary,
    }


def run_selected_baselines(args) -> dict:
    set_seed(args.seed)
    output_dir = ensure_dir(args.output_dir)
    bundle = prepare_window_dataset(args, require_test_ood=True)
    iforest_score_splits = _compute_iforest_score_splits(bundle, random_state=args.seed)
    requested = _resolve_requested_baselines(
        args.baseline,
        method_name=str(getattr(args, "method_name", "") or ""),
        display_name=str(getattr(args, "display_name", "") or ""),
    )

    results = {}
    skipped = []
    for request in requested:
        baseline_dir = ensure_dir(output_dir / request.output_name)
        try:
            report = run_single_baseline(bundle, args, request, iforest_score_splits)
        except OptionalDependencyUnavailable as exc:
            if str(args.baseline).strip().lower() != "all":
                raise
            reason = str(exc)
            skipped.append({"baseline": request.output_name, "backend_name": request.backend_name, "reason": reason})
            print(
                json.dumps(
                    {
                        "baseline": request.output_name,
                        "backend_name": request.backend_name,
                        "status": "skipped",
                        "reason": reason,
                    },
                    ensure_ascii=False,
                )
            )
            continue

        save_json(report, baseline_dir / "eval_report.json")
        results[request.output_name] = report
        print(
            json.dumps(
                {
                    "baseline": request.output_name,
                    "backend_name": request.backend_name,
                    "status": "success",
                    "id_micro_f1": report["id_test"]["micro_f1"],
                    "ood_auroc": report["ood_test"]["auroc"],
                    "ood_score_name": report["ood_score_name"],
                },
                ensure_ascii=False,
            )
        )

    skipped_path = output_dir / "skipped_baselines.json"
    if skipped:
        save_json(skipped, skipped_path)
    elif skipped_path.exists():
        skipped_path.unlink()

    summary = {
        "requested_baselines": [request.output_name for request in requested],
        "requested_backends": [request.backend_name for request in requested],
        "successful_baselines": list(results.keys()),
        "skipped_baselines": skipped,
        "split_source": bundle.split_source,
        "window_counts": bundle.window_counts(),
        "results": results,
    }
    save_json(summary, output_dir / "sklearn_baseline_summary.json")
    return summary


def main() -> None:
    args = build_arg_parser().parse_args()
    summary = run_selected_baselines(args)
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
