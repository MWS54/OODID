from __future__ import annotations

import importlib.util
import tempfile
import unittest
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = ROOT / "scripts" / "prepare_uav_ndd_case1.py"
SPEC = importlib.util.spec_from_file_location("prepare_uav_ndd_case1", MODULE_PATH)
prepare_uav_ndd_case1 = importlib.util.module_from_spec(SPEC)
assert SPEC is not None and SPEC.loader is not None
SPEC.loader.exec_module(prepare_uav_ndd_case1)


class PrepareUavNddCase1Tests(unittest.TestCase):
    def test_default_class_partitions_keep_recon_scanning_in_id(self):
        self.assertIn("recon_scanning", prepare_uav_ndd_case1.DEFAULT_ID_CLASSES)
        self.assertNotIn("recon_scanning", prepare_uav_ndd_case1.DEFAULT_OOD_CLASSES)
        self.assertEqual(
            prepare_uav_ndd_case1.DEFAULT_OOD_CLASSES,
            ["replay", "fake_landing"],
        )

    def test_scan_valid_csv_prefix_stops_at_first_malformed_line(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "sample.csv"
            path.write_text(
                "a,b,Label\n"
                "1,2,Normal\n"
                "3,4,DoS\n"
                "binary_tail_without_commas\n",
                encoding="latin1",
            )
            summary = prepare_uav_ndd_case1.scan_valid_csv_prefix(path)
            self.assertEqual(summary["expected_fields"], 3)
            self.assertEqual(summary["valid_rows"], 2)
            self.assertEqual(summary["first_invalid_line"], 4)
            self.assertTrue(summary["invalid_tail_detected"])

    def test_coerce_mixed_numeric_parses_hex_strings(self):
        series = pd.Series(["0x000A", "5", "bad", "", None])
        numeric = prepare_uav_ndd_case1.coerce_mixed_numeric(series)
        self.assertEqual(float(numeric.iloc[0]), 10.0)
        self.assertEqual(float(numeric.iloc[1]), 5.0)
        self.assertTrue(np.isnan(numeric.iloc[2]))
        self.assertTrue(np.isnan(numeric.iloc[3]))
        self.assertTrue(np.isnan(numeric.iloc[4]))

    def test_normalise_label_merges_recon_alias(self):
        self.assertEqual(prepare_uav_ndd_case1.normalise_label("Scanning"), "recon_scanning")
        self.assertEqual(prepare_uav_ndd_case1.normalise_label("Reconnassiance"), "recon_scanning")
        self.assertEqual(prepare_uav_ndd_case1.normalise_label("FakeLanding"), "fake_landing")


if __name__ == "__main__":
    unittest.main()
