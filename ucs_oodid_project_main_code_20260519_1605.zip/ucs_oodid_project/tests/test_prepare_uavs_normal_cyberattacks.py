from __future__ import annotations

import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = ROOT / "scripts" / "prepare_uavs_normal_cyberattacks.py"
SPEC = importlib.util.spec_from_file_location("prepare_uavs_normal_cyberattacks", MODULE_PATH)
prepare_uavs_normal_cyberattacks = importlib.util.module_from_spec(SPEC)
assert SPEC is not None and SPEC.loader is not None
SPEC.loader.exec_module(prepare_uavs_normal_cyberattacks)


def make_row(idx: int, label: str) -> dict:
    return {
        "timestamp_c": float(idx),
        "frame.number": idx,
        "frame.len": 100 + idx,
        "frame.protocols": idx % 3,
        "wlan.duration": idx % 5,
        "wlan.ra": idx % 7,
        "wlan.ta": idx % 11,
        "wlan.da": idx % 13,
        "wlan.sa": idx % 17,
        "wlan.bssid": idx % 19,
        "wlan.frag": idx % 2,
        "wlan.seq": idx,
        "llc.type": 2048,
        "ip.hdr_len": 20 + (idx % 2),
        "ip.len": 60 + idx,
        "ip.id": 1000 + idx,
        "ip.flags": idx % 4,
        "ip.ttl": 64,
        "ip.proto": 6,
        "ip.src": idx % 23,
        "ip.dst": idx % 29,
        "tcp.srcport": 5000 + idx,
        "tcp.dstport": 80,
        "tcp.seq_raw": 100000 + idx,
        "tcp.ack_raw": 200000 + idx,
        "tcp.hdr_len": 32,
        "tcp.flags": idx % 8,
        "tcp.window_size": 64240,
        "tcp.options": idx % 4,
        "udp.srcport": 0,
        "udp.dstport": 0,
        "udp.length": 0,
        "data.data": idx,
        "data.len": idx % 9,
        "wlan.fc.type": 2,
        "wlan.fc.subtype": idx % 16,
        "time_since_last_packet": float(idx) / 10.0,
        "class": label,
    }


class PrepareUavsNormalCyberattacksTests(unittest.TestCase):
    def test_prepare_uav04_filters_mixed_rows_and_maps_labels(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            input_path = root / "Dataset_T-ITS.csv"
            output_path = root / "prepared.csv"
            notes_path = root / "prepared_notes.json"

            rows = []
            rows.extend(make_row(i, "benign") for i in range(10))
            rows.extend(make_row(100 + i, "DoS attack") for i in range(10))
            rows.extend(make_row(200 + i, "Replay") for i in range(6))
            mixed_1 = make_row(300, "")
            mixed_1["ip.flags"] = "benign"
            rows.append(mixed_1)
            mixed_2 = make_row(301, "")
            mixed_2["ip.flags"] = "Replay"
            rows.append(mixed_2)
            header_like = make_row(302, "class")
            rows.append(header_like)
            pd.DataFrame(rows).to_csv(input_path, index=False)

            prepared, summary = prepare_uavs_normal_cyberattacks.prepare_uavs_normal_cyberattacks_dataset(
                input_csv=str(input_path),
                output=str(output_path),
                notes_json=str(notes_path),
                keep_conflicting_patterns=True,
            )

            self.assertTrue(output_path.exists())
            self.assertTrue(notes_path.exists())
            self.assertEqual(len(prepared), 26)
            self.assertEqual(summary["direct_valid_rows"], 26)
            self.assertEqual(summary["ignored_blank_or_mixed_rows"], 2)
            self.assertEqual(summary["repeated_header_rows"], 1)
            self.assertEqual(set(prepared["label"].unique().tolist()), {"benign", "dos", "replay"})
            self.assertEqual(set(prepared["source_class"].unique().tolist()), {"benign", "DoS attack", "Replay"})
            self.assertEqual(set(prepared["split"].unique().tolist()), {"train", "val", "test_id", "test_ood"})
            self.assertIn("raw_frame_len", prepared.columns)
            self.assertIn("raw_wlan_fc_subtype", prepared.columns)
            self.assertIn("raw_time_since_last_packet", prepared.columns)
            self.assertNotIn("timestamp_c", prepared.columns)
            self.assertNotIn("frame.number", prepared.columns)
            self.assertNotIn("wlan.ra", prepared.columns)
            self.assertNotIn("ip.src", prepared.columns)
            self.assertNotIn("tcp.srcport", prepared.columns)
            self.assertEqual(prepared["record_id"].tolist(), list(range(26)))

            notes = json.loads(notes_path.read_text(encoding="utf-8"))
            self.assertEqual(notes["full_label_counts"], {"benign": 10, "dos": 10, "replay": 6})


if __name__ == "__main__":
    unittest.main()
