from __future__ import annotations

import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = ROOT / "scripts" / "prepare_unsw_nb15.py"
SPEC = importlib.util.spec_from_file_location("prepare_unsw_nb15", MODULE_PATH)
prepare_unsw_nb15 = importlib.util.module_from_spec(SPEC)
assert SPEC is not None and SPEC.loader is not None
SPEC.loader.exec_module(prepare_unsw_nb15)

REQUIRED_METADATA_COLUMNS = [
    "record_id",
    "timestamp",
    "uav_id",
    "dataset_name",
    "source_type",
    "label",
    "label_normalized",
    "split",
]


def run_command(cmd: list[object]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [str(part) for part in cmd],
        cwd=str(ROOT),
        check=True,
        capture_output=True,
        text=True,
    )


def assert_required_metadata_prefix(testcase: unittest.TestCase, frame: pd.DataFrame) -> None:
    testcase.assertEqual(
        frame.columns[: len(REQUIRED_METADATA_COLUMNS)].tolist(),
        REQUIRED_METADATA_COLUMNS,
    )


def make_row(idx: int, attack_cat: str, event_time: int, fold: str, note: str | None) -> dict:
    return {
        "id": idx,
        "dur": float(idx) / 10.0,
        "attack_cat": attack_cat,
        "label": 0 if attack_cat.lower() in {"normal", "benign"} else 1,
        "event_time": event_time,
        "fold": fold,
        "note": note,
    }


class PrepareUnswNb15Tests(unittest.TestCase):
    def test_normalise_label_maps_normal_and_backdoors(self):
        self.assertEqual(prepare_unsw_nb15.normalise_label("Normal"), "benign")
        self.assertEqual(prepare_unsw_nb15.normalise_label("benign"), "benign")
        self.assertEqual(prepare_unsw_nb15.normalise_label("Backdoors"), "backdoor")

    def test_prepare_unsw_nb15_builds_unified_csv(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            input_root = root / "unsw"
            input_root.mkdir(parents=True, exist_ok=True)
            train_path = input_root / "UNSW_NB15_training-set.csv"
            test_path = input_root / "UNSW_NB15_testing-set.csv"
            output_path = root / "prepared.csv"

            pd.DataFrame(
                [
                    make_row(1, "Normal", 1000, "TRAIN", "ok"),
                    make_row(2, "DoS", 1001, "TRAIN", None),
                    make_row(3, "Benign", 1002, "TRAIN", "ok"),
                ]
            ).to_csv(train_path, index=False)
            pd.DataFrame(
                [
                    make_row(4, "Backdoor", 2000, "TEST", "ok"),
                    make_row(5, "normal", 2001, "TEST", "ok"),
                ]
            ).to_csv(test_path, index=False)

            prepared, summary = prepare_unsw_nb15.prepare_unsw_nb15_dataset(
                input_path=str(input_root),
                output=str(output_path),
                uav_id="uav-ext-01",
                dataset_name="unsw_demo",
                timestamp_column="event_time",
                split_column="fold",
            )

            required_columns = set(REQUIRED_METADATA_COLUMNS)
            self.assertTrue(output_path.exists())
            self.assertTrue(required_columns.issubset(prepared.columns))
            assert_required_metadata_prefix(self, prepared)
            self.assertEqual(prepared["source_type"].unique().tolist(), ["external_non_uav"])
            self.assertEqual(prepared["uav_id"].unique().tolist(), ["uav-ext-01"])
            self.assertEqual(prepared["dataset_name"].unique().tolist(), ["unsw_demo"])
            self.assertEqual(prepared["label_normalized"].value_counts().to_dict(), {"benign": 3, "dos": 1, "backdoor": 1})
            self.assertEqual(set(prepared["split"].tolist()), {"train", "test"})
            self.assertEqual(prepared["timestamp"].tolist(), [1000, 1001, 1002, 2000, 2001])
            self.assertIn("source_file", prepared.columns)

            self.assertEqual(summary["source_type"], "external_non_uav")
            self.assertEqual(summary["label_column_used"], "attack_cat")
            self.assertEqual(summary["timestamp_column_used"], "event_time")
            self.assertEqual(summary["split_column_used"], "fold")
            self.assertEqual(summary["benign_samples"], 3)
            self.assertEqual(summary["attack_samples_by_category"], {"backdoor": 1, "dos": 1})
            self.assertEqual(summary["missing_values"]["note"], 1)

            written = pd.read_csv(output_path)
            self.assertTrue(required_columns.issubset(written.columns))
            assert_required_metadata_prefix(self, written)
            self.assertEqual(written["label_normalized"].value_counts().to_dict(), {"benign": 3, "dos": 1, "backdoor": 1})

    def test_prepare_unsw_nb15_defaults_metadata_for_uav05_when_optional_columns_are_missing(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            input_path = root / "UNSW_NB15_training-set.csv"
            output_path = root / "prepared.csv"

            pd.DataFrame(
                [
                    {"id": 10, "dur": 0.1, "attack_cat": "Normal", "note": "ok"},
                    {"id": 11, "dur": 0.2, "attack_cat": "Backdoors", "note": "ood"},
                ]
            ).to_csv(input_path, index=False)

            prepared, summary = prepare_unsw_nb15.prepare_unsw_nb15_dataset(
                input_path=str(input_path),
                output=str(output_path),
                uav_id="uav_05",
                dataset_name="unsw_nb15",
            )

            self.assertTrue(output_path.exists())
            assert_required_metadata_prefix(self, prepared)
            self.assertEqual(prepared["uav_id"].unique().tolist(), ["uav_05"])
            self.assertEqual(prepared["dataset_name"].unique().tolist(), ["unsw_nb15"])
            self.assertEqual(prepared["source_type"].unique().tolist(), ["external_non_uav"])
            self.assertEqual(prepared["split"].unique().tolist(), ["all"])
            self.assertEqual(prepared["timestamp"].tolist(), [0, 1])
            self.assertIsNone(summary["timestamp_column_used"])
            self.assertIsNone(summary["split_column_used"])
            self.assertEqual(summary["attack_samples_by_category"], {"backdoor": 1})

            written = pd.read_csv(output_path)
            assert_required_metadata_prefix(self, written)
            self.assertEqual(written["label_normalized"].tolist(), ["benign", "backdoor"])

    def test_prepare_unsw_nb15_cli_smoke(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            input_root = root / "unsw"
            input_root.mkdir(parents=True, exist_ok=True)
            output_path = root / "prepared.csv"

            pd.DataFrame(
                [
                    make_row(1, "Normal", 10, "TRAIN", "ok"),
                    make_row(2, "Analysis", 20, "TEST", "ok"),
                    make_row(3, "Normal", 30, "TEST", "ok"),
                ]
            ).to_csv(input_root / "UNSW_NB15_training-set.csv", index=False)
            pd.DataFrame(columns=["id", "dur", "attack_cat", "label", "event_time", "fold", "note"]).to_csv(
                input_root / "UNSW_NB15_testing-set.csv",
                index=False,
            )

            completed = run_command(
                [
                    sys.executable,
                    MODULE_PATH,
                    "--input",
                    input_root,
                    "--output",
                    output_path,
                    "--uav_id",
                    "uav-cli",
                    "--dataset_name",
                    "unsw_cli",
                    "--label_column",
                    "attack_cat",
                    "--timestamp_column",
                    "event_time",
                    "--split_column",
                    "fold",
                ]
            )

            self.assertTrue(output_path.exists(), msg=completed.stdout + completed.stderr)
            payload = json.loads(completed.stdout)
            self.assertEqual(payload["prepare_unsw_nb15"]["total_samples"], 3)
            self.assertEqual(payload["prepare_unsw_nb15"]["source_type"], "external_non_uav")

            prepared = pd.read_csv(output_path)
            self.assertEqual(set(prepared["label_normalized"].tolist()), {"benign", "analysis"})
            self.assertEqual(prepared["uav_id"].unique().tolist(), ["uav-cli"])


if __name__ == "__main__":
    unittest.main()
