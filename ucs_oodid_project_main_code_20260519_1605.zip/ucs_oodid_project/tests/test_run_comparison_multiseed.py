from __future__ import annotations

import importlib.util
import subprocess
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
SCRIPT_PATH = ROOT / "scripts" / "run_comparison_multiseed.py"
SPEC = importlib.util.spec_from_file_location("run_comparison_multiseed", SCRIPT_PATH)
run_comparison_multiseed = importlib.util.module_from_spec(SPEC)
assert SPEC is not None and SPEC.loader is not None
SPEC.loader.exec_module(run_comparison_multiseed)


def make_args(input_path: Path, output_root: Path, seeds: str = "1,2") -> SimpleNamespace:
    return SimpleNamespace(
        input=str(input_path),
        output_root=str(output_root),
        label_col="label",
        timestamp_col="timestamp",
        record_id_col="record_id",
        group_col="uav_id",
        id_classes="benign,dos",
        ood_classes="evil",
        window_mode="count",
        window_size=16,
        stride=8,
        time_window_seconds=2.0,
        adaptive_min_size=8,
        adaptive_max_size=64,
        normalization_mode="group",
        q_ood=0.9,
        epochs=10,
        device="auto",
        skip_sklearn=False,
        skip_neural=False,
        methods="",
        seeds=seeds,
        benign_label="benign",
        allow_ports=False,
    )


class ComparisonMultiseedTests(unittest.TestCase):
    def test_run_comparison_multiseed_aggregates_mean_std_tables(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            input_path = tmp_path / "toy.csv"
            input_path.write_text("record_id,timestamp,uav_id,label,feat_a\nr0,0,uav_01,benign,0.0\n", encoding="utf-8")
            output_root = tmp_path / "runs"
            args = make_args(input_path, output_root, seeds="1,2")

            def fake_runner(cmd):
                cmd = [str(part) for part in cmd]
                out_dir = Path(cmd[cmd.index("--output_root") + 1])
                seed = int(cmd[cmd.index("--seed") + 1])
                out_dir.mkdir(parents=True, exist_ok=True)
                known = pd.DataFrame(
                    [
                        {
                            "Method": "RIDS-style",
                            "Micro-F1": 0.8 if seed == 1 else 0.6,
                            "Macro-F1": 0.7 if seed == 1 else 0.5,
                            "mAP": 0.75 if seed == 1 else 0.55,
                            "Hamming Loss": 0.2 if seed == 1 else 0.4,
                            "Subset Acc.": 0.6 if seed == 1 else 0.4,
                        },
                        {
                            "Method": "UCS-OODID",
                            "Micro-F1": 0.9 if seed == 1 else 0.8,
                            "Macro-F1": 0.85 if seed == 1 else 0.75,
                            "mAP": 0.88 if seed == 1 else 0.78,
                            "Hamming Loss": 0.1 if seed == 1 else 0.2,
                            "Subset Acc.": 0.7 if seed == 1 else 0.6,
                        },
                    ]
                )
                ood = pd.DataFrame(
                    [
                        {
                            "Method": "RIDS-style",
                            "AUROC": 0.7 if seed == 1 else 0.5,
                            "AUPR-Out": 0.6 if seed == 1 else 0.4,
                            "FPR95": 0.3 if seed == 1 else 0.5,
                            "Precision": 0.65 if seed == 1 else 0.45,
                            "Recall": 0.75 if seed == 1 else 0.55,
                            "OOD-F1": 0.7 if seed == 1 else 0.5,
                            "FPR@theta": 0.2 if seed == 1 else 0.4,
                        },
                        {
                            "Method": "UCS-OODID",
                            "AUROC": 0.95 if seed == 1 else 0.85,
                            "AUPR-Out": 0.93 if seed == 1 else 0.83,
                            "FPR95": 0.1 if seed == 1 else 0.2,
                            "Precision": 0.9 if seed == 1 else 0.8,
                            "Recall": 0.92 if seed == 1 else 0.82,
                            "OOD-F1": 0.91 if seed == 1 else 0.81,
                            "FPR@theta": 0.08 if seed == 1 else 0.18,
                        },
                    ]
                )
                known.to_csv(out_dir / "known_detection_table.csv", index=False)
                ood.to_csv(out_dir / "ood_detection_table.csv", index=False)
                return subprocess.CompletedProcess(cmd, 0, stdout="ok", stderr="")

            summary = run_comparison_multiseed.run_comparison_multiseed(args, runner=fake_runner)

            self.assertEqual(summary["seeds"], [1, 2])
            self.assertEqual(len(summary["successful_seed_dirs"]), 2)
            known_mean_std = pd.read_csv(output_root / "known_detection_table_mean_std.csv")
            ood_mean_std = pd.read_csv(output_root / "ood_detection_table_mean_std.csv")
            self.assertEqual(
                known_mean_std.loc[known_mean_std["Method"] == "RIDS-style", "Micro-F1"].iloc[0],
                "0.7000 ± 0.1000",
            )
            self.assertEqual(
                ood_mean_std.loc[ood_mean_std["Method"] == "UCS-OODID", "AUROC"].iloc[0],
                "0.9000 ± 0.0500",
            )
            known_tex = (output_root / "known_detection_table_mean_std.tex").read_text(encoding="utf-8")
            ood_tex = (output_root / "ood_detection_table_mean_std.tex").read_text(encoding="utf-8")
            self.assertIn(r"$\pm$", known_tex)
            self.assertIn(r"\textbf{UCS-OODID}", known_tex)
            self.assertIn(r"\textbf{0.9000} $\pm$ \textbf{0.0500}", ood_tex)


if __name__ == "__main__":
    unittest.main()
