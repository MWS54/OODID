from __future__ import annotations

import importlib.util
import tempfile
import unittest
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = ROOT / "scripts" / "run_cross_uav_generalization.py"
SPEC = importlib.util.spec_from_file_location("run_cross_uav_generalization", MODULE_PATH)
cross_uav = importlib.util.module_from_spec(SPEC)
assert SPEC is not None and SPEC.loader is not None
SPEC.loader.exec_module(cross_uav)


class CrossUavGeneralizationTests(unittest.TestCase):
    def test_merge_cross_uav_frames_aligns_feature_union_and_unique_ids(self):
        source_df = pd.DataFrame(
            {
                "feat_a": [1.0, 2.0],
                "shared_feat": [5.0, np.inf],
                "label": ["benign", "dos"],
                "split": ["train", "val"],
                "timestamp": [0.0, 1.0],
                "record_id": [0, 1],
            }
        )
        target_df = pd.DataFrame(
            {
                "shared_feat": [7.0, 8.0],
                "feat_b": [-np.inf, np.nan],
                "label": ["benign", "evil"],
                "split": ["test_id", "test_ood"],
                "timestamp": [2.0, 3.0],
                "record_id": [10, 11],
            }
        )

        merged, summary = cross_uav.merge_cross_uav_frames(
            source_df,
            target_df,
            source_uav_id="uav_src",
            target_uav_id="uav_tgt",
        )

        self.assertEqual(
            merged.columns.tolist(),
            ["feat_a", "shared_feat", "feat_b", "label", "split", "timestamp", "record_id", "uav_id", "dataset_name"],
        )
        self.assertEqual(merged["record_id"].tolist(), ["uav_src_0", "uav_src_1", "uav_tgt_10", "uav_tgt_11"])
        self.assertEqual(len(set(merged["record_id"].tolist())), len(merged))
        self.assertTrue(np.allclose(merged["feat_b"].iloc[:2].to_numpy(), np.zeros(2)))
        self.assertTrue(np.allclose(merged["feat_a"].iloc[2:].to_numpy(), np.zeros(2)))
        self.assertEqual(float(merged["shared_feat"].iloc[1]), 0.0)
        self.assertTrue(np.allclose(merged["feat_b"].iloc[2:].to_numpy(), np.zeros(2)))
        self.assertEqual(summary["missing_features_filled"]["source"], ["feat_b"])
        self.assertEqual(summary["missing_features_filled"]["target"], ["feat_a"])

    def test_merge_cross_uav_frames_uses_source_train_and_target_test_only(self):
        source_df = pd.DataFrame(
            {
                "feat_a": [1.0, 2.0, 3.0, 4.0],
                "label": ["benign", "dos", "benign", "evil"],
                "split": ["train", "val", "test_id", "test_ood"],
                "timestamp": [0.0, 1.0, 2.0, 3.0],
                "record_id": [0, 1, 2, 3],
            }
        )
        target_df = pd.DataFrame(
            {
                "feat_b": [10.0, 11.0, 12.0, 13.0],
                "label": ["benign", "dos", "benign", "evil"],
                "split": ["train", "val", "test_id", "test_ood"],
                "timestamp": [4.0, 5.0, 6.0, 7.0],
                "record_id": [10, 11, 12, 13],
            }
        )

        merged, summary = cross_uav.merge_cross_uav_frames(
            source_df,
            target_df,
            source_uav_id="uav_01",
            target_uav_id="uav_02",
        )

        train_val = merged[merged["split"].isin(["train", "val"])]
        target_tests = merged[merged["split"].isin(["test_id", "test_ood"])]
        self.assertEqual(train_val["dataset_name"].unique().tolist(), ["source"])
        self.assertEqual(train_val["uav_id"].unique().tolist(), ["uav_01"])
        self.assertEqual(target_tests["dataset_name"].unique().tolist(), ["target"])
        self.assertEqual(target_tests["uav_id"].unique().tolist(), ["uav_02"])
        self.assertEqual(summary["used_rows"]["source_train"], 1)
        self.assertEqual(summary["used_rows"]["source_val"], 1)
        self.assertEqual(summary["used_rows"]["target_test_id"], 1)
        self.assertEqual(summary["used_rows"]["target_test_ood"], 1)
        self.assertEqual(summary["global_split_distribution"], {"test_id": 1, "test_ood": 1, "train": 1, "val": 1})

    def test_save_cross_uav_summary_generates_expected_json(self):
        dataset_summary = {
            "source_rows": 100,
            "target_rows": 80,
            "used_rows": {
                "source_train": 50,
                "source_val": 10,
                "target_test_id": 12,
                "target_test_ood": 8,
            },
        }
        eval_report = {
            "id_test": {"micro_f1": 0.9},
            "ood_test": {"auroc": 0.8},
            "id_test_by_group": {"uav_02": {"micro_f1": 0.9}},
            "ood_test_by_group": {"uav_02": {"auroc": 0.8}},
        }
        group_detection_summary = {
            "groups": {
                "uav_02": {"windows": 20, "threshold": 1.23}
            }
        }

        with tempfile.TemporaryDirectory() as tmp:
            out_path = Path(tmp) / "cross_uav_summary.json"
            summary = cross_uav.save_cross_uav_summary(
                output_path=out_path,
                source_uav="uav_01",
                target_uav="uav_02",
                dataset_summary=dataset_summary,
                eval_report=eval_report,
                group_detection_summary=group_detection_summary,
            )

            self.assertTrue(out_path.exists())
            self.assertEqual(summary["source_uav"], "uav_01")
            self.assertEqual(summary["target_uav"], "uav_02")
            self.assertEqual(summary["source_rows"], 100)
            self.assertEqual(summary["target_rows"], 80)
            self.assertEqual(summary["target_id_metrics"], {"micro_f1": 0.9})
            self.assertEqual(summary["target_ood_metrics"], {"auroc": 0.8})
            self.assertEqual(summary["target_group_metrics"]["id_test"], {"micro_f1": 0.9})
            self.assertEqual(summary["target_group_metrics"]["ood_test"], {"auroc": 0.8})
            self.assertEqual(summary["target_group_metrics"]["detection_summary"]["threshold"], 1.23)


if __name__ == "__main__":
    unittest.main()
