from __future__ import annotations

import importlib.util
import json
import subprocess
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = ROOT / "scripts" / "run_encoder_ablation.py"
SPEC = importlib.util.spec_from_file_location("run_encoder_ablation", MODULE_PATH)
run_encoder_ablation = importlib.util.module_from_spec(SPEC)
assert SPEC is not None and SPEC.loader is not None
SPEC.loader.exec_module(run_encoder_ablation)


def fake_eval_report(experiment_name: str, encoder_ablation: str) -> dict:
    return {
        "experiment_name": experiment_name,
        "encoder_ablation": encoder_ablation,
        "id_test": {"micro_f1": 0.91, "macro_f1": 0.83, "mAP": 0.87},
        "id_test_by_group": {
            "uav_01": {"micro_f1": 0.90},
            "uav_02": {"micro_f1": 0.93},
            "uav_03": {"micro_f1": 0.89},
        },
        "ood_test": {"auroc": 0.89, "fpr95": 0.10, "ood_f1": 0.76},
        "ood_test_by_group": {
            "uav_01": {"auroc": 0.87, "ood_f1": 0.71},
            "uav_02": {"auroc": 0.93, "ood_f1": 0.78},
            "uav_03": {"auroc": 0.85, "ood_f1": 0.69},
        },
    }


def ablation_config(name: str) -> dict:
    return next(cfg for cfg in run_encoder_ablation.ENCODER_ABLATION_CONFIGS if cfg["experiment_name"] == name)


class RunEncoderAblationTests(unittest.TestCase):
    def make_args(self, output_root: Path):
        return SimpleNamespace(
            input="data/multi_uav_hetero_experiment.csv",
            output_root=str(output_root),
            id_classes="benign,dos",
            ood_classes="evil",
            label_col="label",
            timestamp_col="timestamp",
            record_id_col="record_id",
            group_col="uav_id",
            benign_label="benign",
            allow_ports=False,
            window_mode="count",
            window_size=16,
            stride=8,
            time_window_seconds=2.0,
            adaptive_min_size=8,
            adaptive_max_size=64,
            graph_k=8,
            graph_tau=0.5,
            graph_metric="cosine",
            graph_variant="sym_weighted",
            hidden_dim=128,
            num_heads=4,
            num_layers=2,
            gcn_layers=2,
            dropout=0.1,
            gate="learned",
            record_head=False,
            epochs=3,
            batch_size=64,
            lr=1e-3,
            weight_decay=1e-4,
            lambda_record=0.0,
            q_ood=0.95,
            bank_k=5,
            fusion="correlation_aware",
            ood_direction_calibration="none",
            phase_aware_threshold=False,
            phase_column="mission_phase_proxy",
            phase_threshold_min_samples=32,
            phase_threshold_quantile=None,
            phase_threshold_fallback="global",
            normalization_mode="group",
            ood_threshold_mode="group",
            group_threshold_strategy="conservative",
            group_threshold_shrink_k=1000.0,
            group_threshold_min_ratio=1.0,
            group_threshold_min_samples=10,
            use_group_embedding=True,
            group_embedding_dim=16,
            seed=42,
            device="auto",
        )

    def test_build_train_command_uses_shared_recommended_defaults(self):
        args = self.make_args(Path("runs/out"))
        cmd = run_encoder_ablation.build_train_command(
            args,
            config=ablation_config("random_graph"),
            output_dir=Path("runs/out/random_graph"),
        )

        self.assertIn("--encoder_ablation", cmd)
        self.assertIn("random_graph", cmd)
        self.assertIn("--normalization_mode", cmd)
        self.assertIn("group", cmd)
        self.assertIn("--ood_threshold_mode", cmd)
        self.assertIn("conservative", cmd)
        self.assertIn("--use_group_embedding", cmd)
        self.assertIn("--seed", cmd)
        self.assertIn("42", [str(part) for part in cmd])

    def test_build_encoder_ablation_summary_row_extracts_requested_fields(self):
        row = run_encoder_ablation.build_encoder_ablation_summary_row(
            config=ablation_config("full"),
            eval_report=fake_eval_report("full", "full"),
            status="success",
            error_message=None,
        )

        self.assertEqual(row["experiment_name"], "full")
        self.assertEqual(row["encoder_ablation"], "full")
        self.assertEqual(row["id_micro_f1"], 0.91)
        self.assertEqual(row["ood_auroc"], 0.89)
        self.assertEqual(row["uav_01_id_micro_f1"], 0.90)
        self.assertEqual(row["uav_01_ood_f1"], 0.71)
        self.assertEqual(row["uav_02_ood_f1"], 0.78)
        self.assertEqual(row["uav_03_ood_auroc"], 0.85)
        self.assertEqual(row["uav_count"], 3)
        self.assertEqual(row["group_names"], "uav_01,uav_02,uav_03")
        self.assertAlmostEqual(row["macro_uav_id_micro_f1"], (0.90 + 0.93 + 0.89) / 3.0)
        self.assertAlmostEqual(row["macro_uav_ood_f1"], (0.71 + 0.78 + 0.69) / 3.0)
        self.assertEqual(row["worst_uav_ood_f1"], 0.69)

    def test_run_encoder_ablation_continues_after_failure_and_writes_summary(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            args = self.make_args(root)

            def fake_runner(cmd):
                cmd = [str(part) for part in cmd]
                script_name = Path(cmd[1]).name
                self.assertEqual(script_name, "train.py")
                out_dir = Path(cmd[cmd.index("--output_dir") + 1])
                encoder_ablation = cmd[cmd.index("--encoder_ablation") + 1]
                if encoder_ablation == "mlp_only":
                    raise subprocess.CalledProcessError(1, cmd)
                out_dir.mkdir(parents=True, exist_ok=True)
                (out_dir / "artifact.pt").write_bytes(b"artifact")
                (out_dir / "eval_report.json").write_text(
                    json.dumps(fake_eval_report(out_dir.name, encoder_ablation), ensure_ascii=False),
                    encoding="utf-8",
                )

            payload = run_encoder_ablation.run_encoder_ablation(args, runner=fake_runner)

            self.assertEqual(len(payload["experiments"]), 5)
            self.assertIn("mlp_only", payload["failed_experiments"])
            failed_row = next(row for row in payload["experiments"] if row["experiment_name"] == "mlp_only")
            self.assertEqual(failed_row["status"], "failed")
            self.assertIsNone(failed_row["id_micro_f1"])
            success_row = next(row for row in payload["experiments"] if row["experiment_name"] == "transformer_only")
            self.assertEqual(success_row["status"], "success")
            self.assertEqual(success_row["uav_01_ood_f1"], 0.71)
            self.assertEqual(success_row["uav_03_ood_f1"], 0.69)
            self.assertAlmostEqual(success_row["macro_uav_id_micro_f1"], (0.90 + 0.93 + 0.89) / 3.0)
            self.assertAlmostEqual(success_row["macro_uav_ood_f1"], (0.71 + 0.78 + 0.69) / 3.0)

            csv_path = root / "encoder_ablation_summary.csv"
            json_path = root / "encoder_ablation_summary.json"
            self.assertTrue(csv_path.exists())
            self.assertTrue(json_path.exists())

            df = pd.read_csv(csv_path)
            self.assertEqual(set(df["experiment_name"]), {cfg["experiment_name"] for cfg in run_encoder_ablation.ENCODER_ABLATION_CONFIGS})
            self.assertIn("encoder_ablation", df.columns)
            self.assertIn("macro_uav_id_micro_f1", df.columns)
            self.assertIn("macro_uav_ood_f1", df.columns)
            self.assertIn("worst_uav_ood_f1", df.columns)
            self.assertIn("uav_03_ood_f1", df.columns)


if __name__ == "__main__":
    unittest.main()
