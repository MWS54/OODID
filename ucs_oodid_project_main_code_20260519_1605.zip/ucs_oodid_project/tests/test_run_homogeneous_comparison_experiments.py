from __future__ import annotations

import importlib.util
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
SCRIPT_PATH = ROOT / "scripts" / "run_homogeneous_comparison_experiments.py"
SPEC = importlib.util.spec_from_file_location("run_homogeneous_comparison_experiments", SCRIPT_PATH)
homogeneous = importlib.util.module_from_spec(SPEC)
assert SPEC is not None and SPEC.loader is not None
SPEC.loader.exec_module(homogeneous)


def make_args(input_path: Path, output_root: Path, *, groups: str = "", heterogeneous_results_dir: str = "") -> SimpleNamespace:
    return SimpleNamespace(
        input=str(input_path),
        output_root=str(output_root),
        output_dir=str(output_root),
        heterogeneous_results_dir=heterogeneous_results_dir,
        groups=groups,
        label_col="label",
        timestamp_col="timestamp",
        record_id_col="record_id",
        group_col="uav_id",
        id_classes="benign,dos",
        ood_classes="evil",
        window_mode="count",
        window_size=2,
        stride=1,
        time_window_seconds=2.0,
        adaptive_min_size=8,
        adaptive_max_size=64,
        normalization_mode="group",
        q_ood=0.9,
        epochs=1,
        seed=42,
        device="auto",
        skip_sklearn=False,
        skip_neural=False,
        methods="rids_lite_proxy,ucs_oodid",
        benign_label="benign",
        allow_ports=False,
    )


def write_multi_group_dataset(path: Path) -> None:
    rows = []
    for group_name, base in [("uav_01", 0), ("uav_02", 100)]:
        for idx in range(6):
            rows.append(
                {
                    "record_id": f"{group_name}_{idx}",
                    "timestamp": base + idx,
                    "uav_id": group_name,
                    "label": "dos" if idx % 3 == 0 else "benign",
                    "feat_a": float(base + idx),
                    "feat_b": float(idx % 2),
                }
            )
        for idx in range(2):
            rows.append(
                {
                    "record_id": f"{group_name}_ood_{idx}",
                    "timestamp": base + 100 + idx,
                    "uav_id": group_name,
                    "label": "evil",
                    "feat_a": float(base + 100 + idx),
                    "feat_b": float((idx + 1) % 2),
                }
            )
    pd.DataFrame(rows).to_csv(path, index=False)


def build_fake_summary(output_root: Path, metrics_by_method: dict[str, dict]) -> dict:
    methods = []
    for method_name, display_name, category in [
        ("rids_lite_proxy", "RIDS-style", "sklearn"),
        ("ucs_oodid", "UCS-OODID", "neural"),
    ]:
        metrics = metrics_by_method[method_name]
        methods.append(
            {
                "method_name": method_name,
                "display_name": display_name,
                "category": category,
                "status": "success",
                "note": "",
                "output_dir": str(output_root / method_name),
                "eval_report": str(output_root / method_name / "eval_report.json"),
                "known_detection": {
                    "micro_f1": metrics["micro_f1"],
                    "macro_f1": metrics.get("macro_f1", metrics["micro_f1"] - 0.05),
                    "mAP": metrics.get("mAP", metrics["micro_f1"] + 0.02),
                    "hamming_loss": metrics.get("hamming_loss", 0.1),
                    "subset_accuracy": metrics.get("subset_accuracy", metrics["micro_f1"] - 0.1),
                },
                "ood_detection": {
                    "auroc": metrics["auroc"],
                    "aupr_out": metrics.get("aupr_out", metrics["auroc"] - 0.03),
                    "fpr95": metrics["fpr95"],
                    "precision": metrics.get("precision", 0.8),
                    "recall": metrics.get("recall", 0.75),
                    "ood_f1": metrics["ood_f1"],
                    "fpr_at_threshold": metrics.get("fpr_at_threshold", metrics["fpr95"] - 0.05),
                },
            }
        )
    summary = {
        "input": "",
        "output_root": str(output_root),
        "output_dir": str(output_root),
        "selected_methods": ["rids_lite_proxy", "ucs_oodid"],
        "successful_methods": ["rids_lite_proxy", "ucs_oodid"],
        "skipped_methods": [],
        "failed_methods": [],
        "methods": methods,
        "tables": {},
        "failed_methods_file": str(output_root / "failed_methods.json"),
    }
    output_root.mkdir(parents=True, exist_ok=True)
    (output_root / "comparison_summary.json").write_text(json.dumps(summary, ensure_ascii=False), encoding="utf-8")
    return summary


class HomogeneousComparisonExperimentTests(unittest.TestCase):
    def test_run_homogeneous_comparison_experiments_filters_groups_and_aggregates_outputs(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            input_path = tmp_path / "multi.csv"
            output_root = tmp_path / "runs"
            write_multi_group_dataset(input_path)

            per_source_metrics = {
                "uav_01": {
                    "rids_lite_proxy": {"micro_f1": 0.8, "auroc": 0.7, "ood_f1": 0.72, "fpr95": 0.30},
                    "ucs_oodid": {"micro_f1": 0.85, "auroc": 0.94, "ood_f1": 0.90, "fpr95": 0.10},
                },
                "uav_02": {
                    "rids_lite_proxy": {"micro_f1": 0.6, "auroc": 0.5, "ood_f1": 0.52, "fpr95": 0.40},
                    "ucs_oodid": {"micro_f1": 0.80, "auroc": 0.88, "ood_f1": 0.84, "fpr95": 0.16},
                },
            }
            heterogeneous_metrics = {
                "rids_lite_proxy": {"micro_f1": 0.65, "auroc": 0.52, "ood_f1": 0.50, "fpr95": 0.45},
                "ucs_oodid": {"micro_f1": 0.79, "auroc": 0.87, "ood_f1": 0.82, "fpr95": 0.18},
            }
            call_log: list[dict] = []

            def fake_executor(child_args):
                df = pd.read_csv(child_args.input)
                groups = sorted(df["uav_id"].astype(str).unique().tolist())
                output_dir = Path(child_args.output_root)
                call_log.append({"groups": groups, "output_root": str(output_dir)})
                if len(groups) == 1:
                    return build_fake_summary(output_dir, per_source_metrics[groups[0]])
                return build_fake_summary(output_dir, heterogeneous_metrics)

            summary = homogeneous.run_homogeneous_comparison_experiments(
                make_args(input_path, output_root),
                comparison_executor=fake_executor,
            )

            self.assertEqual(call_log[0]["groups"], ["uav_01", "uav_02"])
            self.assertEqual(call_log[1]["groups"], ["uav_01"])
            self.assertEqual(call_log[2]["groups"], ["uav_02"])
            self.assertEqual(summary["selected_groups"], ["uav_01", "uav_02"])
            self.assertEqual(summary["completed_source_count"], 2)
            self.assertEqual(summary["heterogeneous_reference"]["mode"], "generated")
            self.assertTrue((output_root / "homogeneous_known_detection_table.csv").exists())
            self.assertTrue((output_root / "homogeneous_ood_detection_table.csv").exists())
            self.assertTrue((output_root / "homogeneous_summary.json").exists())
            self.assertTrue((output_root / "homogeneous_vs_heterogeneous_table.csv").exists())
            self.assertTrue((output_root / "homogeneous_vs_heterogeneous_table.tex").exists())

            known_table = pd.read_csv(output_root / "homogeneous_known_detection_table.csv")
            self.assertEqual(
                known_table.loc[known_table["Method"] == "RIDS-style", "Micro-F1"].iloc[0],
                "0.7000 ± 0.1000",
            )
            self.assertEqual(
                known_table.loc[known_table["Method"] == "UCS-OODID", "Micro-F1"].iloc[0],
                "0.8250 ± 0.0250",
            )

            ood_table = pd.read_csv(output_root / "homogeneous_ood_detection_table.csv")
            self.assertEqual(
                ood_table.loc[ood_table["Method"] == "UCS-OODID", "AUROC"].iloc[0],
                "0.9100 ± 0.0300",
            )

            vs_table = pd.read_csv(output_root / "homogeneous_vs_heterogeneous_table.csv")
            self.assertEqual(
                vs_table.loc[vs_table["Method"] == "RIDS-style", "Micro-F1 Drop"].iloc[0],
                0.0500,
            )
            self.assertEqual(
                vs_table.loc[vs_table["Method"] == "UCS-OODID", "AUROC Drop"].iloc[0],
                0.0400,
            )
            self.assertEqual(
                vs_table.loc[vs_table["Method"] == "UCS-OODID", "FPR95 Increase"].iloc[0],
                0.0500,
            )

            paper_questions = summary["paper_questions"]["ucs_oodid_robustness"]
            self.assertEqual(paper_questions["auroc_drop_rank_best_to_worst"], 1)

    def test_run_homogeneous_comparison_experiments_supports_group_subset_and_external_hetero_summary(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            input_path = tmp_path / "multi.csv"
            output_root = tmp_path / "runs"
            hetero_root = tmp_path / "hetero"
            write_multi_group_dataset(input_path)

            build_fake_summary(
                hetero_root,
                {
                    "rids_lite_proxy": {"micro_f1": 0.66, "auroc": 0.56, "ood_f1": 0.51, "fpr95": 0.44},
                    "ucs_oodid": {"micro_f1": 0.81, "auroc": 0.87, "ood_f1": 0.83, "fpr95": 0.17},
                },
            )

            call_log: list[list[str]] = []

            def fake_executor(child_args):
                df = pd.read_csv(child_args.input)
                groups = sorted(df["uav_id"].astype(str).unique().tolist())
                call_log.append(groups)
                return build_fake_summary(
                    Path(child_args.output_root),
                    {
                        "rids_lite_proxy": {"micro_f1": 0.61, "auroc": 0.52, "ood_f1": 0.53, "fpr95": 0.42},
                        "ucs_oodid": {"micro_f1": 0.82, "auroc": 0.89, "ood_f1": 0.85, "fpr95": 0.15},
                    },
                )

            summary = homogeneous.run_homogeneous_comparison_experiments(
                make_args(
                    input_path,
                    output_root,
                    groups="uav_02",
                    heterogeneous_results_dir=str(hetero_root),
                ),
                comparison_executor=fake_executor,
            )

            self.assertEqual(call_log, [["uav_02"]])
            self.assertEqual(summary["selected_groups"], ["uav_02"])
            self.assertEqual(summary["completed_source_count"], 1)
            self.assertEqual(summary["heterogeneous_reference"]["mode"], "provided")
            self.assertEqual(summary["heterogeneous_reference"]["output_root"], str(hetero_root))


if __name__ == "__main__":
    unittest.main()
