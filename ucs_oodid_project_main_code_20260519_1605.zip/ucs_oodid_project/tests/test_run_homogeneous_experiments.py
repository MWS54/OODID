from __future__ import annotations

import importlib.util
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
SCRIPT_PATH = ROOT / "scripts" / "run_homogeneous_experiments.py"
SPEC = importlib.util.spec_from_file_location("run_homogeneous_experiments", SCRIPT_PATH)
homogeneous = importlib.util.module_from_spec(SPEC)
assert SPEC is not None and SPEC.loader is not None
SPEC.loader.exec_module(homogeneous)

KNOWN_METRICS = [
    ("Micro-F1", "micro_f1"),
    ("Macro-F1", "macro_f1"),
    ("mAP", "mAP"),
    ("Hamming Loss", "hamming_loss"),
    ("Subset Acc.", "subset_accuracy"),
]
OOD_METRICS = [
    ("AUROC", "auroc"),
    ("AUPR-Out", "aupr_out"),
    ("FPR95", "fpr95"),
    ("Precision", "precision"),
    ("Recall", "recall"),
    ("OOD-F1", "ood_f1"),
    ("FPR@theta", "fpr_at_threshold"),
]


def make_args(
    input_path: Path,
    output_root: Path,
    *,
    groups: str = "",
    keep_temp_csv: bool = False,
    per_group_label_config: str = "",
) -> SimpleNamespace:
    return SimpleNamespace(
        input=str(input_path),
        output_root=str(output_root),
        output_dir=str(output_root),
        label_col="label",
        timestamp_col="timestamp",
        record_id_col="record_id",
        group_col="uav_id",
        groups=groups,
        id_classes="benign,dos",
        ood_classes="evil",
        window_mode="count",
        window_size=2,
        stride=1,
        normalization_mode="global",
        q_ood=0.9,
        epochs=1,
        seed=42,
        device="auto",
        methods="",
        skip_sklearn=False,
        skip_neural=False,
        per_group_label_config=per_group_label_config,
        min_records=10,
        min_test_ood_windows=3,
        keep_temp_csv=keep_temp_csv,
    )


def write_dataset(path: Path) -> None:
    rows = []
    specs = [
        ("uav_ok", 12, 6, 0),
        ("uav_fail_ood_run", 12, 6, 100),
        ("uav_fail_runtime", 12, 6, 150),
        ("uav_few_records", 5, 2, 200),
        ("uav_low_ood", 12, 1, 300),
        ("uav_no_ood", 12, 0, 400),
    ]
    for group_name, id_count, ood_count, base in specs:
        for idx in range(id_count):
            rows.append(
                {
                    "record_id": f"{group_name}_id_{idx}",
                    "timestamp": base + idx,
                    "uav_id": group_name,
                    "label": "dos" if idx % 4 == 0 else "benign",
                    "feat_a": float(base + idx),
                    "feat_b": float(idx % 3),
                }
            )
        for idx in range(ood_count):
            rows.append(
                {
                    "record_id": f"{group_name}_ood_{idx}",
                    "timestamp": base + 100 + idx,
                    "uav_id": group_name,
                    "label": "evil",
                    "feat_a": float(base + 100 + idx),
                    "feat_b": float((idx + 1) % 3),
                }
            )
    pd.DataFrame(rows).to_csv(path, index=False)


def write_group_outputs(output_root: Path, methods: list[dict]) -> dict:
    output_root.mkdir(parents=True, exist_ok=True)
    summary = {
        "input": "",
        "output_root": str(output_root),
        "output_dir": str(output_root),
        "selected_methods": [item["method_name"] for item in methods],
        "successful_methods": [item["method_name"] for item in methods if item.get("status", "success") == "success"],
        "skipped_methods": [item["method_name"] for item in methods if item.get("status") == "skipped"],
        "failed_methods": [item["method_name"] for item in methods if item.get("status") == "failed"],
        "methods": methods,
        "tables": {},
        "failed_methods_file": str(output_root / "failed_methods.json"),
    }
    (output_root / "comparison_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False),
        encoding="utf-8",
    )
    known_rows = []
    ood_rows = []
    for item in methods:
        known = item.get("known_detection", {})
        ood = item.get("ood_detection", {})
        known_rows.append({"Method": item["display_name"], **{column: known.get(key) for column, key in KNOWN_METRICS}})
        ood_rows.append({"Method": item["display_name"], **{column: ood.get(key) for column, key in OOD_METRICS}})
    pd.DataFrame(known_rows).to_csv(output_root / "known_detection_table.csv", index=False)
    pd.DataFrame(ood_rows).to_csv(output_root / "ood_detection_table.csv", index=False)
    return summary


def method_entry(method_name: str, display_name: str, known: dict, ood: dict) -> dict:
    return {
        "method_name": method_name,
        "display_name": display_name,
        "status": "success",
        "note": "",
        "known_detection": dict(known),
        "ood_detection": dict(ood),
    }


class HomogeneousExperimentTests(unittest.TestCase):
    def test_check_group_viability_reports_label_presence_and_warning(self):
        args = make_args(Path("dummy.csv"), Path("runs"))
        df = pd.DataFrame(
            [
                {"label": "benign"},
                {"label": "dos"},
                {"label": "unknown_but_not_ood"},
                {"label": "evil"},
            ]
        )

        result = homogeneous.check_group_viability(df, args)

        self.assertEqual(result["records"], 4)
        self.assertEqual(result["id_records"], 3)
        self.assertEqual(result["ood_records"], 1)
        self.assertEqual(result["unique_labels"], ["benign", "dos", "evil", "unknown_but_not_ood"])
        self.assertEqual(result["id_labels_present"], ["benign", "dos", "unknown_but_not_ood"])
        self.assertEqual(result["ood_labels_present"], ["evil"])
        self.assertTrue(result["has_id_records"])
        self.assertTrue(result["has_ood_records"])
        self.assertIn("Warning: OOD record count 1 < window_size 2", result["warnings"][0])

    def test_run_homogeneous_experiments_skips_groups_and_continues_after_failure(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            input_path = tmp_path / "multi.csv"
            output_root = tmp_path / "runs"
            write_dataset(input_path)

            call_log: list[str] = []

            def fake_prechecker(precheck_args, precheck_dir):
                del precheck_dir
                group = pd.read_csv(precheck_args.input)["uav_id"].astype(str).iloc[0]
                window_counts = {
                    "uav_ok": {"train": 7, "val": 1, "test_id": 1, "test_ood": 5},
                    "uav_fail_ood_run": {"train": 7, "val": 1, "test_id": 1, "test_ood": 5},
                    "uav_fail_runtime": {"train": 7, "val": 1, "test_id": 1, "test_ood": 5},
                    "uav_low_ood": {"train": 7, "val": 1, "test_id": 1, "test_ood": 1},
                }
                if group not in window_counts:
                    raise ValueError("precheck unavailable")
                return {"split_source": "chronological_fallback", "window_counts": window_counts[group]}

            def fake_executor(child_args):
                group = pd.read_csv(child_args.input)["uav_id"].astype(str).iloc[0]
                call_log.append(group)
                if group == "uav_fail_ood_run":
                    raise RuntimeError(homogeneous.NOT_ENOUGH_OOD_REASON)
                if group == "uav_fail_runtime":
                    raise RuntimeError("simulated group failure")
                write_group_outputs(
                    Path(child_args.output_root),
                    [
                        method_entry(
                            "rapier_proxy",
                            "RAPIER-style",
                            {
                                "micro_f1": 0.61,
                                "macro_f1": 0.55,
                                "mAP": 0.65,
                                "hamming_loss": 0.12,
                                "subset_accuracy": 0.50,
                            },
                            {
                                "auroc": 0.71,
                                "aupr_out": 0.68,
                                "fpr95": 0.33,
                                "precision": 0.62,
                                "recall": 0.59,
                                "ood_f1": 0.60,
                                "fpr_at_threshold": 0.30,
                            },
                        ),
                        method_entry(
                            "ucs_oodid",
                            "UCS-OODID",
                            {
                                "micro_f1": 0.84,
                                "macro_f1": 0.80,
                                "mAP": 0.88,
                                "hamming_loss": 0.06,
                                "subset_accuracy": 0.76,
                            },
                            {
                                "auroc": 0.94,
                                "aupr_out": 0.91,
                                "fpr95": 0.10,
                                "precision": 0.82,
                                "recall": 0.86,
                                "ood_f1": 0.84,
                                "fpr_at_threshold": 0.09,
                            },
                        ),
                    ],
                )

            summary = homogeneous.run_homogeneous_experiments(
                make_args(input_path, output_root),
                comparison_executor=fake_executor,
                group_prechecker=fake_prechecker,
            )

            self.assertEqual(
                summary["groups"],
                ["uav_fail_ood_run", "uav_fail_runtime", "uav_few_records", "uav_low_ood", "uav_no_ood", "uav_ok"],
            )
            self.assertEqual(summary["successful_groups"], ["uav_ok"])
            self.assertEqual(call_log, ["uav_fail_ood_run", "uav_fail_runtime", "uav_ok"])
            self.assertEqual(len(summary["group_results"]), 1)
            self.assertEqual(summary["group_results"][0]["methods"]["ucs_oodid"]["known_detection"]["micro_f1"], 0.84)
            self.assertEqual(summary["group_results"][0]["dataset_stats"]["ood_records"], 6)

            skipped = {item["group"]: item["skip_reason"] for item in summary["skipped_groups"]}
            self.assertEqual(skipped["uav_few_records"], "record_count 7 < min_records 10")
            self.assertEqual(skipped["uav_low_ood"], "test_ood windows 1 < min_test_ood_windows 3")
            self.assertEqual(skipped["uav_no_ood"], homogeneous.NO_OOD_REASON)
            self.assertEqual(skipped["uav_fail_ood_run"], homogeneous.NOT_ENOUGH_OOD_REASON)

            self.assertEqual(len(summary["failed_groups"]), 1)
            self.assertEqual(summary["failed_groups"][0]["group"], "uav_fail_runtime")
            self.assertIn("simulated group failure", summary["failed_groups"][0]["error_message"])

            failed_groups = json.loads((output_root / "failed_groups.json").read_text(encoding="utf-8"))
            self.assertEqual(len(failed_groups), 1)
            self.assertEqual(failed_groups[0]["group"], "uav_fail_runtime")

            known_table = pd.read_csv(output_root / "homogeneous_known_detection_table.csv")
            self.assertEqual(known_table.columns.tolist(), homogeneous.KNOWN_COLUMNS)
            self.assertEqual(set(known_table["Group"].tolist()), {"uav_ok"})
            self.assertEqual(known_table["Method"].tolist(), ["RAPIER-style", "UCS-OODID"])

            ood_table = pd.read_csv(output_root / "homogeneous_ood_detection_table.csv")
            self.assertEqual(ood_table.columns.tolist(), homogeneous.OOD_COLUMNS)
            self.assertEqual(set(ood_table["Group"].tolist()), {"uav_ok"})

            main_table = pd.read_csv(output_root / "homogeneous_main_table.csv")
            self.assertEqual(main_table.columns.tolist(), homogeneous.MAIN_TABLE_COLUMNS)
            self.assertEqual(main_table["Dataset / Group"].tolist(), ["uav_ok"])
            self.assertEqual(main_table.loc[0, "Best Baseline OOD-F1"], 0.6000)
            self.assertTrue(pd.isna(main_table.loc[0, "ReCDA-style OOD-F1"]))
            self.assertEqual(main_table.loc[0, "UCS-OODID OOD-F1"], 0.8400)
            self.assertEqual(main_table.loc[0, "UCS-OODID AUROC"], 0.9400)
            self.assertEqual(main_table.loc[0, "UCS-OODID FPR@theta"], 0.0900)
            main_tex = (output_root / "homogeneous_main_table.tex").read_text(encoding="utf-8")
            self.assertIn(homogeneous.MAIN_TABLE_CAPTION, main_tex)

            group_stats = pd.read_csv(output_root / "group_dataset_stats.csv")
            self.assertEqual(group_stats.columns.tolist(), homogeneous.GROUP_STATS_COLUMNS)
            by_group = {row["Group"]: row for _, row in group_stats.iterrows()}
            self.assertEqual(by_group["uav_ok"]["Status"], "success")
            self.assertEqual(by_group["uav_no_ood"]["Status"], "skipped")
            self.assertEqual(by_group["uav_no_ood"]["Reason"], homogeneous.NO_OOD_REASON)
            self.assertEqual(by_group["uav_fail_ood_run"]["Status"], "skipped")
            self.assertIn("Warning: OOD record count 1 < window_size 2", str(by_group["uav_low_ood"]["Reason"]))
            self.assertEqual(by_group["uav_fail_runtime"]["Status"], "failed")

            self.assertFalse((output_root / "_temp_inputs").exists())

    def test_run_homogeneous_experiments_supports_per_group_label_config(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            input_path = tmp_path / "multi.csv"
            output_root = tmp_path / "runs"
            config_path = tmp_path / "per_group_label_config.json"
            write_dataset(input_path)
            config_path.write_text(
                json.dumps(
                    {
                        "uav_ok": {
                            "id_classes": "benign",
                            "ood_classes": "dos,evil",
                        }
                    },
                    ensure_ascii=False,
                ),
                encoding="utf-8",
            )

            seen_configs: dict[str, dict[str, str]] = {}

            def fake_prechecker(precheck_args, precheck_dir):
                del precheck_dir
                group = pd.read_csv(precheck_args.input)["uav_id"].astype(str).iloc[0]
                seen_configs.setdefault(group, {})
                seen_configs[group]["precheck_id_classes"] = str(precheck_args.id_classes)
                seen_configs[group]["precheck_ood_classes"] = str(precheck_args.ood_classes)
                return {
                    "split_source": "chronological_fallback",
                    "window_counts": {"train": 7, "val": 1, "test_id": 1, "test_ood": 5},
                }

            def fake_executor(child_args):
                group = pd.read_csv(child_args.input)["uav_id"].astype(str).iloc[0]
                seen_configs.setdefault(group, {})
                seen_configs[group]["executor_id_classes"] = str(child_args.id_classes)
                seen_configs[group]["executor_ood_classes"] = str(child_args.ood_classes)
                write_group_outputs(
                    Path(child_args.output_root),
                    [
                        method_entry(
                            "ucs_oodid",
                            "UCS-OODID",
                            {
                                "micro_f1": 0.84,
                                "macro_f1": 0.80,
                                "mAP": 0.88,
                                "hamming_loss": 0.06,
                                "subset_accuracy": 0.76,
                            },
                            {
                                "auroc": 0.94,
                                "aupr_out": 0.91,
                                "fpr95": 0.10,
                                "precision": 0.82,
                                "recall": 0.86,
                                "ood_f1": 0.84,
                                "fpr_at_threshold": 0.09,
                            },
                        ),
                    ],
                )

            summary = homogeneous.run_homogeneous_experiments(
                make_args(
                    input_path,
                    output_root,
                    groups="uav_ok,uav_fail_runtime",
                    per_group_label_config=str(config_path),
                ),
                comparison_executor=fake_executor,
                group_prechecker=fake_prechecker,
            )

            self.assertEqual(summary["successful_groups"], ["uav_ok", "uav_fail_runtime"])
            self.assertEqual(seen_configs["uav_ok"]["precheck_id_classes"], "benign")
            self.assertEqual(seen_configs["uav_ok"]["precheck_ood_classes"], "dos,evil")
            self.assertEqual(seen_configs["uav_ok"]["executor_id_classes"], "benign")
            self.assertEqual(seen_configs["uav_ok"]["executor_ood_classes"], "dos,evil")
            self.assertEqual(seen_configs["uav_fail_runtime"]["precheck_id_classes"], "benign,dos")
            self.assertEqual(seen_configs["uav_fail_runtime"]["precheck_ood_classes"], "evil")

            resolved = summary["resolved_group_label_configs"]
            self.assertEqual(resolved["uav_ok"]["id_classes"], ["benign"])
            self.assertEqual(resolved["uav_ok"]["ood_classes"], ["dos", "evil"])
            self.assertEqual(resolved["uav_ok"]["label_config_source"], "per_group_label_config")
            self.assertEqual(resolved["uav_fail_runtime"]["id_classes"], ["benign", "dos"])
            self.assertEqual(resolved["uav_fail_runtime"]["ood_classes"], ["evil"])
            self.assertEqual(resolved["uav_fail_runtime"]["label_config_source"], "global_defaults")

            by_group_result = {item["group"]: item for item in summary["group_results"]}
            self.assertEqual(by_group_result["uav_ok"]["id_classes"], ["benign"])
            self.assertEqual(by_group_result["uav_ok"]["ood_classes"], ["dos", "evil"])
            self.assertEqual(by_group_result["uav_ok"]["dataset_stats"]["id_classes"], ["benign"])
            self.assertEqual(by_group_result["uav_fail_runtime"]["id_classes"], ["benign", "dos"])

            group_stats = pd.read_csv(output_root / "group_dataset_stats.csv")
            by_group = {row["Group"]: row for _, row in group_stats.iterrows()}
            self.assertEqual(by_group["uav_ok"]["ID Classes Used"], "benign")
            self.assertEqual(by_group["uav_ok"]["OOD Classes Used"], "dos,evil")
            self.assertEqual(by_group["uav_fail_runtime"]["ID Classes Used"], "benign,dos")
            self.assertEqual(by_group["uav_fail_runtime"]["OOD Classes Used"], "evil")

    def test_run_homogeneous_experiments_keeps_temp_csv_and_filters_latex(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            input_path = tmp_path / "multi.csv"
            output_root = tmp_path / "runs"
            write_dataset(input_path)

            def fake_prechecker(precheck_args, precheck_dir):
                del precheck_dir
                group = pd.read_csv(precheck_args.input)["uav_id"].astype(str).iloc[0]
                self.assertEqual(group, "uav_ok")
                return {
                    "split_source": "chronological_fallback",
                    "window_counts": {"train": 7, "val": 1, "test_id": 1, "test_ood": 5},
                }

            def fake_executor(child_args):
                write_group_outputs(
                    Path(child_args.output_root),
                    [
                        method_entry(
                            "rids_lite_proxy",
                            "RIDS-style",
                            {"micro_f1": 0.51, "macro_f1": 0.49, "mAP": 0.57, "hamming_loss": 0.16, "subset_accuracy": 0.40},
                            {"auroc": 0.58, "aupr_out": 0.56, "fpr95": 0.46, "precision": 0.49, "recall": 0.44, "ood_f1": 0.46, "fpr_at_threshold": 0.42},
                        ),
                        method_entry(
                            "rapier_proxy",
                            "RAPIER-style",
                            {"micro_f1": 0.61, "macro_f1": 0.55, "mAP": 0.65, "hamming_loss": 0.12, "subset_accuracy": 0.50},
                            {"auroc": 0.71, "aupr_out": 0.68, "fpr95": 0.33, "precision": 0.62, "recall": 0.59, "ood_f1": 0.60, "fpr_at_threshold": 0.30},
                        ),
                        method_entry(
                            "hypervision_proxy",
                            "HyperVision-style",
                            {"micro_f1": 0.64, "macro_f1": 0.60, "mAP": 0.69, "hamming_loss": 0.11, "subset_accuracy": 0.53},
                            {"auroc": 0.75, "aupr_out": 0.72, "fpr95": 0.29, "precision": 0.66, "recall": 0.63, "ood_f1": 0.64, "fpr_at_threshold": 0.27},
                        ),
                        method_entry(
                            "recda_proxy",
                            "ReCDA-style",
                            {"micro_f1": 0.77, "macro_f1": 0.73, "mAP": 0.81, "hamming_loss": 0.08, "subset_accuracy": 0.67},
                            {"auroc": 0.88, "aupr_out": 0.85, "fpr95": 0.17, "precision": 0.77, "recall": 0.79, "ood_f1": 0.78, "fpr_at_threshold": 0.15},
                        ),
                        method_entry(
                            "auxiliary_probe",
                            "Auxiliary Probe",
                            {"micro_f1": 0.41, "macro_f1": 0.38, "mAP": 0.44, "hamming_loss": 0.22, "subset_accuracy": 0.29},
                            {"auroc": 0.49, "aupr_out": 0.45, "fpr95": 0.61, "precision": 0.35, "recall": 0.33, "ood_f1": 0.34, "fpr_at_threshold": 0.58},
                        ),
                        method_entry(
                            "ucs_oodid",
                            "UCS-OODID",
                            {"micro_f1": 0.84, "macro_f1": 0.80, "mAP": 0.88, "hamming_loss": 0.06, "subset_accuracy": 0.76},
                            {"auroc": 0.94, "aupr_out": 0.91, "fpr95": 0.10, "precision": 0.82, "recall": 0.86, "ood_f1": 0.84, "fpr_at_threshold": 0.09},
                        ),
                    ],
                )

            original_limit = homogeneous.LATEX_FULL_ROW_LIMIT
            homogeneous.LATEX_FULL_ROW_LIMIT = 1
            try:
                summary = homogeneous.run_homogeneous_experiments(
                    make_args(input_path, output_root, groups="uav_ok", keep_temp_csv=True),
                    comparison_executor=fake_executor,
                    group_prechecker=fake_prechecker,
                )
            finally:
                homogeneous.LATEX_FULL_ROW_LIMIT = original_limit

            self.assertEqual(summary["groups"], ["uav_ok"])
            self.assertEqual(summary["successful_groups"], ["uav_ok"])
            self.assertTrue((output_root / "_temp_inputs" / "uav_ok.csv").exists())
            self.assertTrue((output_root / "group_dataset_stats.csv").exists())

            known_csv = pd.read_csv(output_root / "homogeneous_known_detection_table.csv")
            self.assertIn("RIDS-style", known_csv["Method"].tolist())

            main_table = pd.read_csv(output_root / "homogeneous_main_table.csv")
            self.assertEqual(main_table["Dataset / Group"].tolist(), ["uav_ok"])
            self.assertEqual(main_table.loc[0, "Best Baseline OOD-F1"], 0.7800)
            self.assertEqual(main_table.loc[0, "ReCDA-style OOD-F1"], 0.7800)
            self.assertEqual(main_table.loc[0, "UCS-OODID OOD-F1"], 0.8400)
            self.assertEqual(main_table.loc[0, "UCS-OODID AUROC"], 0.9400)
            self.assertEqual(main_table.loc[0, "UCS-OODID FPR@theta"], 0.0900)

            known_tex = (output_root / "homogeneous_known_detection_table.tex").read_text(encoding="utf-8")
            self.assertNotIn("Auxiliary Probe", known_tex)
            self.assertIn("RIDS-style", known_tex)
            self.assertIn("RAPIER-style", known_tex)
            self.assertIn("HyperVision-style", known_tex)
            self.assertIn("ReCDA-style", known_tex)
            self.assertIn("UCS-OODID", known_tex)

            ood_tex = (output_root / "homogeneous_ood_detection_table.tex").read_text(encoding="utf-8")
            self.assertNotIn("Auxiliary Probe", ood_tex)
            self.assertIn("UCS-OODID", ood_tex)

            main_tex = (output_root / "homogeneous_main_table.tex").read_text(encoding="utf-8")
            self.assertIn(homogeneous.MAIN_TABLE_CAPTION, main_tex)


if __name__ == "__main__":
    unittest.main()
