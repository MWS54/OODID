from __future__ import annotations

import importlib.util
import json
import subprocess
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = ROOT / "scripts" / "run_multi_uav_ablation.py"
SPEC = importlib.util.spec_from_file_location("run_multi_uav_ablation", MODULE_PATH)
run_multi_uav_ablation = importlib.util.module_from_spec(SPEC)
assert SPEC is not None and SPEC.loader is not None
SPEC.loader.exec_module(run_multi_uav_ablation)


def fake_eval_report(experiment_name: str) -> dict:
    return {
        "id_test": {"micro_f1": 0.90, "macro_f1": 0.80, "mAP": 0.85},
        "ood_test": {
            "auroc": 0.88,
            "aupr_out": 0.77,
            "fpr95": 0.12,
            "ood_f1": 0.74,
            "fpr_at_threshold": 0.09,
        },
        "id_test_by_group": {
            "uav_01": {"micro_f1": 0.91},
            "uav_02": {"micro_f1": 0.92},
            "uav_03": {"micro_f1": 0.87},
        },
        "ood_test_by_group": {
            "uav_01": {"auroc": 0.83, "ood_f1": 0.71},
            "uav_02": {"auroc": 0.95, "ood_f1": 0.78},
            "uav_03": {"auroc": 0.89, "ood_f1": 0.69},
        },
        "timing": {
            "test_id_windows": 12,
            "test_ood_windows": 6,
            "test_windows": 18,
            "detection_time_s": 0.054,
            "average_detection_time_ms": 3.0,
            "throughput_windows_per_s": 333.3333333333,
        },
        "experiment_name": experiment_name,
    }


def fake_group_detection_summary() -> dict:
    return {
        "global": {"alert_rate": 0.11},
        "groups": {
            "uav_01": {"alert_rate": 0.14},
            "uav_02": {"alert_rate": 0.05},
            "uav_03": {"alert_rate": 0.09},
        },
    }


def ablation_config(name: str) -> dict:
    return next(cfg for cfg in run_multi_uav_ablation.ABLATION_CONFIGS if cfg["experiment_name"] == name)


class MultiUavAblationTests(unittest.TestCase):
    def make_args(self, output_root: Path):
        return SimpleNamespace(
            input="data/multi_uav_hetero_experiment.csv",
            output_root=str(output_root),
            id_classes="benign,dos",
            ood_classes="evil",
            group_col="uav_id",
            label_col="label",
            timestamp_col="timestamp",
            record_id_col="record_id",
            window_size=16,
            stride=8,
            seed=42,
            benign_label="benign",
            allow_ports=False,
            device="auto",
        )

    def test_build_train_command_reflects_experiment_config(self):
        args = self.make_args(Path("runs/out"))
        output_dir = Path("runs/out/base_global_mean")

        base_cmd = run_multi_uav_ablation.build_train_command(
            args,
            config=ablation_config("base_global_mean"),
            output_dir=output_dir,
        )
        embedding_cmd = run_multi_uav_ablation.build_train_command(
            args,
            config=ablation_config("group_embedding_only"),
            output_dir=output_dir,
        )
        conservative_cmd = run_multi_uav_ablation.build_train_command(
            args,
            config=ablation_config("full_ucs_oodid"),
            output_dir=output_dir,
        )

        self.assertIn("--encoder_ablation", base_cmd)
        self.assertIn("transformer_only", base_cmd)
        self.assertIn("--fusion", base_cmd)
        self.assertIn("mean", base_cmd)
        self.assertIn("--normalization_mode", base_cmd)
        self.assertIn("global", base_cmd)
        self.assertIn("--ood_threshold_mode", base_cmd)
        self.assertIn("--group_threshold_strategy", base_cmd)
        self.assertIn("raw", base_cmd)
        self.assertIn("--bank_k", base_cmd)
        self.assertIn("5", base_cmd)
        self.assertIn("--q_ood", base_cmd)
        self.assertIn("0.9", base_cmd)
        self.assertIn("--epochs", base_cmd)
        self.assertIn("10", base_cmd)
        self.assertNotIn("--use_group_embedding", base_cmd)
        self.assertIn("--use_group_embedding", embedding_cmd)
        self.assertIn("--group_embedding_dim", embedding_cmd)
        self.assertIn("16", embedding_cmd)
        self.assertIn("group", conservative_cmd)
        self.assertIn("conservative", conservative_cmd)

    def test_run_multi_uav_ablation_continues_after_failure_and_writes_summary(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            args = self.make_args(root)

            def fake_runner(cmd):
                cmd = [str(part) for part in cmd]
                script_name = Path(cmd[1]).name
                if script_name == "train.py":
                    out_dir = Path(cmd[cmd.index("--output_dir") + 1])
                    experiment_name = out_dir.name
                    if experiment_name == "group_norm_only":
                        raise subprocess.CalledProcessError(1, cmd)
                    out_dir.mkdir(parents=True, exist_ok=True)
                    (out_dir / "artifact.pt").write_bytes(b"artifact")
                    (out_dir / "eval_report.json").write_text(
                        json.dumps(fake_eval_report(experiment_name), ensure_ascii=False),
                        encoding="utf-8",
                    )
                else:
                    raise AssertionError(f"Unexpected command: {cmd}")

            payload = run_multi_uav_ablation.run_multi_uav_ablation(args, runner=fake_runner)

            self.assertEqual(len(payload["experiments"]), 7)
            self.assertIn("group_norm_only", payload["failed_experiments"])
            failed_row = next(row for row in payload["experiments"] if row["experiment_name"] == "group_norm_only")
            self.assertEqual(failed_row["status"], "failed")
            self.assertIsNone(failed_row["id_micro_f1"])
            success_row = next(row for row in payload["experiments"] if row["experiment_name"] == "full_ucs_oodid")
            self.assertEqual(success_row["status"], "success")
            self.assertEqual(success_row["id_micro_f1"], 0.90)
            self.assertAlmostEqual(success_row["macro_uav_ood_f1"], (0.71 + 0.78 + 0.69) / 3.0)
            self.assertEqual(success_row["fpr_at_threshold"], 0.09)
            self.assertEqual(success_row["average_detection_time_ms"], 3.0)

            csv_path = root / "ablation_summary.csv"
            json_path = root / "ablation_summary.json"
            tex_path = root / "ablation_summary_table.tex"
            self.assertTrue(csv_path.exists())
            self.assertTrue(json_path.exists())
            self.assertTrue(tex_path.exists())

            df = pd.read_csv(csv_path)
            self.assertEqual(set(df["experiment_name"]), {cfg["experiment_name"] for cfg in run_multi_uav_ablation.ABLATION_CONFIGS})
            self.assertIn("status", df.columns)
            self.assertIn("error_message", df.columns)
            self.assertIn("fusion", df.columns)
            self.assertIn("fpr_at_threshold", df.columns)
            self.assertIn("average_detection_time_ms", df.columns)
            self.assertIn("throughput_windows_per_s", df.columns)
            self.assertIn("macro_uav_ood_f1", df.columns)
            self.assertIn("worst_uav_ood_f1", df.columns)
            tex = tex_path.read_text(encoding="utf-8")
            self.assertIn("Variant", tex)
            self.assertIn("Time(ms)", tex)
            self.assertIn(r"\textbf{Full UCS-OODID}", tex)

    def test_build_ablation_summary_row_extracts_requested_fields(self):
        row = run_multi_uav_ablation.build_ablation_summary_row(
            config=ablation_config("group_threshold_raw"),
            eval_report=fake_eval_report("group_threshold_raw"),
            status="success",
            error_message=None,
        )

        self.assertEqual(row["experiment_name"], "group_threshold_raw")
        self.assertEqual(row["normalization_mode"], "global")
        self.assertEqual(row["fusion"], "correlation_aware")
        self.assertEqual(row["ood_threshold_mode"], "group")
        self.assertEqual(row["group_threshold_strategy"], "raw")
        self.assertEqual(row["group_threshold_min_ratio"], 1.0)
        self.assertEqual(row["group_threshold_min_samples"], 10)
        self.assertFalse(row["use_group_embedding"])
        self.assertEqual(row["id_micro_f1"], 0.90)
        self.assertEqual(row["ood_auroc"], 0.88)
        self.assertEqual(row["ood_aupr_out"], 0.77)
        self.assertEqual(row["fpr_at_threshold"], 0.09)
        self.assertEqual(row["average_detection_time_ms"], 3.0)
        self.assertAlmostEqual(row["throughput_windows_per_s"], 333.3333333333)
        self.assertEqual(row["uav_count"], 3)
        self.assertEqual(row["group_names"], "uav_01,uav_02,uav_03")
        self.assertAlmostEqual(row["macro_uav_id_micro_f1"], (0.91 + 0.92 + 0.87) / 3.0)
        self.assertAlmostEqual(row["macro_uav_ood_f1"], (0.71 + 0.78 + 0.69) / 3.0)
        self.assertEqual(row["worst_uav_ood_f1"], 0.69)


if __name__ == "__main__":
    unittest.main()
