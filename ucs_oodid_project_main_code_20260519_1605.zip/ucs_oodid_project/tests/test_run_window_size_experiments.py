from __future__ import annotations

import importlib.util
import json
import subprocess
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
SCRIPT_PATH = ROOT / "scripts" / "run_window_size_experiments.py"
SPEC = importlib.util.spec_from_file_location("run_window_size_experiments", SCRIPT_PATH)
run_window_size_experiments = importlib.util.module_from_spec(SPEC)
assert SPEC is not None and SPEC.loader is not None
SPEC.loader.exec_module(run_window_size_experiments)


def make_args(input_path: Path, output_root: Path, window_sizes: str = "8,16,32") -> SimpleNamespace:
    return SimpleNamespace(
        input=str(input_path),
        output_root=str(output_root),
        id_classes="benign,dos",
        ood_classes="evil",
        group_col="uav_id",
        label_col="label",
        timestamp_col="timestamp",
        record_id_col="record_id",
        window_sizes=window_sizes,
        stride_policy="half",
        methods="rapier_proxy,hypervision_proxy,ucs_oodid",
        epochs=10,
        q_ood=0.9,
        device="auto",
        seed=42,
        benign_label="benign",
        allow_ports=False,
    )


class WindowSizeExperimentsTests(unittest.TestCase):
    def test_build_window_command_uses_half_stride(self):
        args = make_args(Path("toy.csv"), Path("runs"), window_sizes="32")

        cmd = [
            str(part)
            for part in run_window_size_experiments.build_window_command(
                args,
                window_size=32,
                stride=run_window_size_experiments.resolve_stride(32, "half"),
                window_output_root=Path("runs") / "window_32",
            )
        ]

        self.assertEqual(cmd[cmd.index("--window_size") + 1], "32")
        self.assertEqual(cmd[cmd.index("--stride") + 1], "16")
        self.assertEqual(cmd[cmd.index("--output_root") + 1], str(Path("runs") / "window_32"))
        self.assertEqual(cmd[cmd.index("--methods") + 1], "rapier_proxy,hypervision_proxy,ucs_oodid")

    def test_run_window_size_experiments_aggregates_outputs_and_records_failures(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            input_path = tmp_path / "toy.csv"
            input_path.write_text("record_id,timestamp,uav_id,label,feat_a\nr0,0,uav_01,benign,0.0\n", encoding="utf-8")
            output_root = tmp_path / "runs"
            args = make_args(input_path, output_root)
            seen_commands: list[list[str]] = []

            def fake_runner(cmd):
                cmd = [str(part) for part in cmd]
                seen_commands.append(cmd)
                out_dir = Path(cmd[cmd.index("--output_root") + 1])
                window_size = int(cmd[cmd.index("--window_size") + 1])
                stride = int(cmd[cmd.index("--stride") + 1])
                out_dir.mkdir(parents=True, exist_ok=True)

                if window_size == 32:
                    return subprocess.CompletedProcess(cmd, 1, stdout="partial stdout", stderr="boom")

                known = pd.DataFrame(
                    [
                        {
                            "Method": "RAPIER-style",
                            "Micro-F1": 0.70 + 0.01 * window_size,
                            "Macro-F1": 0.60 + 0.01 * window_size,
                            "mAP": 0.65 + 0.01 * window_size,
                            "Hamming Loss": 0.20,
                            "Subset Acc.": 0.55,
                        },
                        {
                            "Method": "HyperVision-style",
                            "Micro-F1": np.nan if window_size == 8 else 0.80,
                            "Macro-F1": np.nan if window_size == 8 else 0.75,
                            "mAP": np.nan if window_size == 8 else 0.78,
                            "Hamming Loss": np.nan if window_size == 8 else 0.15,
                            "Subset Acc.": np.nan if window_size == 8 else 0.65,
                        },
                        {
                            "Method": "UCS-OODID",
                            "Micro-F1": 0.85 + 0.001 * window_size,
                            "Macro-F1": 0.80 + 0.001 * window_size,
                            "mAP": 0.83 + 0.001 * window_size,
                            "Hamming Loss": 0.10,
                            "Subset Acc.": 0.70,
                        },
                    ]
                )
                ood = pd.DataFrame(
                    [
                        {
                            "Method": "RAPIER-style",
                            "AUROC": 0.75 + 0.001 * window_size,
                            "AUPR-Out": 0.70 + 0.001 * window_size,
                            "FPR95": 0.30,
                            "Precision": 0.68,
                            "Recall": 0.72,
                            "OOD-F1": 0.70,
                            "FPR@theta": 0.22,
                        },
                        {
                            "Method": "HyperVision-style",
                            "AUROC": np.nan if window_size == 8 else 0.88,
                            "AUPR-Out": np.nan if window_size == 8 else 0.84,
                            "FPR95": np.nan if window_size == 8 else 0.18,
                            "Precision": np.nan if window_size == 8 else 0.82,
                            "Recall": np.nan if window_size == 8 else 0.80,
                            "OOD-F1": np.nan if window_size == 8 else 0.81,
                            "FPR@theta": np.nan if window_size == 8 else 0.15,
                        },
                        {
                            "Method": "UCS-OODID",
                            "AUROC": 0.92 + 0.001 * window_size,
                            "AUPR-Out": 0.89 + 0.001 * window_size,
                            "FPR95": 0.12,
                            "Precision": 0.87,
                            "Recall": 0.90,
                            "OOD-F1": 0.88,
                            "FPR@theta": 0.09,
                        },
                    ]
                )
                time = pd.DataFrame(
                    [
                        {
                            "Method": "RAPIER-style",
                            "Avg. Detection Time (ms/window)": 1.0 + 0.1 * window_size,
                            "Throughput (windows/s)": 1000.0 / max(window_size, 1),
                            "Test Windows": 20,
                        },
                        {
                            "Method": "HyperVision-style",
                            "Avg. Detection Time (ms/window)": np.nan if window_size == 8 else 5.5,
                            "Throughput (windows/s)": np.nan if window_size == 8 else 180.0,
                            "Test Windows": 20,
                        },
                        {
                            "Method": "UCS-OODID",
                            "Avg. Detection Time (ms/window)": 2.5 + 0.1 * window_size,
                            "Throughput (windows/s)": 400.0 / max(window_size / 8.0, 1.0),
                            "Test Windows": 20,
                        },
                    ]
                )
                known.to_csv(out_dir / "known_detection_table.csv", index=False)
                ood.to_csv(out_dir / "ood_detection_table.csv", index=False)
                time.to_csv(out_dir / "detection_time_table.csv", index=False)
                summary = {
                    "successful_methods": ["rapier_proxy", "ucs_oodid"] if window_size == 8 else ["rapier_proxy", "hypervision_proxy", "ucs_oodid"],
                    "failed_methods": ["hypervision_proxy"] if window_size == 8 else [],
                    "skipped_methods": [],
                    "methods": [
                        {
                            "method_name": "rapier_proxy",
                            "display_name": "RAPIER-style",
                            "status": "success",
                            "note": "",
                            "output_dir": str(out_dir / "rapier_proxy"),
                            "eval_report": str(out_dir / "rapier_proxy" / "eval_report.json"),
                        },
                        {
                            "method_name": "hypervision_proxy",
                            "display_name": "HyperVision-style",
                            "status": "failed" if window_size == 8 else "success",
                            "note": "simulated failure" if window_size == 8 else "",
                            "output_dir": str(out_dir / "hypervision_proxy"),
                            "eval_report": str(out_dir / "hypervision_proxy" / "eval_report.json"),
                        },
                        {
                            "method_name": "ucs_oodid",
                            "display_name": "UCS-OODID",
                            "status": "success",
                            "note": "",
                            "output_dir": str(out_dir / "ucs_oodid"),
                            "eval_report": str(out_dir / "ucs_oodid" / "eval_report.json"),
                        },
                    ],
                }
                (out_dir / "comparison_summary.json").write_text(json.dumps(summary, ensure_ascii=False), encoding="utf-8")
                return subprocess.CompletedProcess(cmd, 0, stdout=f"ok window={window_size} stride={stride}", stderr="")

            summary = run_window_size_experiments.run_window_size_experiments(args, runner=fake_runner)

            self.assertEqual(summary["successful_window_sizes"], [8, 16])
            self.assertEqual(len(seen_commands), 3)
            stride_by_window = {
                int(cmd[cmd.index("--window_size") + 1]): int(cmd[cmd.index("--stride") + 1])
                for cmd in seen_commands
            }
            self.assertEqual(stride_by_window[8], 4)
            self.assertEqual(stride_by_window[16], 8)
            self.assertEqual(stride_by_window[32], 16)

            known_table = pd.read_csv(output_root / "window_size_known_table.csv")
            ood_table = pd.read_csv(output_root / "window_size_ood_table.csv")
            time_table = pd.read_csv(output_root / "window_size_time_table.csv")
            summary_table = pd.read_csv(output_root / "window_size_summary.csv")
            self.assertTrue((output_root / "window_size_summary.json").exists())
            self.assertTrue((output_root / "window_size_summary_table.tex").exists())
            self.assertEqual(
                known_table.columns.tolist(),
                ["Window Size", "Stride", "Method", "Micro-F1", "Macro-F1", "mAP", "Hamming Loss", "Subset Acc."],
            )
            self.assertEqual(
                ood_table.columns.tolist(),
                ["Window Size", "Stride", "Method", "AUROC", "AUPR-Out", "FPR95", "Precision", "Recall", "OOD-F1", "FPR@theta"],
            )
            self.assertEqual(
                time_table.columns.tolist(),
                ["Window Size", "Stride", "Method", "Avg. Detection Time (ms/window)", "Throughput (windows/s)", "Test Windows"],
            )
            self.assertEqual(
                summary_table.columns.tolist(),
                [
                    "Window Size",
                    "Stride",
                    "Method",
                    "Micro-F1",
                    "Macro-F1",
                    "mAP",
                    "AUROC",
                    "AUPR-Out",
                    "FPR95",
                    "OOD-F1",
                    "FPR@theta",
                    "Avg. Detection Time (ms/window)",
                    "Throughput (windows/s)",
                ],
            )
            self.assertIn("RAPIER-style", summary_table["Method"].tolist())
            self.assertIn("UCS-OODID", summary_table["Method"].tolist())
            self.assertNotIn("random_forest", summary_table["Method"].tolist())
            self.assertEqual(sorted(summary_table["Window Size"].unique().tolist()), [8, 16])

            failed = json.loads((output_root / "failed_window_runs.json").read_text(encoding="utf-8"))
            self.assertEqual(len(failed), 2)
            method_failure = next(item for item in failed if item["method_name"] == "hypervision_proxy")
            self.assertEqual(method_failure["display_name"], "HyperVision-style")
            self.assertEqual(method_failure["window_size"], 8)
            process_failure = next(item for item in failed if item["method_name"] is None)
            self.assertEqual(process_failure["window_size"], 32)
            self.assertEqual(process_failure["return_code"], 1)
            self.assertIn("boom", process_failure["stderr_tail"])

            summary_tex = (output_root / "window_size_summary_table.tex").read_text(encoding="utf-8")
            self.assertIn("Window-size sensitivity summary under the same metadata-window protocol.", summary_tex)
            self.assertIn("Time(ms)", summary_tex)
            self.assertIn(r"\textbf{UCS-OODID}", summary_tex)


if __name__ == "__main__":
    unittest.main()
