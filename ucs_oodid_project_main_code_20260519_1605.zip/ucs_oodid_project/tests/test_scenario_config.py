from __future__ import annotations

from pathlib import Path
import unittest

import yaml

from ucs_oodid.simulator.scenario import AttackEvent, ScenarioConfig, get_active_attacks, load_scenario_from_yaml

ROOT = Path(__file__).resolve().parents[1]
NEW_SCENARIO_PATHS = (
    "configs/scenarios/single_attack_uav05_unsw.yaml",
    "configs/scenarios/single_attack_uav06_ecu_ioft.yaml",
    "configs/scenarios/single_attack_uav07_uavids.yaml",
    "configs/scenarios/mixed_attack_6datasets.yaml",
    "configs/scenarios/external_ood_unsw_demo.yaml",
)
REQUIRED_ATTACK_EVENT_FIELDS = {
    "uav_id",
    "source_dataset",
    "source_type",
    "attack_types",
    "start_time",
    "duration",
    "intensity",
    "replay_mode",
    "is_ood",
}


class ScenarioConfigTests(unittest.TestCase):
    def test_load_single_attack_demo_uses_default_active_scenario(self):
        scenario = load_scenario_from_yaml("configs/scenarios/single_attack_demo.yaml")

        self.assertEqual(scenario.name, "single_attack_demo")
        self.assertEqual(scenario.scenario_type, "single_attack")
        self.assertIsNone(scenario.mix_mode)
        self.assertEqual([event.source_dataset for event in scenario.attack_events], ["uav_ndd", "gcs_to_uav_updated", "isot_drone"])
        self.assertEqual([event.attack_types for event in scenario.attack_events], [("flood",), ("replay",), ("flood",)])

        active = get_active_attacks(14.0, "uav_01", "cruise")
        self.assertEqual(len(active), 1)
        self.assertEqual(active[0].attack_types, ("flood",))
        self.assertEqual(get_active_attacks(14.0, "uav_01", "hover"), [])

    def test_load_mixed_attack_demo_filters_by_uav_and_phase(self):
        scenario = load_scenario_from_yaml("configs/scenarios/mixed_attack_demo.yaml", set_as_active=False)

        self.assertEqual(scenario.name, "mixed_attack_demo")
        self.assertEqual(scenario.scenario_type, "mixed_attack")
        self.assertEqual(scenario.mix_mode, "multi_uav_multi_attack")

        uav_01_active = scenario.get_active_attacks(28.0, "uav_01", "cruise")
        self.assertEqual(len(uav_01_active), 1)
        self.assertEqual(uav_01_active[0].attack_types, ("flood", "scan"))
        self.assertEqual(uav_01_active[0].replay_mode, "loop")

        self.assertEqual(get_active_attacks(32.0, "uav_03", "hover", scenario_config=scenario), [])
        uav_03_active = get_active_attacks(32.0, "uav_03", "cruise", scenario_config=scenario)
        self.assertEqual(len(uav_03_active), 1)
        self.assertEqual(uav_03_active[0].attack_types, ("scan",))

    def test_single_uav_multi_attack_mode_accepts_multi_attack_event(self):
        scenario = ScenarioConfig(
            name="single_uav_mix",
            scenario_type="mixed_attack",
            mix_mode="single_uav_multi_attack",
            attack_events=(
                AttackEvent(
                    uav_id="uav_01",
                    source_dataset="UAV-NDD",
                    attack_types="DoS + Scan",
                    start_time=5.0,
                    duration=10.0,
                    intensity=0.8,
                    replay_mode="loop",
                    mission_phase_constraint=["cruise", "hover"],
                    is_ood=True,
                ),
            ),
        )

        active = scenario.get_active_attacks(8.0, "uav_01", "hover")
        self.assertEqual(len(active), 1)
        self.assertEqual(active[0].attack_types, ("flood", "scan"))
        self.assertTrue(active[0].is_ood)

    def test_attack_event_accepts_extended_dataset_aliases(self):
        unsw = AttackEvent(
            uav_id="uav_05",
            source_dataset="UNSW-NB15",
            attack_types="scan",
            start_time=1.0,
            duration=2.0,
            intensity=0.6,
        )
        ecu = AttackEvent(
            uav_id="uav_06",
            source_dataset="ECU-IoFT-main",
            attack_types="command_injection",
            start_time=1.0,
            duration=2.0,
            intensity=0.6,
        )
        uavids = AttackEvent(
            uav_id="uav_07",
            source_dataset="UAVIDS",
            attack_types="flood",
            start_time=1.0,
            duration=2.0,
            intensity=0.6,
        )

        self.assertEqual(unsw.source_dataset, "unsw_nb15")
        self.assertEqual(ecu.source_dataset, "ecu_ioft")
        self.assertEqual(uavids.source_dataset, "uavids")
        self.assertEqual(unsw.source_type, "external_non_uav")
        self.assertEqual(unsw.simulation_role, "external_ood")
        self.assertIn("not real UAV flight", unsw.source_note)
        self.assertEqual(ecu.source_type, "uav_iot_wifi")
        self.assertEqual(ecu.simulation_role, "uav_replay")
        self.assertEqual(uavids.source_type, "uav")
        self.assertEqual(uavids.simulation_role, "uav_replay")

    def test_new_scenario_yaml_events_include_required_fields_without_uav04(self):
        for relative_path in NEW_SCENARIO_PATHS:
            with self.subTest(path=relative_path):
                raw = yaml.safe_load((ROOT / relative_path).read_text(encoding="utf-8"))
                self.assertIsInstance(raw, dict)
                self.assertIn("attack_events", raw)
                for event in raw["attack_events"]:
                    self.assertTrue(REQUIRED_ATTACK_EVENT_FIELDS.issubset(event.keys()))
                    self.assertNotEqual(event["uav_id"], "uav_04")

    def test_load_new_single_attack_scenarios_for_uav05_uav06_uav07(self):
        cases = (
            (
                "configs/scenarios/single_attack_uav05_unsw.yaml",
                "uav_05",
                "unsw_nb15",
                "external_non_uav",
                ("scan",),
            ),
            (
                "configs/scenarios/single_attack_uav06_ecu_ioft.yaml",
                "uav_06",
                "ecu_ioft",
                "uav_iot_wifi",
                ("command_injection",),
            ),
            (
                "configs/scenarios/single_attack_uav07_uavids.yaml",
                "uav_07",
                "uavids",
                "uav",
                ("command_injection",),
            ),
        )
        for relative_path, expected_uav, expected_dataset, expected_source_type, expected_attack_types in cases:
            with self.subTest(path=relative_path):
                scenario = load_scenario_from_yaml(relative_path, set_as_active=False)
                self.assertEqual(scenario.scenario_type, "single_attack")
                self.assertEqual(len(scenario.attack_events), 1)
                event = scenario.attack_events[0]
                self.assertEqual(event.uav_id, expected_uav)
                self.assertEqual(event.source_dataset, expected_dataset)
                self.assertEqual(event.source_type, expected_source_type)
                self.assertEqual(event.attack_types, expected_attack_types)
                self.assertTrue(event.is_ood)

    def test_mixed_attack_6datasets_covers_expected_uavs_and_datasets(self):
        scenario = load_scenario_from_yaml("configs/scenarios/mixed_attack_6datasets.yaml", set_as_active=False)

        self.assertEqual(scenario.scenario_type, "mixed_attack")
        self.assertEqual(scenario.mix_mode, "multi_uav_multi_attack")
        self.assertEqual(len(scenario.attack_events), 6)

        by_uav = {event.uav_id: event for event in scenario.attack_events}
        self.assertEqual(set(by_uav), {"uav_01", "uav_02", "uav_03", "uav_05", "uav_06", "uav_07"})
        self.assertNotIn("uav_04", by_uav)
        self.assertEqual(by_uav["uav_01"].source_dataset, "uav_ndd")
        self.assertEqual(by_uav["uav_02"].source_dataset, "gcs_to_uav_updated")
        self.assertEqual(by_uav["uav_03"].source_dataset, "isot_drone")
        self.assertEqual(by_uav["uav_05"].source_dataset, "unsw_nb15")
        self.assertEqual(by_uav["uav_05"].source_type, "external_non_uav")
        self.assertEqual(by_uav["uav_06"].source_dataset, "ecu_ioft")
        self.assertEqual(by_uav["uav_06"].source_type, "uav_iot_wifi")
        self.assertEqual(by_uav["uav_07"].source_dataset, "uavids")

    def test_external_ood_unsw_demo_uses_unsw_as_external_ood_source(self):
        scenario = load_scenario_from_yaml("configs/scenarios/external_ood_unsw_demo.yaml", set_as_active=False)

        self.assertEqual(scenario.scenario_type, "single_attack")
        self.assertEqual(len(scenario.attack_events), 1)
        event = scenario.attack_events[0]
        self.assertEqual(event.uav_id, "uav_05")
        self.assertEqual(event.source_dataset, "unsw_nb15")
        self.assertEqual(event.source_type, "external_non_uav")
        self.assertEqual(event.simulation_role, "external_ood")
        self.assertEqual(event.attack_types, ("scan",))
        self.assertTrue(event.is_ood)


if __name__ == "__main__":
    unittest.main()
