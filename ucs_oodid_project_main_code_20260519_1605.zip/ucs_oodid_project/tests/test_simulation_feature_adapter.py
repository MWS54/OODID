from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

import numpy as np
import pandas as pd

from ucs_oodid.io import save_json
from ucs_oodid.preprocessing import MetadataPreprocessor
from ucs_oodid.realtime.simulation_feature_adapter import SimulationFeatureAdapter


class SimulationFeatureAdapterTests(unittest.TestCase):
    def test_adapter_uses_feature_whitelist_order_and_drops_extra_columns(self):
        train_df = pd.DataFrame(
            [
                {"feat_a": 1.0, "feat_b": 10.0, "label": "benign", "timestamp": 0.0, "record_id": "r0"},
                {"feat_a": 2.0, "feat_b": 20.0, "label": "benign", "timestamp": 1.0, "record_id": "r1"},
                {"feat_a": 3.0, "feat_b": 30.0, "label": "benign", "timestamp": 2.0, "record_id": "r2"},
            ]
        )
        pre = MetadataPreprocessor(label_col="label", timestamp_col="timestamp", record_id_col="record_id")
        pre.fit(train_df, feature_cols=["feat_b", "feat_a"])
        artifact = {
            "feature_cols": ["feat_a", "feat_b"],
            "global_scaler": pre.scaler,
            "normalization_mode": "global",
            "model_config": {"input_dim": 2},
        }

        with tempfile.TemporaryDirectory() as tmp_dir:
            artifact_path = Path(tmp_dir) / "artifact.pt"
            artifact_path.write_bytes(b"placeholder")
            save_json(["feat_b", "feat_a"], Path(tmp_dir) / "feature_columns.json")
            adapter = SimulationFeatureAdapter(artifact, artifact_path=artifact_path)
            transformed = adapter.transform(
                pd.DataFrame(
                    [
                        {
                            "feat_a": 4.0,
                            "mission_phase": "cruise",
                            "feat_b": 40.0,
                            "sim_battery_soc": 88.0,
                            "dataset_name": "uav_ndd",
                        }
                    ]
                )
            )

        expected = pre.scaler.transform(np.asarray([[40.0, 4.0]], dtype=np.float32))
        self.assertEqual(transformed.shape, (1, 2))
        self.assertTrue(np.allclose(transformed, expected.astype(np.float32)))
        diagnostics = adapter.diagnostics()
        self.assertEqual(diagnostics["model_input_columns"], ["feat_b", "feat_a"])
        self.assertEqual(diagnostics["missing_model_features"], [])
        self.assertIn("mission_phase", diagnostics["extra_simulation_columns"])
        self.assertIn("sim_battery_soc", diagnostics["dropped_simulation_columns"])

    def test_adapter_fills_missing_features_with_zero(self):
        train_df = pd.DataFrame(
            [
                {"feat_a": 1.0, "feat_b": 5.0, "label": "benign", "timestamp": 0.0, "record_id": "r0"},
                {"feat_a": 2.0, "feat_b": 6.0, "label": "benign", "timestamp": 1.0, "record_id": "r1"},
            ]
        )
        pre = MetadataPreprocessor(label_col="label", timestamp_col="timestamp", record_id_col="record_id")
        pre.fit(train_df, feature_cols=["feat_a", "feat_b"])
        adapter = SimulationFeatureAdapter(
            {
                "feature_cols": ["feat_a", "feat_b"],
                "global_scaler": pre.scaler,
                "normalization_mode": "global",
            }
        )

        transformed = adapter.transform(pd.DataFrame([{"feat_a": 3.0, "extra_numeric": 99.0}]))
        expected = pre.scaler.transform(np.asarray([[3.0, 0.0]], dtype=np.float32))
        self.assertTrue(np.allclose(transformed, expected.astype(np.float32)))
        self.assertEqual(adapter.last_transform_summary["missing_model_features"], ["feat_b"])
        self.assertIn("extra_numeric", adapter.last_transform_summary["extra_simulation_columns"])

    def test_adapter_rejects_forbidden_simulation_model_columns_in_strict_mode(self):
        with self.assertRaises(ValueError):
            SimulationFeatureAdapter(
                {
                    "feature_cols": ["mission_phase", "feat_a"],
                    "global_scaler": None,
                    "normalization_mode": "global",
                }
            )

        with self.assertRaises(ValueError):
            SimulationFeatureAdapter(
                {
                    "feature_cols": ["source_missing", "feat_a"],
                    "global_scaler": None,
                    "normalization_mode": "global",
                }
            )


if __name__ == "__main__":
    unittest.main()
