from __future__ import annotations

import csv
import tempfile
import random
import unittest
import warnings
from pathlib import Path

import pandas as pd

from ucs_oodid.simulator.attacks import AttackEvent, AttackInjector, build_attack_snapshot
from ucs_oodid.simulator.channel import LinkState, simulate_link_state
from ucs_oodid.simulator.attack_replay import AttackReplayPool
from ucs_oodid.simulator.engine import PureIDSCsvReplayCursor, SimulationConfig, SimulationEngine
from ucs_oodid.simulator.energy import estimate_step_energy
from ucs_oodid.simulator.entities import Attacker, GCS, UAV
from ucs_oodid.simulator.scenario import AttackEvent as ScenarioAttackEvent
from ucs_oodid.simulator.mission import update_uav_mission
from ucs_oodid.simulator.scenario import ScenarioConfig
from ucs_oodid.simulator.scenario import build_attack_injector as build_scenario_attack_injector
from ucs_oodid.simulator.scenario import build_fleet, build_fleet_preview_rows
from ucs_oodid.simulator.demo_config import default_demo_scene_config_path, load_demo_scene_config
from ucs_oodid.io import load_json, read_jsonl


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    pd.DataFrame(rows).to_csv(path, index=False)


def build_replay_dataset_paths(tmp_path: Path) -> dict[str, Path]:
    uav_ndd_path = tmp_path / "uav_ndd.csv"
    gcs_path = tmp_path / "gcs_to_uav.csv"
    isot_path = tmp_path / "isot.csv"
    write_csv(
        uav_ndd_path,
        [
            {"feature": 1.0, "label": "benign", "timestamp": 0.0, "record_id": "b0"},
            {"feature": 2.0, "label": "benign", "timestamp": 1.0, "record_id": "b1"},
            {"feature": 10.0, "label": "jamming", "timestamp": 2.0, "record_id": "a0"},
        ],
    )
    write_csv(
        gcs_path,
        [
            {"feature": 21.0, "label": "benign", "timestamp": 0.0, "record_id": "g_b0"},
            {"feature": 22.0, "label": "reply", "timestamp": 1.0, "record_id": "g_a0"},
        ],
    )
    write_csv(
        isot_path,
        [
            {"feature": 31.0, "label": "injection", "timestamp": 0.0, "record_id": "i0"},
        ],
    )
    return {
        "uav_ndd": uav_ndd_path,
        "gcs_to_uav_updated": gcs_path,
        "isot_drone": isot_path,
    }


def build_extended_replay_dataset_paths(tmp_path: Path) -> dict[str, Path]:
    unsw_path = tmp_path / "unsw.csv"
    ecu_path = tmp_path / "ecu.csv"
    uavids_path = tmp_path / "uavids.csv"
    write_csv(
        unsw_path,
        [
            {"feature": 1.0, "label": "benign", "timestamp": 0.0, "record_id": "u05_b0"},
            {"feature": 2.0, "label": "analysis", "timestamp": 1.0, "record_id": "u05_a0"},
            {"feature": 3.0, "label": "backdoor", "timestamp": 2.0, "record_id": "u05_a1"},
        ],
    )
    write_csv(
        ecu_path,
        [
            {"feature": 4.0, "label": "benign", "timestamp": 0.0, "record_id": "u06_b0"},
            {"feature": 5.0, "label": "unauthorized_udp", "timestamp": 1.0, "record_id": "u06_a0"},
        ],
    )
    write_csv(
        uavids_path,
        [
            {"feature": 6.0, "label": "benign", "timestamp": 0.0, "record_id": "u07_b0"},
            {"feature": 7.0, "label": "wormhole", "timestamp": 1.0, "record_id": "u07_a0"},
        ],
    )
    return {
        "unsw_nb15": unsw_path,
        "ecu_ioft": ecu_path,
        "uavids": uavids_path,
    }


class SimulatorCoreTests(unittest.TestCase):
    def test_mission_state_machine_visits_expected_phases(self):
        uav = UAV(
            uav_id="uav_test",
            route_length_m=10.0,
            hover_duration_s=2.0,
            cruise_altitude_m=20.0,
            cruise_speed_mps=5.0,
        )

        visited: set[str] = {uav.mission_phase}
        for step in range(30):
            update_uav_mission(uav, dt_s=1.0, sim_time_s=float(step))
            visited.add(uav.mission_phase)

        self.assertTrue({"idle", "takeoff", "climb", "cruise", "hover", "return_home", "land"}.issubset(visited))
        self.assertTrue(uav.mission_completed)
        self.assertEqual(uav.mission_phase, "idle")

    def test_jamming_proxy_degrades_link_quality(self):
        uav = UAV(uav_id="uav_link", x_m=500.0, altitude_m=100.0, mission_phase="cruise")
        gcs = GCS()
        attacker = Attacker(x_m=520.0, y_m=40.0)
        benign = simulate_link_state(uav, gcs, attack=build_attack_snapshot("benign"), rng=random.Random(7))
        jammed = simulate_link_state(
            uav,
            gcs,
            attack=build_attack_snapshot("jamming_proxy", intensity=1.0),
            attacker=attacker,
            rng=random.Random(7),
        )

        self.assertLess(jammed.snr_db, benign.snr_db)
        self.assertGreater(jammed.latency_ms, benign.latency_ms)
        self.assertGreater(jammed.loss_rate, benign.loss_rate)

    def test_default_scenario_assigns_distinct_mission_contexts(self):
        config = {
            "uav_count": 3,
            "route_length_m": 600.0,
            "hover_duration_s": 10.0,
            "cruise_altitude_m": 90.0,
            "cruise_speed_mps": 17.0,
            "battery_capacity_wh": 180.0,
            "start_spacing_s": 3.0,
            "scenario_profile_path": "configs/simulator_default.yaml",
        }

        uavs = build_fleet(config)

        self.assertEqual([uav.mission_context for uav in uavs], ["surveillance", "delivery", "inspection"])
        self.assertGreater(uavs[0].route_length_m, uavs[1].route_length_m)
        self.assertGreater(uavs[2].metadata["inspection_lateral_wave_m"], 0.0)
        self.assertGreater(uavs[1].metadata["payload_power_factor"], 1.0)

    def test_environmental_factors_are_exposed_in_link_state(self):
        uav = UAV(
            uav_id="uav_env",
            mission_context="inspection",
            mission_phase="hover",
            altitude_m=20.0,
            x_m=120.0,
            y_m=10.0,
        )
        uav.metadata["scenario_profile_path"] = "configs/simulator_default.yaml"
        uav.metadata["wind_sensitivity"] = 1.0
        uav.metadata["obstacle_sensitivity"] = 1.0
        uav.metadata["wind_bias"] = 0.08
        uav.metadata["obstacle_bias"] = 0.12
        link = simulate_link_state(uav, GCS(), attack=build_attack_snapshot("benign"), rng=random.Random(17))

        self.assertGreater(link.distance_to_gcs, 0.0)
        self.assertGreater(link.wind_level, 0.0)
        self.assertGreater(link.obstacle_factor, 0.0)
        self.assertLess(link.rssi_dbm, 0.0)

    def test_attack_injector_uses_schedule(self):
        injector = AttackInjector(
            [
                AttackEvent(start_s=5.0, end_s=10.0, attack_type="scan", intensity=0.5),
                AttackEvent(start_s=10.0, end_s=15.0, attack_type="flood", intensity=1.0),
            ]
        )

        self.assertEqual(injector.snapshot_at(0.0).attack_type, "benign")
        mid_scan = injector.snapshot_at(7.0)
        mid_flood = injector.snapshot_at(12.0)

        self.assertTrue(mid_scan.active)
        self.assertEqual(mid_scan.attack_type, "scan")
        self.assertEqual(mid_flood.attack_type, "flood")
        self.assertAlmostEqual(mid_flood.intensity, 1.0)

    def test_build_attack_snapshot_accepts_reply_alias(self):
        snapshot = build_attack_snapshot("reply", intensity=0.5)

        self.assertTrue(snapshot.active)
        self.assertEqual(snapshot.attack_type, "replay")
        self.assertAlmostEqual(snapshot.intensity, 0.5)

    def test_energy_breakdown_total_matches_components(self):
        uav = UAV(uav_id="uav_energy", mission_phase="cruise", speed_mps=15.0, altitude_m=80.0)
        link = LinkState(distance_m=420.0, rssi_dbm=-61.0, snr_db=18.0, latency_ms=18.0, loss_rate=0.03)
        attack = build_attack_snapshot("flood", intensity=0.5)

        breakdown = estimate_step_energy(
            dt_s=1.0,
            uav=uav,
            link=link,
            bytes_up=4000,
            bytes_down=3000,
            attack=attack,
        )

        self.assertGreater(breakdown.flight_wh, 0.0)
        self.assertGreater(breakdown.communication_wh, 0.0)
        self.assertGreater(breakdown.detection_wh, 0.0)
        self.assertGreater(breakdown.cpu_load, 0.0)
        self.assertGreater(breakdown.board_temperature_c, 0.0)
        self.assertAlmostEqual(
            breakdown.total_wh,
            breakdown.flight_wh + breakdown.communication_wh + breakdown.detection_wh,
        )

    def test_engine_generates_required_record_fields(self):
        uav = UAV(
            uav_id="uav_engine",
            route_length_m=20.0,
            hover_duration_s=1.0,
            cruise_altitude_m=18.0,
            cruise_speed_mps=6.0,
        )
        gcs = GCS()
        attacker = Attacker()
        injector = AttackInjector(
            [
                AttackEvent(start_s=5.0, end_s=7.0, attack_type="command_injection", intensity=1.0),
            ]
        )
        engine = SimulationEngine(
            uavs=[uav],
            gcs=gcs,
            attacker=attacker,
            attack_injector=injector,
            config=SimulationConfig(duration_s=8.0, dt_s=1.0, seed=3),
        )

        result = engine.run()

        self.assertEqual(len(result.records), 8)
        self.assertGreater(result.attack_record_count, 0)
        self.assertTrue(any(record.mission_phase == "emergency" for record in result.records))
        first_record = result.records[0].to_dict()
        required_fields = {
            "timestamp",
            "sim_time",
            "uav_id",
            "dataset_name",
            "source_type",
            "mission_phase",
            "battery_soc",
            "speed",
            "altitude",
            "rssi",
            "snr",
            "latency_ms",
            "loss_rate",
            "distance_to_gcs",
            "wind_level",
            "obstacle_factor",
            "bytes_up",
            "bytes_down",
            "attack_active",
            "attack_type",
            "gt_attack_active",
            "gt_attack_type",
            "sim_source",
            "mission_context",
            "cpu_load",
            "board_temperature_c",
            "response_action",
            "response_time",
            "response_reason",
        }
        self.assertTrue(required_fields.issubset(first_record.keys()))
        self.assertEqual(first_record["dataset_name"], "simulator")
        self.assertEqual(first_record["source_type"], "simulator")
        self.assertEqual(first_record["simulation_role"], "simulator_synthetic")

    def test_engine_uses_scenario_config_to_mix_benign_and_attack_replay_rows(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            pool = AttackReplayPool(
                dataset_paths=build_replay_dataset_paths(Path(tmp_dir)),
                uav_dataset_bindings={"uav_01": "uav_ndd"},
                seed=23,
            )
            scenario = ScenarioConfig(
                name="scenario_mix",
                scenario_type="single_attack",
                attack_events=(
                    ScenarioAttackEvent(
                        uav_id="uav_01",
                        source_dataset="gcs_to_uav_updated",
                        attack_types="replay",
                        start_time=1.0,
                        duration=1.0,
                        intensity=1.0,
                        replay_mode="sequential",
                    ),
                ),
            )
            uav = UAV(
                uav_id="uav_01",
                route_length_m=12.0,
                hover_duration_s=1.0,
                cruise_altitude_m=18.0,
                cruise_speed_mps=5.0,
            )
            engine = SimulationEngine(
                uavs=[uav],
                gcs=GCS(),
                attacker=Attacker(),
                attack_injector=AttackInjector(),
                attack_replay_pool=pool,
                scenario_config=scenario,
                config=SimulationConfig(duration_s=3.0, dt_s=1.0, seed=23),
            )

            result = engine.run()

        self.assertEqual(len(result.records), 3)
        rows = [record.to_dict() for record in result.records]
        self.assertEqual(rows[0]["sim_source"], "benign_replay")
        self.assertFalse(rows[0]["gt_attack_active"])
        self.assertEqual(rows[0]["dataset_name"], "uav_ndd")
        self.assertEqual(rows[1]["sim_source"], "attack_replay")
        self.assertTrue(rows[1]["gt_attack_active"])
        self.assertEqual(rows[1]["gt_attack_type"], "replay")
        self.assertEqual(rows[1]["dataset_name"], "gcs_to_uav_updated")
        self.assertEqual(rows[1]["attack_source_dataset"], "gcs_to_uav_updated")
        self.assertEqual(rows[1]["source_type"], "uav")
        self.assertTrue(str(rows[1]["record_id"]).startswith("uav_01:1.000000:"))
        self.assertEqual(rows[2]["sim_source"], "benign_replay")
        self.assertFalse(rows[2]["gt_attack_active"])

    def test_engine_supports_extended_mixed_attack_replay_and_dataset_detection_summary(self):
        class StubOnlineDetector:
            def consume_records(self, records):
                rows = []
                for idx, record in enumerate(records):
                    payload = record.to_dict()
                    rows.append(
                        {
                            "window_id": idx,
                            "group_id": record.uav_id,
                            "record_ids": [str(payload.get("record_id", f"{record.uav_id}:{record.timestamp:.1f}"))],
                            "simulation_time_s": float(payload.get("sim_time", record.timestamp)),
                            "known_pred_labels": [str(payload.get("gt_attack_type", "benign"))],
                            "ood_score": 0.95 if bool(payload.get("gt_attack_active", False)) else 0.05,
                            "ood_threshold": 0.4,
                            "is_ood": bool(payload.get("gt_attack_active", False)),
                            "alert_level": "warning" if bool(payload.get("gt_attack_active", False)) else "normal",
                            "has_alert": bool(payload.get("gt_attack_active", False)),
                            "top_suspicious_records": [],
                            "ground_truth": {
                                "attack_active": bool(payload.get("gt_attack_active", False)),
                                "attack_types": []
                                if not bool(payload.get("gt_attack_active", False))
                                else [str(payload.get("gt_attack_type", "benign"))],
                            },
                        }
                    )
                return rows

            def simulation_diagnostics(self):
                return {
                    "model_input_columns": ["feat_a", "feat_b"],
                    "dropped_simulation_columns": ["sim_mission_phase", "sim_rssi"],
                    "missing_model_features": ["feat_b"],
                    "extra_simulation_columns": ["dataset_name", "sim_mission_phase"],
                    "per_uav_missing_feature_ratio": {"uav_01": 0.25},
                    "per_uav_zero_feature_ratio": {"uav_01": 0.5},
                    "per_uav_input_mean": {"uav_01": 0.15},
                    "per_uav_input_std": {"uav_01": 0.07},
                    "score_mode": "normalized",
                    "threshold_mode": "per_uav_benign_warmup_raw_quantile",
                    "score_direction": "higher_is_more_anomalous",
                    "normalized_threshold": 1.5,
                    "per_uav_threshold": {"uav_01": 0.45},
                    "per_uav_raw_threshold": {"uav_01": 0.45},
                    "per_uav_normalized_threshold": {"uav_01": 1.5},
                    "per_uav_threshold_source": {"uav_01": "warmup_quantile"},
                    "per_uav_id_score_mean": {"uav_01": 0.12},
                    "per_uav_id_score_median": {"uav_01": 0.11},
                    "per_uav_benign_score_q50": {"uav_01": 0.10},
                    "per_uav_benign_score_q90": {"uav_01": 0.14},
                    "per_uav_benign_score_q95": {"uav_01": 0.15},
                    "per_uav_benign_score_q99": {"uav_01": 0.16},
                    "per_uav_raw_score_q50": {"uav_01": 0.20},
                    "per_uav_raw_score_q90": {"uav_01": 0.45},
                    "per_uav_raw_score_q95": {"uav_01": 0.55},
                    "per_uav_raw_score_q99": {"uav_01": 0.70},
                    "per_uav_normalized_score_q50": {"uav_01": 0.12},
                    "per_uav_normalized_score_q90": {"uav_01": 0.44},
                    "per_uav_normalized_score_q95": {"uav_01": 0.60},
                    "per_uav_normalized_score_q99": {"uav_01": 0.82},
                    "per_uav_raw_ood_score_mean": {"uav_01": 0.33},
                    "per_uav_normalized_ood_score_mean": {"uav_01": 0.44},
                    "per_uav_score_unique_count": {"uav_01": 2},
                    "per_uav_inference_error_count": {"uav_01": 1},
                    "per_window_raw_ood_score": [{"window_id": 0, "group_id": "uav_01", "raw_ood_score": 0.1, "inference_error": False}],
                    "per_window_normalized_ood_score": [
                        {"window_id": 0, "group_id": "uav_01", "normalized_ood_score": 0.1, "inference_error": False}
                    ],
                    "inference_error_count": 1,
                    "fallback_score_used_count": 0,
                    "feature_adapter_enabled": True,
                    "strict_model_feature_mode": True,
                    "feature_columns_source": "artifact.feature_cols",
                    "threshold_quantile": 0.95,
                }

            def simulation_diagnostics(self):
                return {
                    "model_input_columns": ["feat_a", "feat_b"],
                    "dropped_simulation_columns": ["sim_mission_phase", "sim_rssi"],
                    "missing_model_features": ["feat_b"],
                    "extra_simulation_columns": ["dataset_name", "sim_mission_phase"],
                    "per_uav_missing_feature_ratio": {"uav_01": 0.25},
                    "per_uav_zero_feature_ratio": {"uav_01": 0.5},
                    "per_uav_input_mean": {"uav_01": 0.15},
                    "per_uav_input_std": {"uav_01": 0.07},
                    "score_mode": "normalized",
                    "threshold_mode": "per_uav_benign_warmup_raw_quantile",
                    "score_direction": "higher_is_more_anomalous",
                    "normalized_threshold": 1.5,
                    "per_uav_threshold": {"uav_01": 0.45},
                    "per_uav_raw_threshold": {"uav_01": 0.45},
                    "per_uav_normalized_threshold": {"uav_01": 1.5},
                    "per_uav_threshold_source": {"uav_01": "warmup_quantile"},
                    "per_uav_id_score_mean": {"uav_01": 0.12},
                    "per_uav_id_score_median": {"uav_01": 0.11},
                    "per_uav_benign_score_q50": {"uav_01": 0.10},
                    "per_uav_benign_score_q90": {"uav_01": 0.14},
                    "per_uav_benign_score_q95": {"uav_01": 0.15},
                    "per_uav_benign_score_q99": {"uav_01": 0.16},
                    "per_uav_raw_score_q50": {"uav_01": 0.20},
                    "per_uav_raw_score_q90": {"uav_01": 0.45},
                    "per_uav_raw_score_q95": {"uav_01": 0.55},
                    "per_uav_raw_score_q99": {"uav_01": 0.70},
                    "per_uav_normalized_score_q50": {"uav_01": 0.12},
                    "per_uav_normalized_score_q90": {"uav_01": 0.44},
                    "per_uav_normalized_score_q95": {"uav_01": 0.60},
                    "per_uav_normalized_score_q99": {"uav_01": 0.82},
                    "per_uav_raw_ood_score_mean": {"uav_01": 0.33},
                    "per_uav_normalized_ood_score_mean": {"uav_01": 0.44},
                    "per_uav_score_unique_count": {"uav_01": 2},
                    "per_uav_inference_error_count": {"uav_01": 1},
                    "per_window_raw_ood_score": [{"window_id": 0, "group_id": "uav_01", "raw_ood_score": 0.1, "inference_error": False}],
                    "per_window_normalized_ood_score": [
                        {"window_id": 0, "group_id": "uav_01", "normalized_ood_score": 0.1, "inference_error": False}
                    ],
                    "inference_error_count": 1,
                    "fallback_score_used_count": 0,
                    "feature_adapter_enabled": True,
                    "strict_model_feature_mode": True,
                    "feature_columns_source": "artifact.feature_cols",
                    "threshold_quantile": 0.95,
                }

        with tempfile.TemporaryDirectory() as tmp_dir:
            output_dir = Path(tmp_dir) / "exports"
            pool = AttackReplayPool(
                dataset_paths=build_extended_replay_dataset_paths(Path(tmp_dir)),
                uav_dataset_bindings={"uav_05": "unsw_nb15", "uav_06": "ecu_ioft", "uav_07": "uavids"},
                seed=31,
            )
            scenario = ScenarioConfig(
                name="extended_mix",
                scenario_type="mixed_attack",
                mix_mode="multi_uav_multi_attack",
                attack_events=(
                    ScenarioAttackEvent(
                        uav_id="uav_05",
                        source_dataset="UNSW-NB15",
                        attack_types="scan + command_injection",
                        start_time=0.0,
                        duration=2.0,
                        intensity=2.0,
                        replay_mode="loop",
                    ),
                    ScenarioAttackEvent(
                        uav_id="uav_06",
                        source_dataset="ECU-IoFT-main",
                        attack_types="command_injection",
                        start_time=0.0,
                        duration=2.0,
                        intensity=1.0,
                        replay_mode="loop",
                    ),
                ),
            )
            uavs = [
                UAV(uav_id="uav_05", route_length_m=12.0, hover_duration_s=1.0, cruise_altitude_m=18.0, cruise_speed_mps=5.0),
                UAV(uav_id="uav_06", route_length_m=12.0, hover_duration_s=1.0, cruise_altitude_m=18.0, cruise_speed_mps=5.0),
            ]
            engine = SimulationEngine(
                uavs=uavs,
                gcs=GCS(),
                attacker=Attacker(),
                attack_injector=AttackInjector(),
                attack_replay_pool=pool,
                scenario_config=scenario,
                online_detector=StubOnlineDetector(),
                config=SimulationConfig(
                    duration_s=2.0,
                    dt_s=1.0,
                    seed=31,
                    enable_online_detection=True,
                    output_dir=str(output_dir),
                ),
            )

            result = engine.run()
            summary = load_json(output_dir / "simulation_summary.json")

        rows = [record.to_dict() for record in result.records]
        required_fields = {
            "sim_time",
            "uav_id",
            "dataset_name",
            "source_type",
            "mission_phase",
            "sim_mission_phase",
            "battery_soc",
            "sim_battery_soc",
            "rssi",
            "sim_rssi",
            "snr",
            "latency_ms",
            "loss_rate",
            "attack_active",
            "attack_type",
            "gt_attack_active",
            "gt_attack_type",
            "sim_source",
        }
        self.assertTrue(all(required_fields.issubset(row.keys()) for row in rows))

        unsw_rows = [row for row in rows if row["uav_id"] == "uav_05"]
        ecu_rows = [row for row in rows if row["uav_id"] == "uav_06"]
        self.assertTrue(unsw_rows)
        self.assertTrue(ecu_rows)
        self.assertTrue(all(row["dataset_name"] == "unsw_nb15" for row in unsw_rows))
        self.assertTrue(all(row["source_type"] == "external_non_uav" for row in unsw_rows))
        self.assertTrue(all(row["simulation_role"] == "external_ood" for row in unsw_rows))
        self.assertTrue(all(bool(row["ground_truth_is_ood"]) for row in unsw_rows))
        self.assertTrue(all("not real UAV flight" in str(row.get("source_note", "")) for row in unsw_rows))
        self.assertTrue(all(row["dataset_name"] == "ecu_ioft" for row in ecu_rows))
        self.assertTrue(all(row["source_type"] == "uav_iot_wifi" for row in ecu_rows))
        self.assertTrue(all(not bool(row["ground_truth_is_ood"]) for row in ecu_rows))

        by_dataset = {row["dataset_name"]: row for row in summary["dataset_detection_stats"]}
        self.assertIn("unsw_nb15", by_dataset)
        self.assertIn("ecu_ioft", by_dataset)
        self.assertEqual(by_dataset["unsw_nb15"]["source_type"], "external_non_uav")
        self.assertEqual(by_dataset["unsw_nb15"]["simulation_role"], "external_ood")
        self.assertIn("not real UAV flight", by_dataset["unsw_nb15"]["source_note"])
        self.assertGreater(by_dataset["unsw_nb15"]["detection_count"], 0)
        self.assertGreater(by_dataset["unsw_nb15"]["detected_attack_window_count"], 0)
        self.assertEqual(by_dataset["ecu_ioft"]["source_type"], "uav_iot_wifi")
        self.assertGreater(by_dataset["ecu_ioft"]["attack_window_count"], 0)

    def test_engine_collects_online_detection_results_when_enabled(self):
        class StubOnlineDetector:
            def __init__(self):
                self.calls = 0

            def consume_records(self, records):
                rows = []
                for offset, record in enumerate(records):
                    rows.append(
                        {
                            "window_id": self.calls + offset,
                            "record_ids": [f"{record.uav_id}:{record.timestamp:.1f}"],
                            "known_pred_labels": ["benign"],
                            "known_pred_probs": {"benign": 0.95},
                            "ood_score": 1.2,
                            "ood_threshold": 0.5,
                            "is_ood": True,
                            "alert_level": "warning",
                            "top_suspicious_records": [],
                            "ground_truth": {"attack_active": bool(record.attack_active), "attack_types": []},
                        }
                    )
                self.calls += len(rows)
                return rows

        uav = UAV(uav_id="uav_online", route_length_m=12.0, hover_duration_s=1.0, cruise_altitude_m=15.0, cruise_speed_mps=5.0)
        engine = SimulationEngine(
            uavs=[uav],
            gcs=GCS(),
            attacker=Attacker(),
            attack_injector=AttackInjector(),
            config=SimulationConfig(duration_s=4.0, dt_s=1.0, seed=9, enable_online_detection=True),
            online_detector=StubOnlineDetector(),
        )

        result = engine.run()

        self.assertEqual(len(result.records), 4)
        self.assertEqual(len(result.online_detection_results), 4)
        self.assertTrue(all("simulation_step" in row for row in result.online_detection_results))
        self.assertTrue(all("simulation_time_s" in row for row in result.online_detection_results))
        self.assertTrue(all("alert_level" in row for row in result.online_detection_results))
        self.assertTrue(all("gt_attack_active" in row for row in result.online_detection_results))
        self.assertTrue(all("gt_attack_type" in row for row in result.online_detection_results))

    def test_pure_ids_csv_cursor_filters_splits_and_warns_on_partition_fallback(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            csv_path = Path(tmp_dir) / "pure_ids_partition_only.csv"
            write_csv(
                csv_path,
                [
                    {"uav_id": "uav_01", "recommended_partition": "id", "label": "scan", "record_id": "id_row"},
                    {"uav_id": "uav_01", "recommended_partition": "ood", "label": "wormhole", "record_id": "ood_row"},
                    {"uav_id": "uav_01", "recommended_partition": "train", "label": "benign", "record_id": "train_row"},
                ],
            )

            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter("always")
                cursor = PureIDSCsvReplayCursor(
                    csv_path=csv_path,
                    group_col="uav_id",
                    selected_uav_ids=["uav_01"],
                    split_filter=("test_id", "test_ood"),
                )

            self.assertTrue(any("recommended_partition" in str(item.message) for item in caught))
            self.assertEqual(cursor.total_rows_by_uav()["uav_01"], 2)

            id_rows, split_changed = cursor.next_rows("uav_01", 10)
            self.assertEqual([row["record_id"] for row in id_rows], ["id_row"])
            self.assertEqual([row["split"] for row in id_rows], ["test_id"])
            self.assertTrue(split_changed)

            cursor.acknowledge_split_change()
            ood_rows, split_changed = cursor.next_rows("uav_01", 10)
            self.assertEqual([row["record_id"] for row in ood_rows], ["ood_row"])
            self.assertEqual([row["split"] for row in ood_rows], ["test_ood"])
            self.assertFalse(split_changed)

    def test_engine_replays_pure_ids_csv_in_split_stages_and_resets_buffer(self):
        class ResetTrackingBuffer:
            def __init__(self):
                self.reset_count = 0

            def reset(self):
                self.reset_count += 1

        class SplitTrackingDetector:
            def __init__(self):
                self.buffer = ResetTrackingBuffer()
                self.class_to_idx = {"scan": 0, "replay": 1}
                self.step_splits: list[list[str]] = []

            def consume_records(self, records):
                self.step_splits.append([str(record.to_dict().get("split", "")) for record in records])
                rows = []
                for idx, record in enumerate(records):
                    payload = record.to_dict()
                    gt_is_ood = bool(payload.get("ground_truth_is_ood", False))
                    gt_attack_active = bool(payload.get("gt_attack_active", False))
                    rows.append(
                        {
                            "window_id": len(self.step_splits) * 100 + idx,
                            "group_id": record.uav_id,
                            "record_ids": [str(payload.get("record_id", f"{record.uav_id}:{record.timestamp:.1f}"))],
                            "known_pred_labels": [] if gt_is_ood or not gt_attack_active else [str(payload.get("gt_attack_type", "benign"))],
                            "known_attack_alert": bool(gt_attack_active and not gt_is_ood),
                            "known_attack_pred_labels": []
                            if gt_is_ood or not gt_attack_active
                            else [str(payload.get("gt_attack_type", "benign"))],
                            "ood_score": 0.95 if gt_is_ood else 0.15,
                            "ood_threshold": 0.5,
                            "is_ood": gt_is_ood,
                            "ood_alert": gt_is_ood,
                            "alert_level": "warning" if (gt_attack_active or gt_is_ood) else "normal",
                            "has_alert": bool(gt_attack_active or gt_is_ood),
                            "top_suspicious_records": [],
                            "ground_truth": {
                                "attack_active": gt_attack_active,
                                "attack_types": []
                                if not gt_attack_active
                                else [str(payload.get("gt_attack_type", "benign"))],
                                "is_ood": gt_is_ood,
                            },
                        }
                    )
                return rows

        with tempfile.TemporaryDirectory() as tmp_dir:
            csv_path = Path(tmp_dir) / "pure_ids_split.csv"
            write_csv(
                csv_path,
                [
                    {"uav_id": "uav_01", "split": "test_id", "label": "benign", "record_id": "u1_id_0"},
                    {"uav_id": "uav_01", "split": "test_ood", "label": "wormhole", "record_id": "u1_ood_0"},
                    {"uav_id": "uav_02", "split": "test_id", "label": "scan", "record_id": "u2_id_0"},
                    {"uav_id": "uav_02", "split": "test_id", "label": "replay", "record_id": "u2_id_1"},
                    {"uav_id": "uav_02", "split": "test_ood", "label": "backdoor", "record_id": "u2_ood_0"},
                    {"uav_id": "uav_02", "split": "train", "label": "benign", "record_id": "u2_train_0"},
                ],
            )

            detector = SplitTrackingDetector()
            engine = SimulationEngine(
                uavs=[
                    UAV(uav_id="uav_01", route_length_m=12.0, hover_duration_s=1.0, cruise_altitude_m=15.0, cruise_speed_mps=5.0),
                    UAV(uav_id="uav_02", route_length_m=12.0, hover_duration_s=1.0, cruise_altitude_m=15.0, cruise_speed_mps=5.0),
                ],
                gcs=GCS(),
                attacker=Attacker(),
                attack_injector=AttackInjector(),
                config=SimulationConfig(
                    duration_s=10.0,
                    dt_s=1.0,
                    seed=31,
                    enable_online_detection=True,
                    dataset_replay_mode="pure_ids_csv",
                    pure_ids_csv_path=str(csv_path),
                    pure_ids_group_col="uav_id",
                    pure_ids_replay_records_per_uav_per_step=1,
                    pure_ids_replay_split_filter=("test_id", "test_ood"),
                    pure_ids_replay_reset_buffer_on_split_change=True,
                ),
                online_detector=detector,
            )

            result = engine.run()

        record_splits = [str(record.to_dict().get("split", "")) for record in result.records]
        self.assertEqual(record_splits, ["test_id", "test_id", "test_id", "test_ood", "test_ood"])
        self.assertEqual(detector.step_splits, [["test_id", "test_id"], ["test_id"], ["test_ood", "test_ood"]])
        self.assertEqual(detector.buffer.reset_count, 1)
        self.assertEqual(result.diagnostics["pure_ids_split_source_column"], "split")
        self.assertEqual(result.diagnostics["pure_ids_total_rows_by_uav"], {"uav_01": 2, "uav_02": 3})

    def test_pure_ids_truth_from_payload_prioritizes_explicit_flags_then_split_fields(self):
        class StubDetector:
            class_to_idx = {"scan": 0, "replay": 1}

        engine = SimulationEngine(
            uavs=[UAV(uav_id="uav_01", route_length_m=12.0, hover_duration_s=1.0, cruise_altitude_m=15.0, cruise_speed_mps=5.0)],
            gcs=GCS(),
            attacker=Attacker(),
            attack_injector=AttackInjector(),
            config=SimulationConfig(duration_s=1.0, dt_s=1.0, seed=3),
            online_detector=StubDetector(),
        )

        truth = engine._pure_ids_truth_from_payload(
            {
                "label": "wormhole",
                "ground_truth_is_ood": False,
                "is_ood": True,
                "split": "test_ood",
                "recommended_partition": "ood",
            }
        )
        self.assertFalse(bool(truth["ground_truth_is_ood"]))

        truth = engine._pure_ids_truth_from_payload({"label": "scan", "is_ood": True})
        self.assertTrue(bool(truth["ground_truth_is_ood"]))

        truth = engine._pure_ids_truth_from_payload({"label": "normal", "split": "test_ood"})
        self.assertTrue(bool(truth["ground_truth_is_ood"]))
        self.assertFalse(bool(truth["attack_active"]))

        truth = engine._pure_ids_truth_from_payload({"label": "scan", "recommended_partition": "ood"})
        self.assertTrue(bool(truth["ground_truth_is_ood"]))

        truth = engine._pure_ids_truth_from_payload({"label": "wormhole"})
        self.assertTrue(bool(truth["ground_truth_is_ood"]))

    def test_engine_exports_required_simulation_artifacts(self):
        class StubOnlineDetector:
            def consume_records(self, records):
                rows = []
                for idx, record in enumerate(records):
                    payload = record.to_dict()
                    record_id = str(payload.get("record_id", f"{record.uav_id}:{record.timestamp:.1f}"))
                    rows.append(
                        {
                            "window_id": idx,
                            "group_id": record.uav_id,
                            "record_ids": [record_id],
                            "known_pred_labels": ["replay"] if record.attack_active else ["benign"],
                            "ood_score": 0.9 if record.attack_active else 0.1,
                            "ood_threshold": 0.4,
                            "is_ood": bool(record.attack_active),
                            "alert_level": "warning" if record.attack_active else "normal",
                            "top_suspicious_records": [{"record_id": record_id, "score": 0.9}],
                            "ground_truth": {
                                "attack_active": bool(record.attack_active),
                                "attack_types": [] if not record.attack_active else [record.attack_type],
                            },
                        }
                    )
                return rows

            def simulation_diagnostics(self):
                return {
                    "model_input_columns": ["feat_a", "feat_b"],
                    "dropped_simulation_columns": ["sim_mission_phase", "sim_rssi"],
                    "missing_model_features": ["feat_b"],
                    "extra_simulation_columns": ["dataset_name", "sim_mission_phase"],
                    "per_uav_missing_feature_ratio": {"uav_01": 0.25},
                    "per_uav_zero_feature_ratio": {"uav_01": 0.5},
                    "per_uav_input_mean": {"uav_01": 0.15},
                    "per_uav_input_std": {"uav_01": 0.07},
                    "score_mode": "normalized",
                    "threshold_mode": "per_uav_benign_warmup_raw_quantile",
                    "score_direction": "higher_is_more_anomalous",
                    "normalized_threshold": 1.5,
                    "per_uav_threshold": {"uav_01": 0.45},
                    "per_uav_raw_threshold": {"uav_01": 0.45},
                    "per_uav_normalized_threshold": {"uav_01": 1.5},
                    "per_uav_threshold_source": {"uav_01": "warmup_quantile"},
                    "per_uav_id_score_mean": {"uav_01": 0.12},
                    "per_uav_id_score_median": {"uav_01": 0.11},
                    "per_uav_benign_score_q50": {"uav_01": 0.10},
                    "per_uav_benign_score_q90": {"uav_01": 0.14},
                    "per_uav_benign_score_q95": {"uav_01": 0.15},
                    "per_uav_benign_score_q99": {"uav_01": 0.16},
                    "per_uav_raw_score_q50": {"uav_01": 0.20},
                    "per_uav_raw_score_q90": {"uav_01": 0.45},
                    "per_uav_raw_score_q95": {"uav_01": 0.55},
                    "per_uav_raw_score_q99": {"uav_01": 0.70},
                    "per_uav_normalized_score_q50": {"uav_01": 0.12},
                    "per_uav_normalized_score_q90": {"uav_01": 0.44},
                    "per_uav_normalized_score_q95": {"uav_01": 0.60},
                    "per_uav_normalized_score_q99": {"uav_01": 0.82},
                    "per_uav_raw_ood_score_mean": {"uav_01": 0.33},
                    "per_uav_normalized_ood_score_mean": {"uav_01": 0.44},
                    "per_uav_score_unique_count": {"uav_01": 2},
                    "per_uav_inference_error_count": {"uav_01": 1},
                    "per_window_raw_ood_score": [{"window_id": 0, "group_id": "uav_01", "raw_ood_score": 0.1, "inference_error": False}],
                    "per_window_normalized_ood_score": [
                        {"window_id": 0, "group_id": "uav_01", "normalized_ood_score": 0.1, "inference_error": False}
                    ],
                    "inference_error_count": 1,
                    "fallback_score_used_count": 0,
                    "feature_adapter_enabled": True,
                    "strict_model_feature_mode": True,
                    "feature_columns_source": "artifact.feature_cols",
                    "threshold_quantile": 0.95,
                }

        with tempfile.TemporaryDirectory() as tmp_dir:
            output_dir = Path(tmp_dir) / "exports"
            pool = AttackReplayPool(
                dataset_paths=build_replay_dataset_paths(Path(tmp_dir)),
                uav_dataset_bindings={"uav_01": "uav_ndd"},
                seed=29,
            )
            scenario = ScenarioConfig(
                name="scenario_export",
                scenario_type="single_attack",
                attack_events=(
                    ScenarioAttackEvent(
                        uav_id="uav_01",
                        source_dataset="gcs_to_uav_updated",
                        attack_types="replay",
                        start_time=1.0,
                        duration=1.0,
                        intensity=1.0,
                        replay_mode="sequential",
                    ),
                ),
            )
            uav = UAV(
                uav_id="uav_01",
                route_length_m=12.0,
                hover_duration_s=1.0,
                cruise_altitude_m=18.0,
                cruise_speed_mps=5.0,
            )
            engine = SimulationEngine(
                uavs=[uav],
                gcs=GCS(),
                attacker=Attacker(),
                attack_injector=AttackInjector(),
                attack_replay_pool=pool,
                scenario_config=scenario,
                online_detector=StubOnlineDetector(),
                config=SimulationConfig(
                    duration_s=3.0,
                    dt_s=1.0,
                    seed=29,
                    enable_online_detection=True,
                    output_dir=str(output_dir),
                ),
            )

            result = engine.run()
            record_rows = read_jsonl(output_dir / "simulation_records.jsonl")
            detection_rows = read_jsonl(output_dir / "simulation_detections.jsonl")
            summary = load_json(output_dir / "simulation_summary.json")
            with (output_dir / "per_uav_detection_summary.csv").open("r", encoding="utf-8", newline="") as handle:
                per_uav_rows = list(csv.DictReader(handle))
            with (output_dir / "threshold_diagnostics.csv").open("r", encoding="utf-8", newline="") as handle:
                threshold_rows = list(csv.DictReader(handle))

        self.assertEqual(len(record_rows), len(result.records))
        self.assertEqual(len(detection_rows), len(result.online_detection_results))
        self.assertEqual(summary["record_count"], len(result.records))
        self.assertEqual(summary["detection_count"], len(result.online_detection_results))
        self.assertIn("simulation_records", result.export_paths)
        self.assertIn("simulation_detections", result.export_paths)
        self.assertIn("simulation_summary", result.export_paths)
        self.assertIn("per_uav_detection_summary", result.export_paths)
        self.assertIn("threshold_diagnostics", result.export_paths)
        required_detection_fields = {
            "gt_attack_active",
            "gt_attack_type",
            "known_pred_labels",
            "raw_ood_score",
            "normalized_ood_score",
            "ood_score",
            "threshold",
            "ood_threshold",
            "threshold_source",
            "is_ood",
            "score_direction",
            "ground_truth_is_ood",
            "window_partition",
            "false_alert",
            "alert_level",
            "top_suspicious_records",
        }
        self.assertTrue(required_detection_fields.issubset(detection_rows[0].keys()))
        self.assertTrue(any(bool(row["gt_attack_active"]) for row in detection_rows))
        self.assertTrue(any(str(row["gt_attack_type"]) == "replay" for row in detection_rows))
        self.assertIn("gt_attack_window_count", summary)
        self.assertIn("benign_window_count", summary)
        self.assertIn("gt_ood_window_count", summary)
        self.assertIn("pred_alert_window_count", summary)
        self.assertIn("false_alert_window_count", summary)
        self.assertIn("missed_attack_window_count", summary)
        self.assertEqual(summary["false_alert_window_count"], 0)
        self.assertEqual(summary["gt_ood_window_count"], 0)
        self.assertEqual(summary["model_input_columns"], ["feat_a", "feat_b"])
        self.assertEqual(summary["dropped_simulation_columns"], ["sim_mission_phase", "sim_rssi"])
        self.assertEqual(summary["missing_model_features"], ["feat_b"])
        self.assertEqual(summary["extra_simulation_columns"], ["dataset_name", "sim_mission_phase"])
        self.assertEqual(summary["per_uav_missing_feature_ratio"]["uav_01"], 0.25)
        self.assertEqual(summary["per_uav_zero_feature_ratio"]["uav_01"], 0.5)
        self.assertEqual(summary["per_uav_input_mean"]["uav_01"], 0.15)
        self.assertEqual(summary["per_uav_input_std"]["uav_01"], 0.07)
        self.assertEqual(summary["score_mode"], "normalized")
        self.assertEqual(summary["threshold_mode"], "per_uav_benign_warmup_raw_quantile")
        self.assertEqual(summary["score_direction"], "higher_is_more_anomalous")
        self.assertEqual(summary["normalized_threshold"], 1.5)
        self.assertEqual(summary["per_uav_threshold"]["uav_01"], 0.45)
        self.assertEqual(summary["per_uav_raw_threshold"]["uav_01"], 0.45)
        self.assertEqual(summary["per_uav_normalized_threshold"]["uav_01"], 1.5)
        self.assertEqual(summary["per_uav_threshold_source"]["uav_01"], "warmup_quantile")
        self.assertEqual(summary["per_uav_raw_ood_score_mean"]["uav_01"], 0.33)
        self.assertEqual(summary["per_uav_normalized_ood_score_mean"]["uav_01"], 0.44)
        self.assertEqual(summary["per_uav_score_unique_count"]["uav_01"], 2)
        self.assertEqual(summary["per_uav_inference_error_count"]["uav_01"], 1)
        self.assertEqual(summary["inference_error_count"], 1)
        self.assertEqual(summary["fallback_score_used_count"], 0)
        self.assertEqual(summary["per_window_raw_ood_score"][0]["group_id"], "uav_01")
        self.assertEqual(summary["per_window_normalized_ood_score"][0]["group_id"], "uav_01")
        self.assertTrue(bool(summary["feature_adapter_enabled"]))
        self.assertTrue(bool(summary["strict_model_feature_mode"]))
        self.assertEqual(summary["per_uav_gt_attack_window_count"]["uav_01"], 1)
        self.assertEqual(summary["per_uav_gt_ood_window_count"].get("uav_01", 0), 0)
        self.assertEqual(summary["per_uav_pred_alert_window_count"]["uav_01"], 1)
        self.assertEqual(summary["per_uav_pred_ood_window_count"]["uav_01"], 1)
        self.assertEqual(summary["per_uav_false_alert_rate_on_benign_windows"]["uav_01"], 0.0)
        self.assertEqual(len(per_uav_rows), 1)
        self.assertEqual(per_uav_rows[0]["uav_id"], "uav_01")
        self.assertEqual(per_uav_rows[0]["benign_window_count"], "2")
        self.assertEqual(per_uav_rows[0]["gt_attack_window_count"], "1")
        self.assertEqual(per_uav_rows[0]["gt_ood_window_count"], "0")
        self.assertEqual(per_uav_rows[0]["pred_alert_window_count"], "1")
        self.assertEqual(per_uav_rows[0]["pred_ood_window_count"], "1")
        self.assertEqual(per_uav_rows[0]["threshold_source"], "warmup_quantile")
        self.assertEqual(per_uav_rows[0]["score_mode"], "normalized")
        self.assertEqual(per_uav_rows[0]["threshold_mode"], "per_uav_benign_warmup_raw_quantile")
        self.assertEqual(per_uav_rows[0]["raw_threshold"], "0.45")
        self.assertEqual(per_uav_rows[0]["normalized_threshold"], "1.5")
        self.assertEqual(per_uav_rows[0]["score_unique_count"], "2")
        self.assertEqual(per_uav_rows[0]["inference_error_window_count"], "1")
        self.assertEqual(per_uav_rows[0]["missing_feature_ratio"], "0.25")
        self.assertEqual(per_uav_rows[0]["zero_feature_ratio"], "0.5")
        self.assertEqual(len(threshold_rows), 1)
        self.assertEqual(threshold_rows[0]["uav_id"], "uav_01")
        self.assertEqual(threshold_rows[0]["forbidden_model_input_columns_present"], "False")
        self.assertEqual(threshold_rows[0]["model_input_columns_json"], '["feat_a", "feat_b"]')
        self.assertEqual(threshold_rows[0]["gt_attack_window_count"], "1")
        self.assertEqual(threshold_rows[0]["gt_ood_window_count"], "0")
        self.assertEqual(threshold_rows[0]["pred_alert_window_count"], "1")
        self.assertEqual(threshold_rows[0]["pred_ood_window_count"], "1")
        self.assertEqual(threshold_rows[0]["score_mode"], "normalized")
        self.assertEqual(threshold_rows[0]["threshold_mode"], "per_uav_benign_warmup_raw_quantile")
        self.assertEqual(threshold_rows[0]["raw_threshold"], "0.45")
        self.assertEqual(threshold_rows[0]["normalized_threshold"], "1.5")
        self.assertEqual(threshold_rows[0]["score_unique_count"], "2")
        self.assertEqual(threshold_rows[0]["inference_error_window_count"], "1")
        self.assertEqual(threshold_rows[0]["missing_feature_ratio"], "0.25")

    def test_engine_applies_increase_sampling_response_after_alert(self):
        class OneShotAlertDetector:
            def __init__(self):
                self.fired = False

            def consume_records(self, records):
                if self.fired:
                    return []
                record = records[0]
                self.fired = True
                return [
                    {
                        "window_id": 0,
                        "group_id": record.uav_id,
                        "record_ids": [f"{record.uav_id}:{record.timestamp:.1f}"],
                        "known_pred_labels": [],
                        "known_pred_probs": {},
                        "ood_score": 1.2,
                        "ood_threshold": 0.4,
                        "is_ood": True,
                        "alert_level": "warning",
                        "top_suspicious_records": [],
                        "ground_truth": {"attack_active": False, "attack_types": []},
                    }
                ]

        uav = UAV(
            uav_id="uav_sampling",
            mission_phase="hover",
            auto_start=False,
            hover_duration_s=100.0,
            altitude_m=20.0,
        )
        engine = SimulationEngine(
            uavs=[uav],
            gcs=GCS(),
            attacker=Attacker(),
            attack_injector=AttackInjector(),
            config=SimulationConfig(
                duration_s=3.0,
                dt_s=1.0,
                seed=5,
                enable_online_detection=True,
                response_strategy="increase_sampling",
            ),
            online_detector=OneShotAlertDetector(),
        )

        result = engine.run()

        self.assertEqual(result.alert_count, 1)
        self.assertEqual(result.response_count, 1)
        self.assertEqual(result.response_events[0]["response_action"], "increase_sampling")
        self.assertGreater(result.records[1].bytes_up, result.records[0].bytes_up * 1.4)
        self.assertEqual(result.records[1].response_action, "increase_sampling")
        self.assertTrue(result.online_detection_results[0]["response_triggered"])

    def test_engine_marks_false_alert_and_aborted_return_home_mission(self):
        class OneShotAlertDetector:
            def __init__(self):
                self.fired = False

            def consume_records(self, records):
                if self.fired:
                    return []
                record = records[0]
                self.fired = True
                return [
                    {
                        "window_id": 0,
                        "group_id": record.uav_id,
                        "record_ids": [f"{record.uav_id}:{record.timestamp:.1f}"],
                        "known_pred_labels": [],
                        "known_pred_probs": {},
                        "ood_score": 0.9,
                        "ood_threshold": 0.4,
                        "is_ood": True,
                        "alert_level": "warning",
                        "top_suspicious_records": [],
                        "ground_truth": {"attack_active": False, "attack_types": []},
                    }
                ]

        uav = UAV(
            uav_id="uav_rth",
            mission_phase="cruise",
            auto_start=False,
            x_m=8.0,
            altitude_m=3.5,
            route_length_m=100.0,
            cruise_speed_mps=8.0,
            return_speed_mps=8.0,
        )
        engine = SimulationEngine(
            uavs=[uav],
            gcs=GCS(),
            attacker=Attacker(),
            attack_injector=AttackInjector(),
            config=SimulationConfig(
                duration_s=4.0,
                dt_s=1.0,
                seed=11,
                enable_online_detection=True,
                response_strategy="return_home",
            ),
            online_detector=OneShotAlertDetector(),
        )

        result = engine.run()

        self.assertEqual(result.alert_count, 1)
        self.assertEqual(result.false_alert_count, 1)
        self.assertEqual(result.response_count, 1)
        self.assertFalse(result.mission_success)
        self.assertTrue(any(record.mission_phase == "return_home" for record in result.records[1:]))
        self.assertEqual(result.response_events[0]["response_action"], "return_home")

    def test_engine_reports_average_alert_delay_from_attack_start(self):
        class DelayedTrueAlertDetector:
            def __init__(self):
                self.fired = False

            def consume_records(self, records):
                record = records[0]
                if self.fired or not record.attack_active or record.timestamp < 2.0:
                    return []
                self.fired = True
                return [
                    {
                        "window_id": 0,
                        "group_id": record.uav_id,
                        "record_ids": [f"{record.uav_id}:{record.timestamp:.1f}"],
                        "known_pred_labels": [],
                        "known_pred_probs": {},
                        "ood_score": 1.1,
                        "ood_threshold": 0.5,
                        "is_ood": True,
                        "alert_level": "critical",
                        "top_suspicious_records": [],
                        "ground_truth": {"attack_active": True, "attack_types": [record.attack_type]},
                    }
                ]

        uav = UAV(
            uav_id="uav_delay",
            mission_phase="hover",
            auto_start=False,
            hover_duration_s=100.0,
            altitude_m=15.0,
        )
        injector = AttackInjector(
            [AttackEvent(start_s=1.0, end_s=4.0, attack_type="scan", intensity=0.6)]
        )
        engine = SimulationEngine(
            uavs=[uav],
            gcs=GCS(),
            attacker=Attacker(),
            attack_injector=injector,
            config=SimulationConfig(
                duration_s=5.0,
                dt_s=1.0,
                seed=13,
                enable_online_detection=True,
                response_strategy="alert_only",
            ),
            online_detector=DelayedTrueAlertDetector(),
        )

        result = engine.run()

        self.assertEqual(result.alert_count, 1)
        self.assertEqual(result.false_alert_count, 0)
        self.assertEqual(result.response_count, 1)
        self.assertAlmostEqual(result.average_alert_delay, 1.0)
        self.assertEqual(result.response_events[0]["response_action"], "alert_only")

    def test_multi_uav_engine_supports_different_attack_plans(self):
        config = {
            "uav_count": 3,
            "route_length_m": 600.0,
            "hover_duration_s": 10.0,
            "cruise_altitude_m": 90.0,
            "cruise_speed_mps": 17.0,
            "battery_capacity_wh": 180.0,
            "start_spacing_s": 3.0,
            "attack_type": "benign",
            "attack_start_s": 0.0,
            "attack_end_s": 0.0,
            "attack_intensity": 0.0,
            "scenario_profile_path": "configs/simulator_default.yaml",
        }
        uavs = build_fleet(config)
        engine = SimulationEngine(
            uavs=uavs,
            gcs=GCS(),
            attacker=Attacker(),
            attack_injector=build_scenario_attack_injector(config, uavs),
            config=SimulationConfig(duration_s=36.0, dt_s=1.0, seed=21, scenario_profile_path=config["scenario_profile_path"]),
        )

        result = engine.run()
        at_t30 = {record.uav_id: record for record in result.records if abs(record.timestamp - 30.0) < 1e-6}

        self.assertEqual(at_t30["uav_01"].mission_context, "surveillance")
        self.assertEqual(at_t30["uav_02"].mission_context, "delivery")
        self.assertEqual(at_t30["uav_03"].mission_context, "inspection")
        self.assertEqual(at_t30["uav_01"].attack_type, "jamming_proxy")
        self.assertEqual(at_t30["uav_02"].attack_type, "replay")
        self.assertEqual(at_t30["uav_03"].attack_type, "benign")

    def test_demo_scene_config_overlay_inherits_unspecified_defaults(self):
        self.assertTrue(Path(default_demo_scene_config_path()).exists())
        with tempfile.TemporaryDirectory() as tmp_dir:
            overlay_path = Path(tmp_dir) / "demo_overlay.yaml"
            overlay_path.write_text(
                "uav_count: 1\n"
                "attack_type: benign\n"
                "battery_capacity_wh: 220.0\n",
                encoding="utf-8",
            )
            config = load_demo_scene_config(overlay_path)

        self.assertEqual(config["uav_count"], 1)
        self.assertEqual(config["attack_type"], "benign")
        self.assertEqual(config["battery_capacity_wh"], 220.0)
        self.assertEqual(config["window_size"], 16)
        self.assertEqual(config["response_strategy"], "conservative_mode")
        self.assertEqual(config["scenario_profile_path"], "configs/simulator_default.yaml")

    def test_fleet_preview_rows_include_per_uav_attack_plans(self):
        config = load_demo_scene_config()
        uavs = build_fleet(config)
        injector = build_scenario_attack_injector(config, uavs)

        preview_rows = build_fleet_preview_rows(uavs, injector)
        by_uav = {row["uav_id"]: row for row in preview_rows}

        self.assertEqual(len(preview_rows), 6)
        self.assertEqual(by_uav["uav_01"]["stagger_index"], 0)
        self.assertEqual(by_uav["uav_02"]["stagger_index"], 1)
        self.assertIn("jamming_proxy", by_uav["uav_01"]["attack_plan"])
        self.assertIn("replay", by_uav["uav_02"]["attack_plan"])
        self.assertIn("command_injection", by_uav["uav_03"]["attack_plan"])
        self.assertEqual(by_uav["uav_03"]["mission_context"], "inspection")


if __name__ == "__main__":
    unittest.main()
