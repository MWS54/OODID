from __future__ import annotations

import unittest

from ucs_oodid.realtime.streaming_buffer import StreamingWindowBuffer


class StreamingWindowBufferTests(unittest.TestCase):
    def test_count_mode_emits_overlapping_windows(self):
        buffer = StreamingWindowBuffer(
            mode="count",
            window_size=3,
            stride=1,
            timestamp_col="timestamp",
            record_id_col="record_id",
            group_col="uav_id",
        )
        rows = [
            {"record_id": "r0", "timestamp": 0.0, "uav_id": "u1"},
            {"record_id": "r1", "timestamp": 1.0, "uav_id": "u1"},
            {"record_id": "r2", "timestamp": 2.0, "uav_id": "u1"},
            {"record_id": "r3", "timestamp": 3.0, "uav_id": "u1"},
        ]

        emitted = []
        for row in rows:
            emitted.extend(buffer.append(row))

        self.assertEqual(len(emitted), 2)
        self.assertEqual(emitted[0].record_ids, ["r0", "r1", "r2"])
        self.assertEqual(emitted[1].record_ids, ["r1", "r2", "r3"])

    def test_time_mode_waits_until_window_is_complete(self):
        buffer = StreamingWindowBuffer(
            mode="time",
            window_size=8,
            stride=2,
            time_seconds=2.0,
            timestamp_col="timestamp",
            record_id_col="record_id",
            group_col="uav_id",
        )
        rows = [
            {"record_id": "r0", "timestamp": 0.0, "uav_id": "u1"},
            {"record_id": "r1", "timestamp": 0.5, "uav_id": "u1"},
            {"record_id": "r2", "timestamp": 1.2, "uav_id": "u1"},
            {"record_id": "r3", "timestamp": 2.1, "uav_id": "u1"},
        ]

        emitted_before = []
        for row in rows[:3]:
            emitted_before.extend(buffer.append(row))
        emitted_after = buffer.append(rows[3])

        self.assertEqual(emitted_before, [])
        self.assertEqual(len(emitted_after), 1)
        self.assertEqual(emitted_after[0].record_ids, ["r0", "r1", "r2"])
        self.assertAlmostEqual(emitted_after[0].start_marker, 0.0)
        self.assertAlmostEqual(emitted_after[0].end_marker, 2.0)

    def test_grouped_count_mode_keeps_uav_streams_isolated(self):
        buffer = StreamingWindowBuffer(
            mode="count",
            window_size=2,
            stride=1,
            timestamp_col="timestamp",
            record_id_col="record_id",
            group_col="uav_id",
        )
        rows = [
            {"record_id": "u1_r0", "timestamp": 0.0, "uav_id": "u1"},
            {"record_id": "u2_r0", "timestamp": 0.0, "uav_id": "u2"},
            {"record_id": "u1_r1", "timestamp": 1.0, "uav_id": "u1"},
            {"record_id": "u2_r1", "timestamp": 1.0, "uav_id": "u2"},
        ]

        emitted = []
        for row in rows:
            emitted.extend(buffer.append(row))

        self.assertEqual(len(emitted), 2)
        grouped = {window.group_id: window.record_ids for window in emitted}
        self.assertEqual(grouped["u1"], ["u1_r0", "u1_r1"])
        self.assertEqual(grouped["u2"], ["u2_r0", "u2_r1"])


if __name__ == "__main__":
    unittest.main()
