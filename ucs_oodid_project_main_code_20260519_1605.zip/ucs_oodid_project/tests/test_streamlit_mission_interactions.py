from __future__ import annotations

import unittest
from pathlib import Path

from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parents[1]
APP_PATH = ROOT / "app" / "streamlit_app.py"
APP_TIMEOUT_S = 60


def attack_type_multiselect_keys(app: AppTest) -> list[str]:
    return [
        widget.key
        for widget in app.multiselect
        if widget.key and widget.key.endswith("_attack_types_multi")
    ]


class MissionPageInteractionTests(unittest.TestCase):
    def test_attack_type_controls_remain_stable_across_mode_and_uav_changes(self):
        app = AppTest.from_file(str(APP_PATH))
        app.run(timeout=APP_TIMEOUT_S)

        initial_uavs = list(app.multiselect(key="cfg_selected_uav_ids").value)
        self.assertEqual(
            attack_type_multiselect_keys(app),
            [f"cfg_{uav_id}_attack_types_multi" for uav_id in initial_uavs],
        )

        app.selectbox(key="cfg_attack_mode").set_value("single_attack")
        app.run(timeout=APP_TIMEOUT_S)

        single_mode_widgets = [
            widget
            for widget in app.multiselect
            if widget.key and widget.key.endswith("_attack_types_multi")
        ]
        self.assertEqual(
            [widget.key for widget in single_mode_widgets],
            [f"cfg_{uav_id}_attack_types_multi" for uav_id in initial_uavs],
        )
        self.assertTrue(all(len(widget.value) <= 1 for widget in single_mode_widgets))

        reduced_uavs = ["uav_01", "uav_05"]
        app.multiselect(key="cfg_selected_uav_ids").set_value(reduced_uavs)
        app.run(timeout=APP_TIMEOUT_S)

        self.assertEqual(
            attack_type_multiselect_keys(app),
            [f"cfg_{uav_id}_attack_types_multi" for uav_id in reduced_uavs],
        )

        app.selectbox(key="cfg_attack_mode").set_value("mixed_attack")
        app.run(timeout=APP_TIMEOUT_S)

        self.assertEqual(
            attack_type_multiselect_keys(app),
            [f"cfg_{uav_id}_attack_types_multi" for uav_id in reduced_uavs],
        )
        self.assertEqual(len(app.exception), 0)


if __name__ == "__main__":
    unittest.main()
