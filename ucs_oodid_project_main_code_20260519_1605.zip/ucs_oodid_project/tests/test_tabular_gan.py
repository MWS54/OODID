from __future__ import annotations

import unittest

import numpy as np

from ucs_oodid.tabular_gan import FeaturePostprocessor, TabularGanConfig, augment_class_with_wgan


class TabularGanTests(unittest.TestCase):
    def test_feature_postprocessor_snaps_discrete_and_integer_like_columns(self):
        real_x = np.asarray(
            [
                [0.0, 10.0, 1.0],
                [1.0, 20.0, 2.0],
                [0.0, 30.0, 3.0],
            ],
            dtype=np.float32,
        )
        post = FeaturePostprocessor(max_discrete_values=4).fit(real_x)
        generated = np.asarray(
            [
                [0.3, 12.6, 2.4],
                [0.8, 29.9, 3.1],
            ],
            dtype=np.float32,
        )
        fixed = post.transform(generated)
        self.assertTrue(set(np.unique(fixed[:, 0]).tolist()).issubset({0.0, 1.0}))
        self.assertTrue(np.all(fixed[:, 1] == np.round(fixed[:, 1])))
        self.assertTrue(np.all((fixed[:, 2] >= 1.0) & (fixed[:, 2] <= 3.0)))

    def test_augment_class_with_wgan_returns_requested_shape(self):
        rng = np.random.default_rng(7)
        real_x = np.column_stack(
            [
                rng.normal(0.0, 1.0, 96),
                rng.normal(10.0, 2.0, 96),
                rng.integers(0, 4, 96),
            ]
        ).astype(np.float32)
        cfg = TabularGanConfig(
            noise_dim=8,
            hidden_dim=32,
            batch_size=32,
            epochs=3,
            critic_steps=1,
            sample_batch_size=64,
            device="cpu",
        )
        samples, summary = augment_class_with_wgan(
            real_x,
            n_generate=12,
            config=cfg,
            seed=11,
            distance_quantile=0.95,
            distance_scale=1.5,
        )
        self.assertEqual(samples.shape, (12, 3))
        self.assertFalse(np.isnan(samples).any())
        self.assertEqual(summary["sampling"]["generated"], 12)


if __name__ == "__main__":
    unittest.main()
