from __future__ import annotations

import csv
import json
import tempfile
import unittest
from pathlib import Path

import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ucs_oodid.io import load_json
from ucs_oodid.reporting.text_summary import export_metric_summary


def write_json(path: Path, payload: dict) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


def write_jsonl(path: Path, rows: list[dict]) -> None:
    lines = [json.dumps(row, ensure_ascii=False) for row in rows]
    path.write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")


class TextSummaryExportTests(unittest.TestCase):
    def test_export_metric_summary_writes_required_outputs(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            reports_dir = Path(tmp_dir) / "reports"
            reports_dir.mkdir(parents=True, exist_ok=True)

            write_json(
                reports_dir / "eval_report.json",
                {
                    "encoder_ablation": "transformer_only",
                    "graph_enabled": False,
                    "graph_variant": "identity_graph",
                    "ood_fusion": "correlation_aware",
                    "normalization_mode": "group",
                    "ood_threshold_mode": "group",
                    "group_config": {"group_col": "uav_id"},
                    "window_config": {"mode": "count", "size": 16, "stride": 8},
                    "class_names": ["benign", "dos"],
                    "seed": 42,
                    "id_test": {
                        "micro_f1": 0.91,
                        "macro_f1": 0.87,
                        "mAP": 0.89,
                        "subset_accuracy": 0.83,
                        "hamming_loss": 0.07,
                        "per_class_metrics": {
                            "benign": {"precision": 0.95, "recall": 0.96, "f1": 0.955},
                            "dos": {"precision": 0.88, "recall": 0.84, "f1": 0.86},
                        },
                    },
                    "ood_test": {
                        "auroc": 0.93,
                        "aupr_out": 0.90,
                        "fpr95": 0.08,
                        "precision": 0.82,
                        "tpr": 0.79,
                        "ood_f1": 0.80,
                    },
                    "global_ood_threshold": 0.55,
                    "ood_fusion_weights": {"proto": 0.65, "energy": 0.15, "conf": 0.10, "knn": 0.10},
                    "single_attack_results": {"micro_f1": 0.93, "ood_f1": 0.82},
                    "mixed_attack_results": {"micro_f1": 0.88, "ood_f1": 0.76},
                    "id_test_by_group": {
                        "uav_01": {
                            "windows": 120,
                            "micro_f1": 0.92,
                            "macro_f1": 0.88,
                            "present_class_macro_f1": 0.93,
                            "present_class_count": 2,
                            "present_class_names": ["benign", "dos"],
                            "absent_class_count": 0,
                            "subset_accuracy": 0.84,
                            "mAP": 0.91,
                        },
                        "uav_02": {
                            "windows": 100,
                            "micro_f1": 0.90,
                            "macro_f1": 0.85,
                            "present_class_macro_f1": 0.90,
                            "present_class_count": 1,
                            "present_class_names": ["dos"],
                            "absent_class_count": 1,
                            "subset_accuracy": 0.81,
                            "mAP": 0.87,
                        },
                    },
                    "ood_test_by_group": {
                        "uav_01": {"windows": 150, "ood_windows": 30, "auroc": 0.94, "fpr95": 0.07},
                        "uav_02": {"windows": 110, "ood_windows": 20, "auroc": 0.90, "fpr95": 0.10},
                    },
                },
            )
            write_json(
                reports_dir / "group_detection_summary.json",
                {
                    "group_col": "uav_id",
                    "present_class_min_support": 1,
                    "groups": {
                        "uav_01": {
                            "windows": 150,
                            "ood_alerts": 25,
                            "alert_rate": 0.1667,
                            "macro_f1": 0.88,
                            "present_class_macro_f1": 0.93,
                            "present_class_count": 2,
                            "present_class_names": ["benign", "dos"],
                            "absent_class_count": 0,
                            "absent_class_names": [],
                            "class_support": {"benign": 70, "dos": 50},
                        },
                        "uav_02": {
                            "windows": 110,
                            "ood_alerts": 15,
                            "alert_rate": 0.1364,
                            "macro_f1": 0.85,
                            "present_class_macro_f1": 0.90,
                            "present_class_count": 1,
                            "present_class_names": ["dos"],
                            "absent_class_count": 1,
                            "absent_class_names": ["benign"],
                            "class_support": {"benign": 0, "dos": 45},
                        },
                    },
                    "global": {
                        "windows": 260,
                        "ood_alerts": 40,
                        "alert_rate": 0.1538,
                        "mean_ood_score": 0.41,
                        "max_ood_score": 0.92,
                    },
                    "ood_threshold_mode": "group",
                },
            )
            write_json(
                reports_dir / "simulation_summary.json",
                {
                    "scenario_name": "demo_mission",
                    "uav_ids": ["uav_01", "uav_02"],
                    "record_count": 300,
                    "detection_count": 260,
                    "attack_record_count": 50,
                    "total_energy_wh": 5.0,
                    "alert_count": 40,
                    "response_count": 3,
                    "average_alert_delay": 1.5,
                    "false_alert_count": 2,
                    "mission_success": True,
                    "output_files": {
                        "simulation_records": "simulation_records.jsonl",
                        "simulation_detections": "simulation_detections.jsonl",
                    },
                },
            )
            write_json(
                reports_dir / "benchmark_report.json",
                {
                    "encoder_ablation": "transformer_only",
                    "device": "cpu",
                    "num_windows": 100,
                    "average_window_inference_ms": 4.2,
                    "run_times_ms": [420.0, 400.0, 415.0],
                },
            )
            write_json(
                reports_dir / "ablation_summary.json",
                {
                    "experiments": [
                        {
                            "experiment_name": "base",
                            "id_micro_f1": 0.90,
                            "ood_auroc": 0.88,
                            "macro_uav_ood_f1": 0.74,
                            "status": "success",
                        },
                        {
                            "experiment_name": "full_conservative",
                            "id_micro_f1": 0.91,
                            "ood_auroc": 0.94,
                            "macro_uav_ood_f1": 0.79,
                            "status": "success",
                        },
                        {
                            "experiment_name": "group_norm",
                            "status": "failed",
                            "error_message": "mock failure",
                        },
                    ],
                    "failed_experiments": ["group_norm"],
                },
            )
            write_json(
                reports_dir / "cross_uav_summary.json",
                {
                    "source_uav": "uav_01",
                    "target_uav": "uav_02",
                    "used_rows": {
                        "source_train": 80,
                        "source_val": 20,
                        "target_test_id": 60,
                        "target_test_ood": 15,
                    },
                    "target_id_metrics": {"micro_f1": 0.89},
                    "target_ood_metrics": {"auroc": 0.91, "fpr95": 0.10},
                    "target_group_metrics": {
                        "id_test": {"micro_f1": 0.90, "macro_f1": 0.85},
                        "ood_test": {"auroc": 0.90, "fpr95": 0.10},
                        "detection_summary": {"windows": 110, "ood_alerts": 15},
                    },
                },
            )
            write_jsonl(
                reports_dir / "simulation_records.jsonl",
                [
                    {
                        "uav_id": "uav_01",
                        "dataset_name": "uav_ndd",
                        "attack_active": False,
                        "flight_energy_wh": 1.0,
                        "communication_energy_wh": 0.20,
                        "detection_energy_wh": 0.05,
                        "total_energy_wh": 1.25,
                        "timestamp": 0.0,
                    },
                    {
                        "uav_id": "uav_01",
                        "dataset_name": "uav_ndd",
                        "attack_active": True,
                        "flight_energy_wh": 1.2,
                        "communication_energy_wh": 0.10,
                        "detection_energy_wh": 0.04,
                        "total_energy_wh": 1.34,
                        "timestamp": 1.0,
                    },
                    {
                        "uav_id": "uav_02",
                        "dataset_name": "gcs_to_uav_updated",
                        "attack_active": False,
                        "flight_energy_wh": 1.3,
                        "communication_energy_wh": 0.15,
                        "detection_energy_wh": 0.03,
                        "total_energy_wh": 1.48,
                        "timestamp": 2.0,
                    },
                    {
                        "uav_id": "uav_02",
                        "dataset_name": "gcs_to_uav_updated",
                        "attack_active": True,
                        "flight_energy_wh": 0.8,
                        "communication_energy_wh": 0.05,
                        "detection_energy_wh": 0.08,
                        "total_energy_wh": 0.93,
                        "timestamp": 3.0,
                    },
                ],
            )
            write_jsonl(
                reports_dir / "simulation_detections.jsonl",
                [
                    {"group_id": "uav_01", "is_ood": True, "alert_level": "warning", "gt_attack_active": False, "dominant_ood_source": "proto"},
                    {"group_id": "uav_01", "is_ood": True, "alert_level": "warning", "gt_attack_active": True, "dominant_ood_source": "proto"},
                    {"group_id": "uav_02", "is_ood": True, "alert_level": "warning", "gt_attack_active": False, "dominant_ood_source": "energy"},
                ],
            )

            payload = export_metric_summary(reports_dir)

            generated = payload["generated_files"]
            expected_files = [
                "metrics_summary_md",
                "metrics_summary_txt",
                "metrics_summary_json",
                "metrics_table_tex",
                "dataset_mapping_table_tex",
                "known_attack_metrics_table_tex",
                "ood_metrics_table_tex",
                "energy_metrics_table_tex",
                "per_uav_metrics_csv",
                "per_dataset_metrics_csv",
                "per_source_type_metrics_csv",
                "energy_summary_csv",
            ]
            for key in expected_files:
                self.assertTrue(Path(generated[key]).exists(), key)

            summary_json = load_json(generated["metrics_summary_json"])
            self.assertTrue(summary_json["source_files"]["report"]["used_alias"])
            self.assertEqual(summary_json["known_attack_detection"]["micro_f1"], 0.91)
            self.assertEqual(summary_json["ood_unknown_attack_detection"]["threshold_mode"], "group")
            self.assertEqual(summary_json["ood_unknown_attack_detection"]["dominant_ood_source"], "proto")
            self.assertAlmostEqual(summary_json["transformer_inference_energy"]["average_inference_latency_ms"], 4.2)
            self.assertAlmostEqual(summary_json["transformer_inference_energy"]["max_inference_latency_ms"], 4.2)
            self.assertAlmostEqual(summary_json["transformer_inference_energy"]["total_flight_energy_j"], 15480.0)
            self.assertAlmostEqual(summary_json["transformer_inference_energy"]["total_communication_energy_j"], 1800.0)
            self.assertAlmostEqual(summary_json["transformer_inference_energy"]["total_ids_energy_j"], 720.0)
            self.assertAlmostEqual(summary_json["transformer_inference_energy"]["total_energy_j"], 18000.0)
            self.assertEqual(len(summary_json["dataset_uav_mapping"]), 6)
            self.assertEqual(len(summary_json["per_dataset_metrics"]), 6)
            self.assertEqual(len(summary_json["per_source_type_metrics"]), 4)
            uav_summary_row = next(
                row for row in summary_json["multi_uav_group_detection"]["rows"] if row["uav_id"] == "uav_01"
            )
            self.assertEqual(uav_summary_row["present_class_macro_f1"], 0.93)
            self.assertEqual(uav_summary_row["present_class_count"], 2)
            self.assertEqual(uav_summary_row["present_class_names"], ["benign", "dos"])
            gcs_mapping = next(row for row in summary_json["dataset_uav_mapping"] if row["uav_id"] == "uav_02")
            self.assertEqual(gcs_mapping["dataset_display"], "GCS-to-UAV Updated")
            self.assertEqual(gcs_mapping["source_type"], "uav_gcs")
            unsw_mapping = next(row for row in summary_json["dataset_uav_mapping"] if row["uav_id"] == "uav_05")
            self.assertEqual(unsw_mapping["summary_note"], "UNSW-NB15 用于外部泛化或非 UAV OOD 测试，不作为真实 UAV 飞行流量主实验依据。")

            markdown_text = Path(generated["metrics_summary_md"]).read_text(encoding="utf-8")
            for heading in [
                "## 实验配置概述",
                "## 数据集与 UAV 映射",
                "## 各数据集指标汇总",
                "## 各 source_type 指标汇总",
                "## 已知攻击检测结果",
                "## OOD 未知攻击检测结果",
                "## 单独攻击与混合攻击结果",
                "## 多 UAV 分组检测结果",
                "## 飞行仿真与在线检测结果",
                "## Transformer 推理开销与能耗结果",
                "## 消融实验结论",
                "## 总体结论",
            ]:
                self.assertIn(heading, markdown_text)
            self.assertIn("Transformer-only", markdown_text)
            self.assertIn("uav_gcs", markdown_text)
            self.assertIn("UNSW-NB15 用于外部泛化或非 UAV OOD 测试，不作为真实 UAV 飞行流量主实验依据。", markdown_text)
            self.assertIn("present_class_macro_f1", markdown_text)
            self.assertIn(
                "由于每个 UAV 只包含全局标签空间中的部分攻击类型，直接计算 per-UAV Macro-F1 会将不存在类别也纳入平均",
                markdown_text,
            )

            dataset_mapping_tex = Path(generated["dataset_mapping_table_tex"]).read_text(encoding="utf-8")
            self.assertIn("Dataset-to-UAV mapping used in textual summary", dataset_mapping_tex)
            self.assertIn("UAV-NDD", dataset_mapping_tex)
            self.assertIn("UNSW-NB15", dataset_mapping_tex)

            with Path(generated["per_uav_metrics_csv"]).open("r", encoding="utf-8", newline="") as handle:
                per_uav_rows = list(csv.DictReader(handle))
            self.assertEqual({row["uav_id"] for row in per_uav_rows}, {"uav_01", "uav_02", "uav_03", "uav_05", "uav_06", "uav_07"})
            uav_01 = next(row for row in per_uav_rows if row["uav_id"] == "uav_01")
            self.assertEqual(uav_01["dataset_display"], "UAV-NDD")
            self.assertEqual(uav_01["dataset_name"], "uav_ndd")
            self.assertEqual(uav_01["source_type"], "uav")
            self.assertEqual(uav_01["sample_count"], "120")
            self.assertEqual(uav_01["attack_count"], "30")
            self.assertEqual(uav_01["present_class_macro_f1"], "0.93")
            self.assertEqual(uav_01["present_class_count"], "2")
            self.assertEqual(uav_01["present_class_names"], "benign, dos")
            self.assertEqual(uav_01["absent_class_count"], "0")
            self.assertEqual(uav_01["subset_accuracy"], "0.84")
            self.assertEqual(uav_01["mAP"], "0.91")
            self.assertEqual(uav_01["alert_count"], "25")
            self.assertEqual(uav_01["false_alert_count"], "1")
            self.assertEqual(uav_01["auprc"], "N/A")
            uav_03 = next(row for row in per_uav_rows if row["uav_id"] == "uav_03")
            self.assertEqual(uav_03["sample_count"], "N/A")
            self.assertEqual(uav_03["auroc"], "N/A")

            with Path(generated["per_dataset_metrics_csv"]).open("r", encoding="utf-8", newline="") as handle:
                per_dataset_rows = list(csv.DictReader(handle))
            self.assertEqual(len(per_dataset_rows), 6)
            gcs_dataset_row = next(row for row in per_dataset_rows if row["dataset_name"] == "gcs_to_uav_updated")
            self.assertEqual(gcs_dataset_row["source_type"], "uav_gcs")
            self.assertEqual(gcs_dataset_row["uav_id"], "uav_02")
            unsw_dataset_row = next(row for row in per_dataset_rows if row["dataset_name"] == "unsw_nb15")
            self.assertEqual(unsw_dataset_row["summary_note"], "UNSW-NB15 用于外部泛化或非 UAV OOD 测试，不作为真实 UAV 飞行流量主实验依据。")
            self.assertEqual(unsw_dataset_row["sample_count"], "N/A")

            with Path(generated["per_source_type_metrics_csv"]).open("r", encoding="utf-8", newline="") as handle:
                per_source_type_rows = list(csv.DictReader(handle))
            self.assertEqual(
                {row["source_type"] for row in per_source_type_rows},
                {"uav", "uav_gcs", "uav_iot_wifi", "external_non_uav"},
            )
            by_source_type = {row["source_type"]: row for row in per_source_type_rows}
            self.assertEqual(by_source_type["uav"]["uav_ids"], "uav_01")
            self.assertEqual(by_source_type["uav"]["sample_count"], "120")
            self.assertEqual(by_source_type["uav_gcs"]["sample_count"], "100")
            self.assertEqual(by_source_type["uav_iot_wifi"]["sample_count"], "N/A")
            self.assertEqual(
                by_source_type["external_non_uav"]["summary_note"],
                "UNSW-NB15 用于外部泛化或非 UAV OOD 测试，不作为真实 UAV 飞行流量主实验依据。",
            )
            self.assertEqual(by_source_type["external_non_uav"]["sample_count"], "N/A")

            with Path(generated["energy_summary_csv"]).open("r", encoding="utf-8", newline="") as handle:
                energy_rows = list(csv.DictReader(handle))
            self.assertEqual(len(energy_rows), 1)
            self.assertEqual(energy_rows[0]["average_inference_latency_ms"], "4.2")
            self.assertEqual(energy_rows[0]["total_ids_energy_j"], "720")

    def test_export_metric_summary_marks_unsw_as_external_non_uav(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            reports_dir = Path(tmp_dir) / "reports"
            reports_dir.mkdir(parents=True, exist_ok=True)

            write_json(
                reports_dir / "eval_report.json",
                {
                    "encoder_ablation": "transformer_only",
                    "group_config": {"group_col": "uav_id"},
                    "window_config": {"mode": "count", "size": 8, "stride": 4},
                    "id_test_by_group": {
                        "uav_05": {"windows": 18, "micro_f1": 0.81, "macro_f1": 0.79, "dataset_name": "unsw_nb15"},
                    },
                    "ood_test_by_group": {
                        "uav_05": {"windows": 9, "ood_windows": 4, "auroc": 0.88, "fpr95": 0.12, "dataset_name": "unsw_nb15"},
                    },
                },
            )
            write_json(
                reports_dir / "group_detection_summary.json",
                {
                    "group_col": "uav_id",
                    "groups": {
                        "uav_05": {"windows": 9, "ood_alerts": 3, "false_alert_count": 1},
                    },
                    "global": {"windows": 9, "ood_alerts": 3, "false_alert_count": 1},
                },
            )
            write_json(
                reports_dir / "simulation_summary.json",
                {
                    "scenario_name": "external_ood_demo",
                    "uav_ids": ["uav_05"],
                    "record_count": 2,
                    "detection_count": 1,
                    "attack_record_count": 1,
                    "alert_count": 1,
                    "false_alert_count": 0,
                    "response_count": 0,
                    "average_alert_delay": 0.5,
                    "mission_success": True,
                    "output_files": {
                        "simulation_records": "simulation_records.jsonl",
                        "simulation_detections": "simulation_detections.jsonl",
                    },
                },
            )
            write_jsonl(
                reports_dir / "simulation_records.jsonl",
                [
                    {
                        "uav_id": "uav_05",
                        "dataset_name": "unsw_nb15",
                        "attack_active": False,
                        "flight_energy_wh": 1.0,
                        "communication_energy_wh": 0.1,
                        "detection_energy_wh": 0.05,
                        "total_energy_wh": 1.15,
                        "timestamp": 0.0,
                    },
                    {
                        "uav_id": "uav_05",
                        "dataset_name": "unsw_nb15",
                        "attack_active": True,
                        "flight_energy_wh": 1.1,
                        "communication_energy_wh": 0.2,
                        "detection_energy_wh": 0.06,
                        "total_energy_wh": 1.36,
                        "timestamp": 1.0,
                    },
                ],
            )
            write_jsonl(
                reports_dir / "simulation_detections.jsonl",
                [
                    {
                        "group_id": "uav_05",
                        "is_ood": True,
                        "alert_level": "warning",
                        "gt_attack_active": True,
                        "dominant_ood_source": "proto",
                    },
                ],
            )

            payload = export_metric_summary(reports_dir)
            generated = payload["generated_files"]
            summary_json = load_json(generated["metrics_summary_json"])

            dataset_row = next(row for row in summary_json["dataset_uav_mapping"] if row["uav_id"] == "uav_05")
            per_uav_row = next(
                row for row in summary_json["multi_uav_group_detection"]["rows"] if row["uav_id"] == "uav_05"
            )
            per_source_type_row = next(
                row for row in summary_json["per_source_type_metrics"] if row["source_type"] == "external_non_uav"
            )

            self.assertEqual(dataset_row["dataset_name"], "unsw_nb15")
            self.assertEqual(dataset_row["dataset_role"], "external_non_uav")
            self.assertEqual(dataset_row["dataset_display"], "UNSW-NB15")
            self.assertEqual(dataset_row["summary_note"], "UNSW-NB15 用于外部泛化或非 UAV OOD 测试，不作为真实 UAV 飞行流量主实验依据。")
            self.assertEqual(per_uav_row["dataset_role"], "external_non_uav")
            self.assertEqual(per_uav_row["source_type"], "external_non_uav")
            self.assertEqual(per_uav_row["dataset_display"], "UNSW-NB15")
            self.assertEqual(per_source_type_row["sample_count"], 18)
            self.assertEqual(per_source_type_row["attack_count"], 4)
            self.assertEqual(
                per_source_type_row["summary_note"],
                "UNSW-NB15 用于外部泛化或非 UAV OOD 测试，不作为真实 UAV 飞行流量主实验依据。",
            )

            markdown_text = Path(generated["metrics_summary_md"]).read_text(encoding="utf-8")
            self.assertIn("external_non_uav", markdown_text)
            self.assertIn("UNSW-NB15 用于外部泛化或非 UAV OOD 测试，不作为真实 UAV 飞行流量主实验依据。", markdown_text)

    def test_export_metric_summary_handles_missing_inputs_with_na(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            reports_dir = Path(tmp_dir) / "reports"
            reports_dir.mkdir(parents=True, exist_ok=True)

            payload = export_metric_summary(reports_dir)
            summary_json = load_json(payload["generated_files"]["metrics_summary_json"])

            self.assertEqual(summary_json["known_attack_detection"]["micro_f1"], "N/A")
            self.assertEqual(summary_json["ood_unknown_attack_detection"]["auroc"], "N/A")
            self.assertEqual(summary_json["transformer_inference_energy"]["total_energy_j"], "N/A")
            self.assertEqual(len(summary_json["dataset_uav_mapping"]), 6)
            self.assertEqual(len(summary_json["per_dataset_metrics"]), 6)
            self.assertEqual(len(summary_json["per_source_type_metrics"]), 4)

            with Path(payload["generated_files"]["energy_summary_csv"]).open("r", encoding="utf-8", newline="") as handle:
                rows = list(csv.DictReader(handle))
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0]["total_energy_j"], "N/A")

            with Path(payload["generated_files"]["per_dataset_metrics_csv"]).open("r", encoding="utf-8", newline="") as handle:
                per_dataset_rows = list(csv.DictReader(handle))
            self.assertEqual(len(per_dataset_rows), 6)
            self.assertTrue(all(row["sample_count"] == "N/A" for row in per_dataset_rows))

            with Path(payload["generated_files"]["per_source_type_metrics_csv"]).open("r", encoding="utf-8", newline="") as handle:
                per_source_type_rows = list(csv.DictReader(handle))
            self.assertEqual(len(per_source_type_rows), 4)
            self.assertTrue(all(row["sample_count"] == "N/A" for row in per_source_type_rows))

            markdown_text = Path(payload["generated_files"]["metrics_summary_md"]).read_text(encoding="utf-8")
            self.assertIn("## 总体结论", markdown_text)
            self.assertIn("N/A", markdown_text)


if __name__ == "__main__":
    unittest.main()
