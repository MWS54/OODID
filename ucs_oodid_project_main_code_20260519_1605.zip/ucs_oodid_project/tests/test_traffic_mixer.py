from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

import pandas as pd

from ucs_oodid.preprocessing import MetadataPreprocessor
from ucs_oodid.simulator.attack_replay import AttackReplayPool
from ucs_oodid.simulator.channel import LinkState
from ucs_oodid.simulator.entities import UAV
from ucs_oodid.simulator.traffic_mixer import SyntheticTrafficContext, TrafficMixer
from ucs_oodid.windowing import attach_parsed_labels, build_count_windows


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    pd.DataFrame(rows).to_csv(path, index=False)


def build_dataset(
    tmp_path: Path,
    *,
    include_benign: bool,
    include_record_id: bool = True,
) -> tuple[dict[str, Path], dict[str, str]]:
    path = tmp_path / "uav_ndd.csv"
    rows: list[dict[str, object]] = []
    if include_benign:
        benign_rows = [
            {"feat_a": 1.0, "feat_b": 2.0, "label": "benign", "timestamp": 0.0},
            {"feat_a": 1.5, "feat_b": 2.5, "label": "normal", "timestamp": 1.0},
        ]
        if include_record_id:
            benign_rows[0]["record_id"] = "b0"
            benign_rows[1]["record_id"] = "b1"
        rows.extend(benign_rows)
    attack_rows = [
        {"feat_a": 10.0, "feat_b": 20.0, "label": "jamming", "timestamp": 2.0},
        {"feat_a": 11.0, "feat_b": 21.0, "label": "jamming", "timestamp": 3.0},
        {"feat_a": 12.0, "feat_b": 22.0, "label": "replay", "timestamp": 4.0},
    ]
    if include_record_id:
        attack_rows[0]["record_id"] = "a0"
        attack_rows[1]["record_id"] = "a1"
        attack_rows[2]["record_id"] = "a2"
    rows.extend(attack_rows)
    write_csv(path, rows)
    return {"uav_ndd": path}, {"uav_01": "uav_ndd"}


def build_context_rows(count: int) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for idx in range(count):
        rows.append(
            {
                "timestamp": float(idx),
                "uav_id": "uav_01",
                "mission_phase": "cruise",
                "mission_context": "surveillance",
                "battery_soc": 95.0 - idx,
                "speed": 12.0,
                "altitude": 80.0,
                "rssi": -64.0,
                "snr": 18.0,
                "latency_ms": 19.0,
                "loss_rate": 0.01,
                "distance_to_gcs": 140.0,
                "wind_level": 0.10,
                "obstacle_factor": 0.05,
                "cpu_load": 0.35,
                "board_temperature_c": 38.0,
            }
        )
    return rows


def build_synthetic_contexts(count: int) -> list[SyntheticTrafficContext]:
    contexts: list[SyntheticTrafficContext] = []
    for idx in range(count):
        uav = UAV(
            uav_id="uav_01",
            mission_phase="cruise",
            mission_context="surveillance",
            altitude_m=60.0,
            speed_mps=10.0,
            battery_soc=90.0,
        )
        link = LinkState(
            distance_m=120.0,
            rssi_dbm=-62.0,
            snr_db=17.0,
            latency_ms=18.0,
            loss_rate=0.02,
            distance_to_gcs=120.0,
            wind_level=0.08,
            obstacle_factor=0.03,
        )
        contexts.append(
            SyntheticTrafficContext(
                timestamp_s=float(idx),
                uav=uav,
                link=link,
            )
        )
    return contexts


def per_window_attack_counts(df: pd.DataFrame, window_size: int) -> list[int]:
    return [
        int(df.iloc[start : start + window_size]["gt_attack_active"].sum())
        for start in range(0, len(df), window_size)
    ]


class TrafficMixerTests(unittest.TestCase):
    def test_mixer_prefers_benign_replay_and_stays_window_ratio_compatible(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            dataset_paths, bindings = build_dataset(Path(tmp_dir), include_benign=True, include_record_id=True)
            pool = AttackReplayPool(
                dataset_paths=dataset_paths,
                uav_dataset_bindings=bindings,
                seed=11,
            )
            mixer = TrafficMixer(pool, seed=11)

            df = mixer.mix(
                build_context_rows(8),
                attack_type="jamming_proxy",
                window_size=4,
                mixed_window_ratio=0.25,
                attack_replay_mode="loop",
                benign_replay_mode="loop",
                as_dataframe=True,
            )

        self.assertEqual(len(df), 8)
        self.assertEqual(per_window_attack_counts(df, 4), [1, 1])
        self.assertEqual(set(df.loc[df["gt_attack_active"], "sim_source"].tolist()), {"attack_replay"})
        self.assertEqual(set(df.loc[~df["gt_attack_active"], "sim_source"].tolist()), {"benign_replay"})
        self.assertTrue(df["record_id"].notna().all())
        self.assertTrue(df["source_record_id"].notna().all())
        self.assertEqual(set(df["gt_attack_type"].tolist()), {"benign", "jamming"})
        self.assertEqual(set(df["source_type"].tolist()), {"uav"})
        self.assertEqual(set(df["simulation_role"].tolist()), {"uav_replay"})
        self.assertIn("sim_mission_phase", df.columns)
        self.assertIn("sim_battery_soc", df.columns)
        self.assertIn("sim_rssi", df.columns)
        self.assertNotIn("mission_phase", df.columns)
        self.assertNotIn("battery_soc", df.columns)

        work = attach_parsed_labels(df, "label")
        pre = MetadataPreprocessor(label_col="label", timestamp_col="timestamp", record_id_col="record_id")
        features = pre.fit_transform(work)
        self.assertNotIn("source_type", pre.feature_cols)
        self.assertNotIn("simulation_role", pre.feature_cols)
        self.assertNotIn("dataset_name", pre.feature_cols)
        self.assertNotIn("sim_battery_soc", pre.feature_cols)
        self.assertNotIn("sim_rssi", pre.feature_cols)
        windows = build_count_windows(
            features,
            work,
            {"benign": 0, "jamming": 1},
            label_col="label",
            record_id_col="record_id",
            window_size=4,
            stride=4,
        )
        self.assertEqual(len(windows), 2)
        self.assertEqual(windows.record_ids.shape, (2, 4))

    def test_mixer_falls_back_to_benign_synthetic_when_no_benign_rows_exist(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            dataset_paths, bindings = build_dataset(Path(tmp_dir), include_benign=False, include_record_id=False)
            pool = AttackReplayPool(
                dataset_paths=dataset_paths,
                uav_dataset_bindings=bindings,
                seed=13,
            )
            mixer = TrafficMixer(pool, seed=13)

            rows = mixer.mix(
                build_synthetic_contexts(6),
                attack_type="jamming_proxy",
                window_size=3,
                mixed_window_ratio=1.0 / 3.0,
                attack_replay_mode="loop",
                benign_replay_mode="sequential",
                as_dataframe=False,
            )

        self.assertEqual(len(rows), 6)
        self.assertFalse(mixer.has_benign_replay("uav_01"))
        self.assertIn("benign_synthetic", {str(row["sim_source"]) for row in rows})
        self.assertIn("attack_replay", {str(row["sim_source"]) for row in rows})
        self.assertTrue(all(row.get("record_id") not in {None, ""} for row in rows))
        attack_rows = [row for row in rows if bool(row["gt_attack_active"])]
        self.assertTrue(all(row.get("source_record_id") not in {None, ""} for row in attack_rows))
        synthetic_rows = [row for row in rows if str(row["sim_source"]) == "benign_synthetic"]
        self.assertTrue(all(str(row.get("dataset_name")) == "simulator" for row in synthetic_rows))

    def test_benign_dominated_mode_varies_attack_counts_across_windows(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            dataset_paths, bindings = build_dataset(Path(tmp_dir), include_benign=True, include_record_id=True)
            exact_pool = AttackReplayPool(
                dataset_paths=dataset_paths,
                uav_dataset_bindings=bindings,
                seed=19,
            )
            exact_mixer = TrafficMixer(exact_pool, seed=19)
            dominated_pool = AttackReplayPool(
                dataset_paths=dataset_paths,
                uav_dataset_bindings=bindings,
                seed=19,
            )
            dominated_mixer = TrafficMixer(dominated_pool, seed=19)

            exact_df = exact_mixer.mix(
                build_context_rows(40),
                attack_type="jamming_proxy",
                window_size=10,
                mixed_window_ratio=0.10,
                benign_dominated=False,
                as_dataframe=True,
            )
            dominated_df = dominated_mixer.mix(
                build_context_rows(40),
                attack_type="jamming_proxy",
                window_size=10,
                mixed_window_ratio=0.10,
                benign_dominated=True,
                as_dataframe=True,
            )

        self.assertEqual(per_window_attack_counts(exact_df, 10), [1, 1, 1, 1])
        dominated_counts = per_window_attack_counts(dominated_df, 10)
        self.assertEqual(len(dominated_counts), 4)
        self.assertTrue(any(count != 1 for count in dominated_counts))


if __name__ == "__main__":
    unittest.main()
