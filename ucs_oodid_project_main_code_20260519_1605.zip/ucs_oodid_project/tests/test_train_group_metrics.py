from __future__ import annotations

import contextlib
import importlib.util
import io
import json
import unittest
from pathlib import Path

import numpy as np
import pandas as pd

from ucs_oodid.windowing import WindowedData

ROOT = Path(__file__).resolve().parents[1]
MODULE_PATH = ROOT / "scripts" / "train.py"
SPEC = importlib.util.spec_from_file_location("train_script", MODULE_PATH)
train_script = importlib.util.module_from_spec(SPEC)
assert SPEC is not None and SPEC.loader is not None
SPEC.loader.exec_module(train_script)


def make_windows(group_ids=None):
    return WindowedData(
        x=np.zeros((4, 1, 2), dtype=np.float32),
        y=np.asarray(
            [
                [1.0, 0.0],
                [0.0, 1.0],
                [1.0, 0.0],
                [0.0, 1.0],
            ],
            dtype=np.float32,
        ),
        record_indices=np.asarray([[0], [1], [2], [3]], dtype=np.int64),
        record_ids=np.asarray([["r0"], ["r1"], ["r2"], ["r3"]], dtype=object),
        ood=np.zeros(4, dtype=bool),
        group_ids=None if group_ids is None else np.asarray(group_ids, dtype=object),
    )


class TrainGroupMetricTests(unittest.TestCase):
    def test_encoder_ablation_helpers_report_branch_flags_and_graph_variant(self):
        self.assertTrue(train_script.temporal_enabled_for_ablation("full"))
        self.assertTrue(train_script.graph_enabled_for_ablation("full"))
        self.assertTrue(train_script.temporal_enabled_for_ablation("transformer_only"))
        self.assertFalse(train_script.graph_enabled_for_ablation("transformer_only"))
        self.assertFalse(train_script.temporal_enabled_for_ablation("gcn_only"))
        self.assertTrue(train_script.graph_enabled_for_ablation("gcn_only"))
        self.assertFalse(train_script.graph_enabled_for_ablation("mlp_only"))
        self.assertEqual(train_script.graph_neighbor_strategy_for_ablation("random_graph"), "random")
        self.assertEqual(train_script.effective_graph_variant("transformer_only", "sym_weighted"), "disabled")
        self.assertEqual(train_script.effective_graph_variant("mlp_only", "sym_weighted"), "disabled")
        self.assertEqual(train_script.effective_graph_variant("random_graph", "sym_weighted"), "random_graph")
        self.assertEqual(train_script.effective_graph_variant("full", "sym_weighted"), "sym_weighted")

    def test_infer_method_name_matches_comparison_aliases(self):
        self.assertEqual(train_script.infer_method_name("gcn_only", "mean", "global"), "gcn_only")
        self.assertEqual(train_script.infer_method_name("random_graph", "mean", "global"), "random_graph")
        self.assertEqual(train_script.infer_method_name("full", "mean", "global"), "hypervision_proxy")
        self.assertEqual(train_script.infer_method_name("transformer_only", "correlation_aware", "global"), "recda_proxy")
        self.assertEqual(
            train_script.infer_method_name("transformer_only", "correlation_aware", "group", "conservative"),
            "ucs_oodid",
        )
        self.assertEqual(train_script.infer_method_name("transformer_only", "mean", "global"), "transformer_only_mean")

    def test_compute_id_metrics_by_group_returns_grouped_multilabel_metrics(self):
        windows = make_windows(group_ids=["uav_01", "uav_01", "uav_02", "uav_02"])
        probs = np.asarray(
            [
                [0.9, 0.2],
                [0.2, 0.9],
                [0.8, 0.7],
                [0.7, 0.1],
            ],
            dtype=np.float32,
        )
        thresholds = np.asarray([0.5, 0.5], dtype=np.float32)

        grouped = train_script.compute_id_metrics_by_group(windows, probs, thresholds)

        self.assertEqual(set(grouped), {"uav_01", "uav_02"})
        self.assertEqual(grouped["uav_01"]["windows"], 2)
        self.assertEqual(grouped["uav_02"]["windows"], 2)
        expected_uav_01 = train_script.multilabel_metrics(windows.y[:2], probs[:2], thresholds)
        expected_uav_02 = train_script.multilabel_metrics(windows.y[2:], probs[2:], thresholds)
        self.assertEqual(grouped["uav_01"]["micro_f1"], expected_uav_01["micro_f1"])
        self.assertEqual(grouped["uav_02"]["macro_f1"], expected_uav_02["macro_f1"])
        self.assertEqual(train_script.compute_id_metrics_by_group(make_windows(), probs, thresholds), {})

    def test_compute_id_metrics_by_group_reports_present_class_statistics(self):
        label_names = ["attack_a", "attack_b", "attack_c", "attack_d", "attack_e"]
        windows = WindowedData(
            x=np.zeros((6, 1, 2), dtype=np.float32),
            y=np.asarray(
                [
                    [1.0, 0.0, 0.0, 0.0, 0.0],
                    [0.0, 1.0, 0.0, 0.0, 0.0],
                    [1.0, 0.0, 0.0, 0.0, 0.0],
                    [0.0, 1.0, 0.0, 0.0, 0.0],
                    [0.0, 0.0, 1.0, 0.0, 0.0],
                    [0.0, 0.0, 0.0, 0.0, 0.0],
                ],
                dtype=np.float32,
            ),
            record_indices=np.asarray([[0], [1], [2], [3], [4], [5]], dtype=np.int64),
            record_ids=np.asarray([["r0"], ["r1"], ["r2"], ["r3"], ["r4"], ["r5"]], dtype=object),
            ood=np.zeros(6, dtype=bool),
            group_ids=np.asarray(["uav_01", "uav_01", "uav_01", "uav_01", "uav_02", "uav_02"], dtype=object),
        )
        probs = np.asarray(
            [
                [0.9, 0.1, 0.7, 0.1, 0.1],
                [0.1, 0.9, 0.1, 0.8, 0.1],
                [0.9, 0.1, 0.1, 0.1, 0.9],
                [0.1, 0.9, 0.1, 0.1, 0.1],
                [0.1, 0.1, 0.9, 0.1, 0.1],
                [0.1, 0.1, 0.1, 0.1, 0.1],
            ],
            dtype=np.float32,
        )
        thresholds = np.full(len(label_names), 0.5, dtype=np.float32)

        grouped = train_script.compute_id_metrics_by_group(
            windows,
            probs,
            thresholds,
            label_names=label_names,
            present_class_min_support=1,
        )

        self.assertAlmostEqual(grouped["uav_01"]["macro_f1"], 0.4)
        self.assertAlmostEqual(grouped["uav_01"]["present_class_macro_f1"], 1.0)
        self.assertEqual(grouped["uav_01"]["present_class_count"], 2)
        self.assertEqual(grouped["uav_01"]["present_class_names"], ["attack_a", "attack_b"])
        self.assertEqual(grouped["uav_01"]["absent_class_count"], 3)
        self.assertEqual(
            grouped["uav_01"]["class_support"],
            {"attack_a": 2, "attack_b": 2, "attack_c": 0, "attack_d": 0, "attack_e": 0},
        )

        grouped_with_min_support = train_script.compute_id_metrics_by_group(
            windows,
            probs,
            thresholds,
            label_names=label_names,
            present_class_min_support=2,
        )

        self.assertTrue(np.isnan(grouped_with_min_support["uav_02"]["present_class_macro_f1"]))
        self.assertEqual(grouped_with_min_support["uav_02"]["present_class_count"], 0)
        self.assertEqual(grouped_with_min_support["uav_02"]["absent_class_count"], 5)

    def test_compute_ood_metrics_by_group_returns_grouped_ood_metrics(self):
        group_ids = np.asarray(["uav_01", "uav_01", "uav_02", "uav_02"], dtype=object)
        y_true_ood = np.asarray([0, 1, 0, 1], dtype=np.int64)
        scores = np.asarray([0.1, 0.9, 0.2, 0.8], dtype=np.float32)
        decisions = np.asarray([0, 1, 0, 1], dtype=np.int64)

        grouped = train_script.compute_ood_metrics_by_group(group_ids, y_true_ood, scores, decisions)

        self.assertEqual(set(grouped), {"uav_01", "uav_02"})
        self.assertEqual(grouped["uav_01"]["known_windows"], 1)
        self.assertEqual(grouped["uav_01"]["ood_windows"], 1)
        self.assertEqual(grouped["uav_02"]["alert_rate"], 0.5)
        expected_uav_01 = train_script.ood_metrics(y_true_ood[:2], scores[:2], decisions[:2])
        expected_uav_02 = train_script.ood_metrics(y_true_ood[2:], scores[2:], decisions[2:])
        self.assertEqual(grouped["uav_01"]["auroc"], expected_uav_01["auroc"])
        self.assertEqual(grouped["uav_02"]["ood_f1"], expected_uav_02["ood_f1"])
        self.assertEqual(train_script.compute_ood_metrics_by_group(None, y_true_ood, scores, decisions), {})

    def test_log_split_summaries_reports_record_and_window_group_counts(self):
        split_frames = {
            "train": pd.DataFrame(
                {
                    "__labels": [["benign"], ["dos"], ["benign"]],
                    "uav_id": ["uav_01", "uav_01", "uav_02"],
                }
            )
        }
        split_windows = {
            "train": WindowedData(
                x=np.zeros((3, 1, 1), dtype=np.float32),
                y=np.zeros((3, 1), dtype=np.float32),
                record_indices=np.asarray([[0], [1], [2]], dtype=np.int64),
                record_ids=np.asarray([["r0"], ["r1"], ["r2"]], dtype=object),
                ood=np.zeros(3, dtype=bool),
                group_ids=np.asarray(["uav_01", "uav_01", "uav_02"], dtype=object),
            )
        }

        with io.StringIO() as buf, contextlib.redirect_stdout(buf):
            train_script.log_split_summaries(
                "split_column",
                split_frames,
                split_windows,
                id_classes=["benign", "dos"],
                group_col="uav_id",
            )
            payload = json.loads(buf.getvalue())

        train_summary = payload["dataset_split_summary"]["splits"]["train"]
        self.assertEqual(train_summary["group_distribution"], {"uav_01": 2, "uav_02": 1})
        self.assertEqual(train_summary["window_group_distribution"], {"uav_01": 2, "uav_02": 1})


if __name__ == "__main__":
    unittest.main()
