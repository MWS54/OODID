from __future__ import annotations

import importlib.util
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

import pandas as pd

from ucs_oodid.baselines import OptionalDependencyUnavailable

ROOT = Path(__file__).resolve().parents[1]
SCRIPT_PATH = ROOT / "scripts" / "train_sklearn_baselines.py"
SPEC = importlib.util.spec_from_file_location("train_sklearn_baselines", SCRIPT_PATH)
train_sklearn_baselines = importlib.util.module_from_spec(SPEC)
assert SPEC is not None and SPEC.loader is not None
SPEC.loader.exec_module(train_sklearn_baselines)


def write_toy_dataset(path: Path) -> None:
    rows = []
    for idx in range(24):
        rows.append(
            {
                "record_id": f"id_{idx}",
                "timestamp": idx,
                "uav_id": "uav_01",
                "label": "dos" if idx % 4 == 0 else "benign",
                "feat_a": float(idx),
                "feat_b": float(idx % 5),
            }
        )
    for idx in range(12):
        rows.append(
            {
                "record_id": f"ood_{idx}",
                "timestamp": 24 + idx,
                "uav_id": "uav_01",
                "label": "evil",
                "feat_a": float(100 + idx),
                "feat_b": float((idx + 1) % 5),
            }
        )
    pd.DataFrame(rows).to_csv(path, index=False)


def make_args(
    input_path: Path,
    output_dir: Path,
    baseline: str = "random_forest",
    *,
    method_name: str = "",
    display_name: str = "",
) -> SimpleNamespace:
    return SimpleNamespace(
        input=str(input_path),
        output_dir=str(output_dir),
        label_col="label",
        timestamp_col="timestamp",
        record_id_col="record_id",
        group_col="uav_id",
        id_classes="benign,dos",
        ood_classes="evil",
        benign_label="benign",
        allow_ports=False,
        window_mode="count",
        window_size=2,
        stride=1,
        time_window_seconds=2.0,
        adaptive_min_size=2,
        adaptive_max_size=8,
        normalization_mode="global",
        baseline=baseline,
        method_name=method_name,
        display_name=display_name,
        q_ood=0.9,
        seed=42,
    )


class TrainSklearnBaselinesTests(unittest.TestCase):
    def test_proxy_run_writes_eval_report_and_summary(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            input_path = tmp_path / "toy.csv"
            output_dir = tmp_path / "runs"
            write_toy_dataset(input_path)

            summary = train_sklearn_baselines.run_selected_baselines(
                make_args(
                    input_path,
                    output_dir,
                    baseline="random_forest",
                    method_name="rapier_proxy",
                    display_name="RAPIER-style",
                )
            )

            report_path = output_dir / "rapier_proxy" / "eval_report.json"
            self.assertTrue(report_path.exists())
            report = json.loads(report_path.read_text(encoding="utf-8"))
            self.assertEqual(report["method"], "rapier_proxy")
            self.assertEqual(report["display_name"], "RAPIER-style")
            self.assertEqual(report["backend_name"], "random_forest")
            self.assertEqual(report["ood_score_name"], "uncertainty")
            self.assertIn("micro_f1", report["id_test"])
            self.assertIn("auroc", report["ood_test"])
            self.assertIn("timing", report)
            self.assertEqual(
                report["timing"]["test_windows"],
                report["timing"]["test_id_windows"] + report["timing"]["test_ood_windows"],
            )
            self.assertEqual(report["timing"]["test_id_windows"], report["window_counts"]["test_id"])
            self.assertEqual(report["timing"]["test_ood_windows"], report["window_counts"]["test_ood"])
            self.assertIsNotNone(report["timing"]["average_detection_time_ms"])
            self.assertIsNotNone(report["timing"]["throughput_windows_per_s"])
            self.assertEqual(summary["requested_baselines"], ["rapier_proxy"])
            self.assertEqual(summary["requested_backends"], ["random_forest"])
            self.assertEqual(summary["successful_baselines"], ["rapier_proxy"])
            self.assertTrue((output_dir / "sklearn_baseline_summary.json").exists())
            self.assertGreater(report["window_counts"]["train"], 0)
            self.assertGreater(report["window_counts"]["test_ood"], 0)

    def test_build_timing_report_returns_null_rates_for_empty_test_set(self):
        timing = train_sklearn_baselines._build_timing_report(0, 0, 0.0)

        self.assertEqual(timing["test_id_windows"], 0)
        self.assertEqual(timing["test_ood_windows"], 0)
        self.assertEqual(timing["test_windows"], 0)
        self.assertEqual(timing["detection_time_s"], 0.0)
        self.assertIsNone(timing["average_detection_time_ms"])
        self.assertIsNone(timing["throughput_windows_per_s"])

    def test_proxy_alias_resolves_to_backend_and_display_name(self):
        requested = train_sklearn_baselines._resolve_requested_baselines("rapier_proxy")

        self.assertEqual(len(requested), 1)
        self.assertEqual(requested[0].output_name, "rapier_proxy")
        self.assertEqual(requested[0].backend_name, "random_forest")
        self.assertEqual(requested[0].display_name, "RAPIER-style")

    def test_all_mode_records_skipped_xgboost(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            input_path = tmp_path / "toy.csv"
            output_dir = tmp_path / "runs"
            write_toy_dataset(input_path)
            args = make_args(input_path, output_dir, baseline="all")

            with mock.patch.object(train_sklearn_baselines, "BASELINE_ORDER", ("xgboost",)):
                with mock.patch.object(
                    train_sklearn_baselines,
                    "make_baseline",
                    side_effect=OptionalDependencyUnavailable("xgboost missing for test"),
                ):
                    summary = train_sklearn_baselines.run_selected_baselines(args)

            skipped_path = output_dir / "skipped_baselines.json"
            self.assertTrue(skipped_path.exists())
            skipped = json.loads(skipped_path.read_text(encoding="utf-8"))
            self.assertEqual(len(skipped), 1)
            self.assertEqual(skipped[0]["baseline"], "xgboost")
            self.assertIn("xgboost missing for test", skipped[0]["reason"])
            self.assertEqual(summary["successful_baselines"], [])
            self.assertEqual(summary["skipped_baselines"], skipped)


if __name__ == "__main__":
    unittest.main()
