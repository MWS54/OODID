from __future__ import annotations

from dataclasses import dataclass, field
import math
from pathlib import Path
import random
from typing import Any, Mapping, Sequence

import pandas as pd

from ..dataset_registry import (
    DATASET_METADATA_BY_NAME,
    DEFAULT_ATTACK_DATASET_PATHS,
    DEFAULT_UAV_DATASET_BINDINGS,
    canonical_dataset_name,
    dataset_name_for_uav,
)

ROOT = Path(__file__).resolve().parents[2]

ATTACK_REPLAY_MODES: tuple[str, ...] = ("sequential", "random", "loop")

ATTACK_TYPE_LABEL_ALIASES: dict[str, tuple[str, ...]] = {
    "flood": ("icmp_flooding", "udp_flooding", "dos", "ddos"),
    "scan": ("recon_scanning", "analysis"),
    "replay": ("replay", "reply"),
    "reply": ("replay", "reply"),
    "command_injection": (
        "injection",
        "payload_manipulation",
        "fake_landing",
        "evil",
        "unauthorized_udp",
        "backdoor",
        "shellcode",
        "exploits",
        "fuzzers",
        "worms",
        "bruteforce",
        "deauthentication",
        "sybil",
        "blackhole",
        "wormhole",
    ),
    "jamming_proxy": ("jamming",),
}

ATTACK_LABEL_CANONICAL_MAP: dict[str, str] = {
    "reply": "replay",
}

BENIGN_REPLAY_LABEL_ALIASES: tuple[str, ...] = (
    "benign",
    "normal",
    "background",
    "legitimate",
    "none",
    "0",
)

SOURCE_FIELD_RENAMES: dict[str, str] = {
    "timestamp": "source_timestamp",
    "record_id": "source_record_id",
    "uav_id": "source_uav_id",
    "dataset_name": "source_dataset_name",
}

SIM_CONTEXT_FIELD_RENAMES: dict[str, str] = {
    "mission_phase": "sim_mission_phase",
    "mission_context": "sim_mission_context",
    "battery_soc": "sim_battery_soc",
    "speed": "sim_speed",
    "altitude": "sim_altitude",
    "rssi": "sim_rssi",
    "snr": "sim_snr",
    "latency_ms": "sim_latency_ms",
    "loss_rate": "sim_loss_rate",
    "distance_to_gcs": "sim_distance_to_gcs",
    "wind_level": "sim_wind_level",
    "obstacle_factor": "sim_obstacle_factor",
    "bytes_up": "sim_bytes_up",
    "bytes_down": "sim_bytes_down",
    "cpu_load": "sim_cpu_load",
    "board_temperature_c": "sim_board_temperature_c",
    "response_action": "sim_response_action",
    "response_time": "sim_response_time",
    "response_reason": "sim_response_reason",
    "flight_energy_wh": "sim_flight_energy_wh",
    "communication_energy_wh": "sim_communication_energy_wh",
    "detection_energy_wh": "sim_detection_energy_wh",
    "total_energy_wh": "sim_total_energy_wh",
    "cumulative_energy_wh": "sim_cumulative_energy_wh",
}

EXTERNAL_OOD_SIMULATION_ROLE = "external_ood"
EXTERNAL_OOD_SOURCE_NOTE = "External OOD/generalization source, not real UAV flight traffic."


def _ordered_unique(values: Sequence[str]) -> list[str]:
    ordered: list[str] = []
    seen: set[str] = set()
    for value in values:
        text = str(value)
        if text not in seen:
            ordered.append(text)
            seen.add(text)
    return ordered


def _normalize_token(value: object) -> str:
    return str(value).strip().lower()


def _clean_text(value: object) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except TypeError:
        pass
    return str(value).strip()


def _canonicalize_attack_label(value: object) -> str:
    normalized = _normalize_token(value)
    return ATTACK_LABEL_CANONICAL_MAP.get(normalized, normalized)


def _normalize_requested_values(value: str | Sequence[str] | None) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        parts = value.split(",")
    else:
        parts = []
        for item in value:
            parts.extend(str(item).split(","))
    return [str(item).strip() for item in parts if str(item).strip()]


def _resolve_path(value: str | Path) -> Path:
    candidate = Path(value).expanduser()
    if candidate.is_absolute():
        return candidate
    return (ROOT / candidate).resolve()


def _pythonize(value: object) -> object:
    try:
        if pd.isna(value):
            return None
    except TypeError:
        pass
    if hasattr(value, "item"):
        try:
            return value.item()
        except Exception:
            return value
    return value


def _normalize_sim_fields(sim_fields: Mapping[str, Any] | None) -> dict[str, Any]:
    if not sim_fields:
        return {}
    payload: dict[str, Any] = {}
    for key, value in sim_fields.items():
        column_name = str(key)
        payload[SIM_CONTEXT_FIELD_RENAMES.get(column_name, column_name)] = _pythonize(value)
    return payload


def resolve_simulation_source_metadata(
    *,
    dataset_name: str | None = None,
    uav_id: str | None = None,
    source_type: object | None = None,
    simulation_role: object | None = None,
    source_note: object | None = None,
) -> dict[str, object]:
    resolved_dataset_name = canonical_dataset_name(_clean_text(dataset_name))
    if not resolved_dataset_name and _clean_text(uav_id):
        resolved_dataset_name = canonical_dataset_name(dataset_name_for_uav(_clean_text(uav_id)))
    metadata = dict(DATASET_METADATA_BY_NAME.get(resolved_dataset_name, {}))

    resolved_source_type = _clean_text(source_type) or _clean_text(metadata.get("source_type"))
    resolved_simulation_role = _clean_text(simulation_role) or _clean_text(metadata.get("simulation_role"))
    if not resolved_simulation_role and resolved_source_type == "external_non_uav":
        resolved_simulation_role = EXTERNAL_OOD_SIMULATION_ROLE

    resolved_source_note = _clean_text(source_note) or _clean_text(metadata.get("source_note"))
    if not resolved_source_note and resolved_simulation_role == EXTERNAL_OOD_SIMULATION_ROLE:
        resolved_source_note = EXTERNAL_OOD_SOURCE_NOTE

    return {
        "dataset_name": resolved_dataset_name,
        "dataset_display": _clean_text(metadata.get("dataset_display")) or resolved_dataset_name,
        "dataset_role": _clean_text(metadata.get("dataset_role")),
        "source_type": resolved_source_type,
        "simulation_role": resolved_simulation_role,
        "source_note": resolved_source_note,
        "is_external_ood": resolved_simulation_role == EXTERNAL_OOD_SIMULATION_ROLE,
    }


def _fill_text_column(frame: pd.DataFrame, column_name: str, default_value: str) -> pd.DataFrame:
    if not default_value:
        return frame
    if column_name not in frame.columns:
        frame[column_name] = default_value
        return frame

    mask = frame[column_name].map(lambda value: not _clean_text(value))
    if bool(mask.any()):
        frame.loc[mask, column_name] = default_value
    return frame


@dataclass
class _ReplayDataset:
    name: str
    csv_path: Path
    label_col: str = "label"
    source_metadata: dict[str, object] = field(default_factory=dict)
    _attack_frame: pd.DataFrame | None = field(default=None, init=False, repr=False)
    _selection_cache: dict[tuple[str, ...], pd.DataFrame] = field(default_factory=dict, init=False, repr=False)

    def attack_frame(self) -> pd.DataFrame:
        if self._attack_frame is None:
            if not self.csv_path.exists():
                raise FileNotFoundError(f"Attack replay dataset not found: {self.csv_path}")
            frame = pd.read_csv(self.csv_path, low_memory=False)
            if self.label_col not in frame.columns:
                raise ValueError(f"{self.csv_path} is missing required label column {self.label_col!r}")
            work = frame.copy()
            work["_attack_replay_order"] = list(range(len(work)))
            work["_attack_replay_label"] = work[self.label_col].map(_normalize_token)
            work = _fill_text_column(
                work,
                "source_type",
                _clean_text(self.source_metadata.get("source_type")) or "uav",
            )
            work = _fill_text_column(
                work,
                "simulation_role",
                _clean_text(self.source_metadata.get("simulation_role")) or "uav_replay",
            )
            work = _fill_text_column(
                work,
                "source_note",
                _clean_text(self.source_metadata.get("source_note")),
            )
            work = work[~work["_attack_replay_label"].isin(BENIGN_REPLAY_LABEL_ALIASES)].reset_index(drop=True)
            self._attack_frame = work
        return self._attack_frame

    def available_labels(self) -> list[str]:
        frame = self.attack_frame()
        labels = [str(value).strip() for value in frame[self.label_col].tolist() if str(value).strip()]
        return _ordered_unique(labels)

    def select(self, normalized_labels: Sequence[str]) -> pd.DataFrame:
        key = tuple(_ordered_unique(sorted(_normalize_token(value) for value in normalized_labels if _normalize_token(value))))
        if key not in self._selection_cache:
            frame = self.attack_frame()
            if key:
                subset = frame[frame["_attack_replay_label"].isin(key)].copy()
            else:
                subset = frame.copy()
            subset = subset.sort_values("_attack_replay_order", kind="stable").reset_index(drop=True)
            self._selection_cache[key] = subset
        return self._selection_cache[key]


class AttackReplayPool:
    """Replay attack rows from prepared per-UAV CSV datasets."""

    def __init__(
        self,
        dataset_paths: Mapping[str, str | Path] | None = None,
        *,
        uav_dataset_bindings: Mapping[str, str] | None = None,
        label_col: str = "label",
        seed: int = 42,
    ):
        resolved_paths = dataset_paths or DEFAULT_ATTACK_DATASET_PATHS
        self.label_col = str(label_col)
        self.rng = random.Random(int(seed))
        self.datasets: dict[str, _ReplayDataset] = {}
        for dataset_name, raw_path in resolved_paths.items():
            resolved = _resolve_path(raw_path)
            if not resolved.exists():
                raise FileNotFoundError(f"Attack replay dataset not found: {resolved}")
            canonical_name = str(dataset_name).strip()
            self.datasets[canonical_name] = _ReplayDataset(
                name=canonical_name,
                csv_path=resolved,
                label_col=self.label_col,
                source_metadata=resolve_simulation_source_metadata(dataset_name=canonical_name),
            )
        bindings = uav_dataset_bindings or DEFAULT_UAV_DATASET_BINDINGS
        self.uav_dataset_bindings = {
            str(uav_id).strip(): str(dataset_name).strip()
            for uav_id, dataset_name in bindings.items()
            if str(dataset_name).strip() in self.datasets
        }
        self._cursor_by_selection: dict[tuple[str, str, tuple[str, ...], str], int] = {}

    @classmethod
    def from_default_paths(
        cls,
        *,
        label_col: str = "label",
        seed: int = 42,
        allow_missing: bool = False,
    ) -> "AttackReplayPool | None":
        dataset_paths: dict[str, Path] = {}
        missing: list[str] = []
        for dataset_name, csv_path in DEFAULT_ATTACK_DATASET_PATHS.items():
            if csv_path.exists():
                dataset_paths[dataset_name] = csv_path
            else:
                missing.append(f"{dataset_name}: {csv_path}")
        if missing and not allow_missing:
            raise FileNotFoundError(f"Missing default attack replay dataset(s): {missing}")
        if not dataset_paths:
            return None
        bindings = {
            uav_id: dataset_name
            for uav_id, dataset_name in DEFAULT_UAV_DATASET_BINDINGS.items()
            if dataset_name in dataset_paths
        }
        if not bindings:
            return None
        return cls(
            dataset_paths=dataset_paths,
            uav_dataset_bindings=bindings,
            label_col=label_col,
            seed=seed,
        )

    def reset(self) -> None:
        self._cursor_by_selection.clear()

    def has_binding(self, uav_id: str) -> bool:
        return self._dataset_for_uav(uav_id, strict=False) is not None

    def dataset_name_for_uav(self, uav_id: str) -> str:
        dataset = self._dataset_for_uav(uav_id, strict=True)
        return dataset.name

    def available_labels(self, uav_id: str) -> list[str]:
        return self._dataset_for_uav(uav_id, strict=True).available_labels()

    def sample_attack_records(
        self,
        uav_id: str,
        *,
        dataset_name: str | None = None,
        label: str | Sequence[str] | None = None,
        attack_type: str | Sequence[str] | None = None,
        attack_intensity: int | float = 1,
        attack_replay_mode: str = "sequential",
        sim_fields: Mapping[str, Any] | None = None,
    ) -> list[dict[str, Any]]:
        dataset = self._resolve_dataset(uav_id, dataset_name=dataset_name)
        mode = self._canonicalize_mode(attack_replay_mode)
        count = self._resolve_replay_count(attack_intensity)
        if count <= 0:
            return []

        normalized_labels = self._resolve_requested_labels(
            dataset,
            label=label,
            attack_type=attack_type,
        )
        subset = dataset.select(normalized_labels)
        if subset.empty:
            return []

        selection_key = (str(uav_id).strip(), dataset.name, tuple(normalized_labels), mode)
        indices = self._select_indices(selection_key, len(subset), count=count, mode=mode)
        rows: list[dict[str, Any]] = []
        for index in indices:
            rows.append(
                self._build_payload(
                    subset.iloc[int(index)],
                    uav_id=str(uav_id).strip(),
                    dataset_name=dataset.name,
                    sim_fields=sim_fields,
                )
            )
        return rows

    def _dataset_for_uav(self, uav_id: str, *, strict: bool) -> _ReplayDataset | None:
        canonical_uav_id = str(uav_id).strip()
        dataset_name = self.uav_dataset_bindings.get(canonical_uav_id)
        if dataset_name is None:
            if strict:
                raise KeyError(f"No attack replay dataset is bound to UAV {canonical_uav_id!r}")
            return None
        dataset = self.datasets.get(dataset_name)
        if dataset is None:
            if strict:
                raise KeyError(f"Bound attack replay dataset {dataset_name!r} is unavailable for UAV {canonical_uav_id!r}")
            return None
        return dataset

    def _dataset_for_name(self, dataset_name: str, *, strict: bool) -> _ReplayDataset | None:
        canonical_name = str(dataset_name).strip()
        dataset = self.datasets.get(canonical_name)
        if dataset is None:
            if strict:
                raise KeyError(f"Attack replay dataset {canonical_name!r} is unavailable")
            return None
        return dataset

    def _resolve_dataset(self, uav_id: str, *, dataset_name: str | None) -> _ReplayDataset:
        if dataset_name is not None and str(dataset_name).strip():
            return self._dataset_for_name(str(dataset_name), strict=True)
        return self._dataset_for_uav(uav_id, strict=True)

    def _canonicalize_mode(self, attack_replay_mode: str) -> str:
        mode = str(attack_replay_mode).strip().lower()
        if mode not in ATTACK_REPLAY_MODES:
            raise ValueError(f"Unsupported attack replay mode: {attack_replay_mode}")
        return mode

    def _resolve_replay_count(self, attack_intensity: int | float) -> int:
        intensity = float(attack_intensity)
        if intensity <= 0.0:
            return 0
        return max(int(math.ceil(intensity)), 1)

    def _resolve_requested_labels(
        self,
        dataset: _ReplayDataset,
        *,
        label: str | Sequence[str] | None,
        attack_type: str | Sequence[str] | None,
    ) -> list[str]:
        requested = _normalize_requested_values(label) + _normalize_requested_values(attack_type)
        if not requested:
            return []

        available_original = dataset.available_labels()
        available_normalized = {_normalize_token(value) for value in available_original}
        resolved: list[str] = []
        unresolved: list[str] = []
        for item in requested:
            normalized = _normalize_token(item)
            candidates = ATTACK_TYPE_LABEL_ALIASES.get(normalized, (normalized,))
            matched = [candidate for candidate in candidates if candidate in available_normalized]
            if matched:
                resolved.extend(matched)
            else:
                unresolved.append(str(item))
        normalized_unique = _ordered_unique(resolved)
        if normalized_unique:
            return normalized_unique
        available_display = ", ".join(available_original)
        raise ValueError(
            f"Requested labels/attack types {unresolved} are unavailable in dataset {dataset.name!r}. "
            f"Available attack labels: {available_display}"
        )

    def _select_indices(
        self,
        selection_key: tuple[str, str, tuple[str, ...], str],
        total_rows: int,
        *,
        count: int,
        mode: str,
    ) -> list[int]:
        if total_rows <= 0 or count <= 0:
            return []
        if mode == "random":
            return [self.rng.randrange(total_rows) for _ in range(count)]

        cursor = int(self._cursor_by_selection.get(selection_key, 0))
        if mode == "sequential":
            if cursor >= total_rows:
                return []
            end = min(cursor + count, total_rows)
            self._cursor_by_selection[selection_key] = end
            return list(range(cursor, end))

        indices = [(cursor + offset) % total_rows for offset in range(count)]
        self._cursor_by_selection[selection_key] = (cursor + count) % total_rows
        return indices

    def _build_payload(
        self,
        row: pd.Series,
        *,
        uav_id: str,
        dataset_name: str,
        sim_fields: Mapping[str, Any] | None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {}
        for column, value in row.items():
            column_name = str(column)
            if column_name.startswith("_attack_replay_"):
                continue
            payload[SOURCE_FIELD_RENAMES.get(column_name, column_name)] = _pythonize(value)
        attack_label = _canonicalize_attack_label(row[self.label_col])
        if sim_fields:
            payload.update(_normalize_sim_fields(sim_fields))
        payload["uav_id"] = uav_id
        payload["dataset_name"] = dataset_name
        payload["attack_active"] = True
        payload["attack_type"] = attack_label
        payload["attack_source_dataset"] = dataset_name
        return payload


__all__ = [
    "ATTACK_REPLAY_MODES",
    "ATTACK_TYPE_LABEL_ALIASES",
    "AttackReplayPool",
    "DEFAULT_ATTACK_DATASET_PATHS",
    "DEFAULT_UAV_DATASET_BINDINGS",
    "EXTERNAL_OOD_SIMULATION_ROLE",
    "EXTERNAL_OOD_SOURCE_NOTE",
    "resolve_simulation_source_metadata",
]
