from __future__ import annotations

from dataclasses import dataclass

from .entities import Attacker

SUPPORTED_ATTACK_TYPES: tuple[str, ...] = (
    "benign",
    "flood",
    "scan",
    "replay",
    "command_injection",
    "jamming_proxy",
)

ATTACK_TYPE_ALIASES: dict[str, str] = {
    "reply": "replay",
}


@dataclass(frozen=True)
class AttackEvent:
    """Scheduled attack window used by the attack injector."""

    start_s: float
    end_s: float
    attack_type: str
    intensity: float = 1.0
    uav_id: str | None = None
    plan_id: str | None = None
    attack_labels: tuple[str, ...] = ()


@dataclass(frozen=True)
class AttackSnapshot:
    """Attack effects applied during one simulation step."""

    active: bool
    attack_type: str
    intensity: float
    uplink_multiplier: float
    downlink_multiplier: float
    throughput_multiplier: float
    latency_penalty_ms: float
    loss_penalty: float
    snr_penalty_db: float
    detector_load_multiplier: float


class AttackInjector:
    """Convert a time-indexed attack schedule into per-step attack effects."""

    def __init__(self, events: list[AttackEvent] | None = None):
        self.events = sorted(events or [], key=lambda event: (event.start_s, event.end_s))

    def active_event_at(self, sim_time_s: float, *, uav_id: str | None = None) -> AttackEvent | None:
        """Return the active attack event selected for the current simulation time."""

        event: AttackEvent | None = None
        for candidate in self.events:
            if not (candidate.start_s <= sim_time_s < candidate.end_s):
                continue
            if candidate.uav_id not in {None, uav_id}:
                continue
            if event is None or (event.uav_id is None and candidate.uav_id == uav_id):
                event = candidate
        return event

    def snapshot_at(
        self,
        sim_time_s: float,
        *,
        uav_id: str | None = None,
        attacker: Attacker | None = None,
    ) -> AttackSnapshot:
        """Return the active attack profile for the current simulation time."""

        event = self.active_event_at(sim_time_s, uav_id=uav_id)
        snapshot = build_attack_snapshot(
            attack_type="benign" if event is None else event.attack_type,
            intensity=0.0 if event is None else event.intensity,
        )
        if attacker is not None:
            attacker.active = snapshot.active
            attacker.attack_type = snapshot.attack_type
            attacker.intensity = snapshot.intensity
        return snapshot


def build_attack_snapshot(attack_type: str, intensity: float = 1.0) -> AttackSnapshot:
    """Build a deterministic attack effect profile."""

    canonical = _canonicalize_attack_type(attack_type)
    strength = min(max(float(intensity), 0.0), 1.0)
    if canonical == "benign":
        return AttackSnapshot(
            active=False,
            attack_type=canonical,
            intensity=0.0,
            uplink_multiplier=1.0,
            downlink_multiplier=1.0,
            throughput_multiplier=1.0,
            latency_penalty_ms=0.0,
            loss_penalty=0.0,
            snr_penalty_db=0.0,
            detector_load_multiplier=1.0,
        )
    if canonical == "flood":
        return AttackSnapshot(
            active=True,
            attack_type=canonical,
            intensity=strength,
            uplink_multiplier=1.0 + 5.0 * strength,
            downlink_multiplier=1.0 + 4.0 * strength,
            throughput_multiplier=max(0.25, 1.0 - 0.20 * strength),
            latency_penalty_ms=45.0 * strength,
            loss_penalty=0.06 * strength,
            snr_penalty_db=1.0 * strength,
            detector_load_multiplier=1.0 + 1.2 * strength,
        )
    if canonical == "scan":
        return AttackSnapshot(
            active=True,
            attack_type=canonical,
            intensity=strength,
            uplink_multiplier=1.0 + 1.8 * strength,
            downlink_multiplier=1.0 + 0.6 * strength,
            throughput_multiplier=max(0.40, 1.0 - 0.05 * strength),
            latency_penalty_ms=12.0 * strength,
            loss_penalty=0.015 * strength,
            snr_penalty_db=0.5 * strength,
            detector_load_multiplier=1.0 + 0.35 * strength,
        )
    if canonical == "replay":
        return AttackSnapshot(
            active=True,
            attack_type=canonical,
            intensity=strength,
            uplink_multiplier=1.0 + 0.4 * strength,
            downlink_multiplier=1.0 + 1.3 * strength,
            throughput_multiplier=max(0.35, 1.0 - 0.10 * strength),
            latency_penalty_ms=18.0 * strength,
            loss_penalty=0.025 * strength,
            snr_penalty_db=0.4 * strength,
            detector_load_multiplier=1.0 + 0.45 * strength,
        )
    if canonical == "command_injection":
        return AttackSnapshot(
            active=True,
            attack_type=canonical,
            intensity=strength,
            uplink_multiplier=1.0 + 0.2 * strength,
            downlink_multiplier=1.0 + 1.8 * strength,
            throughput_multiplier=max(0.35, 1.0 - 0.10 * strength),
            latency_penalty_ms=20.0 * strength,
            loss_penalty=0.030 * strength,
            snr_penalty_db=0.8 * strength,
            detector_load_multiplier=1.0 + 0.60 * strength,
        )
    if canonical == "jamming_proxy":
        return AttackSnapshot(
            active=True,
            attack_type=canonical,
            intensity=strength,
            uplink_multiplier=max(0.20, 1.0 - 0.5 * strength),
            downlink_multiplier=max(0.20, 1.0 - 0.5 * strength),
            throughput_multiplier=max(0.10, 1.0 - 0.60 * strength),
            latency_penalty_ms=80.0 * strength,
            loss_penalty=0.18 * strength,
            snr_penalty_db=10.0 * strength,
            detector_load_multiplier=1.0 + 0.80 * strength,
        )
    raise ValueError(f"Unsupported attack type: {attack_type}")  # pragma: no cover


def _canonicalize_attack_type(attack_type: str) -> str:
    """Validate an attack type string."""

    raw = str(attack_type).strip().lower()
    canonical = ATTACK_TYPE_ALIASES.get(raw, raw)
    if canonical not in SUPPORTED_ATTACK_TYPES:
        raise ValueError(f"Unsupported attack type: {attack_type}")
    return canonical
