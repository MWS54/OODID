from __future__ import annotations

from dataclasses import dataclass
import math
import random

from .attacks import AttackSnapshot, build_attack_snapshot
from .entities import Attacker, GCS, UAV
from .scenario import load_scenario_profile


@dataclass(frozen=True)
class LinkState:
    """Derived channel metrics for one UAV-to-GCS communication step."""

    distance_m: float
    rssi_dbm: float
    snr_db: float
    latency_ms: float
    loss_rate: float
    distance_to_gcs: float = 0.0
    wind_level: float = 0.0
    obstacle_factor: float = 0.0

    def __post_init__(self) -> None:
        if self.distance_to_gcs <= 0.0:
            object.__setattr__(self, "distance_to_gcs", float(self.distance_m))


def simulate_link_state(
    uav: UAV,
    gcs: GCS,
    attack: AttackSnapshot | None = None,
    attacker: Attacker | None = None,
    rng: random.Random | None = None,
) -> LinkState:
    """Simulate the current radio link given geometry and active attack effects."""

    generator = rng or random.Random(0)
    attack_state = attack or build_attack_snapshot("benign")
    distance_m = max(uav.slant_distance_to(gcs.x_m, gcs.y_m, gcs.altitude_m), 1.0)
    wind_level, obstacle_factor = _resolve_environment_factors(uav, rng=generator)
    distance_km = max(distance_m / 1000.0, 1e-6)
    path_loss_db = 32.44 + 20.0 * math.log10(distance_km) + 20.0 * math.log10(gcs.channel_frequency_mhz)
    fading_db = generator.uniform(-1.5, 1.5)
    environmental_rssi_penalty_db = _environmental_penalty(
        uav,
        "wind_rssi_penalty_db",
        wind_level=wind_level,
        obstacle_factor=0.0,
    ) + _environmental_penalty(
        uav,
        "obstacle_rssi_penalty_db",
        wind_level=0.0,
        obstacle_factor=obstacle_factor,
    )
    rssi_dbm = gcs.tx_power_dbm - path_loss_db + fading_db - environmental_rssi_penalty_db

    jammer_penalty_scale = 1.0
    if attacker is not None and attack_state.attack_type == "jamming_proxy" and attack_state.active:
        attacker_distance_m = max(uav.slant_distance_to(attacker.x_m, attacker.y_m, attacker.altitude_m), 1.0)
        jammer_penalty_scale = min(1.0, 250.0 / attacker_distance_m)

    effective_noise_floor_dbm = gcs.noise_floor_dbm + (0.40 * attack_state.snr_penalty_db * jammer_penalty_scale)
    environmental_snr_penalty_db = _environmental_penalty(
        uav,
        "wind_snr_penalty_db",
        wind_level=wind_level,
        obstacle_factor=0.0,
    ) + _environmental_penalty(
        uav,
        "obstacle_snr_penalty_db",
        wind_level=0.0,
        obstacle_factor=obstacle_factor,
    )
    snr_db = (
        rssi_dbm
        - effective_noise_floor_dbm
        - (0.60 * attack_state.snr_penalty_db * jammer_penalty_scale)
        - environmental_snr_penalty_db
    )

    distance_latency_ms = distance_m / 200.0
    poor_link_latency_ms = max(0.0, 18.0 - snr_db) * 1.6
    environmental_latency_ms = _environmental_penalty(
        uav,
        "wind_latency_ms",
        wind_level=wind_level,
        obstacle_factor=0.0,
    ) + _environmental_penalty(
        uav,
        "obstacle_latency_ms",
        wind_level=0.0,
        obstacle_factor=obstacle_factor,
    )
    latency_ms = (
        gcs.processing_latency_ms
        + 4.0
        + distance_latency_ms
        + poor_link_latency_ms
        + environmental_latency_ms
        + attack_state.latency_penalty_ms
    )

    base_loss_rate = 0.003 + (distance_m / 2500.0) * 0.004
    low_snr_loss_rate = max(0.0, 10.0 - snr_db) * 0.008
    environmental_loss_rate = _environmental_penalty(
        uav,
        "wind_loss_rate",
        wind_level=wind_level,
        obstacle_factor=0.0,
    ) + _environmental_penalty(
        uav,
        "obstacle_loss_rate",
        wind_level=0.0,
        obstacle_factor=obstacle_factor,
    )
    loss_rate = (
        base_loss_rate
        + low_snr_loss_rate
        + environmental_loss_rate
        + attack_state.loss_penalty * jammer_penalty_scale
    )
    loss_rate = min(max(loss_rate, 0.0), 0.95)

    return LinkState(
        distance_m=distance_m,
        rssi_dbm=rssi_dbm,
        snr_db=snr_db,
        latency_ms=latency_ms,
        loss_rate=loss_rate,
        distance_to_gcs=distance_m,
        wind_level=wind_level,
        obstacle_factor=obstacle_factor,
    )


def _resolve_environment_factors(uav: UAV, *, rng: random.Random) -> tuple[float, float]:
    """Resolve configured wind and obstacle factors for the current step."""

    profile = load_scenario_profile(uav.metadata.get("scenario_profile_path"))
    channel_cfg = profile.get("channel", {})
    if not isinstance(channel_cfg, dict):
        return 0.0, 0.0

    phase = str(uav.mission_phase)
    mission_context = str(getattr(uav, "mission_context", "surveillance") or "surveillance").strip().lower()
    phase_wind_bias = _mapping_value(channel_cfg.get("mission_phase_wind_bias", {}), phase)
    context_wind_bias = _mapping_value(channel_cfg.get("mission_context_wind_bias", {}), mission_context)
    gust_range = float(channel_cfg.get("gust_range", 0.0))
    wind_sensitivity = float(uav.metadata.get("wind_sensitivity", 1.0))
    wind_level = (
        float(channel_cfg.get("base_wind_level", 0.0))
        + phase_wind_bias
        + context_wind_bias
        + float(uav.metadata.get("wind_bias", 0.0))
        + rng.uniform(-gust_range, gust_range)
    ) * wind_sensitivity
    wind_level = min(max(wind_level, 0.0), float(channel_cfg.get("max_wind_level", 1.0)))

    phase_obstacle_bias = _mapping_value(channel_cfg.get("mission_phase_obstacle_bias", {}), phase)
    context_obstacle_bias = _mapping_value(channel_cfg.get("mission_context_obstacle_bias", {}), mission_context)
    obstacle_altitude_reference_m = max(float(channel_cfg.get("obstacle_altitude_reference_m", 120.0)), 1.0)
    obstacle_altitude_scale = float(channel_cfg.get("obstacle_altitude_scale", 0.0))
    obstacle_sensitivity = float(uav.metadata.get("obstacle_sensitivity", 1.0))
    altitude_factor = max(0.0, 1.0 - (uav.altitude_m / obstacle_altitude_reference_m))
    obstacle_factor = (
        float(channel_cfg.get("obstacle_base_factor", 0.0))
        + phase_obstacle_bias
        + context_obstacle_bias
        + float(uav.metadata.get("obstacle_bias", 0.0))
    )
    obstacle_factor *= (1.0 + obstacle_altitude_scale * altitude_factor) * obstacle_sensitivity
    obstacle_factor = min(max(obstacle_factor, 0.0), 1.0)
    return wind_level, obstacle_factor


def _environmental_penalty(
    uav: UAV,
    key: str,
    *,
    wind_level: float,
    obstacle_factor: float,
) -> float:
    profile = load_scenario_profile(uav.metadata.get("scenario_profile_path"))
    channel_cfg = profile.get("channel", {})
    if not isinstance(channel_cfg, dict):
        return 0.0
    coefficient = float(channel_cfg.get(key, 0.0))
    return (wind_level + obstacle_factor) * coefficient


def _mapping_value(value: object, key: str) -> float:
    if isinstance(value, dict):
        return float(value.get(key, 0.0))
    return 0.0
