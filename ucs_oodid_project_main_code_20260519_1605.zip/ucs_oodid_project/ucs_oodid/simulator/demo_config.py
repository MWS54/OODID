from __future__ import annotations

import copy
from functools import lru_cache
from pathlib import Path
from typing import Any, Mapping

try:
    import yaml
except Exception:  # pragma: no cover
    yaml = None

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_DEMO_SCENE_CONFIG_PATH = ROOT / "configs" / "demo_scene_default.yaml"


def default_demo_scene_config_path() -> str:
    return str(DEFAULT_DEMO_SCENE_CONFIG_PATH)


def resolve_demo_scene_config_path(path: str | Path | None = None) -> Path:
    if path is None or str(path).strip() == "":
        return DEFAULT_DEMO_SCENE_CONFIG_PATH
    candidate = Path(path).expanduser()
    if candidate.is_absolute():
        return candidate
    return ROOT / candidate


@lru_cache(maxsize=16)
def _load_yaml_file(path_text: str) -> dict[str, Any]:
    if yaml is None:
        raise RuntimeError("pyyaml is required to load demo scene configs")
    resolved = Path(path_text)
    with resolved.open("r", encoding="utf-8") as handle:
        raw = yaml.safe_load(handle) or {}
    if not isinstance(raw, Mapping):
        raise ValueError(f"Demo scene config must be a mapping: {resolved}")
    return dict(raw)


def _deep_merge(base: dict[str, Any], overlay: Mapping[str, Any]) -> dict[str, Any]:
    for key, value in overlay.items():
        if isinstance(value, Mapping) and isinstance(base.get(key), dict):
            base[key] = _deep_merge(dict(base[key]), value)
        else:
            base[key] = copy.deepcopy(value)
    return base


def load_demo_scene_config(path: str | Path | None = None) -> dict[str, Any]:
    default_path = DEFAULT_DEMO_SCENE_CONFIG_PATH.resolve()
    base = copy.deepcopy(_load_yaml_file(str(default_path)))
    resolved = resolve_demo_scene_config_path(path).resolve()
    if resolved == default_path:
        return base
    overlay = _load_yaml_file(str(resolved))
    return _deep_merge(base, overlay)


def build_demo_cli_defaults(config: Mapping[str, Any]) -> dict[str, Any]:
    defaults = dict(config)
    defaults["online_detection"] = bool(defaults.get("enable_online_detection", defaults.get("online_detection", False)))
    defaults["artifact"] = str(defaults.get("artifact_path", defaults.get("artifact", "")) or "")
    defaults.setdefault("uav_id", "uav_demo_01")
    defaults.setdefault("head", 5)
    defaults.setdefault("artifact_out", "")
    defaults.setdefault("output_json", "")
    return defaults
