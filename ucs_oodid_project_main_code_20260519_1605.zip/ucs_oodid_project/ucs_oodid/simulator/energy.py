from __future__ import annotations

from dataclasses import dataclass

from .attacks import AttackSnapshot, build_attack_snapshot
from .channel import LinkState
from .entities import UAV
from .scenario import load_scenario_profile


@dataclass(frozen=True)
class ComputeLoadState:
    """Instantaneous onboard compute state used for detection-energy estimates."""

    cpu_load: float
    board_temperature_c: float
    throttle_factor: float


@dataclass(frozen=True)
class EnergyBreakdown:
    """Energy consumption estimate for a single simulation step."""

    flight_wh: float
    communication_wh: float
    detection_wh: float
    total_wh: float
    cpu_load: float = 0.0
    board_temperature_c: float = 0.0


def estimate_flight_power_w(uav: UAV) -> float:
    """Estimate propulsion power in watts from the current mission phase."""

    phase = uav.mission_phase
    altitude_factor = 0.015 * uav.altitude_m
    base_power_w = 0.0
    if phase == "idle":
        base_power_w = 8.0
    elif phase == "takeoff":
        base_power_w = 165.0 + altitude_factor
    elif phase == "climb":
        base_power_w = 180.0 + altitude_factor
    elif phase == "cruise":
        base_power_w = 135.0 + 1.1 * uav.speed_mps + altitude_factor
    elif phase == "hover":
        base_power_w = 145.0 + altitude_factor
    elif phase == "return_home":
        base_power_w = 140.0 + 0.9 * uav.speed_mps + altitude_factor
    elif phase == "land":
        base_power_w = 105.0 + altitude_factor
    elif phase == "emergency":
        base_power_w = 165.0 + 0.6 * uav.speed_mps + altitude_factor
    else:
        raise ValueError(f"Unsupported mission phase: {phase}")
    return base_power_w * float(uav.metadata.get("payload_power_factor", 1.0))


def estimate_communication_power_w(bytes_up: int, bytes_down: int, dt_s: float, link: LinkState) -> float:
    """Estimate communication power in watts from traffic volume and link quality."""

    if dt_s <= 0.0:
        raise ValueError("dt_s must be positive")
    throughput_kbps = 8.0 * (max(bytes_up, 0) + max(bytes_down, 0)) / (1000.0 * dt_s)
    return 3.0 + 0.02 * throughput_kbps + 12.0 * link.loss_rate + max(0.0, 25.0 - link.snr_db) * 0.08


def estimate_detection_power_w(
    bytes_up: int,
    bytes_down: int,
    dt_s: float,
    attack: AttackSnapshot | None = None,
    *,
    link: LinkState | None = None,
    uav: UAV | None = None,
    compute_state: ComputeLoadState | None = None,
) -> float:
    """Estimate detection/inference power in watts for the current time step."""

    if dt_s <= 0.0:
        raise ValueError("dt_s must be positive")
    attack_state = attack or build_attack_snapshot("benign")
    throughput_kbps = 8.0 * (max(bytes_up, 0) + max(bytes_down, 0)) / (1000.0 * dt_s)
    if compute_state is None or uav is None or link is None:
        return 4.5 * attack_state.detector_load_multiplier + 0.01 * throughput_kbps

    profile = load_scenario_profile(uav.metadata.get("scenario_profile_path"))
    compute_cfg = profile.get("compute", {})
    if not isinstance(compute_cfg, dict):
        compute_cfg = {}
    ambient_temperature_c = float(compute_cfg.get("ambient_temperature_c", 30.0))
    thermal_delta_c = max(0.0, compute_state.board_temperature_c - ambient_temperature_c)
    power_w = float(compute_cfg.get("detection_power_base_w", 2.8))
    power_w += float(compute_cfg.get("detection_power_cpu_scale_w", 4.6)) * compute_state.cpu_load
    power_w += float(compute_cfg.get("detection_power_thermal_scale_w", 0.12)) * thermal_delta_c
    power_w += float(compute_cfg.get("detection_power_loss_scale_w", 0.7)) * float(link.loss_rate)
    power_w *= compute_state.throttle_factor
    return max(power_w, 0.1)


def estimate_compute_state(
    dt_s: float,
    uav: UAV,
    link: LinkState,
    bytes_up: int,
    bytes_down: int,
    attack: AttackSnapshot | None = None,
) -> ComputeLoadState:
    """Estimate onboard CPU and thermal state for the current step."""

    if dt_s <= 0.0:
        raise ValueError("dt_s must be positive")

    attack_state = attack or build_attack_snapshot("benign")
    profile = load_scenario_profile(uav.metadata.get("scenario_profile_path"))
    compute_cfg = profile.get("compute", {})
    if not isinstance(compute_cfg, dict):
        compute_cfg = {}

    mission_context = str(getattr(uav, "mission_context", "surveillance") or "surveillance").strip().lower()
    throughput_kbps = 8.0 * (max(bytes_up, 0) + max(bytes_down, 0)) / (1000.0 * dt_s)
    phase_cpu_bias = _mapping_value(compute_cfg.get("phase_cpu_bias", {}), str(uav.mission_phase))
    mission_cpu_bias = _mapping_value(compute_cfg.get("mission_cpu_bias", {}), mission_context)
    cpu_load = float(compute_cfg.get("baseline_cpu_load", 0.18))
    cpu_load += phase_cpu_bias + mission_cpu_bias
    cpu_load += throughput_kbps * float(compute_cfg.get("throughput_cpu_per_kbps", 0.0))
    cpu_load += max(0.0, 10.0 - float(link.snr_db)) / 10.0 * float(compute_cfg.get("link_quality_cpu_gain", 0.0))
    cpu_load += max(0.0, attack_state.detector_load_multiplier - 1.0) * float(
        compute_cfg.get("detector_attack_multiplier", 0.0)
    )
    cpu_load += float(uav.metadata.get("compute_bias", 0.0))
    cpu_load = min(max(cpu_load, 0.0), float(compute_cfg.get("max_cpu_load", 0.96)))

    ambient_temperature_c = float(compute_cfg.get("ambient_temperature_c", 30.0))
    previous_temperature_c = float(getattr(uav, "board_temperature_c", ambient_temperature_c))
    target_temperature_c = ambient_temperature_c
    target_temperature_c += cpu_load * float(compute_cfg.get("thermal_gain_per_cpu", 18.0))
    target_temperature_c += attack_state.intensity * float(compute_cfg.get("thermal_gain_per_attack", 0.0))
    target_temperature_c -= float(getattr(link, "wind_level", 0.0)) * float(compute_cfg.get("cooling_per_wind_level", 0.0))
    thermal_response = min(max(dt_s * float(compute_cfg.get("thermal_response", 0.22)), 0.0), 1.0)
    board_temperature_c = previous_temperature_c + (target_temperature_c - previous_temperature_c) * thermal_response
    board_temperature_c = max(board_temperature_c, ambient_temperature_c)

    thermal_throttle_start_c = float(compute_cfg.get("thermal_throttle_start_c", 72.0))
    thermal_throttle_power_scale = float(compute_cfg.get("thermal_throttle_power_scale", 0.18))
    throttle_factor = 1.0 - max(0.0, board_temperature_c - thermal_throttle_start_c) * thermal_throttle_power_scale / 100.0
    throttle_factor = min(max(throttle_factor, 0.70), 1.0)
    return ComputeLoadState(
        cpu_load=cpu_load,
        board_temperature_c=board_temperature_c,
        throttle_factor=throttle_factor,
    )


def estimate_step_energy(
    dt_s: float,
    uav: UAV,
    link: LinkState,
    bytes_up: int,
    bytes_down: int,
    attack: AttackSnapshot | None = None,
    compute_state: ComputeLoadState | None = None,
) -> EnergyBreakdown:
    """Estimate flight, communication, detection, and total energy for one step."""

    compute = compute_state or estimate_compute_state(
        dt_s=dt_s,
        uav=uav,
        link=link,
        bytes_up=bytes_up,
        bytes_down=bytes_down,
        attack=attack,
    )
    flight_wh = estimate_flight_power_w(uav) * dt_s / 3600.0
    communication_wh = estimate_communication_power_w(bytes_up, bytes_down, dt_s, link) * dt_s / 3600.0
    detection_wh = (
        estimate_detection_power_w(
            bytes_up,
            bytes_down,
            dt_s,
            attack=attack,
            link=link,
            uav=uav,
            compute_state=compute,
        )
        * dt_s
        / 3600.0
    )
    total_wh = flight_wh + communication_wh + detection_wh
    return EnergyBreakdown(
        flight_wh=flight_wh,
        communication_wh=communication_wh,
        detection_wh=detection_wh,
        total_wh=total_wh,
        cpu_load=compute.cpu_load,
        board_temperature_c=compute.board_temperature_c,
    )


def _mapping_value(value: object, key: str) -> float:
    if isinstance(value, dict):
        return float(value.get(key, 0.0))
    return 0.0
