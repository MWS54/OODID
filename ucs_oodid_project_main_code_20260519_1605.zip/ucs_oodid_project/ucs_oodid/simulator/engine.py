from __future__ import annotations

import csv
from dataclasses import dataclass, field
import json
import math
from pathlib import Path
import random
from typing import Any, Iterable, Mapping, Sequence
import warnings

from ..io import save_json, write_jsonl
from ..utils import parse_label_cell
from .attack_replay import AttackReplayPool, resolve_simulation_source_metadata
from .attacks import AttackEvent as InjectorAttackEvent, AttackInjector, AttackSnapshot, build_attack_snapshot
from .channel import simulate_link_state
from .energy import EnergyBreakdown, estimate_compute_state, estimate_step_energy
from .entities import Attacker, GCS, UAV
from .mission import AIRBORNE_PHASES, trigger_emergency, update_uav_mission
from .response import ResponseManager
from .scenario import (
    AttackEvent as ScenarioAttackEvent,
    ScenarioConfig,
    load_scenario_from_yaml,
    load_scenario_profile,
    resolve_scenario_profile_path,
)
from .stream import TrafficRecord, estimate_traffic_bytes, generate_traffic_record
from .traffic_mixer import TrafficMixer


def _ordered_unique(values: Iterable[object]) -> tuple[str, ...]:
    ordered: list[str] = []
    seen: set[str] = set()
    for value in values:
        text = str(value).strip()
        if text and text not in seen:
            ordered.append(text)
            seen.add(text)
    return tuple(ordered)


def _collapse_attack_types(attack_types: Sequence[object]) -> str:
    ordered = [item for item in _ordered_unique(attack_types) if item != "benign"]
    if not ordered:
        return "benign"
    if len(ordered) == 1:
        return ordered[0]
    return "+".join(ordered)


def _coerce_float(value: object, default: float) -> float:
    try:
        return float(value)
    except Exception:
        return float(default)


def _coerce_int(value: object, default: int) -> int:
    try:
        return int(value)
    except Exception:
        return int(default)


def _coerce_bool(value: object, default: bool = False) -> bool:
    if value is None:
        return bool(default)
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    text = str(value).strip().lower()
    if text in {"1", "true", "yes", "y", "on"}:
        return True
    if text in {"0", "false", "no", "n", "off", ""}:
        return False
    return bool(default)


def _is_missing(value: object) -> bool:
    if value is None:
        return True
    if isinstance(value, str):
        return not value.strip()
    return False


def _clean_text(value: object) -> str:
    return "" if _is_missing(value) else str(value).strip()


def _canonical_pure_ids_split(value: object) -> str:
    text = _clean_text(value).lower()
    if text in {"id", "test_id"}:
        return "test_id"
    if text in {"ood", "test_ood"}:
        return "test_ood"
    return text


def _resolve_project_path(path_text: str | Path) -> Path:
    candidate = Path(path_text).expanduser()
    if candidate.is_absolute():
        return candidate
    return Path(__file__).resolve().parents[2] / candidate


def _detection_has_alert(detection: Mapping[str, object]) -> bool:
    if "has_alert" in detection:
        return bool(detection.get("has_alert", False))
    if "is_ood" in detection:
        return bool(detection.get("is_ood", False))
    return _clean_text(detection.get("alert_level")).lower() not in {"", "normal"}


def _detection_gt_attack_active(detection: Mapping[str, object]) -> bool:
    return bool(detection.get("gt_attack_active", detection.get("attack_active", False)))


def _detection_is_ood(detection: Mapping[str, object]) -> bool:
    return bool(detection.get("is_ood", False))


def _detection_ood_alert(detection: Mapping[str, object]) -> bool:
    if "ood_alert" in detection:
        return bool(detection.get("ood_alert", False))
    return _detection_is_ood(detection)


def _detection_known_attack_alert(detection: Mapping[str, object]) -> bool:
    return bool(detection.get("known_attack_alert", False))


def _detection_false_alert(detection: Mapping[str, object]) -> bool:
    return bool((not _detection_gt_attack_active(detection)) and _detection_has_alert(detection))


def _detection_missed_attack(detection: Mapping[str, object]) -> bool:
    return bool(_detection_gt_attack_active(detection) and not _detection_has_alert(detection))


def _most_common_text(values: Sequence[object]) -> str:
    counts: dict[str, int] = {}
    winner = ""
    winner_count = 0
    for value in values:
        text = _clean_text(value)
        if not text:
            continue
        counts[text] = counts.get(text, 0) + 1
        if counts[text] > winner_count:
            winner = text
            winner_count = counts[text]
    return winner


PER_UAV_DETECTION_SUMMARY_COLUMNS: tuple[str, ...] = (
    "uav_id",
    "dataset_name",
    "dataset_display",
    "source_type",
    "simulation_role",
    "window_count",
    "benign_window_count",
    "gt_attack_window_count",
    "gt_ood_window_count",
    "pred_alert_window_count",
    "pred_ood_window_count",
    "false_alert_window_count",
    "alert_rate",
    "false_alert_rate_on_benign_windows",
    "attack_detection_rate",
    "ood_detection_rate",
    "score_mode",
    "threshold_mode",
    "score_direction",
    "benign_score_mean",
    "attack_score_mean",
    "ood_score_mean",
    "score_separation",
    "direction_warning",
    "reversed_score_separation",
    "raw_ood_score_mean",
    "normalized_ood_score_mean",
    "peak_ood_score",
    "raw_threshold",
    "normalized_threshold",
    "score_unique_count",
    "raw_score_q50",
    "raw_score_q90",
    "raw_score_q95",
    "raw_score_q99",
    "normalized_score_q50",
    "normalized_score_q90",
    "normalized_score_q95",
    "normalized_score_q99",
    "benign_score_q50",
    "benign_score_q90",
    "benign_score_q95",
    "benign_score_q99",
    "inference_error_window_count",
    "missing_feature_ratio",
    "zero_feature_ratio",
    "input_mean",
    "input_std",
    "threshold",
    "threshold_source",
)

THRESHOLD_DIAGNOSTICS_COLUMNS: tuple[str, ...] = (
    "uav_id",
    "dataset_name",
    "dataset_display",
    "source_type",
    "simulation_role",
    "model_input_columns_json",
    "feature_columns_source",
    "missing_model_features_json",
    "dropped_simulation_columns_json",
    "forbidden_model_input_columns_json",
    "forbidden_model_input_columns_present",
    "window_count",
    "benign_warmup_window_count",
    "benign_window_count",
    "gt_attack_window_count",
    "gt_ood_window_count",
    "pred_alert_window_count",
    "pred_ood_window_count",
    "false_alert_window_count",
    "threshold",
    "raw_threshold",
    "normalized_threshold",
    "threshold_source",
    "threshold_quantile",
    "score_mode",
    "threshold_mode",
    "score_direction",
    "id_score_mean",
    "id_score_median",
    "benign_score_mean",
    "attack_score_mean",
    "ood_score_mean",
    "score_separation",
    "direction_warning",
    "reversed_score_separation",
    "false_alert_rate_on_benign_windows",
    "raw_ood_score_mean",
    "normalized_ood_score_mean",
    "raw_score_q50",
    "raw_score_q90",
    "raw_score_q95",
    "raw_score_q99",
    "normalized_score_q50",
    "normalized_score_q90",
    "normalized_score_q95",
    "normalized_score_q99",
    "benign_score_q50",
    "benign_score_q90",
    "benign_score_q95",
    "benign_score_q99",
    "peak_ood_score",
    "score_unique_count",
    "inference_error_window_count",
    "missing_feature_ratio",
    "zero_feature_ratio",
    "input_mean",
    "input_std",
)


def _apply_payload_source_metadata(
    payload: Mapping[str, object],
    *,
    uav_id: str,
    fallback_dataset_name: str = "",
    sim_source: str = "",
) -> dict[str, object]:
    row = dict(payload)
    synthetic_default = str(sim_source).strip().lower().endswith("synthetic")
    metadata = resolve_simulation_source_metadata(
        dataset_name=str(row.get("dataset_name", "") or fallback_dataset_name or ""),
        uav_id=uav_id,
        source_type=row.get("source_type"),
        simulation_role=row.get("simulation_role"),
        source_note=row.get("source_note"),
    )
    resolved_dataset_name = (
        _clean_text(row.get("dataset_name"))
        or _clean_text(metadata.get("dataset_name"))
        or _clean_text(fallback_dataset_name)
        or ("simulator" if synthetic_default else "")
    )
    if resolved_dataset_name:
        row["dataset_name"] = resolved_dataset_name
    if _is_missing(row.get("source_type")):
        row["source_type"] = _clean_text(metadata.get("source_type")) or ("simulator" if synthetic_default else "uav")
    if _is_missing(row.get("simulation_role")):
        row["simulation_role"] = (
            _clean_text(metadata.get("simulation_role"))
            or ("simulator_synthetic" if synthetic_default else "uav_replay")
        )
    if not _is_missing(metadata.get("source_note")) and _is_missing(row.get("source_note")):
        row["source_note"] = metadata["source_note"]
    return row


def _detection_ground_truth_is_ood(detection: Mapping[str, object]) -> bool:
    if detection.get("ground_truth_is_ood") is not None:
        return bool(detection.get("ground_truth_is_ood"))
    truth = detection.get("ground_truth")
    if isinstance(truth, Mapping) and truth.get("is_ood") is not None:
        return bool(truth.get("is_ood"))
    return False


def _detection_partition(detection: Mapping[str, object]) -> str:
    if _detection_ground_truth_is_ood(detection):
        return "ood"
    if _detection_gt_attack_active(detection):
        return "attack"
    return "benign"


def _optional_float(value: object) -> float | None:
    if _is_missing(value):
        return None
    try:
        return float(value)
    except Exception:
        return None


def _mean_or_none(values: Sequence[float | None]) -> float | None:
    clean = [float(value) for value in values if value is not None]
    if not clean:
        return None
    return float(sum(clean) / len(clean))


def _detection_raw_ood_score(detection: Mapping[str, object]) -> float | None:
    value = detection.get("raw_ood_score")
    if value is None:
        value = detection.get("ood_score")
    return _optional_float(value)


def _detection_normalized_ood_score(detection: Mapping[str, object]) -> float | None:
    value = detection.get("normalized_ood_score")
    if value is None:
        value = detection.get("ood_score")
    return _optional_float(value)


def _detection_threshold_value(detection: Mapping[str, object]) -> float | None:
    value = detection.get("threshold")
    if value is None:
        value = detection.get("ood_threshold")
    return _optional_float(value)


def _detection_threshold_source(detection: Mapping[str, object]) -> str:
    return _clean_text(detection.get("threshold_source")) or _clean_text(detection.get("ood_threshold_source")) or "global"


def _detection_selected_score(detection: Mapping[str, object]) -> float | None:
    value = detection.get("ood_score")
    if value is None:
        value = detection.get("normalized_ood_score")
    if value is None:
        value = detection.get("raw_ood_score")
    return _optional_float(value)


def _peak_or_none(values: Sequence[float | None]) -> float | None:
    clean = [float(value) for value in values if value is not None]
    if not clean:
        return None
    return float(max(clean))


def _is_forbidden_model_input_column(column: object) -> bool:
    text = _clean_text(column)
    if not text:
        return False
    lowered = text.lower()
    if lowered in {"label", "attack_type"}:
        return True
    return lowered.startswith(("sim_", "gt_", "source_"))


def _uav_metadata_from_records(records: Sequence[TrafficRecord]) -> dict[str, dict[str, object]]:
    metadata_by_uav: dict[str, dict[str, object]] = {}
    for record in records:
        row = record.to_dict()
        uav_id = _clean_text(row.get("uav_id"))
        if not uav_id:
            continue
        metadata = resolve_simulation_source_metadata(
            dataset_name=_clean_text(row.get("dataset_name")),
            uav_id=uav_id,
            source_type=row.get("source_type"),
            simulation_role=row.get("simulation_role"),
            source_note=row.get("source_note"),
        )
        entry = metadata_by_uav.setdefault(
            uav_id,
            {
                "dataset_name": "",
                "dataset_display": "",
                "source_type": "",
                "simulation_role": "",
            },
        )
        if not entry["dataset_name"]:
            entry["dataset_name"] = _clean_text(metadata.get("dataset_name")) or _clean_text(row.get("dataset_name"))
        if not entry["dataset_display"]:
            entry["dataset_display"] = _clean_text(metadata.get("dataset_display")) or entry["dataset_name"]
        if not entry["source_type"]:
            entry["source_type"] = _clean_text(metadata.get("source_type")) or _clean_text(row.get("source_type"))
        if not entry["simulation_role"]:
            entry["simulation_role"] = _clean_text(metadata.get("simulation_role")) or _clean_text(row.get("simulation_role"))
    return metadata_by_uav


def _write_csv_rows(path: Path, rows: Sequence[Mapping[str, object]], columns: Sequence[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(columns))
        writer.writeheader()
        for row in rows:
            writer.writerow({column: row.get(column) for column in columns})


def _per_uav_detection_summary_rows(
    *,
    records: Sequence[TrafficRecord],
    detections: Sequence[Mapping[str, object]],
    diagnostics: Mapping[str, object],
) -> list[dict[str, object]]:
    metadata_by_uav = _uav_metadata_from_records(records)
    diagnostic_metadata_by_uav = {
        str(uav_id): dict(value)
        for uav_id, value in (diagnostics.get("per_uav_metadata", {}) or {}).items()
        if isinstance(value, Mapping)
    }

    def _map_values(name: str) -> dict[str, object]:
        return {
            str(group_id): value
            for group_id, value in (diagnostics.get(name, {}) or {}).items()
        }

    threshold_map = {
        group_id: float(value)
        for group_id, value in _map_values("per_uav_threshold").items()
        if value is not None
    }
    raw_threshold_map = {
        group_id: float(value)
        for group_id, value in _map_values("per_uav_raw_threshold").items()
        if value is not None
    }
    normalized_threshold_map = {
        group_id: float(value)
        for group_id, value in _map_values("per_uav_normalized_threshold").items()
        if value is not None
    }
    threshold_source_map = {
        group_id: str(value)
        for group_id, value in _map_values("per_uav_threshold_source").items()
        if not _is_missing(value)
    }
    score_unique_count_map = {
        group_id: int(value)
        for group_id, value in _map_values("per_uav_score_unique_count").items()
        if value is not None
    }
    inference_error_count_map = {
        group_id: int(value)
        for group_id, value in _map_values("per_uav_inference_error_count").items()
        if value is not None
    }
    missing_feature_ratio_map = _map_values("per_uav_missing_feature_ratio")
    zero_feature_ratio_map = _map_values("per_uav_zero_feature_ratio")
    input_mean_map = _map_values("per_uav_input_mean")
    input_std_map = _map_values("per_uav_input_std")
    raw_q50_map = _map_values("per_uav_raw_score_q50")
    raw_q90_map = _map_values("per_uav_raw_score_q90")
    raw_q95_map = _map_values("per_uav_raw_score_q95")
    raw_q99_map = _map_values("per_uav_raw_score_q99")
    normalized_q50_map = _map_values("per_uav_normalized_score_q50")
    normalized_q90_map = _map_values("per_uav_normalized_score_q90")
    normalized_q95_map = _map_values("per_uav_normalized_score_q95")
    normalized_q99_map = _map_values("per_uav_normalized_score_q99")
    benign_q50_map = _map_values("per_uav_benign_score_q50")
    benign_q90_map = _map_values("per_uav_benign_score_q90")
    benign_q95_map = _map_values("per_uav_benign_score_q95")
    benign_q99_map = _map_values("per_uav_benign_score_q99")
    default_score_mode = str(diagnostics.get("score_mode", "") or "").strip()
    default_threshold_mode = str(diagnostics.get("threshold_mode", "") or "").strip()
    default_score_direction = str(diagnostics.get("score_direction", "") or "").strip()

    grouped: dict[str, list[Mapping[str, object]]] = {}
    for detection in detections:
        group_id = _clean_text(detection.get("group_id"))
        if not group_id:
            continue
        grouped.setdefault(group_id, []).append(detection)

    rows: list[dict[str, object]] = []
    for uav_id in sorted(set(metadata_by_uav) | set(grouped)):
        items = grouped.get(uav_id, [])
        metadata = dict(diagnostic_metadata_by_uav.get(uav_id, {}))
        metadata.update({key: value for key, value in metadata_by_uav.get(uav_id, {}).items() if not _is_missing(value)})
        partitions = [_detection_partition(item) for item in items]
        benign_items = [item for item, partition in zip(items, partitions) if partition == "benign"]
        attack_items = [item for item, partition in zip(items, partitions) if partition == "attack"]
        ood_items = [item for item, partition in zip(items, partitions) if partition == "ood"]
        benign_window_count = len(benign_items)
        gt_attack_window_count = len(attack_items)
        gt_ood_window_count = len(ood_items)
        pred_alert_window_count = sum(1 for item in items if _detection_has_alert(item))
        pred_ood_window_count = sum(1 for item in items if _detection_is_ood(item))
        false_alert_window_count = sum(1 for item in items if _detection_false_alert(item))
        threshold = threshold_map.get(uav_id)
        if threshold is None:
            threshold = _mean_or_none([_detection_threshold_value(item) for item in items])
        raw_threshold = raw_threshold_map.get(uav_id)
        if raw_threshold is None:
            raw_threshold = _mean_or_none([_optional_float(item.get("raw_threshold")) for item in items])
        normalized_threshold = normalized_threshold_map.get(uav_id)
        if normalized_threshold is None:
            normalized_threshold = _mean_or_none([_optional_float(item.get("normalized_threshold")) for item in items])
        threshold_source = threshold_source_map.get(uav_id)
        if not threshold_source:
            threshold_source = _most_common_text([_detection_threshold_source(item) for item in items]) or "global"
        score_mode = default_score_mode or (_most_common_text([item.get("score_mode") for item in items]) or "normalized")
        threshold_mode = default_threshold_mode or (_most_common_text([item.get("threshold_mode") for item in items]) or "")
        score_direction = default_score_direction or (_most_common_text([item.get("score_direction") for item in items]) or "higher_is_more_anomalous")
        benign_score_mean = _mean_or_none([_detection_selected_score(item) for item in benign_items])
        attack_score_mean = _mean_or_none([_detection_selected_score(item) for item in attack_items])
        ood_score_mean = _mean_or_none([_detection_selected_score(item) for item in ood_items])
        score_separation = None
        if benign_score_mean is not None and attack_score_mean is not None:
            score_separation = float(attack_score_mean - benign_score_mean)
        direction_warning = bool(
            benign_score_mean is not None
            and attack_score_mean is not None
            and float(attack_score_mean) < float(benign_score_mean)
        )
        rows.append(
            {
                "uav_id": uav_id,
                "dataset_name": metadata.get("dataset_name") or "",
                "dataset_display": metadata.get("dataset_display") or metadata.get("dataset_name") or "",
                "source_type": metadata.get("source_type") or "",
                "simulation_role": metadata.get("simulation_role") or "",
                "window_count": int(len(items)),
                "benign_window_count": int(benign_window_count),
                "gt_attack_window_count": int(gt_attack_window_count),
                "gt_ood_window_count": int(gt_ood_window_count),
                "pred_alert_window_count": int(pred_alert_window_count),
                "pred_ood_window_count": int(pred_ood_window_count),
                "false_alert_window_count": int(false_alert_window_count),
                "alert_rate": 0.0 if not items else float(pred_alert_window_count) / float(len(items)),
                "false_alert_rate_on_benign_windows": 0.0
                if benign_window_count <= 0
                else float(false_alert_window_count) / float(benign_window_count),
                "attack_detection_rate": 0.0
                if gt_attack_window_count <= 0
                else float(sum(1 for item in attack_items if _detection_has_alert(item))) / float(gt_attack_window_count),
                "ood_detection_rate": 0.0
                if gt_ood_window_count <= 0
                else float(sum(1 for item in ood_items if _detection_is_ood(item))) / float(gt_ood_window_count),
                "score_mode": score_mode,
                "threshold_mode": threshold_mode,
                "score_direction": score_direction,
                "benign_score_mean": benign_score_mean,
                "attack_score_mean": attack_score_mean,
                "ood_score_mean": ood_score_mean,
                "score_separation": score_separation,
                "direction_warning": direction_warning,
                "reversed_score_separation": None if score_separation is None else float(-score_separation),
                "raw_ood_score_mean": _mean_or_none([_detection_raw_ood_score(item) for item in items]),
                "normalized_ood_score_mean": _mean_or_none([_detection_normalized_ood_score(item) for item in items]),
                "peak_ood_score": _peak_or_none([_detection_selected_score(item) for item in items]),
                "raw_threshold": raw_threshold,
                "normalized_threshold": normalized_threshold,
                "score_unique_count": score_unique_count_map.get(uav_id, 0),
                "raw_score_q50": raw_q50_map.get(uav_id),
                "raw_score_q90": raw_q90_map.get(uav_id),
                "raw_score_q95": raw_q95_map.get(uav_id),
                "raw_score_q99": raw_q99_map.get(uav_id),
                "normalized_score_q50": normalized_q50_map.get(uav_id),
                "normalized_score_q90": normalized_q90_map.get(uav_id),
                "normalized_score_q95": normalized_q95_map.get(uav_id),
                "normalized_score_q99": normalized_q99_map.get(uav_id),
                "benign_score_q50": benign_q50_map.get(uav_id),
                "benign_score_q90": benign_q90_map.get(uav_id),
                "benign_score_q95": benign_q95_map.get(uav_id),
                "benign_score_q99": benign_q99_map.get(uav_id),
                "inference_error_window_count": inference_error_count_map.get(uav_id, 0),
                "missing_feature_ratio": missing_feature_ratio_map.get(uav_id),
                "zero_feature_ratio": zero_feature_ratio_map.get(uav_id),
                "input_mean": input_mean_map.get(uav_id),
                "input_std": input_std_map.get(uav_id),
                "threshold": threshold,
                "threshold_source": threshold_source,
            }
        )
    return rows


def _threshold_diagnostic_rows(
    *,
    records: Sequence[TrafficRecord],
    detections: Sequence[Mapping[str, object]],
    diagnostics: Mapping[str, object],
) -> list[dict[str, object]]:
    summary_rows = _per_uav_detection_summary_rows(records=records, detections=detections, diagnostics=diagnostics)
    summary_by_uav = {str(row["uav_id"]): dict(row) for row in summary_rows}
    model_input_columns = [str(column) for column in (diagnostics.get("model_input_columns", []) or [])]
    forbidden_columns = sorted(
        {
            column
            for column in model_input_columns
            if _is_forbidden_model_input_column(column)
        }
    )
    warmup_counts = {
        str(group_id): int(value)
        for group_id, value in (diagnostics.get("per_uav_benign_warmup_window_count", {}) or {}).items()
    }
    id_mean_map = {
        str(group_id): value for group_id, value in (diagnostics.get("per_uav_id_score_mean", {}) or {}).items()
    }
    id_median_map = {
        str(group_id): value for group_id, value in (diagnostics.get("per_uav_id_score_median", {}) or {}).items()
    }
    raw_mean_map = {
        str(group_id): value for group_id, value in (diagnostics.get("per_uav_raw_ood_score_mean", {}) or {}).items()
    }
    normalized_mean_map = {
        str(group_id): value for group_id, value in (diagnostics.get("per_uav_normalized_ood_score_mean", {}) or {}).items()
    }
    rows: list[dict[str, object]] = []
    for uav_id in sorted(summary_by_uav):
        summary_row = summary_by_uav[uav_id]
        rows.append(
            {
                "uav_id": uav_id,
                "dataset_name": summary_row.get("dataset_name"),
                "dataset_display": summary_row.get("dataset_display"),
                "source_type": summary_row.get("source_type"),
                "simulation_role": summary_row.get("simulation_role"),
                "model_input_columns_json": json.dumps(model_input_columns, ensure_ascii=False),
                "feature_columns_source": diagnostics.get("feature_columns_source"),
                "missing_model_features_json": json.dumps(diagnostics.get("missing_model_features", []) or [], ensure_ascii=False),
                "dropped_simulation_columns_json": json.dumps(diagnostics.get("dropped_simulation_columns", []) or [], ensure_ascii=False),
                "forbidden_model_input_columns_json": json.dumps(forbidden_columns, ensure_ascii=False),
                "forbidden_model_input_columns_present": bool(forbidden_columns),
                "window_count": summary_row.get("window_count"),
                "benign_warmup_window_count": warmup_counts.get(uav_id, 0),
                "benign_window_count": summary_row.get("benign_window_count"),
                "gt_attack_window_count": summary_row.get("gt_attack_window_count"),
                "gt_ood_window_count": summary_row.get("gt_ood_window_count"),
                "pred_alert_window_count": summary_row.get("pred_alert_window_count"),
                "pred_ood_window_count": summary_row.get("pred_ood_window_count"),
                "false_alert_window_count": summary_row.get("false_alert_window_count"),
                "threshold": summary_row.get("threshold"),
                "raw_threshold": summary_row.get("raw_threshold"),
                "normalized_threshold": summary_row.get("normalized_threshold"),
                "threshold_source": summary_row.get("threshold_source"),
                "threshold_quantile": diagnostics.get("threshold_quantile"),
                "score_mode": summary_row.get("score_mode"),
                "threshold_mode": summary_row.get("threshold_mode"),
                "score_direction": summary_row.get("score_direction"),
                "id_score_mean": id_mean_map.get(uav_id),
                "id_score_median": id_median_map.get(uav_id),
                "benign_score_mean": summary_row.get("benign_score_mean"),
                "attack_score_mean": summary_row.get("attack_score_mean"),
                "ood_score_mean": summary_row.get("ood_score_mean"),
                "score_separation": summary_row.get("score_separation"),
                "direction_warning": summary_row.get("direction_warning"),
                "reversed_score_separation": summary_row.get("reversed_score_separation"),
                "false_alert_rate_on_benign_windows": summary_row.get("false_alert_rate_on_benign_windows"),
                "raw_ood_score_mean": raw_mean_map.get(uav_id, summary_row.get("raw_ood_score_mean")),
                "normalized_ood_score_mean": normalized_mean_map.get(uav_id, summary_row.get("normalized_ood_score_mean")),
                "raw_score_q50": summary_row.get("raw_score_q50"),
                "raw_score_q90": summary_row.get("raw_score_q90"),
                "raw_score_q95": summary_row.get("raw_score_q95"),
                "raw_score_q99": summary_row.get("raw_score_q99"),
                "normalized_score_q50": summary_row.get("normalized_score_q50"),
                "normalized_score_q90": summary_row.get("normalized_score_q90"),
                "normalized_score_q95": summary_row.get("normalized_score_q95"),
                "normalized_score_q99": summary_row.get("normalized_score_q99"),
                "benign_score_q50": summary_row.get("benign_score_q50"),
                "benign_score_q90": summary_row.get("benign_score_q90"),
                "benign_score_q95": summary_row.get("benign_score_q95"),
                "benign_score_q99": summary_row.get("benign_score_q99"),
                "peak_ood_score": summary_row.get("peak_ood_score"),
                "score_unique_count": summary_row.get("score_unique_count"),
                "inference_error_window_count": summary_row.get("inference_error_window_count"),
                "missing_feature_ratio": summary_row.get("missing_feature_ratio"),
                "zero_feature_ratio": summary_row.get("zero_feature_ratio"),
                "input_mean": summary_row.get("input_mean"),
                "input_std": summary_row.get("input_std"),
            }
        )
    return rows


def _summarize_dataset_detection_stats(
    records: Sequence[TrafficRecord],
    detections: Sequence[Mapping[str, Any]],
) -> list[dict[str, object]]:
    stats_by_dataset: dict[str, dict[str, object]] = {}
    record_dataset_by_id: dict[str, str] = {}
    record_dataset_by_uav_time: dict[tuple[str, float], list[str]] = {}
    dataset_counts_by_uav: dict[str, dict[str, int]] = {}

    def ensure_entry(
        *,
        dataset_name: str,
        uav_id: str = "",
        source_type: object | None = None,
        simulation_role: object | None = None,
        source_note: object | None = None,
    ) -> dict[str, object]:
        metadata = resolve_simulation_source_metadata(
            dataset_name=dataset_name,
            uav_id=uav_id,
            source_type=source_type,
            simulation_role=simulation_role,
            source_note=source_note,
        )
        resolved_dataset_name = _clean_text(metadata.get("dataset_name")) or _clean_text(dataset_name) or "simulator"
        entry = stats_by_dataset.get(resolved_dataset_name)
        if entry is None:
            entry = {
                "dataset_name": resolved_dataset_name,
                "dataset_display": _clean_text(metadata.get("dataset_display")) or resolved_dataset_name,
                "dataset_role": _clean_text(metadata.get("dataset_role")),
                "source_type": _clean_text(metadata.get("source_type")) or ("simulator" if resolved_dataset_name == "simulator" else ""),
                "simulation_role": _clean_text(metadata.get("simulation_role"))
                or ("simulator_synthetic" if resolved_dataset_name == "simulator" else ""),
                "source_note": _clean_text(metadata.get("source_note")),
                "uav_ids": set(),
                "record_count": 0,
                "attack_record_count": 0,
                "detection_count": 0,
                "attack_window_count": 0,
                "detected_attack_window_count": 0,
                "alert_count": 0,
                "false_alert_count": 0,
                "ood_detection_count": 0,
                "sim_source_counts": {},
            }
            stats_by_dataset[resolved_dataset_name] = entry
        if uav_id:
            entry["uav_ids"].add(uav_id)
        if not entry["source_type"] and _clean_text(metadata.get("source_type")):
            entry["source_type"] = _clean_text(metadata.get("source_type"))
        if not entry["simulation_role"] and _clean_text(metadata.get("simulation_role")):
            entry["simulation_role"] = _clean_text(metadata.get("simulation_role"))
        if not entry["source_note"] and _clean_text(metadata.get("source_note")):
            entry["source_note"] = _clean_text(metadata.get("source_note"))
        return entry

    for record in records:
        row = record.to_dict()
        uav_id = _clean_text(row.get("uav_id"))
        sim_time = _coerce_float(row.get("sim_time", row.get("timestamp")), 0.0)
        entry = ensure_entry(
            dataset_name=_clean_text(row.get("dataset_name")),
            uav_id=uav_id,
            source_type=row.get("source_type"),
            simulation_role=row.get("simulation_role"),
            source_note=row.get("source_note"),
        )
        entry["record_count"] += 1
        if bool(row.get("gt_attack_active", row.get("attack_active", False))):
            entry["attack_record_count"] += 1
        sim_source = _clean_text(row.get("sim_source"))
        if sim_source:
            entry["sim_source_counts"][sim_source] = entry["sim_source_counts"].get(sim_source, 0) + 1
        record_id = _clean_text(row.get("record_id"))
        if record_id:
            record_dataset_by_id[record_id] = str(entry["dataset_name"])
        if uav_id:
            key = (uav_id, sim_time)
            record_dataset_by_uav_time.setdefault(key, []).append(str(entry["dataset_name"]))
            per_uav_counts = dataset_counts_by_uav.setdefault(uav_id, {})
            per_uav_counts[str(entry["dataset_name"])] = per_uav_counts.get(str(entry["dataset_name"]), 0) + 1

    for detection in detections:
        group_id = _clean_text(detection.get("group_id"))
        dataset_candidates: list[str] = []
        record_ids = detection.get("record_ids")
        if isinstance(record_ids, Sequence) and not isinstance(record_ids, (str, bytes, bytearray)):
            for record_id in record_ids:
                resolved = record_dataset_by_id.get(_clean_text(record_id))
                if resolved:
                    dataset_candidates.append(resolved)
        if not dataset_candidates and group_id and not _is_missing(detection.get("simulation_time_s")):
            dataset_candidates.extend(
                record_dataset_by_uav_time.get(
                    (group_id, _coerce_float(detection.get("simulation_time_s"), 0.0)),
                    [],
                )
            )
        if not dataset_candidates and group_id:
            per_uav_counts = dataset_counts_by_uav.get(group_id, {})
            dataset_candidates.extend(
                [
                    dataset_name
                    for dataset_name, _ in sorted(per_uav_counts.items(), key=lambda item: (-item[1], item[0]))
                ]
            )

        entry = ensure_entry(
            dataset_name=_clean_text(detection.get("dataset_name")) or _most_common_text(dataset_candidates),
            uav_id=group_id,
        )
        entry["detection_count"] += 1
        gt_attack_active = _detection_gt_attack_active(detection)
        has_alert = _detection_has_alert(detection)
        is_ood = _detection_is_ood(detection)
        if gt_attack_active:
            entry["attack_window_count"] += 1
        if has_alert:
            entry["alert_count"] += 1
        if is_ood:
            entry["ood_detection_count"] += 1
        if gt_attack_active and has_alert:
            entry["detected_attack_window_count"] += 1
        if _detection_false_alert(detection):
            entry["false_alert_count"] += 1

    rows: list[dict[str, object]] = []
    for dataset_name in sorted(stats_by_dataset):
        entry = dict(stats_by_dataset[dataset_name])
        attack_window_count = int(entry["attack_window_count"])
        entry["uav_ids"] = sorted(entry["uav_ids"])
        entry["sim_source_counts"] = dict(sorted(entry["sim_source_counts"].items()))
        entry["detection_rate"] = (
            0.0
            if attack_window_count <= 0
            else float(entry["detected_attack_window_count"]) / float(attack_window_count)
        )
        rows.append(entry)
    return rows


@dataclass(frozen=True)
class _ResolvedAttackState:
    snapshot: AttackSnapshot
    attack_types: tuple[str, ...] = ()
    intensity: float = 0.0
    attack_replay_mode: str = "sequential"
    source_dataset: str | None = None
    is_ood: bool | None = None

    @property
    def active(self) -> bool:
        return bool(self.snapshot.active)

    @property
    def primary_attack_type(self) -> str:
        if self.attack_types:
            return self.attack_types[0]
        return str(self.snapshot.attack_type)

    @property
    def gt_attack_type(self) -> str:
        return _collapse_attack_types(self.attack_types if self.attack_types else (self.primary_attack_type,))


class PureIDSCsvReplayCursor:
    """Replay a grouped IDS CSV sequentially without sampling or mixing."""

    def __init__(
        self,
        *,
        csv_path: str | Path,
        group_col: str = "uav_id",
        selected_uav_ids: Sequence[str] | None = None,
        keep_original_order: bool = True,
        split_filter: Sequence[str] | None = ("test_id", "test_ood"),
    ) -> None:
        self.csv_path = _resolve_project_path(csv_path)
        self.group_col = _clean_text(group_col) or "uav_id"
        self.keep_original_order = bool(keep_original_order)
        if not self.keep_original_order:
            raise ValueError("PureIDSCsvReplayCursor requires keep_original_order=True")
        self.selected_uav_ids = tuple(_clean_text(uav_id) for uav_id in (selected_uav_ids or ()) if _clean_text(uav_id))
        normalized_split_filter = tuple(
            split_name
            for split_name in (_canonical_pure_ids_split(value) for value in (split_filter or ("test_id", "test_ood")))
            if split_name
        )
        if not normalized_split_filter:
            raise ValueError("PureIDSCsvReplayCursor requires at least one replay split")
        self.split_filter = normalized_split_filter
        self.rows_by_split_by_uav: dict[str, dict[str, list[dict[str, object]]]] = {
            split_name: {uav_id: [] for uav_id in self.selected_uav_ids}
            for split_name in self.split_filter
        }
        self.pos_by_split_by_uav: dict[str, dict[str, int]] = {
            split_name: {uav_id: 0 for uav_id in self.selected_uav_ids}
            for split_name in self.split_filter
        }
        self.split_source_column = "split"
        self.active_split_index = 0
        self._split_transition_pending = False
        self._load_rows()

    def _load_rows(self) -> None:
        if not self.csv_path.exists():
            raise FileNotFoundError(f"Pure IDS CSV not found: {self.csv_path}")
        selected = set(self.selected_uav_ids)
        with self.csv_path.open("r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            if reader.fieldnames is None:
                raise ValueError(f"Pure IDS CSV is missing a header row: {self.csv_path}")
            if self.group_col not in reader.fieldnames:
                raise ValueError(
                    f"Pure IDS CSV does not contain group column {self.group_col!r}: {self.csv_path}"
                )
            has_split_column = "split" in reader.fieldnames
            has_partition_column = "recommended_partition" in reader.fieldnames
            if has_split_column:
                self.split_source_column = "split"
            elif has_partition_column:
                self.split_source_column = "recommended_partition"
                warnings.warn(
                    "Pure IDS CSV replay could not find 'split'; falling back to "
                    "'recommended_partition' and mapping id->test_id / ood->test_ood.",
                    RuntimeWarning,
                    stacklevel=2,
                )
            else:
                raise ValueError(
                    "Pure IDS CSV replay requires either a 'split' column or a "
                    "'recommended_partition' column for test split filtering."
                )
            kept_row_count = 0
            for source_row_index, row in enumerate(reader, start=1):
                uav_id = _clean_text(row.get(self.group_col))
                if not uav_id:
                    continue
                if selected and uav_id not in selected:
                    continue
                if has_split_column:
                    replay_split = _canonical_pure_ids_split(row.get("split"))
                else:
                    replay_split = _canonical_pure_ids_split(row.get("recommended_partition"))
                if replay_split not in self.rows_by_split_by_uav:
                    continue
                payload = {str(key): value for key, value in row.items()}
                payload["source_row_index"] = int(source_row_index)
                payload["pure_ids_replay_split"] = replay_split
                if _is_missing(payload.get("split")):
                    payload["split"] = replay_split
                self.rows_by_split_by_uav.setdefault(replay_split, {}).setdefault(uav_id, []).append(payload)
                self.pos_by_split_by_uav.setdefault(replay_split, {}).setdefault(uav_id, 0)
                kept_row_count += 1
        if kept_row_count <= 0:
            raise ValueError(
                "Pure IDS CSV replay found no rows matching the requested replay split filter: "
                + ", ".join(self.split_filter)
            )
        missing_uav_ids = [uav_id for uav_id in self.selected_uav_ids if self.total_rows_by_uav().get(uav_id, 0) <= 0]
        if missing_uav_ids:
            raise ValueError(
                "Pure IDS CSV is missing replay rows for selected UAVs: "
                + ", ".join(sorted(missing_uav_ids))
            )
        self.reset()

    def reset(self) -> None:
        self.pos_by_split_by_uav = {
            split_name: {uav_id: 0 for uav_id in rows_by_uav}
            for split_name, rows_by_uav in self.rows_by_split_by_uav.items()
        }
        self.active_split_index = self._first_nonempty_split_index()
        self._split_transition_pending = False

    @property
    def active_split(self) -> str:
        if 0 <= self.active_split_index < len(self.split_filter):
            return self.split_filter[self.active_split_index]
        return ""

    def _first_nonempty_split_index(self) -> int:
        for index, split_name in enumerate(self.split_filter):
            if self._split_has_remaining_rows(split_name):
                return index
        return len(self.split_filter)

    def _split_has_remaining_rows(self, split_name: str) -> bool:
        rows_by_uav = self.rows_by_split_by_uav.get(split_name, {})
        pos_by_uav = self.pos_by_split_by_uav.get(split_name, {})
        return any(len(rows) > int(pos_by_uav.get(uav_id, 0)) for uav_id, rows in rows_by_uav.items())

    def _active_split_exhausted(self) -> bool:
        active_split = self.active_split
        return not active_split or not self._split_has_remaining_rows(active_split)

    def _advance_to_next_split(self) -> bool:
        next_index = int(self.active_split_index) + 1
        while next_index < len(self.split_filter):
            self.active_split_index = next_index
            if self._split_has_remaining_rows(self.split_filter[next_index]):
                self._split_transition_pending = True
                return True
            next_index += 1
        self.active_split_index = len(self.split_filter)
        self._split_transition_pending = False
        return False

    def acknowledge_split_change(self) -> None:
        self._split_transition_pending = False

    def next_rows(self, uav_id: str, count: int) -> tuple[list[dict[str, object]], bool]:
        clean_uav_id = _clean_text(uav_id)
        active_split = self.active_split
        if count <= 0 or not active_split:
            return [], False
        if self._split_transition_pending:
            return [], False
        rows_by_uav = self.rows_by_split_by_uav.get(active_split, {})
        if clean_uav_id not in rows_by_uav:
            return [], False
        rows = rows_by_uav[clean_uav_id]
        pos_by_uav = self.pos_by_split_by_uav.setdefault(active_split, {})
        start = int(pos_by_uav.get(clean_uav_id, 0))
        end = min(start + int(count), len(rows))
        pos_by_uav[clean_uav_id] = end
        split_changed = False
        if self._active_split_exhausted():
            split_changed = self._advance_to_next_split()
        return [dict(row) for row in rows[start:end]], bool(split_changed)

    def total_rows_by_uav(self) -> dict[str, int]:
        totals: dict[str, int] = {}
        for rows_by_uav in self.rows_by_split_by_uav.values():
            for uav_id, rows in rows_by_uav.items():
                totals[uav_id] = totals.get(uav_id, 0) + int(len(rows))
        return {uav_id: int(totals[uav_id]) for uav_id in sorted(totals)}

    def replayed_rows_by_uav(self) -> dict[str, int]:
        replayed: dict[str, int] = {}
        for split_name, pos_by_uav in self.pos_by_split_by_uav.items():
            for uav_id, position in pos_by_uav.items():
                total_rows = len(self.rows_by_split_by_uav.get(split_name, {}).get(uav_id, []))
                replayed[uav_id] = replayed.get(uav_id, 0) + min(int(position), total_rows)
        return {uav_id: int(replayed[uav_id]) for uav_id in sorted(replayed)}

    def remaining_rows_by_uav(self) -> dict[str, int]:
        totals = self.total_rows_by_uav()
        replayed = self.replayed_rows_by_uav()
        return {uav_id: int(max(totals.get(uav_id, 0) - replayed.get(uav_id, 0), 0)) for uav_id in sorted(totals)}

    def all_exhausted(self) -> bool:
        return all(remaining <= 0 for remaining in self.remaining_rows_by_uav().values())


@dataclass
class _SummaryRecordAggregate:
    record_count: int = 0
    attack_record_count: int = 0
    rssi_sum: float = 0.0
    latency_sum: float = 0.0
    loss_rate_sum: float = 0.0
    cpu_load_sum: float = 0.0
    peak_board_temperature_c: float = float("-inf")
    total_bytes_up: int = 0
    total_bytes_down: int = 0
    ids_energy_wh: float = 0.0
    uav_ids: set[str] = field(default_factory=set)

    def observe_records(self, records: Sequence[TrafficRecord]) -> None:
        for record in records:
            self.record_count += 1
            self.attack_record_count += int(bool(record.attack_active))
            self.rssi_sum += float(record.rssi)
            self.latency_sum += float(record.latency_ms)
            self.loss_rate_sum += float(record.loss_rate)
            self.cpu_load_sum += float(record.cpu_load)
            self.peak_board_temperature_c = max(self.peak_board_temperature_c, float(record.board_temperature_c))
            self.total_bytes_up += int(record.bytes_up)
            self.total_bytes_down += int(record.bytes_down)
            self.ids_energy_wh += float(record.detection_energy_wh)
            self.uav_ids.add(str(record.uav_id))

    def diagnostics(self) -> dict[str, object]:
        count = int(self.record_count)
        return {
            "summary_record_count": count,
            "summary_uav_ids": sorted(self.uav_ids),
            "summary_attack_record_count": int(self.attack_record_count),
            "summary_mean_rssi": 0.0 if count <= 0 else float(self.rssi_sum) / float(count),
            "summary_mean_latency_ms": 0.0 if count <= 0 else float(self.latency_sum) / float(count),
            "summary_mean_loss_rate": 0.0 if count <= 0 else float(self.loss_rate_sum) / float(count),
            "summary_mean_cpu_load": 0.0 if count <= 0 else float(self.cpu_load_sum) / float(count),
            "summary_peak_board_temperature_c": 0.0
            if count <= 0
            else float(self.peak_board_temperature_c),
            "summary_total_bytes_up": int(self.total_bytes_up),
            "summary_total_bytes_down": int(self.total_bytes_down),
            "summary_ids_energy_wh": float(self.ids_energy_wh),
        }


@dataclass(frozen=True)
class SimulationConfig:
    """Global parameters for the discrete-time simulator."""

    duration_s: float = 120.0
    dt_s: float = 1.0
    seed: int = 42
    enable_online_detection: bool = False
    response_strategy: str = "alert_only"
    scenario_profile_path: str = ""
    attack_replay_mode: str = "sequential"
    records_per_uav_per_step: int = 1
    target_records_per_uav: int = 0
    attack_scenario_path: str = ""
    output_dir: str = ""
    export_summary_only: bool = False
    dataset_replay_mode: str = ""
    pure_ids_csv_path: str = ""
    pure_ids_group_col: str = "uav_id"
    pure_ids_replay_records_per_uav_per_step: int = 186
    pure_ids_replay_stop_when_exhausted: bool = True
    pure_ids_replay_keep_original_order: bool = True
    pure_ids_replay_no_mixing: bool = True
    pure_ids_replay_split_filter: tuple[str, ...] = ("test_id", "test_ood")
    pure_ids_replay_reset_buffer_on_split_change: bool = True


@dataclass(frozen=True)
class SimulationResult:
    """Outputs produced by one simulation run."""

    records: list[TrafficRecord]
    total_energy_wh: float
    attack_record_count: int
    online_detection_results: list[dict[str, Any]] = field(default_factory=list)
    response_events: list[dict[str, Any]] = field(default_factory=list)
    alert_count: int = 0
    response_count: int = 0
    average_alert_delay: float = 0.0
    false_alert_count: int = 0
    mission_success: bool = False
    scenario_name: str | None = None
    export_paths: dict[str, str] = field(default_factory=dict)
    diagnostics: dict[str, Any] = field(default_factory=dict)

    def record_rows(self) -> list[dict[str, object]]:
        return [record.to_dict() for record in self.records]

    def summary_payload(self) -> dict[str, object]:
        payload = {
            "scenario_name": self.scenario_name,
            "uav_ids": sorted({record.uav_id for record in self.records}),
            "record_count": len(self.records),
            "detection_count": len(self.online_detection_results),
            "attack_record_count": int(self.attack_record_count),
            "total_energy_wh": float(self.total_energy_wh),
            "alert_count": int(self.alert_count),
            "response_count": int(self.response_count),
            "average_alert_delay": float(self.average_alert_delay),
            "false_alert_count": int(self.false_alert_count),
            "mission_success": bool(self.mission_success),
            "dataset_detection_stats": _summarize_dataset_detection_stats(
                self.records,
                self.online_detection_results,
            ),
            "response_events": list(self.response_events),
            "output_files": dict(self.export_paths),
        }
        payload.update(dict(self.diagnostics))
        return payload

    def export(self, output_dir: str | Path) -> dict[str, str]:
        out_dir = Path(output_dir)
        records_path = out_dir / "simulation_records.jsonl"
        detections_path = out_dir / "simulation_detections.jsonl"
        summary_path = out_dir / "simulation_summary.json"
        per_uav_summary_path = out_dir / "per_uav_detection_summary.csv"
        threshold_diagnostics_path = out_dir / "threshold_diagnostics.csv"
        paths = {
            "simulation_records": str(records_path),
            "simulation_detections": str(detections_path),
            "simulation_summary": str(summary_path),
            "per_uav_detection_summary": str(per_uav_summary_path),
            "threshold_diagnostics": str(threshold_diagnostics_path),
        }
        object.__setattr__(self, "export_paths", paths)
        write_jsonl(self.record_rows(), records_path)
        write_jsonl(list(self.online_detection_results), detections_path)
        _write_csv_rows(
            per_uav_summary_path,
            _per_uav_detection_summary_rows(
                records=self.records,
                detections=self.online_detection_results,
                diagnostics=self.diagnostics,
            ),
            PER_UAV_DETECTION_SUMMARY_COLUMNS,
        )
        _write_csv_rows(
            threshold_diagnostics_path,
            _threshold_diagnostic_rows(
                records=self.records,
                detections=self.online_detection_results,
                diagnostics=self.diagnostics,
            ),
            THRESHOLD_DIAGNOSTICS_COLUMNS,
        )
        save_json(self.summary_payload(), summary_path)
        return dict(self.export_paths)


class SimulationEngine:
    """Coordinate mission, channel, attack, energy, and traffic updates."""

    def __init__(
        self,
        uavs: Sequence[UAV],
        gcs: GCS,
        attacker: Attacker | None = None,
        attack_injector: AttackInjector | None = None,
        config: SimulationConfig | None = None,
        online_detector: Any | None = None,
        response_manager: ResponseManager | None = None,
        attack_replay_pool: AttackReplayPool | None = None,
        scenario_config: ScenarioConfig | None = None,
    ):
        self.uavs = list(uavs)
        self.gcs = gcs
        self.attacker = attacker
        self.attack_injector = attack_injector or AttackInjector()
        self.config = config or SimulationConfig()
        self.scenario_config = scenario_config or self._load_attack_scenario_from_config()
        self.online_detector = online_detector
        response_attack_events = self._response_attack_events()
        self.response_manager = response_manager or ResponseManager(
            strategy=self.config.response_strategy,
            attack_events=response_attack_events,
        )
        self.attack_replay_pool = None if self._pure_ids_csv_enabled() else attack_replay_pool
        self.traffic_mixer = (
            None
            if self._pure_ids_csv_enabled() or self.attack_replay_pool is None
            else TrafficMixer(self.attack_replay_pool, seed=self.config.seed)
        )
        self.pure_ids_cursor = (
            PureIDSCsvReplayCursor(
                csv_path=self.config.pure_ids_csv_path,
                group_col=self.config.pure_ids_group_col,
                selected_uav_ids=[uav.uav_id for uav in self.uavs],
                keep_original_order=bool(self.config.pure_ids_replay_keep_original_order),
                split_filter=self.config.pure_ids_replay_split_filter,
            )
            if self._pure_ids_csv_enabled()
            else None
        )
        self.rng = random.Random(self.config.seed)
        self._initialize_uav_scenario_state()

    def _load_attack_scenario_from_config(self) -> ScenarioConfig | None:
        scenario_path = str(self.config.attack_scenario_path or "").strip()
        if not scenario_path:
            return None
        return load_scenario_from_yaml(scenario_path, set_as_active=False)

    def _response_attack_events(self) -> list[InjectorAttackEvent]:
        if self.scenario_config is None:
            return list(self.attack_injector.events)
        rows: list[InjectorAttackEvent] = []
        for idx, event in enumerate(self.scenario_config.attack_events):
            declared_types = event.attack_types or ("benign",)
            for attack_type in declared_types:
                rows.append(
                    InjectorAttackEvent(
                        start_s=float(event.start_time),
                        end_s=float(event.end_time),
                        attack_type=str(attack_type),
                        intensity=float(event.intensity),
                        uav_id=event.uav_id,
                        plan_id=f"{self.scenario_config.name}:{idx}:{attack_type}",
                        attack_labels=tuple(declared_types),
                    )
                )
        return rows

    def _reset_runtime_components(self) -> None:
        if self.pure_ids_cursor is not None:
            self.pure_ids_cursor.reset()
        if self.attack_replay_pool is not None:
            self.attack_replay_pool.reset()
        if self.traffic_mixer is not None:
            self.traffic_mixer.reset()
        if self.online_detector is not None and hasattr(self.online_detector, "reset"):
            self.online_detector.reset()

    def _pure_ids_csv_enabled(self) -> bool:
        return _clean_text(self.config.dataset_replay_mode).lower() == "pure_ids_csv"

    def _resolve_attack_state(self, *, sim_time_s: float, uav: UAV) -> _ResolvedAttackState:
        if self.scenario_config is None:
            return self._injector_attack_state(sim_time_s=sim_time_s, uav=uav)
        return self._scenario_attack_state(sim_time_s=sim_time_s, uav=uav)

    def _injector_attack_state(self, *, sim_time_s: float, uav: UAV) -> _ResolvedAttackState:
        active_event = self.attack_injector.active_event_at(sim_time_s, uav_id=uav.uav_id)
        snapshot = self.attack_injector.snapshot_at(
            sim_time_s,
            uav_id=uav.uav_id,
            attacker=self.attacker,
        )
        labels = _ordered_unique(getattr(active_event, "attack_labels", ()) if active_event is not None else ())
        if not labels and snapshot.active and snapshot.attack_type != "benign":
            labels = (snapshot.attack_type,)
        return _ResolvedAttackState(
            snapshot=snapshot,
            attack_types=labels,
            intensity=float(snapshot.intensity if active_event is None else getattr(active_event, "intensity", snapshot.intensity)),
            attack_replay_mode=str(self.config.attack_replay_mode),
            source_dataset=None,
            is_ood=False,
        )

    def _scenario_attack_state(self, *, sim_time_s: float, uav: UAV) -> _ResolvedAttackState:
        active_events = self.scenario_config.get_active_attacks(
            sim_time=sim_time_s,
            uav_id=uav.uav_id,
            mission_phase=uav.mission_phase,
        )
        if not active_events:
            snapshot = build_attack_snapshot("benign")
            self._sync_attacker(snapshot)
            return _ResolvedAttackState(
                snapshot=snapshot,
                attack_types=(),
                intensity=0.0,
                attack_replay_mode=str(self.config.attack_replay_mode),
                source_dataset=None,
                is_ood=False,
            )

        primary_event = self._select_primary_scenario_event(active_events)
        primary_attack_type = primary_event.attack_types[0] if primary_event.attack_types else "benign"
        snapshot = build_attack_snapshot(primary_attack_type, intensity=primary_event.intensity)
        self._sync_attacker(snapshot)
        attack_types = _ordered_unique(
            attack_type
            for event in active_events
            for attack_type in event.attack_types
        )
        is_ood = any(
            bool(event.is_ood)
            if event.is_ood is not None
            else bool(event.source_metadata.get("is_external_ood", False))
            for event in active_events
        )
        return _ResolvedAttackState(
            snapshot=snapshot,
            attack_types=attack_types,
            intensity=float(primary_event.intensity),
            attack_replay_mode=str(primary_event.replay_mode),
            source_dataset=str(primary_event.source_dataset),
            is_ood=bool(is_ood),
        )

    def _select_primary_scenario_event(self, events: Sequence[ScenarioAttackEvent]) -> ScenarioAttackEvent:
        return sorted(
            events,
            key=lambda event: (
                -float(event.intensity),
                float(event.start_time),
                -len(event.attack_types),
                str(event.source_dataset),
                str(event.uav_id),
            ),
        )[0]

    def _sync_attacker(self, snapshot: AttackSnapshot) -> None:
        if self.attacker is None:
            return
        self.attacker.active = bool(snapshot.active)
        self.attacker.attack_type = str(snapshot.attack_type)
        self.attacker.intensity = float(snapshot.intensity)

    def _records_per_uav_for_step(self, step_idx: int, total_steps: int) -> int:
        total_steps = int(total_steps)
        if total_steps <= 0:
            return max(int(self.config.records_per_uav_per_step), 0)
        target_records = int(self.config.target_records_per_uav)
        if target_records > 0:
            base_count, remainder = divmod(target_records, total_steps)
            return base_count + (1 if 0 <= int(step_idx) < remainder else 0)
        return max(int(self.config.records_per_uav_per_step), 0)

    def run(self) -> SimulationResult:
        """Run the simulator for the configured duration."""

        pure_ids_mode = self._pure_ids_csv_enabled()
        summary_only_mode = bool(self.config.export_summary_only)
        if self.config.dt_s <= 0.0:
            raise ValueError("dt_s must be positive")
        if self.config.duration_s <= 0.0:
            raise ValueError("duration_s must be positive")
        if self.config.records_per_uav_per_step < 0:
            raise ValueError("records_per_uav_per_step must be non-negative")
        if self.config.target_records_per_uav < 0:
            raise ValueError("target_records_per_uav must be non-negative")
        if pure_ids_mode:
            if self.pure_ids_cursor is None:
                raise ValueError("pure_ids_csv mode requires a valid PureIDSCsvReplayCursor")
            if not _clean_text(self.config.pure_ids_csv_path):
                raise ValueError("pure_ids_csv mode requires pure_ids_csv_path")
            if not _clean_text(self.config.pure_ids_group_col):
                raise ValueError("pure_ids_csv mode requires pure_ids_group_col")
            if int(self.config.pure_ids_replay_records_per_uav_per_step) <= 0:
                raise ValueError("pure_ids_replay_records_per_uav_per_step must be positive")
            if not tuple(self.config.pure_ids_replay_split_filter or ()):
                raise ValueError("pure_ids_csv mode requires at least one pure_ids_replay_split_filter entry")
        self._reset_runtime_components()

        records: list[TrafficRecord] = []
        online_detection_results: list[dict[str, Any]] = []
        record_aggregate = _SummaryRecordAggregate()
        uavs_by_id = {uav.uav_id: uav for uav in self.uavs}
        configured_steps = int(math.ceil(self.config.duration_s / self.config.dt_s))
        step_idx = 0
        while True:
            if pure_ids_mode:
                if bool(self.config.pure_ids_replay_stop_when_exhausted):
                    if self.pure_ids_cursor is not None and self.pure_ids_cursor.all_exhausted():
                        break
                elif step_idx >= configured_steps:
                    break
            elif step_idx >= configured_steps:
                break
            sim_time_s = float(step_idx) * float(self.config.dt_s)
            step_records: list[TrafficRecord] = []
            split_changed_after_step = False
            for uav in self.uavs:
                attack_state = self._resolve_attack_state(sim_time_s=sim_time_s, uav=uav)
                self._apply_attack_side_effects(uav, attack_state.snapshot)
                update_uav_mission(uav, dt_s=self.config.dt_s, sim_time_s=sim_time_s)
                link = simulate_link_state(
                    uav,
                    self.gcs,
                    attack=attack_state.snapshot,
                    attacker=self.attacker,
                    rng=self.rng,
                )
                link = self.response_manager.apply_link_effects(uav, link)
                bytes_up, bytes_down = estimate_traffic_bytes(
                    uav,
                    link,
                    attack_state.snapshot,
                    dt_s=self.config.dt_s,
                    rng=self.rng,
                )
                bytes_up, bytes_down = self.response_manager.apply_traffic_effects(uav, bytes_up, bytes_down)
                compute_state = estimate_compute_state(
                    dt_s=self.config.dt_s,
                    uav=uav,
                    link=link,
                    bytes_up=bytes_up,
                    bytes_down=bytes_down,
                    attack=attack_state.snapshot,
                )
                energy = estimate_step_energy(
                    dt_s=self.config.dt_s,
                    uav=uav,
                    link=link,
                    bytes_up=bytes_up,
                    bytes_down=bytes_down,
                    attack=attack_state.snapshot,
                    compute_state=compute_state,
                )
                self._apply_energy_draw(uav, energy)
                base_record = generate_traffic_record(
                    timestamp_s=sim_time_s,
                    uav=uav,
                    link=link,
                    attack=attack_state.snapshot,
                    dt_s=self.config.dt_s,
                    energy=energy,
                    bytes_up=bytes_up,
                    bytes_down=bytes_down,
                    response_state=self.response_manager.state_for(uav.uav_id),
                )
                if pure_ids_mode:
                    emitted_records, split_changed = self._pure_ids_records_for_step(
                        sim_time_s=sim_time_s,
                        uav=uav,
                        base_record=base_record,
                        attack_state=attack_state,
                        emit_count=int(self.config.pure_ids_replay_records_per_uav_per_step),
                    )
                    split_changed_after_step = split_changed_after_step or bool(split_changed)
                else:
                    emit_count = self._records_per_uav_for_step(step_idx, configured_steps)
                    emitted_records = self._records_for_step(
                        sim_time_s=sim_time_s,
                        uav=uav,
                        base_record=base_record,
                        attack_state=attack_state,
                        emit_count=emit_count,
                    )
                if summary_only_mode:
                    record_aggregate.observe_records(emitted_records)
                else:
                    records.extend(emitted_records)
                step_records.extend(emitted_records)
            if self.config.enable_online_detection:
                if self.online_detector is None or not hasattr(self.online_detector, "consume_records"):
                    raise ValueError("online detection is enabled but no valid online_detector was provided")
                detections = list(self.online_detector.consume_records(step_records))
                for detection in detections:
                    enriched = self._enrich_detection_payload(
                        detection,
                        step_records=step_records,
                        step_idx=step_idx,
                        sim_time_s=sim_time_s,
                    )
                    enriched = self.response_manager.process_detection(
                        enriched,
                        step_records=step_records,
                        uavs_by_id=uavs_by_id,
                        sim_time_s=sim_time_s,
                    )
                    enriched = self._enrich_detection_payload(
                        enriched,
                        step_records=step_records,
                        step_idx=step_idx,
                        sim_time_s=sim_time_s,
                    )
                    online_detection_results.append(enriched)
            if pure_ids_mode and self.pure_ids_cursor is not None and split_changed_after_step:
                if bool(self.config.pure_ids_replay_reset_buffer_on_split_change):
                    detector_buffer = getattr(self.online_detector, "buffer", None) if self.online_detector is not None else None
                    if detector_buffer is not None and hasattr(detector_buffer, "reset"):
                        detector_buffer.reset()
                self.pure_ids_cursor.acknowledge_split_change()
            step_idx += 1

        total_energy_wh = sum(float(uav.cumulative_energy_wh) for uav in self.uavs)
        attack_record_count = (
            int(record_aggregate.attack_record_count)
            if summary_only_mode
            else sum(1 for record in records if record.attack_active)
        )
        response_metrics = self.response_manager.build_metrics(self.uavs)
        detector_diagnostics: dict[str, Any] = {}
        if self.online_detector is not None and hasattr(self.online_detector, "simulation_diagnostics"):
            detector_diagnostics = dict(self.online_detector.simulation_diagnostics() or {})

        gt_ood_window_count = sum(1 for detection in online_detection_results if _detection_ground_truth_is_ood(detection))
        gt_attack_window_count = sum(
            1
            for detection in online_detection_results
            if _detection_gt_attack_active(detection) and not _detection_ground_truth_is_ood(detection)
        )
        benign_window_count = max(len(online_detection_results) - gt_attack_window_count - gt_ood_window_count, 0)
        pred_alert_window_count = sum(1 for detection in online_detection_results if _detection_has_alert(detection))
        pred_known_attack_alert_window_count = sum(
            1 for detection in online_detection_results if _detection_known_attack_alert(detection)
        )
        pred_ood_window_count = sum(1 for detection in online_detection_results if _detection_ood_alert(detection))
        pred_dual_alert_window_count = sum(
            1
            for detection in online_detection_results
            if _detection_known_attack_alert(detection) and _detection_ood_alert(detection)
        )
        false_alert_window_count = sum(1 for detection in online_detection_results if _detection_false_alert(detection))
        missed_attack_window_count = sum(1 for detection in online_detection_results if _detection_missed_attack(detection))
        per_uav_window_totals: dict[str, int] = {}
        per_uav_benign_window_totals: dict[str, int] = {}
        per_uav_gt_attack_window_totals: dict[str, int] = {}
        per_uav_gt_ood_window_totals: dict[str, int] = {}
        per_uav_pred_alert_totals: dict[str, int] = {}
        per_uav_pred_ood_totals: dict[str, int] = {}
        per_uav_false_alert_totals: dict[str, int] = {}
        for detection in online_detection_results:
            group_id = _clean_text(detection.get("group_id"))
            if not group_id:
                continue
            per_uav_window_totals[group_id] = per_uav_window_totals.get(group_id, 0) + 1
            partition = _detection_partition(detection)
            if partition == "benign":
                per_uav_benign_window_totals[group_id] = per_uav_benign_window_totals.get(group_id, 0) + 1
            elif partition == "attack":
                per_uav_gt_attack_window_totals[group_id] = per_uav_gt_attack_window_totals.get(group_id, 0) + 1
            else:
                per_uav_gt_ood_window_totals[group_id] = per_uav_gt_ood_window_totals.get(group_id, 0) + 1
            if _detection_has_alert(detection):
                per_uav_pred_alert_totals[group_id] = per_uav_pred_alert_totals.get(group_id, 0) + 1
            if _detection_is_ood(detection):
                per_uav_pred_ood_totals[group_id] = per_uav_pred_ood_totals.get(group_id, 0) + 1
            if _detection_false_alert(detection):
                per_uav_false_alert_totals[group_id] = per_uav_false_alert_totals.get(group_id, 0) + 1
        per_uav_alert_rate = {
            group_id: 0.0 if total <= 0 else float(per_uav_pred_alert_totals.get(group_id, 0)) / float(total)
            for group_id, total in sorted(per_uav_window_totals.items())
        }
        per_uav_false_alert_rate_on_benign_windows = {
            group_id: 0.0
            if benign_total <= 0
            else float(per_uav_false_alert_totals.get(group_id, 0)) / float(benign_total)
            for group_id, benign_total in sorted(
                ((group_id, per_uav_benign_window_totals.get(group_id, 0)) for group_id in per_uav_window_totals),
                key=lambda item: item[0],
            )
        }
        summary_diagnostics = {
            "model_input_columns": list(detector_diagnostics.get("model_input_columns", [])),
            "dropped_simulation_columns": list(detector_diagnostics.get("dropped_simulation_columns", [])),
            "missing_model_features": list(detector_diagnostics.get("missing_model_features", [])),
            "extra_simulation_columns": list(detector_diagnostics.get("extra_simulation_columns", [])),
            "per_uav_missing_feature_ratio": dict(detector_diagnostics.get("per_uav_missing_feature_ratio", {})),
            "per_uav_zero_feature_ratio": dict(detector_diagnostics.get("per_uav_zero_feature_ratio", {})),
            "per_uav_input_mean": dict(detector_diagnostics.get("per_uav_input_mean", {})),
            "per_uav_input_std": dict(detector_diagnostics.get("per_uav_input_std", {})),
            "score_mode": detector_diagnostics.get("score_mode"),
            "threshold_mode": detector_diagnostics.get("threshold_mode"),
            "score_direction": detector_diagnostics.get("score_direction"),
            "score_normalization_mode": detector_diagnostics.get("score_normalization_mode"),
            "normalized_threshold": detector_diagnostics.get("normalized_threshold"),
            "per_uav_threshold": dict(detector_diagnostics.get("per_uav_threshold", {})),
            "per_uav_threshold_source": dict(detector_diagnostics.get("per_uav_threshold_source", {})),
            "per_uav_raw_threshold": dict(detector_diagnostics.get("per_uav_raw_threshold", {})),
            "per_uav_normalized_threshold": dict(detector_diagnostics.get("per_uav_normalized_threshold", {})),
            "per_uav_id_score_mean": dict(detector_diagnostics.get("per_uav_id_score_mean", {})),
            "per_uav_id_score_median": dict(detector_diagnostics.get("per_uav_id_score_median", {})),
            "per_uav_benign_warmup_window_count": dict(detector_diagnostics.get("per_uav_benign_warmup_window_count", {})),
            "per_uav_benign_score_q50": dict(detector_diagnostics.get("per_uav_benign_score_q50", {})),
            "per_uav_benign_score_q90": dict(detector_diagnostics.get("per_uav_benign_score_q90", {})),
            "per_uav_benign_score_q95": dict(detector_diagnostics.get("per_uav_benign_score_q95", {})),
            "per_uav_benign_score_q99": dict(detector_diagnostics.get("per_uav_benign_score_q99", {})),
            "per_uav_raw_score_q50": dict(detector_diagnostics.get("per_uav_raw_score_q50", {})),
            "per_uav_raw_score_q90": dict(detector_diagnostics.get("per_uav_raw_score_q90", {})),
            "per_uav_raw_score_q95": dict(detector_diagnostics.get("per_uav_raw_score_q95", {})),
            "per_uav_raw_score_q99": dict(detector_diagnostics.get("per_uav_raw_score_q99", {})),
            "per_uav_normalized_score_q50": dict(detector_diagnostics.get("per_uav_normalized_score_q50", {})),
            "per_uav_normalized_score_q90": dict(detector_diagnostics.get("per_uav_normalized_score_q90", {})),
            "per_uav_normalized_score_q95": dict(detector_diagnostics.get("per_uav_normalized_score_q95", {})),
            "per_uav_normalized_score_q99": dict(detector_diagnostics.get("per_uav_normalized_score_q99", {})),
            "per_uav_benign_window_count": dict(sorted(per_uav_benign_window_totals.items())),
            "per_uav_gt_attack_window_count": dict(sorted(per_uav_gt_attack_window_totals.items())),
            "per_uav_gt_ood_window_count": dict(sorted(per_uav_gt_ood_window_totals.items())),
            "per_uav_pred_alert_window_count": dict(sorted(per_uav_pred_alert_totals.items())),
            "per_uav_pred_ood_window_count": dict(sorted(per_uav_pred_ood_totals.items())),
            "per_uav_alert_rate": per_uav_alert_rate,
            "per_uav_false_alert_rate_on_benign_windows": per_uav_false_alert_rate_on_benign_windows,
            "per_uav_raw_ood_score_mean": dict(detector_diagnostics.get("per_uav_raw_ood_score_mean", {})),
            "per_uav_normalized_ood_score_mean": dict(detector_diagnostics.get("per_uav_normalized_ood_score_mean", {})),
            "per_uav_score_unique_count": dict(detector_diagnostics.get("per_uav_score_unique_count", {})),
            "per_uav_inference_error_count": dict(detector_diagnostics.get("per_uav_inference_error_count", {})),
            "per_window_raw_ood_score": list(detector_diagnostics.get("per_window_raw_ood_score", [])),
            "per_window_normalized_ood_score": list(detector_diagnostics.get("per_window_normalized_ood_score", [])),
            "inference_error_count": int(detector_diagnostics.get("inference_error_count", 0) or 0),
            "fallback_score_used_count": int(detector_diagnostics.get("fallback_score_used_count", 0) or 0),
            "synthetic_benign_used": bool(self.traffic_mixer.synthetic_benign_used) if self.traffic_mixer is not None else False,
            "feature_adapter_enabled": bool(detector_diagnostics.get("feature_adapter_enabled", False)),
            "strict_model_feature_mode": bool(detector_diagnostics.get("strict_model_feature_mode", False)),
            "feature_columns_source": detector_diagnostics.get("feature_columns_source"),
            "threshold_quantile": detector_diagnostics.get("threshold_quantile"),
            "gt_attack_window_count": int(gt_attack_window_count),
            "benign_window_count": int(benign_window_count),
            "gt_ood_window_count": int(gt_ood_window_count),
            "pred_alert_window_count": int(pred_alert_window_count),
            "pred_known_attack_alert_window_count": int(pred_known_attack_alert_window_count),
            "pred_ood_window_count": int(pred_ood_window_count),
            "pred_dual_alert_window_count": int(pred_dual_alert_window_count),
            "false_alert_window_count": int(false_alert_window_count),
            "missed_attack_window_count": int(missed_attack_window_count),
        }
        summary_diagnostics["per_uav_metadata"] = self._metadata_by_uav()
        if summary_only_mode:
            summary_diagnostics.update(record_aggregate.diagnostics())
        if pure_ids_mode and self.pure_ids_cursor is not None:
            summary_diagnostics.update(
                {
                    "dataset_replay_mode": "pure_ids_csv",
                    "pure_ids_csv_path": str(self.config.pure_ids_csv_path),
                    "pure_ids_group_col": str(self.config.pure_ids_group_col),
                    "pure_ids_replay_records_per_uav_per_step": int(
                        self.config.pure_ids_replay_records_per_uav_per_step
                    ),
                    "pure_ids_replay_stop_when_exhausted": bool(self.config.pure_ids_replay_stop_when_exhausted),
                    "pure_ids_replay_keep_original_order": bool(self.config.pure_ids_replay_keep_original_order),
                    "pure_ids_replay_no_mixing": bool(self.config.pure_ids_replay_no_mixing),
                    "pure_ids_replay_split_filter": list(self.config.pure_ids_replay_split_filter),
                    "pure_ids_replay_reset_buffer_on_split_change": bool(
                        self.config.pure_ids_replay_reset_buffer_on_split_change
                    ),
                    "pure_ids_split_source_column": str(self.pure_ids_cursor.split_source_column),
                    "pure_ids_total_rows_by_uav": self.pure_ids_cursor.total_rows_by_uav(),
                    "pure_ids_replayed_rows_by_uav": self.pure_ids_cursor.replayed_rows_by_uav(),
                    "pure_ids_remaining_rows_by_uav": self.pure_ids_cursor.remaining_rows_by_uav(),
                }
            )
        per_uav_summary_rows = _per_uav_detection_summary_rows(
            records=records,
            detections=online_detection_results,
            diagnostics=summary_diagnostics,
        )
        summary_diagnostics.update(
            {
                "per_uav_score_mode": {str(row["uav_id"]): row.get("score_mode") for row in per_uav_summary_rows},
                "per_uav_threshold_mode": {str(row["uav_id"]): row.get("threshold_mode") for row in per_uav_summary_rows},
                "per_uav_score_direction": {str(row["uav_id"]): row.get("score_direction") for row in per_uav_summary_rows},
                "per_uav_benign_score_mean": {str(row["uav_id"]): row.get("benign_score_mean") for row in per_uav_summary_rows},
                "per_uav_attack_score_mean": {str(row["uav_id"]): row.get("attack_score_mean") for row in per_uav_summary_rows},
                "per_uav_ood_score_mean": {str(row["uav_id"]): row.get("ood_score_mean") for row in per_uav_summary_rows},
                "per_uav_score_separation": {str(row["uav_id"]): row.get("score_separation") for row in per_uav_summary_rows},
                "per_uav_direction_warning": {str(row["uav_id"]): row.get("direction_warning") for row in per_uav_summary_rows},
                "per_uav_reversed_score_separation": {
                    str(row["uav_id"]): row.get("reversed_score_separation") for row in per_uav_summary_rows
                },
                "per_uav_detection_summary_rows": per_uav_summary_rows,
            }
        )
        result = SimulationResult(
            records=records,
            total_energy_wh=total_energy_wh,
            attack_record_count=attack_record_count,
            online_detection_results=online_detection_results,
            response_events=[event.to_dict() for event in self.response_manager.response_events],
            alert_count=response_metrics.alert_count,
            response_count=response_metrics.response_count,
            average_alert_delay=response_metrics.average_alert_delay,
            false_alert_count=response_metrics.false_alert_count,
            mission_success=response_metrics.mission_success,
            scenario_name=None if self.scenario_config is None else self.scenario_config.name,
            diagnostics=summary_diagnostics,
        )
        output_dir = str(self.config.output_dir or "").strip()
        if output_dir:
            result.export(output_dir)
        return result

    def _apply_attack_side_effects(self, uav: UAV, attack: AttackSnapshot) -> None:
        """Map selected cyber events to flight-side effects."""

        if attack.attack_type == "command_injection" and attack.active and attack.intensity >= 0.85:
            if uav.mission_phase in AIRBORNE_PHASES and uav.mission_phase not in {"land", "emergency"}:
                trigger_emergency(uav, reason="command_injection_detected")
        elif attack.attack_type == "jamming_proxy" and attack.active and attack.intensity >= 0.95:
            if uav.battery_soc <= max(uav.reserve_battery_soc, 25.0) and uav.mission_phase in {"cruise", "hover"}:
                trigger_emergency(uav, reason="jamming_failsafe")

    def _apply_energy_draw(self, uav: UAV, energy: EnergyBreakdown) -> None:
        """Update cumulative energy counters and battery state-of-charge."""

        uav.cumulative_flight_energy_wh += energy.flight_wh
        uav.cumulative_comm_energy_wh += energy.communication_wh
        uav.cumulative_detect_energy_wh += energy.detection_wh
        uav.cumulative_energy_wh += energy.total_wh
        uav.cpu_load = float(energy.cpu_load)
        uav.board_temperature_c = float(energy.board_temperature_c)
        soc_drop = 100.0 * energy.total_wh / max(uav.battery_capacity_wh, 1e-6)
        uav.battery_soc = min(max(uav.battery_soc - soc_drop, 0.0), 100.0)

    def _initialize_uav_scenario_state(self) -> None:
        """Ensure every UAV has a scenario profile and thermal baseline."""

        scenario_profile_path = str(self.config.scenario_profile_path or "").strip()
        resolved_path = str(resolve_scenario_profile_path(scenario_profile_path))
        profile = load_scenario_profile(resolved_path)
        compute_cfg = profile.get("compute", {})
        ambient_temperature_c = 30.0
        if isinstance(compute_cfg, dict):
            ambient_temperature_c = float(compute_cfg.get("ambient_temperature_c", ambient_temperature_c))
        for uav in self.uavs:
            uav.metadata.setdefault("scenario_profile_path", resolved_path)
            if self.scenario_config is not None:
                uav.metadata.setdefault("attack_scenario_name", self.scenario_config.name)
            if float(getattr(uav, "board_temperature_c", 0.0)) <= 0.0:
                uav.board_temperature_c = ambient_temperature_c

    def _metadata_by_uav(self) -> dict[str, dict[str, object]]:
        rows: dict[str, dict[str, object]] = {}
        for uav in self.uavs:
            uav_metadata = dict(getattr(uav, "metadata", {}) or {})
            metadata = resolve_simulation_source_metadata(
                dataset_name=_clean_text(uav_metadata.get("dataset_name")),
                uav_id=uav.uav_id,
                source_type=uav_metadata.get("source_type"),
                simulation_role=uav_metadata.get("simulation_role"),
                source_note=uav_metadata.get("source_note"),
            )
            rows[str(uav.uav_id)] = {
                "dataset_name": _clean_text(metadata.get("dataset_name")),
                "dataset_display": _clean_text(metadata.get("dataset_display")),
                "source_type": _clean_text(metadata.get("source_type")),
                "simulation_role": _clean_text(metadata.get("simulation_role")),
                "source_note": _clean_text(metadata.get("source_note")),
            }
        return rows

    def _pure_ids_known_labels(self) -> set[str]:
        if self.online_detector is None:
            return set()
        class_to_idx = getattr(self.online_detector, "class_to_idx", None)
        if not isinstance(class_to_idx, Mapping):
            return set()
        return {_clean_text(label).lower() for label in class_to_idx if _clean_text(label)}

    def _pure_ids_truth_from_payload(self, payload: Mapping[str, object]) -> dict[str, object]:
        benign_labels = {"benign", "normal", "normal traffic"}
        labels = [_clean_text(label) for label in parse_label_cell(payload.get("label")) if _clean_text(label)]
        attack_labels = [label for label in labels if label.lower() not in benign_labels]
        explicit_attack_type = _clean_text(payload.get("gt_attack_type")) or _clean_text(payload.get("attack_type"))
        if explicit_attack_type and explicit_attack_type.lower() not in benign_labels:
            attack_type = explicit_attack_type
        elif attack_labels:
            attack_type = _collapse_attack_types(attack_labels)
        else:
            attack_type = "benign"
        explicit_attack_active: bool | None = None
        if not _is_missing(payload.get("gt_attack_active")):
            explicit_attack_active = _coerce_bool(payload.get("gt_attack_active"))
        elif not _is_missing(payload.get("attack_active")):
            explicit_attack_active = _coerce_bool(payload.get("attack_active"))
        attack_active = bool((attack_type != "benign") if explicit_attack_active is None else explicit_attack_active)
        explicit_truth_is_ood: bool | None = None
        if not _is_missing(payload.get("ground_truth_is_ood")):
            explicit_truth_is_ood = _coerce_bool(payload.get("ground_truth_is_ood"))
        if explicit_truth_is_ood is not None:
            ground_truth_is_ood = explicit_truth_is_ood
        elif not _is_missing(payload.get("is_ood")):
            ground_truth_is_ood = _coerce_bool(payload.get("is_ood"))
        elif _clean_text(payload.get("split")).lower() in {"test_ood", "ood", "unknown"}:
            ground_truth_is_ood = True
        elif _clean_text(payload.get("recommended_partition")).lower() in {"ood", "test_ood", "unknown"}:
            ground_truth_is_ood = True
        else:
            known_labels = self._pure_ids_known_labels()
            candidate_labels = attack_labels or ([attack_type] if attack_type.lower() not in benign_labels else [])
            ground_truth_is_ood = bool(
                any(
                    label
                    and label.lower() not in benign_labels
                    and label.lower() not in known_labels
                    for label in candidate_labels
                )
            ) if known_labels else False
        if not attack_active:
            attack_type = "benign"
        label_value = payload.get("label")
        if _is_missing(label_value):
            label_value = attack_type if attack_active else "benign"
        return {
            "label": label_value,
            "attack_active": bool(attack_active),
            "attack_type": str(attack_type),
            "ground_truth_is_ood": bool(ground_truth_is_ood),
        }

    def _pure_ids_payload_for_replay(
        self,
        *,
        base_record: TrafficRecord,
        source_row: Mapping[str, object],
        attack_state: _ResolvedAttackState,
    ) -> dict[str, object]:
        payload = {str(key): value for key, value in source_row.items()}
        if _is_missing(payload.get("source_record_id")) and not _is_missing(payload.get("record_id")):
            payload["source_record_id"] = payload.get("record_id")
        payload.pop("record_id", None)
        if _is_missing(payload.get("source_record_id")):
            payload["source_record_id"] = f"csv_row_{int(_coerce_int(payload.get('source_row_index'), 0))}"
        if _is_missing(payload.get("source_timestamp")) and not _is_missing(payload.get("timestamp")):
            payload["source_timestamp"] = payload.get("timestamp")
        payload.pop("timestamp", None)
        if not _is_missing(payload.get(self.config.pure_ids_group_col)):
            payload["source_group_value"] = payload.get(self.config.pure_ids_group_col)
        truth = self._pure_ids_truth_from_payload(payload)
        sim_payload = base_record.to_dict()
        payload["uav_id"] = base_record.uav_id
        payload["label"] = truth["label"]
        payload["attack_active"] = truth["attack_active"]
        payload["attack_type"] = truth["attack_type"]
        payload["gt_attack_active"] = truth["attack_active"]
        payload["gt_attack_type"] = truth["attack_type"]
        payload["ground_truth_is_ood"] = truth["ground_truth_is_ood"]
        payload["sim_source"] = "pure_ids_csv_replay"
        payload["record_kind"] = "pure_ids_csv_replay"
        payload["sim_attack_active"] = bool(sim_payload.get("attack_active", attack_state.active))
        payload["sim_attack_type"] = str(sim_payload.get("attack_type", attack_state.snapshot.attack_type))
        for field_name in (
            "mission_phase",
            "mission_context",
            "battery_soc",
            "speed",
            "altitude",
            "rssi",
            "snr",
            "latency_ms",
            "loss_rate",
            "distance_to_gcs",
            "wind_level",
            "obstacle_factor",
            "cpu_load",
            "board_temperature_c",
            "response_action",
            "response_time",
            "response_reason",
            "flight_energy_wh",
            "communication_energy_wh",
            "detection_energy_wh",
            "total_energy_wh",
            "cumulative_energy_wh",
        ):
            sim_value = sim_payload.get(field_name)
            payload[f"sim_{field_name}"] = sim_value
            if _is_missing(payload.get(field_name)):
                payload[field_name] = sim_value
        return payload

    def _pure_ids_records_for_step(
        self,
        *,
        sim_time_s: float,
        uav: UAV,
        base_record: TrafficRecord,
        attack_state: _ResolvedAttackState,
        emit_count: int,
    ) -> tuple[list[TrafficRecord], bool]:
        if emit_count <= 0 or self.pure_ids_cursor is None:
            return [], False
        source_rows, split_changed = self.pure_ids_cursor.next_rows(uav.uav_id, emit_count)
        if not source_rows:
            return [], bool(split_changed)
        replay_rows = [
            self._pure_ids_payload_for_replay(
                base_record=base_record,
                source_row=row,
                attack_state=attack_state,
            )
            for row in source_rows
        ]
        budgeted_rows = self._allocate_step_budget(base_record=base_record, rows=replay_rows)
        return [self._build_record_from_payload(base_record=base_record, payload=row) for row in budgeted_rows], bool(
            split_changed
        )

    def _records_for_step(
        self,
        *,
        sim_time_s: float,
        uav: UAV,
        base_record: TrafficRecord,
        attack_state: _ResolvedAttackState,
        emit_count: int,
    ) -> list[TrafficRecord]:
        if emit_count <= 0:
            return []
        mixed_rows = self._mixed_rows_for_step(
            base_record=base_record,
            attack_state=attack_state,
            emit_count=emit_count,
        )
        if not mixed_rows:
            mixed_rows = [
                self._fallback_payload_for_step(base_record=base_record, attack_state=attack_state)
                for _ in range(emit_count)
            ]
        budgeted_rows = self._allocate_step_budget(base_record=base_record, rows=mixed_rows)
        return [self._build_record_from_payload(base_record=base_record, payload=row) for row in budgeted_rows]

    def _mixed_rows_for_step(
        self,
        *,
        base_record: TrafficRecord,
        attack_state: _ResolvedAttackState,
        emit_count: int,
    ) -> list[dict[str, object]]:
        if emit_count <= 0:
            return []
        if self.traffic_mixer is None:
            return []
        contexts = [base_record for _ in range(emit_count)]
        if attack_state.active:
            attack_labels: tuple[str, ...] | None = attack_state.attack_types or None
            attack_type = None if attack_labels else attack_state.primary_attack_type
            return list(
                self.traffic_mixer.mix(
                    contexts,
                    attack_dataset_name=attack_state.source_dataset,
                    label=attack_labels,
                    attack_type=attack_type,
                    gt_is_ood=attack_state.is_ood,
                    attack_replay_mode=attack_state.attack_replay_mode,
                    benign_replay_mode="loop",
                    mixed_window_ratio=1.0,
                    window_size=max(emit_count, 1),
                    as_dataframe=False,
                )
            )
        return list(
            self.traffic_mixer.mix(
                contexts,
                benign_replay_mode="loop",
                mixed_window_ratio=0.0,
                window_size=max(emit_count, 1),
                as_dataframe=False,
            )
        )

    def _fallback_payload_for_step(
        self,
        *,
        base_record: TrafficRecord,
        attack_state: _ResolvedAttackState,
    ) -> dict[str, object]:
        payload = base_record.to_dict()
        payload = _apply_payload_source_metadata(
            payload,
            uav_id=base_record.uav_id,
            fallback_dataset_name=str(base_record.dataset_name or ""),
            sim_source="attack_synthetic" if attack_state.active else "benign_synthetic",
        )
        payload["label"] = self._label_for_attack_state(attack_state)
        payload["gt_attack_active"] = bool(attack_state.active)
        payload["gt_attack_type"] = attack_state.gt_attack_type
        payload["ground_truth_is_ood"] = bool(attack_state.is_ood) if attack_state.active else False
        payload["sim_source"] = "attack_synthetic" if attack_state.active else "benign_synthetic"
        payload["record_kind"] = str(payload["sim_source"])
        if attack_state.active and attack_state.source_dataset and not str(payload.get("attack_source_dataset", "")).strip():
            payload["attack_source_dataset"] = str(attack_state.source_dataset)
        return payload

    def _label_for_attack_state(self, attack_state: _ResolvedAttackState) -> str:
        if not attack_state.active:
            return "benign"
        if len(attack_state.attack_types) > 1:
            return ",".join(attack_state.attack_types)
        return attack_state.primary_attack_type

    def _allocate_step_budget(
        self,
        *,
        base_record: TrafficRecord,
        rows: Sequence[Mapping[str, object]],
    ) -> list[dict[str, object]]:
        count = len(rows)
        if count <= 0:
            return []
        bytes_up_parts = self._split_integer(base_record.bytes_up, count)
        bytes_down_parts = self._split_integer(base_record.bytes_down, count)
        flight_part = float(base_record.flight_energy_wh) / count
        communication_part = float(base_record.communication_energy_wh) / count
        detection_part = float(base_record.detection_energy_wh) / count
        total_part = float(base_record.total_energy_wh) / count
        allocated: list[dict[str, object]] = []
        for idx, row in enumerate(rows):
            payload = dict(row)
            payload["timestamp"] = float(base_record.timestamp)
            payload["sim_time"] = float(base_record.sim_time)
            payload.setdefault("sim_bytes_up", int(bytes_up_parts[idx]))
            payload.setdefault("sim_bytes_down", int(bytes_down_parts[idx]))
            payload.setdefault("sim_flight_energy_wh", float(flight_part))
            payload.setdefault("sim_communication_energy_wh", float(communication_part))
            payload.setdefault("sim_detection_energy_wh", float(detection_part))
            payload.setdefault("sim_total_energy_wh", float(total_part))
            payload.setdefault("sim_cumulative_energy_wh", float(base_record.cumulative_energy_wh))
            payload.setdefault("bytes_up", int(bytes_up_parts[idx]))
            payload.setdefault("bytes_down", int(bytes_down_parts[idx]))
            payload.setdefault("flight_energy_wh", float(flight_part))
            payload.setdefault("communication_energy_wh", float(communication_part))
            payload.setdefault("detection_energy_wh", float(detection_part))
            payload.setdefault("total_energy_wh", float(total_part))
            payload.setdefault("cumulative_energy_wh", float(base_record.cumulative_energy_wh))
            payload["record_id"] = self._record_id_for_payload(
                payload=payload,
                base_record=base_record,
                slot=idx if count > 1 else None,
            )
            if count > 1:
                payload.setdefault("traffic_slot", int(idx))
                if str(payload.get("record_kind", "") or "") == "attack_replay":
                    payload.setdefault("attack_replay_slot", int(idx))
            allocated.append(payload)
        return allocated

    def _record_id_for_payload(
        self,
        *,
        payload: Mapping[str, object],
        base_record: TrafficRecord,
        slot: int | None,
    ) -> str:
        source_id = str(payload.get("record_id", payload.get("source_record_id", "")) or "").strip()
        prefix = f"{base_record.uav_id}:{float(base_record.timestamp):.6f}"
        suffix = "" if slot is None else f":slot{int(slot)}"
        if source_id:
            return f"{prefix}:{source_id}{suffix}"
        if suffix:
            return f"{prefix}{suffix}"
        return prefix

    def _build_record_from_payload(
        self,
        *,
        base_record: TrafficRecord,
        payload: Mapping[str, object],
    ) -> TrafficRecord:
        enriched_payload = _apply_payload_source_metadata(
            payload,
            uav_id=str(payload.get("uav_id", base_record.uav_id) or base_record.uav_id),
            fallback_dataset_name=str(payload.get("dataset_name", base_record.dataset_name) or base_record.dataset_name or ""),
            sim_source=str(payload.get("sim_source", "") or ""),
        )
        standard_fields = {
            "timestamp",
            "uav_id",
            "mission_phase",
            "mission_context",
            "battery_soc",
            "speed",
            "altitude",
            "rssi",
            "snr",
            "latency_ms",
            "loss_rate",
            "distance_to_gcs",
            "wind_level",
            "obstacle_factor",
            "bytes_up",
            "bytes_down",
            "attack_active",
            "attack_type",
            "cpu_load",
            "board_temperature_c",
            "response_action",
            "response_time",
            "response_reason",
            "flight_energy_wh",
            "communication_energy_wh",
            "detection_energy_wh",
            "total_energy_wh",
            "cumulative_energy_wh",
            "sim_time",
            "dataset_name",
            "attack_source_dataset",
            "record_kind",
        }
        extra_features = {
            str(key): value
            for key, value in enriched_payload.items()
            if str(key) not in standard_fields
        }
        response_time_value = enriched_payload.get("response_time", base_record.response_time)
        response_time = None if response_time_value in {None, ""} else _coerce_float(response_time_value, 0.0)
        response_action_value = enriched_payload.get("response_action", base_record.response_action)
        response_reason_value = enriched_payload.get("response_reason", base_record.response_reason)
        return TrafficRecord(
            timestamp=_coerce_float(enriched_payload.get("timestamp", base_record.timestamp), base_record.timestamp),
            uav_id=str(enriched_payload.get("uav_id", base_record.uav_id) or base_record.uav_id),
            mission_phase=str(enriched_payload.get("mission_phase", base_record.mission_phase) or base_record.mission_phase),
            mission_context=str(
                enriched_payload.get("mission_context", base_record.mission_context) or base_record.mission_context
            ),
            battery_soc=_coerce_float(enriched_payload.get("battery_soc", base_record.battery_soc), base_record.battery_soc),
            speed=_coerce_float(enriched_payload.get("speed", base_record.speed), base_record.speed),
            altitude=_coerce_float(enriched_payload.get("altitude", base_record.altitude), base_record.altitude),
            rssi=_coerce_float(enriched_payload.get("rssi", base_record.rssi), base_record.rssi),
            snr=_coerce_float(enriched_payload.get("snr", base_record.snr), base_record.snr),
            latency_ms=_coerce_float(
                enriched_payload.get("latency_ms", base_record.latency_ms),
                base_record.latency_ms,
            ),
            loss_rate=_coerce_float(enriched_payload.get("loss_rate", base_record.loss_rate), base_record.loss_rate),
            distance_to_gcs=_coerce_float(
                enriched_payload.get("distance_to_gcs", base_record.distance_to_gcs),
                base_record.distance_to_gcs,
            ),
            wind_level=_coerce_float(enriched_payload.get("wind_level", base_record.wind_level), base_record.wind_level),
            obstacle_factor=_coerce_float(
                enriched_payload.get("obstacle_factor", base_record.obstacle_factor),
                base_record.obstacle_factor,
            ),
            bytes_up=_coerce_int(enriched_payload.get("bytes_up", base_record.bytes_up), base_record.bytes_up),
            bytes_down=_coerce_int(enriched_payload.get("bytes_down", base_record.bytes_down), base_record.bytes_down),
            attack_active=bool(enriched_payload.get("attack_active", base_record.attack_active)),
            attack_type=str(enriched_payload.get("attack_type", base_record.attack_type) or base_record.attack_type),
            cpu_load=_coerce_float(enriched_payload.get("cpu_load", base_record.cpu_load), base_record.cpu_load),
            board_temperature_c=_coerce_float(
                enriched_payload.get("board_temperature_c", base_record.board_temperature_c),
                base_record.board_temperature_c,
            ),
            response_action=None if response_action_value in {None, ""} else str(response_action_value),
            response_time=response_time,
            response_reason=None if response_reason_value in {None, ""} else str(response_reason_value),
            flight_energy_wh=_coerce_float(
                enriched_payload.get("flight_energy_wh", base_record.flight_energy_wh),
                base_record.flight_energy_wh,
            ),
            communication_energy_wh=_coerce_float(
                enriched_payload.get("communication_energy_wh", base_record.communication_energy_wh),
                base_record.communication_energy_wh,
            ),
            detection_energy_wh=_coerce_float(
                enriched_payload.get("detection_energy_wh", base_record.detection_energy_wh),
                base_record.detection_energy_wh,
            ),
            total_energy_wh=_coerce_float(
                enriched_payload.get("total_energy_wh", base_record.total_energy_wh),
                base_record.total_energy_wh,
            ),
            cumulative_energy_wh=_coerce_float(
                enriched_payload.get("cumulative_energy_wh", base_record.cumulative_energy_wh),
                base_record.cumulative_energy_wh,
            ),
            sim_time=_coerce_float(enriched_payload.get("sim_time", base_record.sim_time), base_record.sim_time),
            dataset_name=str(enriched_payload.get("dataset_name", base_record.dataset_name) or ""),
            attack_source_dataset=str(
                enriched_payload.get("attack_source_dataset", base_record.attack_source_dataset) or ""
            ),
            record_kind=str(enriched_payload.get("record_kind", base_record.record_kind) or base_record.record_kind),
            extra_features=extra_features,
        )

    def _enrich_detection_payload(
        self,
        detection: Mapping[str, Any],
        *,
        step_records: Sequence[TrafficRecord],
        step_idx: int,
        sim_time_s: float,
    ) -> dict[str, Any]:
        enriched = dict(detection)
        enriched["simulation_step"] = _coerce_int(enriched.get("simulation_step", step_idx), step_idx)
        enriched["simulation_time_s"] = _coerce_float(enriched.get("simulation_time_s", sim_time_s), sim_time_s)
        gt_attack_active, attack_types, ground_truth_is_ood = self._attack_truth_from_detection(
            enriched,
            step_records=step_records,
        )
        explicit_gt_active = enriched.get("gt_attack_active")
        if explicit_gt_active is not None:
            gt_attack_active = bool(explicit_gt_active)
        explicit_truth_is_ood = enriched.get("ground_truth_is_ood")
        if explicit_truth_is_ood is not None:
            ground_truth_is_ood = bool(explicit_truth_is_ood)
        gt_attack_type = str(enriched.get("gt_attack_type", "") or "").strip()
        if not gt_attack_type:
            gt_attack_type = _collapse_attack_types(attack_types if gt_attack_active else ())
        if not gt_attack_active:
            gt_attack_type = "benign"
        enriched["gt_attack_active"] = bool(gt_attack_active)
        enriched["gt_attack_type"] = gt_attack_type
        enriched["ground_truth_is_ood"] = bool(ground_truth_is_ood)
        enriched["window_partition"] = (
            "ood" if enriched["ground_truth_is_ood"] else ("attack" if enriched["gt_attack_active"] else "benign")
        )
        enriched["known_pred_labels"] = list(enriched.get("known_pred_labels", []) or [])
        score_mode = str(enriched.get("score_mode", "") or "").strip().lower()
        if enriched.get("ood_score") is None:
            if score_mode == "raw" and enriched.get("raw_ood_score") is not None:
                enriched["ood_score"] = enriched.get("raw_ood_score")
            elif enriched.get("normalized_ood_score") is not None:
                enriched["ood_score"] = enriched.get("normalized_ood_score")
            elif enriched.get("raw_ood_score") is not None:
                enriched["ood_score"] = enriched.get("raw_ood_score")
        if (
            enriched.get("normalized_ood_score") is None
            and score_mode == "normalized"
            and enriched.get("ood_score") is not None
        ):
            enriched["normalized_ood_score"] = enriched.get("ood_score")
        if enriched.get("raw_ood_score") is None and score_mode == "raw" and enriched.get("ood_score") is not None:
            enriched["raw_ood_score"] = enriched.get("ood_score")
        if enriched.get("threshold") is None:
            if enriched.get("ood_threshold") is not None:
                enriched["threshold"] = enriched.get("ood_threshold")
            elif score_mode == "raw" and enriched.get("raw_threshold") is not None:
                enriched["threshold"] = enriched.get("raw_threshold")
            elif score_mode == "normalized" and enriched.get("normalized_threshold") is not None:
                enriched["threshold"] = enriched.get("normalized_threshold")
        enriched.setdefault("normalized_ood_score", None)
        enriched.setdefault("ood_score", None)
        enriched.setdefault("raw_ood_score", None)
        enriched.setdefault("threshold", enriched.get("ood_threshold"))
        enriched.setdefault("ood_threshold", enriched.get("threshold"))
        threshold_source = str(
            enriched.get("threshold_source", enriched.get("ood_threshold_source", "global")) or "global"
        )
        enriched["threshold_source"] = threshold_source
        enriched["ood_threshold_source"] = threshold_source
        truth = dict(enriched.get("ground_truth", {}) or {}) if isinstance(enriched.get("ground_truth"), Mapping) else {}
        truth["attack_active"] = bool(gt_attack_active)
        truth["attack_types"] = list(attack_types if gt_attack_active else ())
        truth["is_ood"] = bool(ground_truth_is_ood)
        enriched["ground_truth"] = truth
        enriched["score_direction"] = str(
            enriched.get("score_direction", "higher_is_more_anomalous") or "higher_is_more_anomalous"
        )
        enriched["is_ood"] = bool(enriched.get("is_ood", False))
        enriched["has_alert"] = bool(enriched.get("has_alert", enriched["is_ood"]))
        enriched["alert_level"] = str(enriched.get("alert_level", "normal") or "normal")
        enriched["top_suspicious_records"] = list(enriched.get("top_suspicious_records", []) or [])
        enriched["false_alert"] = bool((not enriched["gt_attack_active"]) and enriched["has_alert"])
        return enriched

    def _attack_truth_from_detection(
        self,
        detection: Mapping[str, Any],
        *,
        step_records: Sequence[TrafficRecord],
    ) -> tuple[bool, tuple[str, ...], bool]:
        gt_attack_active = bool(detection.get("gt_attack_active", False))
        gt_attack_type = str(detection.get("gt_attack_type", "") or "").strip()
        attack_types = _ordered_unique(gt_attack_type.replace("+", ",").split(",")) if gt_attack_type else ()
        ground_truth_is_ood = bool(detection.get("ground_truth_is_ood", False))
        truth = detection.get("ground_truth")
        if isinstance(truth, Mapping):
            gt_attack_active = gt_attack_active or bool(truth.get("attack_active", False))
            if not attack_types:
                attack_types = _ordered_unique(truth.get("attack_types", []) or [])
            ground_truth_is_ood = ground_truth_is_ood or bool(truth.get("is_ood", False))
        record_attack_active, record_attack_types, record_truth_is_ood = self._attack_truth_from_records(step_records)
        gt_attack_active = gt_attack_active or record_attack_active
        if not attack_types:
            attack_types = record_attack_types
        ground_truth_is_ood = ground_truth_is_ood or record_truth_is_ood
        return gt_attack_active, attack_types, ground_truth_is_ood

    def _attack_truth_from_records(self, records: Sequence[TrafficRecord]) -> tuple[bool, tuple[str, ...], bool]:
        attack_active = False
        attack_types: list[str] = []
        ground_truth_is_ood = False
        for record in records:
            extra = dict(getattr(record, "extra_features", {}) or {})
            current_active = bool(extra.get("gt_attack_active", record.attack_active))
            attack_active = attack_active or current_active
            ground_truth_is_ood = ground_truth_is_ood or bool(extra.get("ground_truth_is_ood", False))
            if not current_active:
                continue
            current_type = str(extra.get("gt_attack_type", record.attack_type) or record.attack_type)
            for token in current_type.replace("+", ",").split(","):
                text = str(token).strip()
                if text:
                    attack_types.append(text)
        return attack_active, _ordered_unique(attack_types), ground_truth_is_ood

    def _split_integer(self, total: int, count: int) -> list[int]:
        if count <= 0:
            return []
        base = int(total) // int(count)
        remainder = int(total) % int(count)
        return [base + (1 if idx < remainder else 0) for idx in range(count)]


def run_simulation(
    uavs: Sequence[UAV],
    gcs: GCS,
    attacker: Attacker | None = None,
    attack_injector: AttackInjector | None = None,
    config: SimulationConfig | None = None,
    online_detector: Any | None = None,
    response_manager: ResponseManager | None = None,
    attack_replay_pool: AttackReplayPool | None = None,
    scenario_config: ScenarioConfig | None = None,
) -> SimulationResult:
    """Convenience wrapper around :class:`SimulationEngine`."""

    engine = SimulationEngine(
        uavs=uavs,
        gcs=gcs,
        attacker=attacker,
        attack_injector=attack_injector,
        config=config,
        online_detector=online_detector,
        response_manager=response_manager,
        attack_replay_pool=attack_replay_pool,
        scenario_config=scenario_config,
    )
    return engine.run()
