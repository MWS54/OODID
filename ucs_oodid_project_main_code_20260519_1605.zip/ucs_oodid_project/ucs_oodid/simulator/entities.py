from __future__ import annotations

from dataclasses import dataclass, field
import math


@dataclass
class UAV:
    """Mutable UAV state used by the live mission simulator."""

    uav_id: str
    mission_context: str = "surveillance"
    home_x_m: float = 0.0
    home_y_m: float = 0.0
    x_m: float = 0.0
    y_m: float = 0.0
    altitude_m: float = 0.0
    speed_mps: float = 0.0
    battery_soc: float = 100.0
    battery_capacity_wh: float = 180.0
    cpu_load: float = 0.0
    board_temperature_c: float = 30.0
    mission_phase: str = "idle"
    mission_elapsed_s: float = 0.0
    phase_elapsed_s: float = 0.0
    auto_start: bool = True
    start_delay_s: float = 0.0
    takeoff_altitude_m: float = 12.0
    cruise_altitude_m: float = 120.0
    takeoff_rate_mps: float = 3.0
    climb_rate_mps: float = 4.0
    descent_rate_mps: float = 3.5
    cruise_speed_mps: float = 18.0
    return_speed_mps: float = 16.0
    route_length_m: float = 800.0
    hover_duration_s: float = 12.0
    critical_battery_soc: float = 12.0
    reserve_battery_soc: float = 20.0
    mission_completed: bool = False
    emergency_reason: str | None = None
    cumulative_flight_energy_wh: float = 0.0
    cumulative_comm_energy_wh: float = 0.0
    cumulative_detect_energy_wh: float = 0.0
    cumulative_energy_wh: float = 0.0
    metadata: dict[str, float | str] = field(default_factory=dict)

    def horizontal_distance_from_home_m(self) -> float:
        """Return current horizontal distance from the home point in meters."""

        return math.hypot(self.x_m - self.home_x_m, self.y_m - self.home_y_m)

    def slant_distance_to(self, x_m: float, y_m: float, altitude_ref_m: float = 0.0) -> float:
        """Return 3D distance to another point in meters."""

        horizontal = math.hypot(self.x_m - x_m, self.y_m - y_m)
        vertical = self.altitude_m - altitude_ref_m
        return math.hypot(horizontal, vertical)


@dataclass
class GCS:
    """Ground control station parameters used by the link model."""

    gcs_id: str = "gcs_01"
    x_m: float = 0.0
    y_m: float = 0.0
    altitude_m: float = 0.0
    tx_power_dbm: float = 30.0
    noise_floor_dbm: float = -96.0
    channel_frequency_mhz: float = 2400.0
    processing_latency_ms: float = 12.0


@dataclass
class Attacker:
    """Attacker entity whose state is updated by the attack injector."""

    attacker_id: str = "attacker_01"
    x_m: float = 250.0
    y_m: float = 50.0
    altitude_m: float = 0.0
    power_dbm: float = 24.0
    active: bool = False
    attack_type: str = "benign"
    intensity: float = 0.0
