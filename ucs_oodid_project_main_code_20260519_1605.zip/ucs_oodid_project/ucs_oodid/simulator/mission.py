from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Any, Literal, Mapping

from .entities import UAV

MissionPhase = Literal["idle", "takeoff", "climb", "cruise", "hover", "return_home", "land", "emergency"]
MISSION_PHASES: tuple[MissionPhase, ...] = (
    "idle",
    "takeoff",
    "climb",
    "cruise",
    "hover",
    "return_home",
    "land",
    "emergency",
)
AIRBORNE_PHASES: frozenset[MissionPhase] = frozenset(
    {"takeoff", "climb", "cruise", "hover", "return_home", "land", "emergency"}
)
MissionContextName = Literal["surveillance", "delivery", "inspection"]
SUPPORTED_MISSION_CONTEXTS: tuple[MissionContextName, ...] = ("surveillance", "delivery", "inspection")


@dataclass(frozen=True)
class MissionUpdate:
    """State transition summary returned after each mission update."""

    previous_phase: MissionPhase
    current_phase: MissionPhase
    transitioned: bool
    reason: str | None = None


@dataclass(frozen=True)
class MissionContext:
    """Task template that shapes a UAV mission without changing phase names."""

    name: MissionContextName
    template: dict[str, Any]


def resolve_mission_context(context: str, profile: Mapping[str, Any]) -> MissionContext:
    """Resolve one configured mission template from the scenario profile."""

    canonical = str(context).strip().lower()
    if canonical not in SUPPORTED_MISSION_CONTEXTS:
        raise ValueError(f"Unsupported mission context: {context}")
    mission_cfg = profile.get("mission_contexts", {})
    if not isinstance(mission_cfg, Mapping):
        raise ValueError("Scenario profile is missing mission_contexts")
    templates = mission_cfg.get("templates", {})
    if not isinstance(templates, Mapping) or canonical not in templates:
        raise ValueError(f"Scenario profile is missing template: {canonical}")
    template = templates[canonical]
    if not isinstance(template, Mapping):
        raise ValueError(f"Mission template must be a mapping: {canonical}")
    return MissionContext(name=canonical, template=dict(template))


def apply_mission_context(
    uav: UAV,
    context: MissionContext,
    *,
    base_route_length_m: float,
    base_hover_duration_s: float,
    base_cruise_altitude_m: float,
    base_cruise_speed_mps: float,
    scale_factor: float = 1.0,
) -> None:
    """Apply a configured mission template onto a UAV state object."""

    template = context.template
    uav.mission_context = context.name
    uav.takeoff_altitude_m = float(template.get("takeoff_altitude_m", uav.takeoff_altitude_m))
    uav.cruise_altitude_m = max(
        uav.takeoff_altitude_m + 8.0,
        float(base_cruise_altitude_m) * float(template.get("cruise_altitude_scale", 1.0)),
    )
    uav.route_length_m = max(
        10.0,
        float(base_route_length_m) * float(template.get("route_length_scale", 1.0)) * float(scale_factor),
    )
    uav.hover_duration_s = max(
        1.0,
        float(base_hover_duration_s) * float(template.get("hover_duration_scale", 1.0)),
    )
    uav.cruise_speed_mps = max(
        1.0,
        float(base_cruise_speed_mps) * float(template.get("cruise_speed_scale", 1.0)),
    )
    uav.return_speed_mps = max(
        1.0,
        uav.cruise_speed_mps * float(template.get("return_speed_scale", 0.92)),
    )
    uav.takeoff_rate_mps = max(0.2, float(uav.takeoff_rate_mps) * float(template.get("takeoff_rate_scale", 1.0)))
    uav.climb_rate_mps = max(0.2, float(uav.climb_rate_mps) * float(template.get("climb_rate_scale", 1.0)))
    uav.descent_rate_mps = max(0.2, float(uav.descent_rate_mps) * float(template.get("descent_rate_scale", 1.0)))
    uav.metadata["mission_context_profile"] = dict(template)
    uav.metadata["payload_power_factor"] = float(template.get("payload_power_factor", 1.0))
    uav.metadata["wind_sensitivity"] = float(template.get("wind_sensitivity", 1.0))
    uav.metadata["obstacle_sensitivity"] = float(template.get("obstacle_sensitivity", 1.0))
    uav.metadata["loiter_radius_m"] = float(template.get("loiter_radius_m", 0.0))
    uav.metadata["loiter_period_s"] = float(template.get("loiter_period_s", 24.0))
    uav.metadata["delivery_drop_altitude_m"] = float(
        template.get("delivery_drop_altitude_m", uav.takeoff_altitude_m)
    )
    uav.metadata["inspection_lateral_wave_m"] = float(template.get("inspection_lateral_wave_m", 0.0))
    uav.metadata["inspection_altitude_wave_m"] = float(template.get("inspection_altitude_wave_m", 0.0))
    uav.metadata["inspection_wave_period_s"] = float(template.get("inspection_wave_period_s", 16.0))


def start_mission(uav: UAV) -> None:
    """Arm the UAV and move it from idle into takeoff."""

    uav.mission_completed = False
    uav.emergency_reason = None
    uav.mission_elapsed_s = 0.0
    for key in (
        "hover_center_x_m",
        "hover_center_y_m",
        "inspection_base_y_m",
        "inspection_base_altitude_m",
    ):
        uav.metadata.pop(key, None)
    _set_phase(uav, "takeoff")


def trigger_emergency(uav: UAV, reason: str) -> None:
    """Force the UAV into the emergency phase."""

    uav.emergency_reason = reason
    _set_phase(uav, "emergency")


def update_uav_mission(uav: UAV, dt_s: float, sim_time_s: float) -> MissionUpdate:
    """Advance the UAV mission state machine by one simulation step."""

    if dt_s <= 0.0:
        raise ValueError("dt_s must be positive")

    previous_phase = _coerce_phase(uav.mission_phase)
    reason: str | None = None

    if previous_phase not in {"idle", "land", "emergency"} and uav.battery_soc <= uav.critical_battery_soc:
        trigger_emergency(uav, reason="critical_battery")
        reason = "critical_battery"
    elif previous_phase in {"cruise", "hover"} and uav.battery_soc <= uav.reserve_battery_soc:
        _set_phase(uav, "return_home")
        reason = "battery_reserve"

    if uav.mission_phase == "idle":
        uav.speed_mps = 0.0
        if uav.auto_start and not uav.mission_completed and sim_time_s >= uav.start_delay_s:
            start_mission(uav)
            reason = reason or "auto_start"
        return MissionUpdate(
            previous_phase=previous_phase,
            current_phase=_coerce_phase(uav.mission_phase),
            transitioned=previous_phase != uav.mission_phase,
            reason=reason,
        )

    uav.phase_elapsed_s += dt_s
    uav.mission_elapsed_s += dt_s

    current_phase = _coerce_phase(uav.mission_phase)
    if current_phase == "takeoff":
        uav.speed_mps = 0.0
        uav.altitude_m = min(uav.takeoff_altitude_m, uav.altitude_m + uav.takeoff_rate_mps * dt_s)
        if uav.altitude_m >= uav.takeoff_altitude_m - 1e-6:
            _set_phase(uav, "climb")
            reason = reason or "takeoff_complete"
    elif current_phase == "climb":
        uav.speed_mps = 0.35 * uav.cruise_speed_mps
        uav.altitude_m = min(uav.cruise_altitude_m, uav.altitude_m + uav.climb_rate_mps * dt_s)
        if uav.altitude_m >= uav.cruise_altitude_m - 1e-6:
            _set_phase(uav, "cruise")
            reason = reason or "climb_complete"
    elif current_phase == "cruise":
        uav.speed_mps = uav.cruise_speed_mps
        remaining_m = max(uav.route_length_m - uav.horizontal_distance_from_home_m(), 0.0)
        travel_m = min(remaining_m, uav.speed_mps * dt_s)
        uav.x_m += travel_m
        if remaining_m <= travel_m + 1e-6:
            _set_phase(uav, "hover")
            reason = reason or "arrived_on_station"
    elif current_phase == "hover":
        uav.speed_mps = 0.0
        if uav.phase_elapsed_s >= uav.hover_duration_s:
            _set_phase(uav, "return_home")
            reason = reason or "hover_complete"
    elif current_phase == "return_home":
        uav.speed_mps = uav.return_speed_mps
        distance_home_m = uav.horizontal_distance_from_home_m()
        travel_m = min(distance_home_m, uav.speed_mps * dt_s)
        _move_toward_home(uav, travel_m)
        if distance_home_m <= travel_m + 1e-6:
            _set_phase(uav, "land")
            reason = reason or "home_reached"
    elif current_phase == "land":
        uav.speed_mps = 0.0
        uav.altitude_m = max(0.0, uav.altitude_m - uav.descent_rate_mps * dt_s)
        if uav.altitude_m <= 1e-6:
            uav.altitude_m = 0.0
            uav.mission_completed = True
            _set_phase(uav, "idle")
            reason = reason or "landing_complete"
    elif current_phase == "emergency":
        uav.speed_mps = max(6.0, 0.6 * uav.return_speed_mps)
        distance_home_m = uav.horizontal_distance_from_home_m()
        travel_m = min(distance_home_m, uav.speed_mps * dt_s)
        _move_toward_home(uav, travel_m)
        uav.altitude_m = max(0.0, uav.altitude_m - 1.2 * uav.descent_rate_mps * dt_s)
        if distance_home_m <= travel_m + 1e-6 and uav.altitude_m <= 1e-6:
            uav.altitude_m = 0.0
            uav.mission_completed = True
            _set_phase(uav, "idle")
            reason = reason or "emergency_complete"
    else:  # pragma: no cover - defensive guard for future changes
        raise ValueError(f"Unsupported mission phase: {uav.mission_phase}")

    _apply_context_dynamics(uav, dt_s)

    return MissionUpdate(
        previous_phase=previous_phase,
        current_phase=_coerce_phase(uav.mission_phase),
        transitioned=previous_phase != uav.mission_phase,
        reason=reason,
    )


def _set_phase(uav: UAV, phase: MissionPhase) -> None:
    """Switch the UAV into a new mission phase."""

    uav.mission_phase = phase
    uav.phase_elapsed_s = 0.0
    if phase == "idle":
        uav.speed_mps = 0.0


def _apply_context_dynamics(uav: UAV, dt_s: float) -> None:
    """Add small task-specific kinematic behaviors for realism."""

    context = str(getattr(uav, "mission_context", "surveillance") or "surveillance").strip().lower()
    profile = uav.metadata.get("mission_context_profile", {})
    if not isinstance(profile, Mapping):
        return

    phase = _coerce_phase(uav.mission_phase)
    if phase == "hover" and context == "surveillance":
        radius_m = float(profile.get("loiter_radius_m", uav.metadata.get("loiter_radius_m", 0.0)))
        period_s = max(float(profile.get("loiter_period_s", uav.metadata.get("loiter_period_s", 24.0))), dt_s)
        if radius_m > 0.0:
            center_x_m = float(uav.metadata.setdefault("hover_center_x_m", uav.x_m))
            center_y_m = float(uav.metadata.setdefault("hover_center_y_m", uav.y_m))
            angle = 2.0 * math.pi * (uav.phase_elapsed_s / period_s)
            uav.x_m = center_x_m + radius_m * math.sin(angle)
            uav.y_m = center_y_m + radius_m * (1.0 - math.cos(angle))
            uav.speed_mps = max(uav.speed_mps, (2.0 * math.pi * radius_m) / period_s)
        return

    if phase == "hover" and context == "delivery":
        drop_altitude_m = min(
            uav.cruise_altitude_m,
            float(profile.get("delivery_drop_altitude_m", uav.metadata.get("delivery_drop_altitude_m", uav.takeoff_altitude_m))),
        )
        midpoint_s = 0.5 * max(uav.hover_duration_s, dt_s)
        if uav.phase_elapsed_s <= midpoint_s:
            uav.altitude_m = max(drop_altitude_m, uav.altitude_m - 0.50 * uav.descent_rate_mps * dt_s)
        else:
            uav.altitude_m = min(uav.cruise_altitude_m, uav.altitude_m + 0.40 * uav.climb_rate_mps * dt_s)
        return

    if context == "inspection" and phase in {"cruise", "hover"}:
        period_s = max(
            float(profile.get("inspection_wave_period_s", uav.metadata.get("inspection_wave_period_s", 16.0))),
            dt_s,
        )
        angle = 2.0 * math.pi * (uav.mission_elapsed_s / period_s)
        lateral_wave_m = float(
            profile.get("inspection_lateral_wave_m", uav.metadata.get("inspection_lateral_wave_m", 0.0))
        )
        altitude_wave_m = float(
            profile.get("inspection_altitude_wave_m", uav.metadata.get("inspection_altitude_wave_m", 0.0))
        )
        base_y_m = float(uav.metadata.setdefault("inspection_base_y_m", uav.home_y_m))
        base_altitude_m = float(uav.metadata.setdefault("inspection_base_altitude_m", uav.cruise_altitude_m))
        if lateral_wave_m > 0.0:
            uav.y_m = base_y_m + lateral_wave_m * math.sin(angle)
        if altitude_wave_m > 0.0:
            uav.altitude_m = max(
                uav.takeoff_altitude_m,
                base_altitude_m + altitude_wave_m * math.sin(angle),
            )


def _move_toward_home(uav: UAV, distance_m: float) -> None:
    """Move the UAV horizontally toward the home point."""

    if distance_m <= 0.0:
        return
    dx = uav.home_x_m - uav.x_m
    dy = uav.home_y_m - uav.y_m
    norm = math.hypot(dx, dy)
    if norm <= 1e-9:
        uav.x_m = uav.home_x_m
        uav.y_m = uav.home_y_m
        return
    scale = min(1.0, distance_m / norm)
    uav.x_m += dx * scale
    uav.y_m += dy * scale


def _coerce_phase(phase: str) -> MissionPhase:
    """Validate and normalize a mission phase string."""

    if phase not in MISSION_PHASES:
        raise ValueError(f"Unsupported mission phase: {phase}")
    return phase
