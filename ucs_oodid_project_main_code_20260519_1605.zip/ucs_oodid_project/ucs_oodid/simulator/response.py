from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Mapping, Sequence

from .attacks import AttackEvent
from .channel import LinkState
from .entities import UAV
from .mission import AIRBORNE_PHASES

SUPPORTED_RESPONSE_ACTIONS: tuple[str, ...] = (
    "alert_only",
    "increase_sampling",
    "conservative_mode",
    "return_home",
    "isolate_link",
)
_ALERT_LEVELS: frozenset[str] = frozenset({"warning", "critical"})
_SCALABLE_UAV_FIELDS: tuple[str, ...] = (
    "takeoff_rate_mps",
    "climb_rate_mps",
    "cruise_speed_mps",
    "return_speed_mps",
)


def _canonicalize_response_action(action: str) -> str:
    canonical = str(action).strip().lower()
    if canonical not in SUPPORTED_RESPONSE_ACTIONS:
        raise ValueError(f"Unsupported response action: {action}")
    return canonical


@dataclass(frozen=True)
class AlertContext:
    """Normalized alert payload emitted by the realtime detector."""

    uav_id: str | None
    simulation_time_s: float
    alert_level: str
    is_ood: bool
    attack_active: bool
    attack_types: tuple[str, ...] = ()
    dominant_ood_source: str | None = None


@dataclass
class ResponseState:
    """Persistent mitigation state applied to one UAV."""

    action: str | None = None
    applied_at_s: float | None = None
    reason: str | None = None
    uplink_multiplier: float = 1.0
    downlink_multiplier: float = 1.0
    link_latency_penalty_ms: float = 0.0
    link_loss_penalty: float = 0.0
    link_snr_penalty_db: float = 0.0
    isolated_link: bool = False
    mission_aborted: bool = False
    metadata: dict[str, float | str | bool] = field(default_factory=dict)

    def update_header(self, *, action: str, applied_at_s: float, reason: str) -> None:
        self.action = str(action)
        self.applied_at_s = float(applied_at_s)
        self.reason = str(reason)


@dataclass(frozen=True)
class ResponseEvent:
    """Single response trigger recorded during simulation."""

    uav_id: str | None
    response_action: str
    response_time: float
    response_reason: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ResponseMetrics:
    """High-level response statistics reported with simulation output."""

    alert_count: int
    response_count: int
    average_alert_delay: float
    false_alert_count: int
    mission_success: bool


class ResponseStrategy:
    """Base class for future response strategies."""

    action_name: str = ""
    allow_retrigger: bool = False

    def should_trigger(self, state: ResponseState, alert: AlertContext) -> bool:
        if self.allow_retrigger:
            return True
        return state.action != self.action_name

    def apply(self, uav: UAV, state: ResponseState, alert: AlertContext) -> ResponseEvent:
        raise NotImplementedError


_STRATEGY_REGISTRY: dict[str, type[ResponseStrategy]] = {}


def register_response_strategy(strategy_cls: type[ResponseStrategy]) -> type[ResponseStrategy]:
    """Register a response strategy so it can be constructed from config."""

    action_name = _canonicalize_response_action(strategy_cls.action_name)
    _STRATEGY_REGISTRY[action_name] = strategy_cls
    return strategy_cls


def build_response_strategy(action: str) -> ResponseStrategy:
    """Construct one registered response strategy."""

    canonical = _canonicalize_response_action(action)
    try:
        return _STRATEGY_REGISTRY[canonical]()
    except KeyError as exc:  # pragma: no cover - defensive guard for future changes
        raise ValueError(f"Unsupported response action: {action}") from exc


def _build_response_reason(alert: AlertContext) -> str:
    parts = [f"alert_level={alert.alert_level}"]
    if alert.attack_types:
        parts.append("attack_types=" + ",".join(alert.attack_types))
    elif alert.is_ood:
        parts.append("attack_types=unknown")
    if alert.dominant_ood_source:
        parts.append(f"dominant_ood_source={alert.dominant_ood_source}")
    return ", ".join(parts)


def _transition_phase(uav: UAV, phase: str) -> None:
    uav.mission_phase = str(phase)
    uav.phase_elapsed_s = 0.0
    if phase == "idle":
        uav.speed_mps = 0.0


def _scale_uav_field_once(uav: UAV, field_name: str, factor: float) -> None:
    base_key = f"response_base_{field_name}"
    if base_key not in uav.metadata:
        uav.metadata[base_key] = float(getattr(uav, field_name))
    setattr(uav, field_name, float(uav.metadata[base_key]) * float(factor))


@register_response_strategy
class AlertOnlyStrategy(ResponseStrategy):
    action_name = "alert_only"
    allow_retrigger = True

    def apply(self, uav: UAV, state: ResponseState, alert: AlertContext) -> ResponseEvent:
        reason = _build_response_reason(alert)
        state.update_header(action=self.action_name, applied_at_s=alert.simulation_time_s, reason=reason)
        return ResponseEvent(
            uav_id=alert.uav_id or uav.uav_id,
            response_action=self.action_name,
            response_time=alert.simulation_time_s,
            response_reason=reason,
        )


@register_response_strategy
class IncreaseSamplingStrategy(ResponseStrategy):
    action_name = "increase_sampling"

    def apply(self, uav: UAV, state: ResponseState, alert: AlertContext) -> ResponseEvent:
        reason = _build_response_reason(alert)
        state.update_header(action=self.action_name, applied_at_s=alert.simulation_time_s, reason=reason)
        state.uplink_multiplier = max(state.uplink_multiplier, 1.8)
        state.downlink_multiplier = max(state.downlink_multiplier, 1.35)
        state.metadata["sampling_boost_enabled"] = True
        return ResponseEvent(
            uav_id=alert.uav_id or uav.uav_id,
            response_action=self.action_name,
            response_time=alert.simulation_time_s,
            response_reason=reason,
        )


@register_response_strategy
class ConservativeModeStrategy(ResponseStrategy):
    action_name = "conservative_mode"

    def apply(self, uav: UAV, state: ResponseState, alert: AlertContext) -> ResponseEvent:
        reason = _build_response_reason(alert)
        state.update_header(action=self.action_name, applied_at_s=alert.simulation_time_s, reason=reason)
        if not bool(state.metadata.get("conservative_mode_applied", False)):
            for field_name in _SCALABLE_UAV_FIELDS:
                _scale_uav_field_once(uav, field_name, 0.70 if "speed" in field_name else 0.85)
            state.metadata["conservative_mode_applied"] = True
        return ResponseEvent(
            uav_id=alert.uav_id or uav.uav_id,
            response_action=self.action_name,
            response_time=alert.simulation_time_s,
            response_reason=reason,
        )


@register_response_strategy
class ReturnHomeStrategy(ResponseStrategy):
    action_name = "return_home"

    def apply(self, uav: UAV, state: ResponseState, alert: AlertContext) -> ResponseEvent:
        reason = _build_response_reason(alert)
        state.update_header(action=self.action_name, applied_at_s=alert.simulation_time_s, reason=reason)
        if uav.mission_phase in AIRBORNE_PHASES and uav.mission_phase not in {"return_home", "land", "emergency"}:
            _transition_phase(uav, "return_home")
            state.mission_aborted = True
        return ResponseEvent(
            uav_id=alert.uav_id or uav.uav_id,
            response_action=self.action_name,
            response_time=alert.simulation_time_s,
            response_reason=reason,
        )


@register_response_strategy
class IsolateLinkStrategy(ResponseStrategy):
    action_name = "isolate_link"

    def apply(self, uav: UAV, state: ResponseState, alert: AlertContext) -> ResponseEvent:
        reason = _build_response_reason(alert)
        state.update_header(action=self.action_name, applied_at_s=alert.simulation_time_s, reason=reason)
        state.isolated_link = True
        state.uplink_multiplier = min(state.uplink_multiplier, 0.10)
        state.downlink_multiplier = min(state.downlink_multiplier, 0.10)
        state.link_latency_penalty_ms = max(state.link_latency_penalty_ms, 120.0)
        state.link_loss_penalty = max(state.link_loss_penalty, 0.35)
        state.link_snr_penalty_db = max(state.link_snr_penalty_db, 4.0)
        state.mission_aborted = True
        return ResponseEvent(
            uav_id=alert.uav_id or uav.uav_id,
            response_action=self.action_name,
            response_time=alert.simulation_time_s,
            response_reason=reason,
        )


class ResponseManager:
    """Track alerts, apply response strategies, and summarize mitigation metrics."""

    def __init__(
        self,
        strategy: str = "alert_only",
        *,
        attack_events: Sequence[AttackEvent] | None = None,
    ) -> None:
        self.strategy_name = _canonicalize_response_action(strategy)
        self.strategy = build_response_strategy(self.strategy_name)
        self.attack_events = sorted(list(attack_events or []), key=lambda event: (event.start_s, event.end_s))
        self._states: dict[str, ResponseState] = {}
        self._response_events: list[ResponseEvent] = []
        self._alert_count = 0
        self._false_alert_count = 0
        self._first_alert_delay_by_episode: dict[tuple[str | None, float, str], float] = {}

    def state_for(self, uav_id: str) -> ResponseState:
        return self._states.setdefault(str(uav_id), ResponseState())

    def apply_link_effects(self, uav: UAV, link: LinkState) -> LinkState:
        state = self.state_for(uav.uav_id)
        if (
            state.link_latency_penalty_ms <= 0.0
            and state.link_loss_penalty <= 0.0
            and state.link_snr_penalty_db <= 0.0
        ):
            return link
        return LinkState(
            distance_m=link.distance_m,
            rssi_dbm=link.rssi_dbm - 0.5 * state.link_snr_penalty_db,
            snr_db=link.snr_db - state.link_snr_penalty_db,
            latency_ms=link.latency_ms + state.link_latency_penalty_ms,
            loss_rate=min(max(link.loss_rate + state.link_loss_penalty, 0.0), 0.99),
        )

    def apply_traffic_effects(self, uav: UAV, bytes_up: int, bytes_down: int) -> tuple[int, int]:
        state = self.state_for(uav.uav_id)
        adjusted_up = max(0, int(round(bytes_up * state.uplink_multiplier)))
        adjusted_down = max(0, int(round(bytes_down * state.downlink_multiplier)))
        return adjusted_up, adjusted_down

    def current_response_payload(self, uav: UAV) -> dict[str, str | float | None]:
        state = self.state_for(uav.uav_id)
        return {
            "response_action": state.action,
            "response_time": state.applied_at_s,
            "response_reason": state.reason,
        }

    def process_detection(
        self,
        detection: Mapping[str, Any],
        *,
        step_records: Sequence[Any],
        uavs_by_id: Mapping[str, UAV],
        sim_time_s: float,
    ) -> dict[str, Any]:
        enriched = dict(detection)
        alert = self._build_alert_context(enriched, step_records=step_records, sim_time_s=sim_time_s)
        if alert.uav_id is not None:
            state = self.state_for(alert.uav_id)
            enriched.setdefault("response_action", state.action)
            enriched.setdefault("response_time", state.applied_at_s)
            enriched.setdefault("response_reason", state.reason)
        else:
            enriched.setdefault("response_action", None)
            enriched.setdefault("response_time", None)
            enriched.setdefault("response_reason", None)
        enriched.setdefault("response_triggered", False)

        if not self._is_alert_payload(enriched):
            return enriched

        self._alert_count += 1
        false_alert = enriched.get("false_alert")
        if false_alert is None:
            false_alert = bool((not alert.attack_active) and self._is_alert_payload(enriched))
        if bool(false_alert):
            self._false_alert_count += 1
        else:
            self._record_first_alert_delay(alert)

        if alert.uav_id is None:
            return enriched
        uav = uavs_by_id.get(alert.uav_id)
        if uav is None:
            return enriched

        state = self.state_for(alert.uav_id)
        if not self.strategy.should_trigger(state, alert):
            enriched["response_action"] = state.action
            enriched["response_time"] = state.applied_at_s
            enriched["response_reason"] = state.reason
            return enriched

        event = self.strategy.apply(uav, state, alert)
        self._response_events.append(event)
        enriched["response_action"] = event.response_action
        enriched["response_time"] = event.response_time
        enriched["response_reason"] = event.response_reason
        enriched["response_triggered"] = True
        return enriched

    def build_metrics(self, uavs: Sequence[UAV]) -> ResponseMetrics:
        delays = list(self._first_alert_delay_by_episode.values())
        average_alert_delay = float(sum(delays) / len(delays)) if delays else 0.0
        mission_success = all(uav.mission_completed for uav in uavs) and all(
            not self.state_for(uav.uav_id).mission_aborted for uav in uavs
        )
        return ResponseMetrics(
            alert_count=int(self._alert_count),
            response_count=int(len(self._response_events)),
            average_alert_delay=average_alert_delay,
            false_alert_count=int(self._false_alert_count),
            mission_success=bool(mission_success),
        )

    @property
    def response_events(self) -> list[ResponseEvent]:
        return list(self._response_events)

    def _build_alert_context(
        self,
        detection: Mapping[str, Any],
        *,
        step_records: Sequence[Any],
        sim_time_s: float,
    ) -> AlertContext:
        truth = detection.get("ground_truth")
        attack_active = bool(detection.get("gt_attack_active", False))
        gt_attack_type = str(detection.get("gt_attack_type", "") or "").strip()
        attack_types: tuple[str, ...] = ()
        if gt_attack_type and gt_attack_type != "benign":
            attack_types = tuple(sorted({token.strip() for token in gt_attack_type.replace("+", ",").split(",") if token.strip()}))
        if isinstance(truth, Mapping):
            attack_active = attack_active or bool(truth.get("attack_active", False))
            truth_attack_types = tuple(sorted({str(item) for item in truth.get("attack_types", []) if str(item).strip()}))
            if truth_attack_types:
                attack_types = truth_attack_types

        matching_event = self._find_matching_attack_event(
            float(detection.get("simulation_time_s", sim_time_s)),
            uav_id=self._resolve_uav_id(detection, step_records=step_records),
            attack_types=attack_types,
        )
        if matching_event is not None:
            attack_active = True
            if not attack_types:
                attack_types = (matching_event.attack_type,)

        return AlertContext(
            uav_id=self._resolve_uav_id(detection, step_records=step_records),
            simulation_time_s=float(detection.get("simulation_time_s", sim_time_s)),
            alert_level=str(detection.get("alert_level", "normal") or "normal").strip().lower(),
            is_ood=bool(detection.get("is_ood", False)),
            attack_active=bool(attack_active),
            attack_types=attack_types,
            dominant_ood_source=(
                None
                if detection.get("dominant_ood_source") in {None, ""}
                else str(detection.get("dominant_ood_source"))
            ),
        )

    def _resolve_uav_id(self, detection: Mapping[str, Any], *, step_records: Sequence[Any]) -> str | None:
        group_id = detection.get("group_id")
        if group_id not in {None, ""}:
            return str(group_id)

        prefixes: set[str] = set()
        for record_id in detection.get("record_ids", []) or []:
            text = str(record_id).strip()
            if not text:
                continue
            prefixes.add(text.split(":", 1)[0])
        if len(prefixes) == 1:
            return next(iter(prefixes))

        truth = detection.get("ground_truth")
        if isinstance(truth, Mapping):
            truth_records = truth.get("records", []) or []
            prefixes = set()
            for row in truth_records:
                if not isinstance(row, Mapping):
                    continue
                record_id = str(row.get("record_id", "")).strip()
                if record_id:
                    prefixes.add(record_id.split(":", 1)[0])
            if len(prefixes) == 1:
                return next(iter(prefixes))

        step_uavs = {str(record.uav_id) for record in step_records if hasattr(record, "uav_id")}
        if len(step_uavs) == 1:
            return next(iter(step_uavs))
        return None

    def _is_alert_payload(self, detection: Mapping[str, Any]) -> bool:
        if detection.get("has_alert") is not None:
            return bool(detection.get("has_alert", False))
        if bool(detection.get("is_ood", False)):
            return True
        alert_level = str(detection.get("alert_level", "normal") or "normal").strip().lower()
        return alert_level in _ALERT_LEVELS

    def _find_matching_attack_event(
        self,
        simulation_time_s: float,
        *,
        uav_id: str | None = None,
        attack_types: Sequence[str] = (),
    ) -> AttackEvent | None:
        desired_types = {str(item) for item in attack_types if str(item).strip()}
        for event in reversed(self.attack_events):
            if not (event.start_s <= simulation_time_s < event.end_s):
                continue
            if event.uav_id not in {None, uav_id}:
                continue
            if desired_types and event.attack_type not in desired_types:
                continue
            return event
        return None

    def _record_first_alert_delay(self, alert: AlertContext) -> None:
        event = self._find_matching_attack_event(
            alert.simulation_time_s,
            uav_id=alert.uav_id,
            attack_types=alert.attack_types,
        )
        if event is None:
            return
        key = (alert.uav_id, float(event.start_s), str(event.attack_type))
        if key in self._first_alert_delay_by_episode:
            return
        self._first_alert_delay_by_episode[key] = max(0.0, float(alert.simulation_time_s - event.start_s))
