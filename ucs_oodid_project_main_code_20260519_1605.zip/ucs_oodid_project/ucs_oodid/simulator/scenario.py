from __future__ import annotations

import copy
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path
from typing import Any, Mapping, Sequence

try:
    import yaml
except Exception:  # pragma: no cover
    yaml = None

from ..dataset_registry import DATASET_NAME_ALIASES
from .attack_replay import ATTACK_REPLAY_MODES, resolve_simulation_source_metadata
from .attacks import AttackEvent as InjectorAttackEvent, AttackInjector
from .entities import UAV
from .mission import MISSION_PHASES, SUPPORTED_MISSION_CONTEXTS, apply_mission_context, resolve_mission_context

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_SCENARIO_PROFILE_PATH = ROOT / "configs" / "simulator_default.yaml"
SUPPORTED_SCENARIO_TYPES: tuple[str, ...] = ("single_attack", "mixed_attack")
SUPPORTED_MIXED_ATTACK_MODES: tuple[str, ...] = (
    "single_uav_multi_attack",
    "multi_uav_multi_attack",
)

_ACTIVE_ATTACK_SCENARIO: ScenarioConfig | None = None
_ATTACK_TYPE_ALIASES: dict[str, str] = {
    "flood": "flood",
    "dos": "flood",
    "ddos": "flood",
    "icmpflood": "flood",
    "udpflood": "flood",
    "scan": "scan",
    "probe": "scan",
    "probing": "scan",
    "reconscanning": "scan",
    "replay": "replay",
    "commandinjection": "command_injection",
    "injection": "command_injection",
    "payloadmanipulation": "command_injection",
    "fakelanding": "command_injection",
    "jamming": "jamming_proxy",
    "jammingproxy": "jamming_proxy",
}


def _normalize_alias_token(value: Any) -> str:
    return "".join(ch for ch in str(value).strip().lower() if ch.isalnum())


def _split_declared_values(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        segments: list[str] = []
        for chunk in value.split(","):
            segments.extend(part for part in chunk.split("+"))
        return [item.strip() for item in segments if item.strip()]
    if isinstance(value, Sequence):
        tokens: list[str] = []
        for item in value:
            tokens.extend(_split_declared_values(item))
        return tokens
    return [str(value).strip()] if str(value).strip() else []


def _ordered_unique(values: Sequence[str]) -> tuple[str, ...]:
    ordered: list[str] = []
    seen: set[str] = set()
    for value in values:
        text = str(value).strip()
        if text and text not in seen:
            ordered.append(text)
            seen.add(text)
    return tuple(ordered)


def _canonicalize_source_dataset(value: Any) -> str:
    raw = str(value).strip()
    if not raw:
        raise ValueError("source_dataset is required")
    canonical = DATASET_NAME_ALIASES.get(_normalize_alias_token(raw))
    if canonical is None:
        raise ValueError(f"Unsupported source_dataset: {value}")
    return canonical


def _canonicalize_attack_type(value: Any) -> str:
    raw = str(value).strip()
    if not raw:
        raise ValueError("attack_types cannot contain empty values")
    canonical = _ATTACK_TYPE_ALIASES.get(_normalize_alias_token(raw))
    if canonical is None:
        raise ValueError(f"Unsupported attack type: {value}")
    return canonical


def _normalize_attack_type_values(value: Any) -> tuple[str, ...]:
    attack_types = _ordered_unique(_canonicalize_attack_type(item) for item in _split_declared_values(value))
    if not attack_types:
        raise ValueError("attack_types must contain at least one attack type")
    return attack_types


def _canonicalize_mission_phase(value: Any) -> str:
    canonical = str(value).strip().lower()
    if canonical not in MISSION_PHASES:
        raise ValueError(f"Unsupported mission phase constraint: {value}")
    return canonical


def _normalize_mission_phase_constraint(value: Any) -> tuple[str, ...] | None:
    if value is None:
        return None
    phases = _ordered_unique(_canonicalize_mission_phase(item) for item in _split_declared_values(value))
    return phases or None


def _canonicalize_scenario_type(value: Any) -> str:
    canonical = str(value).strip().lower()
    if canonical not in SUPPORTED_SCENARIO_TYPES:
        raise ValueError(f"Unsupported scenario_type: {value}")
    return canonical


def _canonicalize_mixed_attack_mode(value: Any) -> str:
    canonical = str(value).strip().lower().replace("-", "_")
    if canonical not in SUPPORTED_MIXED_ATTACK_MODES:
        raise ValueError(f"Unsupported mix_mode: {value}")
    return canonical


def _canonicalize_replay_mode(value: Any) -> str:
    canonical = str(value).strip().lower()
    if canonical not in ATTACK_REPLAY_MODES:
        raise ValueError(f"Unsupported replay_mode: {value}")
    return canonical


def _infer_mixed_attack_mode(events: Sequence[AttackEvent]) -> str:
    uav_ids = {event.uav_id for event in events}
    if len(uav_ids) <= 1 and any(len(event.attack_types) > 1 for event in events):
        return "single_uav_multi_attack"
    return "multi_uav_multi_attack"


@dataclass(frozen=True)
class AttackEvent:
    """Scenario-level attack declaration loaded from YAML."""

    uav_id: str
    source_dataset: str
    attack_types: tuple[str, ...]
    start_time: float
    duration: float
    intensity: float
    replay_mode: str = "sequential"
    mission_phase_constraint: tuple[str, ...] | None = None
    is_ood: bool | None = None

    def __post_init__(self) -> None:
        canonical_uav_id = str(self.uav_id).strip()
        if not canonical_uav_id:
            raise ValueError("uav_id is required")

        start_time = float(self.start_time)
        duration = float(self.duration)
        intensity = float(self.intensity)
        if start_time < 0.0:
            raise ValueError("start_time must be non-negative")
        if duration <= 0.0:
            raise ValueError("duration must be positive")
        if intensity < 0.0:
            raise ValueError("intensity must be non-negative")

        object.__setattr__(self, "uav_id", canonical_uav_id)
        object.__setattr__(self, "source_dataset", _canonicalize_source_dataset(self.source_dataset))
        object.__setattr__(self, "attack_types", _normalize_attack_type_values(self.attack_types))
        object.__setattr__(self, "start_time", start_time)
        object.__setattr__(self, "duration", duration)
        object.__setattr__(self, "intensity", intensity)
        object.__setattr__(self, "replay_mode", _canonicalize_replay_mode(self.replay_mode))
        object.__setattr__(
            self,
            "mission_phase_constraint",
            _normalize_mission_phase_constraint(self.mission_phase_constraint),
        )
        object.__setattr__(self, "is_ood", None if self.is_ood is None else bool(self.is_ood))

    @property
    def end_time(self) -> float:
        return float(self.start_time) + float(self.duration)

    @property
    def source_metadata(self) -> dict[str, object]:
        return resolve_simulation_source_metadata(dataset_name=self.source_dataset, uav_id=self.uav_id)

    @property
    def source_type(self) -> str:
        return str(self.source_metadata.get("source_type", "") or "")

    @property
    def simulation_role(self) -> str:
        return str(self.source_metadata.get("simulation_role", "") or "")

    @property
    def source_note(self) -> str:
        return str(self.source_metadata.get("source_note", "") or "")

    def is_active(self, sim_time: float, *, uav_id: str, mission_phase: str | None = None) -> bool:
        current_uav_id = str(uav_id).strip()
        if current_uav_id != self.uav_id:
            return False
        current_time = float(sim_time)
        if not (self.start_time <= current_time < self.end_time):
            return False
        if self.mission_phase_constraint is None:
            return True
        if mission_phase is None or str(mission_phase).strip() == "":
            return False
        return _canonicalize_mission_phase(mission_phase) in self.mission_phase_constraint


@dataclass(frozen=True)
class ScenarioConfig:
    """Immutable attack scenario configuration."""

    name: str
    scenario_type: str
    attack_events: tuple[AttackEvent, ...]
    description: str = ""
    mix_mode: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    source_path: str = ""

    def __post_init__(self) -> None:
        scenario_name = str(self.name).strip()
        if not scenario_name:
            raise ValueError("Scenario name is required")

        canonical_type = _canonicalize_scenario_type(self.scenario_type)
        events = tuple(
            sorted(
                tuple(self.attack_events),
                key=lambda event: (event.start_time, event.end_time, event.uav_id, event.attack_types),
            )
        )
        if not events:
            raise ValueError("Scenario must define at least one attack event")

        description = str(self.description).strip()
        metadata = {} if self.metadata is None else dict(self.metadata)
        source_path = str(self.source_path).strip()
        mix_mode = None if self.mix_mode in {None, ""} else _canonicalize_mixed_attack_mode(self.mix_mode)

        if canonical_type == "single_attack":
            if any(len(event.attack_types) != 1 for event in events):
                raise ValueError("single_attack scenarios require exactly one attack type per event")
            mix_mode = None
        else:
            if mix_mode is None:
                mix_mode = _infer_mixed_attack_mode(events)
            unique_uavs = {event.uav_id for event in events}
            if mix_mode == "single_uav_multi_attack":
                if len(unique_uavs) != 1:
                    raise ValueError("single_uav_multi_attack scenarios must target exactly one UAV")
                if not any(len(event.attack_types) > 1 for event in events):
                    raise ValueError("single_uav_multi_attack scenarios require at least one multi-attack event")
            elif len(unique_uavs) < 2:
                raise ValueError("multi_uav_multi_attack scenarios must target at least two UAVs")

        object.__setattr__(self, "name", scenario_name)
        object.__setattr__(self, "scenario_type", canonical_type)
        object.__setattr__(self, "attack_events", events)
        object.__setattr__(self, "description", description)
        object.__setattr__(self, "mix_mode", mix_mode)
        object.__setattr__(self, "metadata", metadata)
        object.__setattr__(self, "source_path", source_path)

    def get_active_attacks(
        self,
        sim_time: float,
        uav_id: str,
        mission_phase: str | None = None,
    ) -> list[AttackEvent]:
        return [
            event
            for event in self.attack_events
            if event.is_active(sim_time, uav_id=uav_id, mission_phase=mission_phase)
        ]


def resolve_attack_scenario_path(path: str | Path) -> Path:
    candidate = Path(path).expanduser()
    if candidate.is_absolute():
        return candidate
    return ROOT / candidate


def load_scenario_from_yaml(
    path: str | Path,
    *,
    set_as_active: bool = True,
) -> ScenarioConfig:
    if yaml is None:
        raise RuntimeError("pyyaml is required to load attack scenario configs")
    resolved = resolve_attack_scenario_path(path).resolve()
    with resolved.open("r", encoding="utf-8") as handle:
        raw = yaml.safe_load(handle) or {}
    if not isinstance(raw, Mapping):
        raise ValueError(f"Scenario YAML must be a mapping: {resolved}")

    raw_events = raw.get("attack_events", raw.get("events"))
    if not isinstance(raw_events, Sequence) or isinstance(raw_events, (str, bytes, bytearray)):
        raise ValueError("Scenario YAML must define attack_events as a sequence")

    attack_events: list[AttackEvent] = []
    for row in raw_events:
        if not isinstance(row, Mapping):
            raise ValueError("Each attack event must be a mapping")
        attack_events.append(
            AttackEvent(
                uav_id=str(row.get("uav_id", "")).strip(),
                source_dataset=row.get("source_dataset"),
                attack_types=row.get("attack_types", row.get("attack_type")),
                start_time=float(row.get("start_time", 0.0)),
                duration=float(row.get("duration", 0.0)),
                intensity=float(row.get("intensity", 0.0)),
                replay_mode=row.get("replay_mode", "sequential"),
                mission_phase_constraint=row.get(
                    "mission_phase_constraint",
                    row.get("mission_phase_constraints"),
                ),
                is_ood=row.get("is_ood"),
            )
        )

    metadata = raw.get("metadata", {})
    if metadata is None:
        metadata = {}
    if not isinstance(metadata, Mapping):
        raise ValueError("metadata must be a mapping when provided")

    scenario = ScenarioConfig(
        name=str(raw.get("name", raw.get("scenario_name", resolved.stem))).strip(),
        scenario_type=raw.get("scenario_type", "single_attack"),
        attack_events=tuple(attack_events),
        description=str(raw.get("description", "")).strip(),
        mix_mode=raw.get("mix_mode", raw.get("mixed_mode")),
        metadata=dict(metadata),
        source_path=str(resolved),
    )

    if set_as_active:
        global _ACTIVE_ATTACK_SCENARIO
        _ACTIVE_ATTACK_SCENARIO = scenario

    return scenario


def get_active_attacks(
    sim_time: float,
    uav_id: str,
    mission_phase: str | None = None,
    *,
    scenario_config: ScenarioConfig | None = None,
) -> list[AttackEvent]:
    active_scenario = scenario_config or _ACTIVE_ATTACK_SCENARIO
    if active_scenario is None:
        raise RuntimeError("No attack scenario is loaded; call load_scenario_from_yaml() first")
    return active_scenario.get_active_attacks(sim_time=sim_time, uav_id=uav_id, mission_phase=mission_phase)


def default_scenario_profile_path() -> str:
    return str(DEFAULT_SCENARIO_PROFILE_PATH)


def resolve_scenario_profile_path(path: str | Path | None = None) -> Path:
    if path is None or str(path).strip() == "":
        return DEFAULT_SCENARIO_PROFILE_PATH
    candidate = Path(path).expanduser()
    if candidate.is_absolute():
        return candidate
    return ROOT / candidate


def _normalize_attack_labels(value: Any) -> tuple[str, ...]:
    if value is None:
        return ()
    if isinstance(value, str):
        raw_values = value.split(",")
    elif isinstance(value, Sequence):
        raw_values = []
        for item in value:
            raw_values.extend(str(item).split(","))
    else:
        raw_values = [value]
    labels: list[str] = []
    seen: set[str] = set()
    for item in raw_values:
        text = str(item).strip()
        if text and text not in seen:
            labels.append(text)
            seen.add(text)
    return tuple(labels)


@lru_cache(maxsize=16)
def _load_yaml_file(path_text: str) -> dict[str, Any]:
    if yaml is None:
        raise RuntimeError("pyyaml is required to load simulator scenario configs")
    resolved = Path(path_text)
    with resolved.open("r", encoding="utf-8") as handle:
        raw = yaml.safe_load(handle) or {}
    if not isinstance(raw, Mapping):
        raise ValueError(f"Simulator scenario config must be a mapping: {resolved}")
    return dict(raw)


def _deep_merge(base: dict[str, Any], overlay: Mapping[str, Any]) -> dict[str, Any]:
    for key, value in overlay.items():
        if isinstance(value, Mapping) and isinstance(base.get(key), dict):
            base[key] = _deep_merge(dict(base[key]), value)
        else:
            base[key] = copy.deepcopy(value)
    return base


def load_scenario_profile(path: str | Path | None = None) -> dict[str, Any]:
    default_path = DEFAULT_SCENARIO_PROFILE_PATH.resolve()
    base = copy.deepcopy(_load_yaml_file(str(default_path)))
    resolved = resolve_scenario_profile_path(path).resolve()
    if resolved == default_path:
        return base
    overlay = _load_yaml_file(str(resolved))
    return _deep_merge(base, overlay)


def _mission_cycle(profile: Mapping[str, Any]) -> list[str]:
    multi_cfg = profile.get("multi_uav", {})
    if isinstance(multi_cfg, Mapping):
        cycle = list(multi_cfg.get("mission_cycle", []) or [])
        if cycle:
            return [str(item) for item in cycle]
    return list(SUPPORTED_MISSION_CONTEXTS)


def _per_uav_overrides(profile: Mapping[str, Any]) -> dict[str, Mapping[str, Any]]:
    multi_cfg = profile.get("multi_uav", {})
    if not isinstance(multi_cfg, Mapping):
        return {}
    rows = multi_cfg.get("per_uav", {})
    if not isinstance(rows, Mapping):
        return {}
    return {str(key): value for key, value in rows.items() if isinstance(value, Mapping)}


def _context_for_uav(uav_id: str, idx: int, profile: Mapping[str, Any]) -> str:
    overrides = _per_uav_overrides(profile)
    if uav_id in overrides and str(overrides[uav_id].get("mission_context", "")).strip():
        return str(overrides[uav_id]["mission_context"]).strip().lower()
    cycle = _mission_cycle(profile)
    if cycle:
        return str(cycle[idx % len(cycle)]).strip().lower()
    mission_cfg = profile.get("mission_contexts", {})
    if isinstance(mission_cfg, Mapping) and str(mission_cfg.get("default_context", "")).strip():
        return str(mission_cfg["default_context"]).strip().lower()
    return "surveillance"


def build_fleet(
    runtime_config: Mapping[str, Any],
    *,
    scenario_profile: Mapping[str, Any] | None = None,
    uav_ids: Sequence[str] | None = None,
) -> list[UAV]:
    profile = copy.deepcopy(
        scenario_profile or load_scenario_profile(runtime_config.get("scenario_profile_path"))
    )
    resolved_path = str(resolve_scenario_profile_path(runtime_config.get("scenario_profile_path")))
    count = int(runtime_config.get("uav_count", len(uav_ids) if uav_ids is not None else 1))
    if uav_ids is not None and len(uav_ids) != count:
        raise ValueError("uav_ids length must match uav_count")

    overrides = _per_uav_overrides(profile)
    multi_cfg = profile.get("multi_uav", {})
    compute_cfg = profile.get("compute", {})
    mission_scaling_step = 0.0
    home_y_spacing_m = 0.0
    ambient_temperature_c = 30.0
    baseline_cpu_load = 0.0
    if isinstance(multi_cfg, Mapping):
        mission_scaling_step = float(multi_cfg.get("mission_scaling_step", 0.0))
        home_y_spacing_m = float(multi_cfg.get("home_y_spacing_m", 0.0))
    if isinstance(compute_cfg, Mapping):
        ambient_temperature_c = float(compute_cfg.get("ambient_temperature_c", ambient_temperature_c))
        baseline_cpu_load = float(compute_cfg.get("baseline_cpu_load", baseline_cpu_load))

    uavs: list[UAV] = []
    for idx in range(count):
        uav_id = str(uav_ids[idx]) if uav_ids is not None else f"uav_{idx + 1:02d}"
        override = dict(overrides.get(uav_id, {}) or {})
        mission_context_name = _context_for_uav(uav_id, idx, profile)
        mission_scale = (1.0 + mission_scaling_step * idx) * float(override.get("mission_scale", 1.0))
        home_x_m = float(override.get("home_x_m", 0.0))
        home_y_m = float(override.get("home_y_m", home_y_spacing_m * idx))

        uav = UAV(
            uav_id=uav_id,
            home_x_m=home_x_m,
            home_y_m=home_y_m,
            x_m=home_x_m,
            y_m=home_y_m,
            battery_capacity_wh=float(runtime_config.get("battery_capacity_wh", 180.0))
            * float(override.get("battery_capacity_scale", 1.0)),
            cpu_load=baseline_cpu_load,
            board_temperature_c=ambient_temperature_c,
        )
        apply_mission_context(
            uav,
            resolve_mission_context(mission_context_name, profile),
            base_route_length_m=float(runtime_config.get("route_length_m", 800.0)),
            base_hover_duration_s=float(runtime_config.get("hover_duration_s", 12.0)),
            base_cruise_altitude_m=float(runtime_config.get("cruise_altitude_m", 120.0)),
            base_cruise_speed_mps=float(runtime_config.get("cruise_speed_mps", 18.0)),
            scale_factor=mission_scale,
        )
        uav.start_delay_s = float(runtime_config.get("start_spacing_s", 0.0)) * idx + float(
            override.get("start_delay_bias_s", 0.0)
        )
        uav.metadata["scenario_profile_path"] = resolved_path
        uav.metadata["wind_bias"] = float(override.get("wind_bias", 0.0))
        uav.metadata["obstacle_bias"] = float(override.get("obstacle_bias", 0.0))
        uav.metadata["traffic_bias"] = float(override.get("traffic_bias", 0.0))
        uav.metadata["compute_bias"] = float(override.get("compute_bias", 0.0))
        uav.metadata["mission_scale"] = float(mission_scale)
        uavs.append(uav)
    return uavs


def build_attack_injector(
    runtime_config: Mapping[str, Any],
    uavs: Sequence[UAV],
    *,
    scenario_profile: Mapping[str, Any] | None = None,
) -> AttackInjector:
    profile = copy.deepcopy(
        scenario_profile or load_scenario_profile(runtime_config.get("scenario_profile_path"))
    )
    overrides = _per_uav_overrides(profile)
    events: list[InjectorAttackEvent] = []
    custom_attack_uavs: set[str] = set()

    for uav in uavs:
        override = dict(overrides.get(uav.uav_id, {}) or {})
        attack_plan = list(override.get("attack_plan", []) or [])
        plan_summaries: list[str] = []
        if attack_plan:
            custom_attack_uavs.add(uav.uav_id)
        for plan_idx, row in enumerate(attack_plan):
            start_s = float(row.get("start_s", 0.0))
            end_s = float(row.get("end_s", 0.0))
            if end_s <= start_s:
                continue
            attack_type = str(row.get("attack_type", "benign")).strip().lower()
            intensity = float(row.get("intensity", 1.0))
            attack_labels = _normalize_attack_labels(
                row.get("attack_labels", row.get("labels", row.get("replay_labels")))
            )
            events.append(
                InjectorAttackEvent(
                    start_s=start_s,
                    end_s=end_s,
                    attack_type=attack_type,
                    intensity=intensity,
                    uav_id=uav.uav_id,
                    plan_id=f"{uav.uav_id}_cfg_{plan_idx + 1}",
                    attack_labels=attack_labels,
                )
            )
            label_suffix = "" if not attack_labels else f"[{','.join(attack_labels)}]"
            plan_summaries.append(f"{attack_type}{label_suffix} {start_s:.0f}-{end_s:.0f}s")
        uav.metadata["configured_attack_plan"] = "; ".join(plan_summaries) if plan_summaries else "benign"

    attack_type = str(runtime_config.get("attack_type", "benign")).strip().lower()
    start_s = float(runtime_config.get("attack_start_s", 0.0))
    end_s = float(runtime_config.get("attack_end_s", 0.0))
    intensity = float(runtime_config.get("attack_intensity", 0.0))
    global_attack_labels = _normalize_attack_labels(
        runtime_config.get("attack_labels", runtime_config.get("replay_labels"))
    )
    global_attack_enabled = attack_type != "benign" and end_s > start_s
    if global_attack_enabled:
        for uav in uavs:
            if uav.uav_id in custom_attack_uavs:
                continue
            events.append(
                InjectorAttackEvent(
                    start_s=start_s,
                    end_s=end_s,
                    attack_type=attack_type,
                    intensity=intensity,
                    uav_id=uav.uav_id,
                    plan_id=f"{uav.uav_id}_fallback",
                    attack_labels=global_attack_labels,
                )
            )
            label_suffix = "" if not global_attack_labels else f"[{','.join(global_attack_labels)}]"
            uav.metadata["configured_attack_plan"] = f"{attack_type}{label_suffix} {start_s:.0f}-{end_s:.0f}s"

    return AttackInjector(events)


def attack_schedule_rows(attack_injector: AttackInjector) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for event in attack_injector.events:
        rows.append(
            {
                "uav_id": str(event.uav_id or "fleet"),
                "attack_type": str(event.attack_type),
                "start_s": float(event.start_s),
                "end_s": float(event.end_s),
                "duration_s": max(float(event.end_s - event.start_s), 0.0),
                "intensity": float(event.intensity),
                "plan_id": None if event.plan_id in {None, ""} else str(event.plan_id),
                "attack_labels": list(event.attack_labels) if event.attack_labels else [],
            }
        )
    return rows


def build_fleet_preview_rows(uavs: Sequence[UAV], attack_injector: AttackInjector) -> list[dict[str, Any]]:
    attack_rows = attack_schedule_rows(attack_injector)
    grouped_attack_rows: dict[str, list[dict[str, Any]]] = {}
    for row in attack_rows:
        grouped_attack_rows.setdefault(str(row["uav_id"]), []).append(row)

    preview_rows: list[dict[str, Any]] = []
    for idx, uav in enumerate(uavs):
        attack_summary = grouped_attack_rows.get(uav.uav_id, [])
        if attack_summary:
            attack_plan = "; ".join(
                f"{row['attack_type']} {row['start_s']:.0f}-{row['end_s']:.0f}s" for row in attack_summary
            )
        else:
            attack_plan = "benign"
        preview_rows.append(
            {
                "uav_id": uav.uav_id,
                "mission_context": str(uav.mission_context),
                "start_delay_s": float(uav.start_delay_s),
                "route_length_m": float(uav.route_length_m),
                "cruise_altitude_m": float(uav.cruise_altitude_m),
                "cruise_speed_mps": float(uav.cruise_speed_mps),
                "hover_duration_s": float(uav.hover_duration_s),
                "battery_capacity_wh": float(uav.battery_capacity_wh),
                "wind_bias": float(uav.metadata.get("wind_bias", 0.0)),
                "obstacle_bias": float(uav.metadata.get("obstacle_bias", 0.0)),
                "attack_plan": attack_plan,
                "stagger_index": idx,
            }
        )
    return preview_rows
