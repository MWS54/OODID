from __future__ import annotations

from dataclasses import dataclass, field
import math
import random

from .attacks import AttackSnapshot, build_attack_snapshot
from .channel import LinkState
from .energy import EnergyBreakdown
from .entities import UAV
from .scenario import load_scenario_profile


@dataclass(frozen=True)
class TrafficRecord:
    """Single simulated traffic record emitted by the engine."""

    timestamp: float
    uav_id: str
    mission_phase: str
    mission_context: str
    battery_soc: float
    speed: float
    altitude: float
    rssi: float
    snr: float
    latency_ms: float
    loss_rate: float
    distance_to_gcs: float
    wind_level: float
    obstacle_factor: float
    bytes_up: int
    bytes_down: int
    attack_active: bool
    attack_type: str
    cpu_load: float = 0.0
    board_temperature_c: float = 0.0
    response_action: str | None = None
    response_time: float | None = None
    response_reason: str | None = None
    flight_energy_wh: float = 0.0
    communication_energy_wh: float = 0.0
    detection_energy_wh: float = 0.0
    total_energy_wh: float = 0.0
    cumulative_energy_wh: float = 0.0
    sim_time: float = 0.0
    dataset_name: str = ""
    attack_source_dataset: str = ""
    record_kind: str = "telemetry"
    extra_features: dict[str, object] = field(default_factory=dict)

    def to_dict(self) -> dict[str, object]:
        """Return a JSON/pandas friendly representation of the record."""

        payload: dict[str, object] = dict(self.extra_features)
        payload.update(
            {
                "timestamp": float(self.timestamp),
                "uav_id": self.uav_id,
                "mission_phase": self.mission_phase,
                "mission_context": self.mission_context,
                "battery_soc": float(self.battery_soc),
                "speed": float(self.speed),
                "altitude": float(self.altitude),
                "rssi": float(self.rssi),
                "snr": float(self.snr),
                "latency_ms": float(self.latency_ms),
                "loss_rate": float(self.loss_rate),
                "distance_to_gcs": float(self.distance_to_gcs),
                "wind_level": float(self.wind_level),
                "obstacle_factor": float(self.obstacle_factor),
                "bytes_up": int(self.bytes_up),
                "bytes_down": int(self.bytes_down),
                "attack_active": bool(self.attack_active),
                "attack_type": self.attack_type,
                "cpu_load": float(self.cpu_load),
                "board_temperature_c": float(self.board_temperature_c),
                "response_action": self.response_action,
                "response_time": self.response_time,
                "response_reason": self.response_reason,
                "flight_energy_wh": float(self.flight_energy_wh),
                "communication_energy_wh": float(self.communication_energy_wh),
                "detection_energy_wh": float(self.detection_energy_wh),
                "total_energy_wh": float(self.total_energy_wh),
                "cumulative_energy_wh": float(self.cumulative_energy_wh),
                "sim_time": float(self.sim_time),
                "dataset_name": self.dataset_name,
                "attack_source_dataset": self.attack_source_dataset,
                "record_kind": self.record_kind,
            }
        )
        return payload


def generate_traffic_record(
    timestamp_s: float,
    uav: UAV,
    link: LinkState,
    attack: AttackSnapshot | None = None,
    dt_s: float = 1.0,
    rng: random.Random | None = None,
    energy: EnergyBreakdown | None = None,
    bytes_up: int | None = None,
    bytes_down: int | None = None,
    response_state: object | None = None,
) -> TrafficRecord:
    """Generate one traffic record from UAV state, link state, and attack state."""

    if dt_s <= 0.0:
        raise ValueError("dt_s must be positive")
    attack_state = attack or build_attack_snapshot("benign")
    if bytes_up is None or bytes_down is None:
        bytes_up, bytes_down = estimate_traffic_bytes(uav, link, attack_state, dt_s=dt_s, rng=rng)
    energy_state = energy or EnergyBreakdown(0.0, 0.0, 0.0, 0.0)
    return TrafficRecord(
        timestamp=float(timestamp_s),
        uav_id=uav.uav_id,
        mission_phase=uav.mission_phase,
        mission_context=str(getattr(uav, "mission_context", "surveillance")),
        battery_soc=float(uav.battery_soc),
        speed=float(uav.speed_mps),
        altitude=float(uav.altitude_m),
        rssi=float(link.rssi_dbm),
        snr=float(link.snr_db),
        latency_ms=float(link.latency_ms),
        loss_rate=float(link.loss_rate),
        distance_to_gcs=float(getattr(link, "distance_to_gcs", link.distance_m)),
        wind_level=float(getattr(link, "wind_level", 0.0)),
        obstacle_factor=float(getattr(link, "obstacle_factor", 0.0)),
        bytes_up=bytes_up,
        bytes_down=bytes_down,
        attack_active=bool(attack_state.active),
        attack_type=attack_state.attack_type,
        cpu_load=float(getattr(energy_state, "cpu_load", getattr(uav, "cpu_load", 0.0))),
        board_temperature_c=float(
            getattr(energy_state, "board_temperature_c", getattr(uav, "board_temperature_c", 0.0))
        ),
        response_action=None if response_state is None else getattr(response_state, "action", None),
        response_time=None if response_state is None else getattr(response_state, "applied_at_s", None),
        response_reason=None if response_state is None else getattr(response_state, "reason", None),
        flight_energy_wh=float(energy_state.flight_wh),
        communication_energy_wh=float(energy_state.communication_wh),
        detection_energy_wh=float(energy_state.detection_wh),
        total_energy_wh=float(energy_state.total_wh),
        cumulative_energy_wh=float(uav.cumulative_energy_wh),
        sim_time=float(timestamp_s),
    )


def estimate_traffic_bytes(
    uav: UAV,
    link: LinkState,
    attack: AttackSnapshot,
    dt_s: float,
    rng: random.Random | None = None,
) -> tuple[int, int]:
    """Estimate bytes sent and received during one step."""

    generator = rng or random.Random(0)
    traffic_cfg, phase_baseline, drift_profile = _resolve_traffic_profiles(uav)
    base_up_bps = float(phase_baseline.get("up_bytes_per_s", 800.0))
    base_down_bps = float(phase_baseline.get("down_bytes_per_s", 800.0))
    speed_factor = 1.0 + min(uav.speed_mps / max(uav.cruise_speed_mps, 1.0), 1.0) * float(
        traffic_cfg.get("speed_influence", 0.15)
    )
    link_factor = max(0.15, min(1.15, (link.snr_db + 5.0) / 30.0)) * max(0.20, 1.0 - 0.50 * link.loss_rate)
    throughput_factor = link_factor * attack.throughput_multiplier
    benign_uplink_multiplier = 1.0
    benign_downlink_multiplier = 1.0
    if not attack.active:
        harmonic = math.sin(
            (2.0 * math.pi * (uav.phase_elapsed_s + 0.35 * uav.mission_elapsed_s))
            / max(float(drift_profile.get("period_s", 20.0)), 1.0)
        )
        variability = float(drift_profile.get("variability", 0.0))
        traffic_bias = float(uav.metadata.get("traffic_bias", 0.0))
        benign_uplink_multiplier = float(drift_profile.get("uplink_multiplier", 1.0)) * (
            1.0 + variability * harmonic + traffic_bias
        )
        benign_downlink_multiplier = float(drift_profile.get("downlink_multiplier", 1.0)) * (
            1.0 + variability * math.cos(0.5 * harmonic) - 0.5 * traffic_bias
        )
    uplink = (
        base_up_bps
        * speed_factor
        * throughput_factor
        * attack.uplink_multiplier
        * benign_uplink_multiplier
        * dt_s
    )
    downlink = (
        base_down_bps
        * throughput_factor
        * attack.downlink_multiplier
        * benign_downlink_multiplier
        * dt_s
    )
    uplink *= generator.uniform(float(traffic_cfg.get("jitter_low", 0.92)), float(traffic_cfg.get("jitter_high", 1.08)))
    downlink *= generator.uniform(float(traffic_cfg.get("jitter_low", 0.92)), float(traffic_cfg.get("jitter_high", 1.08)))
    return max(0, int(round(uplink))), max(0, int(round(downlink)))


def _resolve_traffic_profiles(uav: UAV) -> tuple[dict[str, object], dict[str, object], dict[str, object]]:
    profile = load_scenario_profile(uav.metadata.get("scenario_profile_path"))
    traffic_cfg = profile.get("traffic", {})
    if not isinstance(traffic_cfg, dict):
        return {}, {}, {}

    mission_context = str(getattr(uav, "mission_context", "surveillance") or "surveillance").strip().lower()
    phase_baselines = traffic_cfg.get("phase_baselines", {})
    if isinstance(phase_baselines, dict):
        context_phase_baselines = phase_baselines.get(mission_context, {})
        if not isinstance(context_phase_baselines, dict):
            context_phase_baselines = {}
    else:
        context_phase_baselines = {}

    drift_rows = traffic_cfg.get("benign_phase_drift", {})
    if isinstance(drift_rows, dict):
        context_drift_rows = drift_rows.get(mission_context, {})
        if not isinstance(context_drift_rows, dict):
            context_drift_rows = {}
    else:
        context_drift_rows = {}

    phase_baseline = context_phase_baselines.get(str(uav.mission_phase), {})
    if not isinstance(phase_baseline, dict):
        phase_baseline = {}
    drift_profile = context_drift_rows.get(str(uav.mission_phase), {})
    if not isinstance(drift_profile, dict):
        drift_profile = {}
    return traffic_cfg, phase_baseline, drift_profile
