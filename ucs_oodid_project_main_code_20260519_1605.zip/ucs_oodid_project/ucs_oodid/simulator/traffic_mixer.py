from __future__ import annotations

from dataclasses import asdict, dataclass, field, is_dataclass
import random
from typing import Any, Mapping, Sequence

import pandas as pd

from .attack_replay import ATTACK_REPLAY_MODES, AttackReplayPool, resolve_simulation_source_metadata
from .attacks import build_attack_snapshot
from .channel import LinkState
from .energy import EnergyBreakdown
from .entities import UAV
from .stream import TrafficRecord, generate_traffic_record

BENIGN_LABEL_ALIASES: tuple[str, ...] = (
    "benign",
    "normal",
    "background",
    "legitimate",
    "none",
    "0",
)
SIM_SOURCE_VALUES: tuple[str, ...] = (
    "benign_replay",
    "benign_synthetic",
    "attack_replay",
)

SOURCE_FIELD_RENAMES: dict[str, str] = {
    "timestamp": "source_timestamp",
    "record_id": "source_record_id",
    "uav_id": "source_uav_id",
    "dataset_name": "source_dataset_name",
}

SIM_CONTEXT_FIELD_RENAMES: dict[str, str] = {
    "mission_phase": "sim_mission_phase",
    "mission_context": "sim_mission_context",
    "battery_soc": "sim_battery_soc",
    "speed": "sim_speed",
    "altitude": "sim_altitude",
    "rssi": "sim_rssi",
    "snr": "sim_snr",
    "latency_ms": "sim_latency_ms",
    "loss_rate": "sim_loss_rate",
    "distance_to_gcs": "sim_distance_to_gcs",
    "wind_level": "sim_wind_level",
    "obstacle_factor": "sim_obstacle_factor",
    "bytes_up": "sim_bytes_up",
    "bytes_down": "sim_bytes_down",
    "cpu_load": "sim_cpu_load",
    "board_temperature_c": "sim_board_temperature_c",
    "response_action": "sim_response_action",
    "response_time": "sim_response_time",
    "response_reason": "sim_response_reason",
    "flight_energy_wh": "sim_flight_energy_wh",
    "communication_energy_wh": "sim_communication_energy_wh",
    "detection_energy_wh": "sim_detection_energy_wh",
    "total_energy_wh": "sim_total_energy_wh",
    "cumulative_energy_wh": "sim_cumulative_energy_wh",
}


def _normalize_token(value: object) -> str:
    return str(value).strip().lower()


def _pythonize(value: object) -> object:
    try:
        if pd.isna(value):
            return None
    except TypeError:
        pass
    if hasattr(value, "item"):
        try:
            return value.item()
        except Exception:
            return value
    return value


def _is_missing(value: object) -> bool:
    if value is None:
        return True
    if isinstance(value, str):
        return not value.strip()
    try:
        missing = pd.isna(value)
    except Exception:
        return False
    return bool(missing) if isinstance(missing, bool) else False


def _coerce_float(value: object, *, default: float = 0.0) -> float:
    if _is_missing(value):
        return float(default)
    try:
        return float(value)
    except Exception:
        return float(default)


def _as_payload(value: Mapping[str, object] | object) -> dict[str, object]:
    if isinstance(value, Mapping):
        return {str(key): _pythonize(item) for key, item in value.items()}
    if isinstance(value, TrafficRecord):
        return {str(key): _pythonize(item) for key, item in value.to_dict().items()}
    if hasattr(value, "to_dict"):
        payload = value.to_dict()
        if isinstance(payload, Mapping):
            return {str(key): _pythonize(item) for key, item in payload.items()}
    if is_dataclass(value):
        return {str(key): _pythonize(item) for key, item in asdict(value).items()}
    raise TypeError(f"Unsupported traffic mixing context type: {type(value)!r}")


@dataclass(frozen=True)
class SyntheticTrafficContext:
    """Synthetic benign fallback context derived from current simulator state."""

    timestamp_s: float
    uav: UAV
    link: LinkState
    dt_s: float = 1.0
    energy: EnergyBreakdown | None = None
    bytes_up: int | None = None
    bytes_down: int | None = None
    response_state: object | None = None
    sim_time: float | None = None
    extra_fields: Mapping[str, object] = field(default_factory=dict)


@dataclass(frozen=True)
class _PreparedContext:
    payload: dict[str, object]
    sim_fields: dict[str, object]
    uav_id: str
    timestamp: float


class TrafficMixer:
    """Mix benign replay/synthetic rows with attack replay rows window by window."""

    def __init__(
        self,
        attack_replay_pool: AttackReplayPool,
        *,
        benign_label_aliases: Sequence[str] = BENIGN_LABEL_ALIASES,
        seed: int = 42,
    ):
        if attack_replay_pool is None:
            raise ValueError("attack_replay_pool is required")
        self.attack_replay_pool = attack_replay_pool
        self.benign_label_aliases = {_normalize_token(value) for value in benign_label_aliases}
        self.rng = random.Random(int(seed))
        self._benign_frames: dict[str, pd.DataFrame] = {}
        self._benign_cursor_by_selection: dict[tuple[str, str, str], int] = {}
        self._generated_id_counter = 0
        self._synthetic_benign_used = False

    def reset(self) -> None:
        self._benign_cursor_by_selection.clear()
        self._generated_id_counter = 0
        self._synthetic_benign_used = False

    def has_benign_replay(self, uav_id: str) -> bool:
        return not self._benign_frame_for_uav(uav_id).empty

    def mix(
        self,
        contexts: pd.DataFrame | Sequence[Mapping[str, object] | object] | Mapping[str, object] | object,
        *,
        attack_dataset_name: str | None = None,
        label: str | Sequence[str] | None = None,
        attack_type: str | Sequence[str] | None = None,
        gt_is_ood: bool | None = None,
        attack_replay_mode: str = "loop",
        benign_replay_mode: str = "loop",
        mixed_window_ratio: float = 0.25,
        window_size: int = 16,
        benign_dominated: bool = False,
        as_dataframe: bool = True,
    ) -> pd.DataFrame | list[dict[str, object]]:
        if not 0.0 <= float(mixed_window_ratio) <= 1.0:
            raise ValueError("mixed_window_ratio must be within [0.0, 1.0]")
        if int(window_size) <= 0:
            raise ValueError("window_size must be positive")
        if str(attack_replay_mode).strip().lower() not in ATTACK_REPLAY_MODES:
            raise ValueError(f"Unsupported attack_replay_mode: {attack_replay_mode}")
        if str(benign_replay_mode).strip().lower() not in ATTACK_REPLAY_MODES:
            raise ValueError(f"Unsupported benign_replay_mode: {benign_replay_mode}")

        prepared = self._prepare_contexts(contexts)
        if not prepared:
            if as_dataframe:
                return pd.DataFrame(
                    columns=[
                        "timestamp",
                        "sim_time",
                        "uav_id",
                        "dataset_name",
                        "source_type",
                        "record_id",
                        "sim_mission_phase",
                        "sim_battery_soc",
                        "sim_rssi",
                        "sim_snr",
                        "sim_latency_ms",
                        "sim_loss_rate",
                        "label",
                        "attack_active",
                        "attack_type",
                        "gt_attack_active",
                        "gt_attack_type",
                        "sim_source",
                        "simulation_role",
                    ]
                )
            return []

        rows: list[dict[str, object]] = []
        for start in range(0, len(prepared), int(window_size)):
            window = prepared[start : start + int(window_size)]
            attack_flags = self._window_attack_flags(
                window_len=len(window),
                mixed_window_ratio=float(mixed_window_ratio),
                benign_dominated=bool(benign_dominated),
            )
            for context, use_attack in zip(window, attack_flags):
                if use_attack:
                    rows.append(
                        self._build_attack_row(
                            context,
                            attack_dataset_name=attack_dataset_name,
                            label=label,
                            attack_type=attack_type,
                            gt_is_ood=gt_is_ood,
                            attack_replay_mode=attack_replay_mode,
                        )
                    )
                else:
                    rows.append(
                        self._build_benign_row(
                            context,
                            benign_replay_mode=benign_replay_mode,
                        )
                    )
        return pd.DataFrame(rows) if as_dataframe else rows

    def _prepare_contexts(
        self,
        contexts: pd.DataFrame | Sequence[Mapping[str, object] | object] | Mapping[str, object] | object,
    ) -> list[_PreparedContext]:
        if isinstance(contexts, pd.DataFrame):
            raw_items: list[object] = contexts.to_dict(orient="records")
        elif isinstance(contexts, SyntheticTrafficContext) or isinstance(contexts, Mapping):
            raw_items = [contexts]
        elif isinstance(contexts, TrafficRecord):
            raw_items = [contexts]
        elif is_dataclass(contexts):
            raw_items = [contexts]
        else:
            raw_items = list(contexts)
        return [self._prepare_context(item) for item in raw_items]

    def _prepare_context(self, context: Mapping[str, object] | object) -> _PreparedContext:
        if isinstance(context, SyntheticTrafficContext):
            payload = self._synthetic_payload_from_context(context)
        else:
            payload = _as_payload(context)
        if "timestamp" not in payload:
            raise ValueError("Traffic mixing context is missing required field 'timestamp'")
        if "uav_id" not in payload:
            raise ValueError("Traffic mixing context is missing required field 'uav_id'")

        timestamp = _coerce_float(payload.get("timestamp"), default=0.0)
        uav_id = str(payload.get("uav_id", "") or "").strip()
        if not uav_id:
            raise ValueError("Traffic mixing context contains an empty uav_id")

        payload["timestamp"] = timestamp
        payload["uav_id"] = uav_id
        payload["sim_time"] = _coerce_float(payload.get("sim_time", timestamp), default=timestamp)
        if _is_missing(payload.get("dataset_name")):
            bound_dataset = self._bound_dataset_name(uav_id)
            if bound_dataset is not None:
                payload["dataset_name"] = bound_dataset
        return _PreparedContext(
            payload=payload,
            sim_fields=self._extract_sim_fields(payload),
            uav_id=uav_id,
            timestamp=timestamp,
        )

    def _synthetic_payload_from_context(self, context: SyntheticTrafficContext) -> dict[str, object]:
        record = generate_traffic_record(
            timestamp_s=float(context.timestamp_s),
            uav=context.uav,
            link=context.link,
            attack=build_attack_snapshot("benign"),
            dt_s=float(context.dt_s),
            rng=self.rng,
            energy=context.energy,
            bytes_up=context.bytes_up,
            bytes_down=context.bytes_down,
            response_state=context.response_state,
        )
        payload = {str(key): _pythonize(value) for key, value in record.to_dict().items()}
        payload["sim_time"] = _coerce_float(
            context.sim_time if context.sim_time is not None else context.timestamp_s,
            default=float(context.timestamp_s),
        )
        payload.update({str(key): _pythonize(value) for key, value in context.extra_fields.items()})
        return payload

    def _extract_sim_fields(self, payload: Mapping[str, object]) -> dict[str, object]:
        sim_fields: dict[str, object] = {}
        for field_name, renamed_field in SIM_CONTEXT_FIELD_RENAMES.items():
            if field_name in payload and not _is_missing(payload[field_name]):
                sim_fields[renamed_field] = _pythonize(payload[field_name])
        return sim_fields

    def _window_attack_flags(
        self,
        *,
        window_len: int,
        mixed_window_ratio: float,
        benign_dominated: bool,
    ) -> list[bool]:
        if window_len <= 0 or mixed_window_ratio <= 0.0:
            return [False] * max(window_len, 0)
        if mixed_window_ratio >= 1.0:
            return [True] * window_len
        if benign_dominated:
            attack_count = sum(1 for _ in range(window_len) if self.rng.random() < mixed_window_ratio)
        else:
            attack_count = int(round(window_len * mixed_window_ratio))
            if attack_count <= 0:
                attack_count = 1
        attack_count = max(0, min(int(attack_count), window_len))
        flags = [False] * window_len
        for index in self.rng.sample(range(window_len), k=attack_count):
            flags[int(index)] = True
        return flags

    def _build_attack_row(
        self,
        context: _PreparedContext,
        *,
        attack_dataset_name: str | None,
        label: str | Sequence[str] | None,
        attack_type: str | Sequence[str] | None,
        gt_is_ood: bool | None,
        attack_replay_mode: str,
    ) -> dict[str, object]:
        try:
            payloads = self.attack_replay_pool.sample_attack_records(
                uav_id=context.uav_id,
                dataset_name=attack_dataset_name,
                label=label,
                attack_type=attack_type,
                attack_intensity=1,
                attack_replay_mode=attack_replay_mode,
                sim_fields=context.sim_fields,
            )
        except KeyError as exc:
            raise ValueError(f"No attack replay dataset is bound to UAV {context.uav_id!r}") from exc
        if not payloads:
            raise ValueError(f"No attack replay rows are available for UAV {context.uav_id!r}")

        payload = dict(payloads[0])
        dataset_name = str(
            payload.get("dataset_name", "")
            or attack_dataset_name
            or self._bound_dataset_name(context.uav_id)
            or ""
        )
        if _is_missing(payload.get("source_record_id")):
            payload["source_record_id"] = self._next_generated_id(f"{dataset_name or context.uav_id}:attack")
        return self._finalize_payload(
            payload,
            default_dataset_name=dataset_name,
            gt_attack_active=True,
            gt_attack_type=str(payload.get("attack_type", payload.get("label", "attack")) or "attack"),
            gt_is_ood=gt_is_ood,
            sim_source="attack_replay",
        )

    def _build_benign_row(
        self,
        context: _PreparedContext,
        *,
        benign_replay_mode: str,
    ) -> dict[str, object]:
        payload = self._sample_benign_payload(
            uav_id=context.uav_id,
            benign_replay_mode=benign_replay_mode,
            sim_fields=context.sim_fields,
        )
        sim_source = "benign_replay"
        if payload is None:
            payload = {
                str(key): _pythonize(value)
                for key, value in context.payload.items()
                if str(key) not in SIM_CONTEXT_FIELD_RENAMES
            }
            payload.update({str(key): _pythonize(value) for key, value in context.sim_fields.items()})
            payload["dataset_name"] = "simulator"
            if _is_missing(payload.get("source_dataset_name")):
                payload["source_dataset_name"] = "simulator"
            self._synthetic_benign_used = True
            sim_source = "benign_synthetic"
        return self._finalize_payload(
            payload,
            default_dataset_name=str(payload.get("dataset_name", "") or self._bound_dataset_name(context.uav_id) or "simulator"),
            gt_attack_active=False,
            gt_attack_type="benign",
            gt_is_ood=False,
            sim_source=sim_source,
        )

    def _sample_benign_payload(
        self,
        *,
        uav_id: str,
        benign_replay_mode: str,
        sim_fields: Mapping[str, object],
    ) -> dict[str, object] | None:
        frame = self._benign_frame_for_uav(uav_id)
        if frame.empty:
            return None
        dataset_name = self._bound_dataset_name(uav_id)
        if dataset_name is None:
            return None
        selection_key = (str(uav_id).strip(), dataset_name, str(benign_replay_mode).strip().lower())
        indices = self._select_indices(
            self._benign_cursor_by_selection,
            selection_key,
            len(frame),
            count=1,
            mode=selection_key[-1],
        )
        if not indices:
            return None
        return self._build_benign_replay_payload(
            frame.iloc[int(indices[0])],
            uav_id=str(uav_id).strip(),
            dataset_name=dataset_name,
            sim_fields=sim_fields,
        )

    def _bound_dataset_name(self, uav_id: str) -> str | None:
        try:
            return self.attack_replay_pool.dataset_name_for_uav(str(uav_id).strip())
        except KeyError:
            return None

    def _benign_frame_for_uav(self, uav_id: str) -> pd.DataFrame:
        dataset_name = self._bound_dataset_name(uav_id)
        if dataset_name is None:
            return pd.DataFrame()
        if dataset_name not in self._benign_frames:
            dataset = self.attack_replay_pool.datasets[dataset_name]
            frame = pd.read_csv(dataset.csv_path, low_memory=False)
            if dataset.label_col not in frame.columns:
                raise ValueError(f"{dataset.csv_path} is missing required label column {dataset.label_col!r}")
            work = frame.copy()
            work["_traffic_mixer_order"] = list(range(len(work)))
            work["_traffic_mixer_label"] = work[dataset.label_col].map(_normalize_token)
            work = work[work["_traffic_mixer_label"].isin(self.benign_label_aliases)].reset_index(drop=True)
            self._benign_frames[dataset_name] = work
        return self._benign_frames[dataset_name]

    def _build_benign_replay_payload(
        self,
        row: pd.Series,
        *,
        uav_id: str,
        dataset_name: str,
        sim_fields: Mapping[str, object],
    ) -> dict[str, object]:
        payload: dict[str, object] = {}
        source_label: object | None = None
        source_order = int(row["_traffic_mixer_order"]) if "_traffic_mixer_order" in row and not _is_missing(row["_traffic_mixer_order"]) else None
        for column, value in row.items():
            column_name = str(column)
            if column_name in {"_traffic_mixer_order", "_traffic_mixer_label"}:
                continue
            if column_name == self.attack_replay_pool.label_col:
                source_label = _pythonize(value)
                continue
            payload[SOURCE_FIELD_RENAMES.get(column_name, column_name)] = _pythonize(value)
        if not _is_missing(source_label):
            payload["source_label"] = source_label
        payload.update({str(key): _pythonize(value) for key, value in sim_fields.items()})
        payload["uav_id"] = str(uav_id).strip()
        payload["dataset_name"] = dataset_name
        payload["attack_source_dataset"] = ""
        if _is_missing(payload.get("source_record_id")):
            if source_order is not None:
                payload["source_record_id"] = f"{dataset_name}:benign:{source_order}"
            else:
                payload["source_record_id"] = self._next_generated_id(f"{dataset_name}:benign")
        return payload

    def _select_indices(
        self,
        cursor_store: dict[tuple[str, str, str], int],
        selection_key: tuple[str, str, str],
        total_rows: int,
        *,
        count: int,
        mode: str,
    ) -> list[int]:
        if total_rows <= 0 or count <= 0:
            return []
        if mode == "random":
            return [self.rng.randrange(total_rows) for _ in range(count)]
        cursor = int(cursor_store.get(selection_key, 0))
        if mode == "sequential":
            if cursor >= total_rows:
                return []
            end = min(cursor + count, total_rows)
            cursor_store[selection_key] = end
            return list(range(cursor, end))
        indices = [(cursor + offset) % total_rows for offset in range(count)]
        cursor_store[selection_key] = (cursor + count) % total_rows
        return indices

    def _finalize_payload(
        self,
        payload: Mapping[str, object],
        *,
        default_dataset_name: str,
        gt_attack_active: bool,
        gt_attack_type: str,
        gt_is_ood: bool | None,
        sim_source: str,
    ) -> dict[str, object]:
        row = {str(key): _pythonize(value) for key, value in payload.items()}
        uav_id = str(row.get("uav_id", "") or "").strip()
        if not uav_id:
            raise ValueError("Mixed traffic row is missing uav_id")
        timestamp = _coerce_float(row.get("timestamp"), default=0.0)
        row["timestamp"] = timestamp
        row["uav_id"] = uav_id
        row["sim_time"] = _coerce_float(row.get("sim_time", timestamp), default=timestamp)

        if _is_missing(row.get("dataset_name")):
            row["dataset_name"] = default_dataset_name or "simulator"
        source_metadata = resolve_simulation_source_metadata(
            dataset_name=str(row.get("dataset_name", "") or default_dataset_name or ""),
            uav_id=uav_id,
            source_type=row.get("source_type"),
            simulation_role=row.get("simulation_role"),
            source_note=row.get("source_note"),
        )
        if _is_missing(row.get("dataset_name")) and not _is_missing(source_metadata.get("dataset_name")):
            row["dataset_name"] = source_metadata["dataset_name"]
        if _is_missing(row.get("source_type")):
            fallback_source_type = str(source_metadata.get("source_type", "") or "")
            if not fallback_source_type:
                fallback_source_type = "simulator" if sim_source.endswith("synthetic") else "uav"
            row["source_type"] = fallback_source_type
        if _is_missing(row.get("simulation_role")):
            fallback_simulation_role = str(source_metadata.get("simulation_role", "") or "")
            if not fallback_simulation_role:
                fallback_simulation_role = "simulator_synthetic" if sim_source.endswith("synthetic") else "uav_replay"
            row["simulation_role"] = fallback_simulation_role
        if not _is_missing(source_metadata.get("source_note")) and _is_missing(row.get("source_note")):
            row["source_note"] = source_metadata["source_note"]
        if sim_source == "benign_synthetic" and _is_missing(row.get("source_dataset_name")):
            row["source_dataset_name"] = "simulator"
        if gt_attack_active:
            if _is_missing(row.get("attack_source_dataset")):
                row["attack_source_dataset"] = str(row.get("dataset_name", "") or "")
        else:
            row["attack_source_dataset"] = ""

        canonical_attack_type = str(gt_attack_type or "benign").strip() or "benign"
        canonical_label = canonical_attack_type if gt_attack_active else "benign"
        resolved_gt_is_ood = bool(
            gt_attack_active
            and (
                bool(gt_is_ood)
                if gt_is_ood is not None
                else bool(source_metadata.get("is_external_ood", False))
            )
        )
        original_label = row.get("label")
        if not _is_missing(original_label):
            original_label_text = str(original_label).strip()
            if original_label_text and original_label_text != canonical_label and _is_missing(row.get("source_label")):
                row["source_label"] = original_label_text

        row["label"] = canonical_label
        row["attack_active"] = bool(gt_attack_active)
        row["attack_type"] = canonical_attack_type if gt_attack_active else "benign"
        row["gt_attack_active"] = bool(gt_attack_active)
        row["gt_attack_type"] = canonical_attack_type if gt_attack_active else "benign"
        row["ground_truth_is_ood"] = resolved_gt_is_ood
        row["sim_source"] = sim_source
        row["record_kind"] = sim_source

        source_record_id = row.get("source_record_id")
        if _is_missing(source_record_id) and sim_source == "benign_synthetic":
            source_record_id = self._next_generated_id(f"{uav_id}:synthetic")
            row["source_record_id"] = source_record_id
        if _is_missing(row.get("record_id")):
            if not _is_missing(source_record_id):
                row["record_id"] = source_record_id
            else:
                row["record_id"] = self._next_generated_id(f"{uav_id}:{sim_source}")
        return row

    def _next_generated_id(self, prefix: str) -> str:
        self._generated_id_counter += 1
        return f"{prefix}:{self._generated_id_counter}"

    @property
    def synthetic_benign_used(self) -> bool:
        return bool(self._synthetic_benign_used)


def mix_traffic_dataframe(
    contexts: pd.DataFrame | Sequence[Mapping[str, object] | object] | Mapping[str, object] | object,
    attack_replay_pool: AttackReplayPool,
    *,
    seed: int = 42,
    **kwargs: object,
) -> pd.DataFrame:
    mixer = TrafficMixer(attack_replay_pool, seed=seed)
    return mixer.mix(contexts, as_dataframe=True, **kwargs)


def mix_traffic_records(
    contexts: pd.DataFrame | Sequence[Mapping[str, object] | object] | Mapping[str, object] | object,
    attack_replay_pool: AttackReplayPool,
    *,
    seed: int = 42,
    **kwargs: object,
) -> list[dict[str, object]]:
    mixer = TrafficMixer(attack_replay_pool, seed=seed)
    rows = mixer.mix(contexts, as_dataframe=False, **kwargs)
    return list(rows)


__all__ = [
    "BENIGN_LABEL_ALIASES",
    "SIM_SOURCE_VALUES",
    "SyntheticTrafficContext",
    "TrafficMixer",
    "mix_traffic_dataframe",
    "mix_traffic_records",
]
