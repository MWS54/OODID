from __future__ import annotations

from pathlib import Path
from typing import Sequence

import numpy as np
import pandas as pd


def make_synthetic_uav_metadata(
    records: int = 5000,
    seed: int = 42,
    ood_ratio: float = 0.08,
    attack_ratio: float = 0.25,
) -> pd.DataFrame:
    """Create a UAV-like metadata-only dataset with ID and OOD labels.

    Features are side-channel metadata only: packet size, inter-arrival time,
    direction, burst density, duration, packet/byte counts, retransmission cadence.
    """
    rng = np.random.default_rng(seed)
    labels_id = ["benign", "dos", "mitm", "spoof", "replay", "injection", "scan"]
    labels_ood = ["unknown_probe", "unknown_burst"]
    rows = []
    t = 0.0
    mission_phases = ["hovering", "cruising", "maneuvering", "high_rate_sensing", "interference"]
    for i in range(records):
        phase = mission_phases[(i // max(1, records // len(mission_phases))) % len(mission_phases)]
        if rng.random() < ood_ratio:
            label = rng.choice(labels_ood)
        elif rng.random() < attack_ratio:
            label = rng.choice(labels_id[1:])
        else:
            label = "benign"

        # phase-dependent base traffic
        rate_factor = {
            "hovering": 0.8, "cruising": 1.0, "maneuvering": 1.4,
            "high_rate_sensing": 2.5, "interference": 1.2,
        }[phase]
        size_mu = 180 * rate_factor
        iat_mu = 0.05 / rate_factor
        direction = rng.binomial(1, 0.65)
        burst_density = rng.gamma(2.0, 0.2 * rate_factor)
        retrans = rng.poisson(0.1)

        if label == "dos":
            size_mu *= 0.8; iat_mu *= 0.15; burst_density *= 5; retrans += rng.poisson(1.5)
        elif label == "mitm":
            size_mu *= 1.1; iat_mu *= 1.8; direction = rng.binomial(1, 0.5); retrans += rng.poisson(0.8)
        elif label == "spoof":
            size_mu *= 1.4; iat_mu *= 0.8; burst_density *= 1.6
        elif label == "replay":
            size_mu *= 0.95; iat_mu *= 0.45; burst_density *= 2.5
        elif label == "injection":
            size_mu *= 1.8; iat_mu *= 0.7; direction = rng.binomial(1, 0.35)
        elif label == "scan":
            size_mu *= 0.5; iat_mu *= 1.4; burst_density *= 0.6
        elif label == "unknown_probe":
            size_mu *= 0.4; iat_mu *= 2.4; direction = rng.binomial(1, 0.2); burst_density *= 0.4
        elif label == "unknown_burst":
            size_mu *= 2.6; iat_mu *= 0.12; direction = rng.binomial(1, 0.9); burst_density *= 7

        packet_size_mean = max(20, rng.normal(size_mu, 25))
        packet_size_std = abs(rng.normal(25 * rate_factor, 8))
        inter_arrival_mean = max(1e-4, rng.lognormal(np.log(max(iat_mu, 1e-4)), 0.3))
        inter_arrival_std = inter_arrival_mean * rng.uniform(0.2, 1.0)
        duration = rng.exponential(0.5 / max(rate_factor, 1e-6))
        pkt_count = max(1, int(rng.poisson(10 * rate_factor * max(burst_density, 0.1))))
        byte_count = pkt_count * packet_size_mean * rng.uniform(0.8, 1.2)
        t += inter_arrival_mean
        rows.append({
            "timestamp": t,
            "record_id": i,
            "label": label,
            "mission_phase": phase,
            "packet_size_mean": packet_size_mean,
            "packet_size_std": packet_size_std,
            "inter_arrival_mean": inter_arrival_mean,
            "inter_arrival_std": inter_arrival_std,
            "direction": direction,
            "direction_ratio": direction + rng.normal(0, 0.05),
            "burst_density": burst_density,
            "session_duration": duration,
            "packet_count": pkt_count,
            "byte_count": byte_count,
            "retransmission_count": retrans,
            "tcp_flag_count": rng.poisson(1.0 + retrans),
            # leakage-like columns intentionally included so preprocessing removes them
            "src_ip": f"10.0.0.{rng.integers(1, 254)}",
            "dst_ip": "192.168.1.10",
            "message_id": rng.integers(1, 100),
            "payload_len_raw": rng.integers(0, 64),
        })
    return pd.DataFrame(rows)


def save_synthetic(path: str | Path, records: int = 5000, seed: int = 42) -> None:
    df = make_synthetic_uav_metadata(records=records, seed=seed)
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)
