from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Sequence

import numpy as np
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler
import torch
from torch import autograd, nn
from torch.utils.data import DataLoader, TensorDataset


def _build_mlp(input_dim: int, hidden_dim: int, output_dim: int, final_activation: nn.Module | None = None) -> nn.Sequential:
    layers: list[nn.Module] = [
        nn.Linear(input_dim, hidden_dim),
        nn.LeakyReLU(0.2, inplace=True),
        nn.Linear(hidden_dim, hidden_dim),
        nn.LeakyReLU(0.2, inplace=True),
        nn.Linear(hidden_dim, output_dim),
    ]
    if final_activation is not None:
        layers.append(final_activation)
    return nn.Sequential(*layers)


class Generator(nn.Module):
    def __init__(self, noise_dim: int, hidden_dim: int, output_dim: int):
        super().__init__()
        self.net = _build_mlp(noise_dim, hidden_dim, output_dim)

    def forward(self, noise: torch.Tensor) -> torch.Tensor:
        return self.net(noise)


class Critic(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int):
        super().__init__()
        self.net = _build_mlp(input_dim, hidden_dim, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


@dataclass
class TabularGanConfig:
    noise_dim: int = 32
    hidden_dim: int = 128
    batch_size: int = 256
    epochs: int = 60
    critic_steps: int = 3
    lambda_gp: float = 10.0
    lr: float = 2e-4
    sample_batch_size: int = 2048
    device: str = "cpu"


class FeaturePostprocessor:
    def __init__(self, max_discrete_values: int = 32, integer_tol: float = 1e-6):
        self.max_discrete_values = int(max_discrete_values)
        self.integer_tol = float(integer_tol)
        self.min_: np.ndarray | None = None
        self.max_: np.ndarray | None = None
        self.integer_like_: np.ndarray | None = None
        self.discrete_values_: list[np.ndarray | None] = []

    def fit(self, x: np.ndarray) -> "FeaturePostprocessor":
        arr = np.asarray(x, dtype=np.float32)
        self.min_ = arr.min(axis=0)
        self.max_ = arr.max(axis=0)
        self.integer_like_ = np.mean(np.abs(arr - np.round(arr)) <= self.integer_tol, axis=0) >= 0.98
        self.discrete_values_ = []
        for idx in range(arr.shape[1]):
            unique = np.unique(arr[:, idx])
            if unique.size <= self.max_discrete_values:
                self.discrete_values_.append(unique.astype(np.float32))
            else:
                self.discrete_values_.append(None)
        return self

    def transform(self, x: np.ndarray) -> np.ndarray:
        if self.min_ is None or self.max_ is None or self.integer_like_ is None:
            raise RuntimeError("FeaturePostprocessor must be fitted before transform.")
        arr = np.asarray(x, dtype=np.float32).copy()
        arr = np.clip(arr, self.min_, self.max_)
        for idx in range(arr.shape[1]):
            discrete = self.discrete_values_[idx]
            if discrete is not None:
                nearest = np.abs(arr[:, [idx]] - discrete[None, :]).argmin(axis=1)
                arr[:, idx] = discrete[nearest]
            elif self.integer_like_[idx]:
                arr[:, idx] = np.round(arr[:, idx])
        arr = np.clip(arr, self.min_, self.max_)
        return arr.astype(np.float32)


def gradient_penalty(critic: Critic, real: torch.Tensor, fake: torch.Tensor, device: str) -> torch.Tensor:
    alpha = torch.rand(real.size(0), 1, device=device)
    interpolated = alpha * real + (1.0 - alpha) * fake
    interpolated.requires_grad_(True)
    critic_score = critic(interpolated)
    grad = autograd.grad(
        outputs=critic_score.sum(),
        inputs=interpolated,
        create_graph=True,
        retain_graph=True,
        only_inputs=True,
    )[0]
    grad_norm = grad.view(grad.size(0), -1).norm(2, dim=1)
    return ((grad_norm - 1.0) ** 2).mean()


class TabularWGAN:
    def __init__(self, input_dim: int, config: TabularGanConfig):
        self.input_dim = int(input_dim)
        self.config = config
        self.device = str(config.device)
        self.scaler = StandardScaler()
        self.generator = Generator(config.noise_dim, config.hidden_dim, input_dim).to(self.device)
        self.critic = Critic(input_dim, config.hidden_dim).to(self.device)
        self.history: list[dict] = []

    def fit(self, real_x: np.ndarray, seed: int | None = None) -> dict:
        if seed is not None:
            torch.manual_seed(int(seed))
            if torch.cuda.is_available():
                torch.cuda.manual_seed_all(int(seed))

        arr = np.asarray(real_x, dtype=np.float32)
        if arr.ndim != 2 or arr.shape[0] < 2:
            raise ValueError("TabularWGAN expects a 2D array with at least 2 rows.")

        scaled = self.scaler.fit_transform(arr).astype(np.float32)
        batch_size = min(int(self.config.batch_size), len(scaled))
        loader = DataLoader(
            TensorDataset(torch.from_numpy(scaled)),
            batch_size=max(2, batch_size),
            shuffle=True,
            drop_last=False,
        )

        opt_g = torch.optim.Adam(self.generator.parameters(), lr=self.config.lr, betas=(0.5, 0.9))
        opt_d = torch.optim.Adam(self.critic.parameters(), lr=self.config.lr, betas=(0.5, 0.9))

        for epoch in range(1, int(self.config.epochs) + 1):
            critic_losses: list[float] = []
            generator_losses: list[float] = []
            gp_losses: list[float] = []
            wasserstein_terms: list[float] = []
            for step, (real_batch,) in enumerate(loader, start=1):
                real_batch = real_batch.to(self.device)
                batch = real_batch.size(0)
                for _ in range(int(self.config.critic_steps)):
                    noise = torch.randn(batch, self.config.noise_dim, device=self.device)
                    fake_batch = self.generator(noise).detach()
                    gp = gradient_penalty(self.critic, real_batch, fake_batch, self.device)
                    critic_real = self.critic(real_batch).mean()
                    critic_fake = self.critic(fake_batch).mean()
                    wasserstein = critic_real - critic_fake
                    loss_d = critic_fake - critic_real + self.config.lambda_gp * gp
                    opt_d.zero_grad(set_to_none=True)
                    loss_d.backward()
                    opt_d.step()
                    critic_losses.append(float(loss_d.detach().cpu()))
                    gp_losses.append(float(gp.detach().cpu()))
                    wasserstein_terms.append(float(wasserstein.detach().cpu()))

                noise = torch.randn(batch, self.config.noise_dim, device=self.device)
                loss_g = -self.critic(self.generator(noise)).mean()
                opt_g.zero_grad(set_to_none=True)
                loss_g.backward()
                opt_g.step()
                generator_losses.append(float(loss_g.detach().cpu()))

            epoch_summary = {
                "epoch": int(epoch),
                "critic_loss": float(np.mean(critic_losses)) if critic_losses else 0.0,
                "generator_loss": float(np.mean(generator_losses)) if generator_losses else 0.0,
                "gradient_penalty": float(np.mean(gp_losses)) if gp_losses else 0.0,
                "wasserstein": float(np.mean(wasserstein_terms)) if wasserstein_terms else 0.0,
            }
            self.history.append(epoch_summary)

        return {
            "rows": int(len(arr)),
            "input_dim": int(self.input_dim),
            "epochs": int(self.config.epochs),
            "history_tail": self.history[-10:],
            "final_epoch": self.history[-1] if self.history else {},
        }

    def sample(self, n: int, seed: int | None = None) -> np.ndarray:
        if seed is not None:
            torch.manual_seed(int(seed))
            if torch.cuda.is_available():
                torch.cuda.manual_seed_all(int(seed))

        self.generator.eval()
        generated: list[np.ndarray] = []
        remaining = int(n)
        with torch.no_grad():
            while remaining > 0:
                batch = min(int(self.config.sample_batch_size), remaining)
                noise = torch.randn(batch, self.config.noise_dim, device=self.device)
                fake = self.generator(noise).detach().cpu().numpy()
                generated.append(fake)
                remaining -= batch
        scaled = np.concatenate(generated, axis=0).astype(np.float32)
        return self.scaler.inverse_transform(scaled).astype(np.float32)


def _rows_to_keys(x: np.ndarray, decimals: int = 5) -> list[tuple]:
    rounded = np.round(np.asarray(x, dtype=np.float32), decimals=decimals)
    return [tuple(row.tolist()) for row in rounded]


def estimate_distance_threshold(
    real_x: np.ndarray,
    seed: int = 42,
    max_reference_rows: int = 4096,
    quantile: float = 0.95,
) -> tuple[NearestNeighbors, float, dict]:
    arr = np.asarray(real_x, dtype=np.float32)
    rng = np.random.default_rng(seed)
    if len(arr) > max_reference_rows:
        ref_idx = rng.choice(len(arr), size=max_reference_rows, replace=False)
        ref = arr[ref_idx]
    else:
        ref = arr

    full_nn = NearestNeighbors(n_neighbors=1)
    full_nn.fit(arr)

    if len(ref) <= 1:
        threshold = 1e-6
    else:
        self_nn = NearestNeighbors(n_neighbors=2)
        self_nn.fit(ref)
        distances, _ = self_nn.kneighbors(ref)
        threshold = float(np.quantile(distances[:, 1], quantile))
        threshold = max(threshold, 1e-6)

    return full_nn, threshold, {
        "reference_rows": int(len(ref)),
        "distance_quantile": float(quantile),
        "distance_threshold": float(threshold),
    }


def generate_filtered_samples(
    model: TabularWGAN,
    real_x: np.ndarray,
    n_generate: int,
    seed: int = 42,
    distance_quantile: float = 0.95,
    distance_scale: float = 1.25,
    max_rounds: int = 15,
    oversample_factor: float = 3.0,
    decimals: int = 5,
) -> tuple[np.ndarray, dict]:
    real_arr = np.asarray(real_x, dtype=np.float32)
    if n_generate <= 0:
        return np.empty((0, real_arr.shape[1]), dtype=np.float32), {
            "requested": 0,
            "generated": 0,
            "acceptance_rate": 0.0,
        }

    post = FeaturePostprocessor().fit(real_arr)
    scaled_real = model.scaler.transform(real_arr).astype(np.float32)
    nn_index, threshold, threshold_summary = estimate_distance_threshold(
        scaled_real,
        seed=seed,
        quantile=distance_quantile,
    )
    upper_threshold = float(threshold * distance_scale)

    collected: list[np.ndarray] = []
    real_keys = set(_rows_to_keys(real_arr, decimals=decimals))
    synthetic_keys: set[tuple] = set()
    candidate_total = 0
    accepted_total = 0

    for round_idx in range(int(max_rounds)):
        remaining = n_generate - accepted_total
        if remaining <= 0:
            break
        batch_n = max(model.config.sample_batch_size, int(np.ceil(remaining * oversample_factor)))
        raw_candidates = model.sample(batch_n, seed=seed + round_idx + 1)
        post_candidates = post.transform(raw_candidates)
        scaled_candidates = model.scaler.transform(post_candidates).astype(np.float32)
        distances, _ = nn_index.kneighbors(scaled_candidates)
        keep_mask = distances[:, 0] <= upper_threshold
        candidate_total += int(len(post_candidates))

        accepted_batch: list[np.ndarray] = []
        for row, keep in zip(post_candidates, keep_mask):
            if not keep:
                continue
            key = tuple(np.round(row, decimals=decimals).tolist())
            if key in real_keys or key in synthetic_keys:
                continue
            synthetic_keys.add(key)
            accepted_batch.append(row.astype(np.float32))
            if accepted_total + len(accepted_batch) >= n_generate:
                break

        if accepted_batch:
            batch_arr = np.stack(accepted_batch, axis=0)
            collected.append(batch_arr)
            accepted_total += int(len(batch_arr))

    if accepted_total < n_generate:
        remaining = n_generate - accepted_total
        fallback = post.transform(model.sample(remaining * 2, seed=seed + 999))
        accepted_batch = []
        for row in fallback:
            key = tuple(np.round(row, decimals=decimals).tolist())
            if key in real_keys or key in synthetic_keys:
                continue
            synthetic_keys.add(key)
            accepted_batch.append(row.astype(np.float32))
            if len(accepted_batch) >= remaining:
                break
        if accepted_batch:
            batch_arr = np.stack(accepted_batch, axis=0)
            collected.append(batch_arr)
            accepted_total += int(len(batch_arr))

    final = np.concatenate(collected, axis=0)[:n_generate] if collected else np.empty((0, real_arr.shape[1]), dtype=np.float32)
    return final.astype(np.float32), {
        "requested": int(n_generate),
        "generated": int(len(final)),
        "candidate_total": int(candidate_total),
        "acceptance_rate": float(len(final) / candidate_total) if candidate_total else 0.0,
        "distance_scale": float(distance_scale),
        **threshold_summary,
    }


def augment_class_with_wgan(
    real_x: np.ndarray,
    n_generate: int,
    config: TabularGanConfig,
    seed: int = 42,
    distance_quantile: float = 0.95,
    distance_scale: float = 1.25,
) -> tuple[np.ndarray, dict]:
    torch.manual_seed(int(seed))
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(int(seed))
    model = TabularWGAN(input_dim=np.asarray(real_x).shape[1], config=config)
    fit_summary = model.fit(real_x, seed=seed)
    samples, sample_summary = generate_filtered_samples(
        model,
        real_x,
        n_generate=n_generate,
        seed=seed,
        distance_quantile=distance_quantile,
        distance_scale=distance_scale,
    )
    return samples, {
        "fit": fit_summary,
        "sampling": sample_summary,
    }
