from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence

import numpy as np
import pandas as pd

from .utils import parse_label_cell

UNKNOWN_GROUP_TOKEN = "__unknown__"


@dataclass
class WindowedData:
    x: np.ndarray
    y: np.ndarray
    record_indices: np.ndarray
    record_ids: np.ndarray
    ood: np.ndarray
    record_y: Optional[np.ndarray] = None
    valid_mask: Optional[np.ndarray] = None
    timestamps: Optional[np.ndarray] = None
    raw_starts: Optional[np.ndarray] = None
    group_ids: Optional[np.ndarray] = None
    group_index: Optional[np.ndarray] = None

    def __post_init__(self) -> None:
        if self.valid_mask is None and self.x is not None:
            self.valid_mask = np.ones(self.x.shape[:2], dtype=bool)
        elif self.valid_mask is not None:
            self.valid_mask = np.asarray(self.valid_mask, dtype=bool)
        if self.group_ids is not None:
            self.group_ids = np.asarray(self.group_ids)
        if self.group_index is not None:
            self.group_index = np.asarray(self.group_index, dtype=np.int64)

    def __len__(self) -> int:
        return int(self.x.shape[0])


def normalize_group_label(value: object) -> Optional[str]:
    if value is None:
        return None
    if isinstance(value, (float, np.floating)) and np.isnan(value):
        return None
    text = str(value).strip()
    return text or None


def build_group_to_index(group_ids: Optional[Sequence[object]], include_unknown: bool = True, unknown_group: str = UNKNOWN_GROUP_TOKEN) -> Dict[str, int]:
    labels = [] if group_ids is None else [normalize_group_label(value) for value in group_ids]
    mapping = {group_id: idx for idx, group_id in enumerate(sorted({label for label in labels if label is not None}))}
    if include_unknown and unknown_group not in mapping:
        mapping[unknown_group] = len(mapping)
    return mapping


def resolve_group_index_array(
    group_ids: Optional[Sequence[object]],
    group_to_index: Optional[Dict[str, int]],
    unknown_group: str = UNKNOWN_GROUP_TOKEN,
) -> Optional[np.ndarray]:
    if group_ids is None or not group_to_index:
        return None
    unknown_index = group_to_index.get(unknown_group)
    indices = []
    for value in group_ids:
        group_id = normalize_group_label(value)
        if group_id is not None and group_id in group_to_index:
            indices.append(int(group_to_index[group_id]))
        elif unknown_index is not None:
            indices.append(int(unknown_index))
        else:
            indices.append(0)
    return np.asarray(indices, dtype=np.int64)


def attach_group_index(
    windows: WindowedData,
    group_to_index: Optional[Dict[str, int]],
    unknown_group: str = UNKNOWN_GROUP_TOKEN,
) -> WindowedData:
    windows.group_index = resolve_group_index_array(getattr(windows, "group_ids", None), group_to_index, unknown_group=unknown_group)
    return windows


def attach_parsed_labels(df: pd.DataFrame, label_col: str) -> pd.DataFrame:
    df = df.copy()
    df["__labels"] = df[label_col].apply(parse_label_cell) if label_col in df.columns else [[] for _ in range(len(df))]
    return df


def infer_all_labels(df: pd.DataFrame, label_col: str) -> List[str]:
    labels = []
    if "__labels" not in df.columns:
        df = attach_parsed_labels(df, label_col)
    for items in df["__labels"]:
        labels.extend([str(x) for x in items])
    return sorted(set(labels))


def mark_ood_records(df: pd.DataFrame, id_classes: Sequence[str]) -> pd.DataFrame:
    id_set = set(id_classes)
    df = df.copy()
    if "__labels" not in df.columns:
        raise ValueError("Call attach_parsed_labels before mark_ood_records.")
    df["__is_ood_record"] = df["__labels"].apply(lambda labs: any(l not in id_set for l in labs))
    return df


def _window_label(labels: Sequence[List[str]], class_to_idx: Dict[str, int], valid_mask: Optional[Sequence[bool]] = None) -> tuple[np.ndarray, bool, np.ndarray]:
    c = len(class_to_idx)
    y = np.zeros(c, dtype=np.float32)
    rec_y = np.zeros((len(labels), c), dtype=np.float32)
    ood = False
    if valid_mask is None:
        valid_mask = [True] * len(labels)
    for i, labs in enumerate(labels):
        if not bool(valid_mask[i]):
            continue
        for lab in labs:
            if lab in class_to_idx:
                y[class_to_idx[lab]] = 1.0
                rec_y[i, class_to_idx[lab]] = 1.0
            else:
                ood = True
    return y, ood, rec_y


def _record_ids(df: pd.DataFrame, idx: np.ndarray, record_id_col: str):
    return df.iloc[idx][record_id_col].to_numpy() if record_id_col in df.columns else idx


def _empty_windowed(features: np.ndarray, num_classes: int, window_len: int) -> WindowedData:
    feature_dim = int(features.shape[1]) if features.ndim > 1 else 0
    return WindowedData(
        x=np.zeros((0, window_len, feature_dim), dtype=np.float32),
        y=np.zeros((0, num_classes), dtype=np.float32),
        record_indices=np.zeros((0, window_len), dtype=np.int64),
        record_ids=np.empty((0, window_len), dtype=object),
        ood=np.zeros(0, dtype=bool),
        valid_mask=np.zeros((0, window_len), dtype=bool),
    )


def build_count_windows(features: np.ndarray, df: pd.DataFrame, class_to_idx: Dict[str, int], label_col: str = "label", record_id_col: str = "record_id", window_size: int = 16, stride: int = 8, drop_incomplete: bool = True) -> WindowedData:
    if "__labels" not in df.columns:
        df = attach_parsed_labels(df, label_col)
    n = len(df)
    xs, ys, rec_idxs, rec_ids, oods, rec_ys, masks, starts = [], [], [], [], [], [], [], []
    stop = max(n - window_size + 1, 0) if drop_incomplete else n
    for start in range(0, stop, stride):
        end = start + window_size
        if end > n and drop_incomplete:
            break
        real_idx = np.arange(start, min(end, n))
        if len(real_idx) == 0:
            continue
        valid = np.ones(len(real_idx), dtype=bool)
        idx = real_idx
        if len(idx) < window_size:
            pad = np.full(window_size - len(idx), idx[-1])
            idx = np.concatenate([idx, pad])
            valid = np.concatenate([valid, np.zeros(len(pad), dtype=bool)])
        labels = list(df.iloc[idx]["__labels"])
        y, ood, rec_y = _window_label(labels, class_to_idx, valid)
        xs.append(features[idx]); ys.append(y); rec_idxs.append(idx.astype(np.int64)); rec_ids.append(_record_ids(df, idx, record_id_col)); oods.append(ood); rec_ys.append(rec_y); masks.append(valid); starts.append(start)
    if not xs:
        empty_x = np.zeros((0, window_size, features.shape[1]), dtype=np.float32)
        empty_y = np.zeros((0, len(class_to_idx)), dtype=np.float32)
        return WindowedData(empty_x, empty_y, np.zeros((0, window_size), dtype=np.int64), np.zeros((0, window_size)), np.zeros(0, dtype=bool), valid_mask=np.zeros((0, window_size), dtype=bool))
    return WindowedData(np.asarray(xs, dtype=np.float32), np.asarray(ys, dtype=np.float32), np.asarray(rec_idxs, dtype=np.int64), np.asarray(rec_ids), np.asarray(oods, dtype=bool), np.asarray(rec_ys, dtype=np.float32), valid_mask=np.asarray(masks, dtype=bool), raw_starts=np.asarray(starts, dtype=np.int64))


def build_time_windows(features: np.ndarray, df: pd.DataFrame, class_to_idx: Dict[str, int], timestamp_col: str, label_col: str = "label", record_id_col: str = "record_id", time_seconds: float = 2.0, stride_seconds: Optional[float] = None, max_records: int = 64) -> WindowedData:
    if stride_seconds is None:
        stride_seconds = time_seconds / 2
    if "__labels" not in df.columns:
        df = attach_parsed_labels(df, label_col)
    if timestamp_col not in df.columns:
        raise ValueError("timestamp_col is required for time windows")
    work = df.copy().reset_index(drop=True)
    ts = pd.to_numeric(work[timestamp_col], errors="coerce").ffill().fillna(0).to_numpy(float)
    starts = np.arange(float(ts.min()), float(ts.max()) + 1e-9, stride_seconds)
    xs, ys, rec_idxs, rec_ids, oods, rec_ys, masks, raw_starts = [], [], [], [], [], [], [], []
    for s in starts:
        real_idx = np.where((ts >= s) & (ts < s + time_seconds))[0]
        if len(real_idx) == 0:
            continue
        if len(real_idx) > max_records:
            real_idx = real_idx[:max_records]
        valid = np.ones(len(real_idx), dtype=bool)
        idx = real_idx
        if len(idx) < max_records:
            pad = np.full(max_records - len(idx), idx[-1])
            idx = np.concatenate([idx, pad])
            valid = np.concatenate([valid, np.zeros(len(pad), dtype=bool)])
        labels = list(work.iloc[idx]["__labels"])
        y, ood, rec_y = _window_label(labels, class_to_idx, valid)
        xs.append(features[idx]); ys.append(y); rec_idxs.append(idx.astype(np.int64)); rec_ids.append(_record_ids(work, idx, record_id_col)); oods.append(ood); rec_ys.append(rec_y); masks.append(valid); raw_starts.append(real_idx[0])
    if not xs:
        f = features.shape[1]; c = len(class_to_idx)
        return WindowedData(np.zeros((0, max_records, f), dtype=np.float32), np.zeros((0, c), dtype=np.float32), np.zeros((0, max_records), dtype=np.int64), np.zeros((0, max_records)), np.zeros(0, dtype=bool), valid_mask=np.zeros((0, max_records), dtype=bool))
    return WindowedData(np.asarray(xs, dtype=np.float32), np.asarray(ys, dtype=np.float32), np.asarray(rec_idxs, dtype=np.int64), np.asarray(rec_ids), np.asarray(oods, dtype=bool), np.asarray(rec_ys, dtype=np.float32), valid_mask=np.asarray(masks, dtype=bool), raw_starts=np.asarray(raw_starts))


def build_adaptive_windows(features: np.ndarray, df: pd.DataFrame, class_to_idx: Dict[str, int], timestamp_col: str, label_col: str = "label", record_id_col: str = "record_id", min_size: int = 8, max_size: int = 64, target_records: int = 16, stride: Optional[int] = None) -> WindowedData:
    if stride is None:
        stride = max(1, target_records // 2)
    if timestamp_col not in df.columns:
        return build_count_windows(features, df, class_to_idx, label_col, record_id_col, target_records, stride)
    ts = pd.to_numeric(df[timestamp_col], errors="coerce").ffill().fillna(0).to_numpy(float)
    if "__labels" not in df.columns:
        df = attach_parsed_labels(df, label_col)
    xs, ys, rec_idxs, rec_ids, oods, rec_ys, masks, starts = [], [], [], [], [], [], [], []
    i = 0
    n = len(df)
    while i < n:
        j = min(i + target_records, n)
        if j - i >= 2:
            local_span = max(ts[j - 1] - ts[i], 1e-6)
            local_rate = (j - i) / local_span
            size = int(np.clip(target_records * (1.0 + 0.5 / max(local_rate, 1e-6)), min_size, max_size))
        else:
            size = target_records
        end = min(i + size, n)
        real_idx = np.arange(i, end)
        if len(real_idx) == 0:
            break
        valid = np.ones(len(real_idx), dtype=bool)
        idx = real_idx
        if len(idx) < max_size:
            pad = np.full(max_size - len(idx), idx[-1])
            idx = np.concatenate([idx, pad])
            valid = np.concatenate([valid, np.zeros(len(pad), dtype=bool)])
        elif len(idx) > max_size:
            idx = idx[:max_size]
            valid = valid[:max_size]
        labels = list(df.iloc[idx]["__labels"])
        y, ood, rec_y = _window_label(labels, class_to_idx, valid)
        xs.append(features[idx]); ys.append(y); rec_idxs.append(idx.astype(np.int64)); rec_ids.append(_record_ids(df, idx, record_id_col)); oods.append(ood); rec_ys.append(rec_y); masks.append(valid); starts.append(i)
        i += stride
    if not xs:
        f = features.shape[1]; c = len(class_to_idx)
        return WindowedData(np.zeros((0, max_size, f), dtype=np.float32), np.zeros((0, c), dtype=np.float32), np.zeros((0, max_size), dtype=np.int64), np.zeros((0, max_size)), np.zeros(0, dtype=bool), valid_mask=np.zeros((0, max_size), dtype=bool))
    return WindowedData(np.asarray(xs, dtype=np.float32), np.asarray(ys, dtype=np.float32), np.asarray(rec_idxs, dtype=np.int64), np.asarray(rec_ids), np.asarray(oods, dtype=bool), np.asarray(rec_ys, dtype=np.float32), valid_mask=np.asarray(masks, dtype=bool), raw_starts=np.asarray(starts))


def concat_windowed(parts: List[WindowedData]) -> WindowedData:
    if not parts:
        raise ValueError("parts must contain at least one WindowedData")
    non_empty = [part for part in parts if len(part) > 0]
    if not non_empty:
        template = parts[0]
        return WindowedData(
            x=template.x[:0],
            y=template.y[:0],
            record_indices=template.record_indices[:0],
            record_ids=template.record_ids[:0],
            ood=template.ood[:0],
            record_y=template.record_y[:0] if template.record_y is not None else None,
            valid_mask=template.valid_mask[:0] if template.valid_mask is not None else None,
            timestamps=template.timestamps[:0] if template.timestamps is not None else None,
            raw_starts=template.raw_starts[:0] if template.raw_starts is not None else None,
            group_ids=template.group_ids[:0] if template.group_ids is not None else None,
            group_index=template.group_index[:0] if template.group_index is not None else None,
        )
    parts = non_empty

    def _concat_optional(field_name: str) -> Optional[np.ndarray]:
        values = [getattr(part, field_name) for part in parts]
        if all(value is None for value in values):
            return None
        if any(value is None for value in values):
            raise ValueError(f"Cannot concatenate mixed WindowedData.{field_name} values")
        return np.concatenate(values, axis=0)

    return WindowedData(
        x=np.concatenate([part.x for part in parts], axis=0),
        y=np.concatenate([part.y for part in parts], axis=0),
        record_indices=np.concatenate([part.record_indices for part in parts], axis=0),
        record_ids=np.concatenate([part.record_ids for part in parts], axis=0),
        ood=np.concatenate([part.ood for part in parts], axis=0),
        record_y=_concat_optional("record_y"),
        valid_mask=_concat_optional("valid_mask"),
        timestamps=_concat_optional("timestamps"),
        raw_starts=_concat_optional("raw_starts"),
        group_ids=_concat_optional("group_ids"),
        group_index=_concat_optional("group_index"),
    )


def _build_windows_by_mode(
    features: np.ndarray,
    df: pd.DataFrame,
    class_to_idx: Dict[str, int],
    mode: str = "count",
    timestamp_col: str = "timestamp",
    label_col: str = "label",
    record_id_col: str = "record_id",
    window_size: int = 16,
    stride: int = 8,
    time_seconds: float = 2.0,
    adaptive_min_size: int = 8,
    adaptive_max_size: int = 64,
) -> WindowedData:
    mode_key = str(mode or "count").lower()
    if mode_key == "time":
        return build_time_windows(
            features,
            df,
            class_to_idx,
            timestamp_col=timestamp_col,
            label_col=label_col,
            record_id_col=record_id_col,
            time_seconds=time_seconds,
            max_records=window_size,
        )
    if mode_key == "adaptive":
        return build_adaptive_windows(
            features,
            df,
            class_to_idx,
            timestamp_col=timestamp_col,
            label_col=label_col,
            record_id_col=record_id_col,
            min_size=adaptive_min_size,
            max_size=adaptive_max_size,
            target_records=window_size,
            stride=stride,
        )
    return build_count_windows(
        features,
        df,
        class_to_idx,
        label_col=label_col,
        record_id_col=record_id_col,
        window_size=window_size,
        stride=stride,
    )


def build_grouped_windows(
    features: np.ndarray,
    df: pd.DataFrame,
    class_to_idx: Dict[str, int],
    group_col: Optional[str] = None,
    mode: str = "count",
    timestamp_col: str = "timestamp",
    label_col: str = "label",
    record_id_col: str = "record_id",
    window_size: int = 16,
    stride: int = 8,
    time_seconds: float = 2.0,
    adaptive_min_size: int = 8,
    adaptive_max_size: int = 64,
) -> WindowedData:
    work = df if "__labels" in df.columns else attach_parsed_labels(df, label_col)
    if not group_col or group_col not in work.columns:
        return _build_windows_by_mode(
            features,
            work,
            class_to_idx,
            mode=mode,
            timestamp_col=timestamp_col,
            label_col=label_col,
            record_id_col=record_id_col,
            window_size=window_size,
            stride=stride,
            time_seconds=time_seconds,
            adaptive_min_size=adaptive_min_size,
            adaptive_max_size=adaptive_max_size,
        )

    parts: List[WindowedData] = []
    group_series = work[group_col]
    for group_id in pd.unique(group_series):
        if pd.isna(group_id):
            group_mask = group_series.isna().to_numpy(dtype=bool)
        else:
            group_mask = group_series.eq(group_id).fillna(False).to_numpy(dtype=bool)
        group_positions = np.flatnonzero(group_mask)
        if len(group_positions) == 0:
            continue

        group_windows = _build_windows_by_mode(
            features[group_positions],
            work.iloc[group_positions].copy(),
            class_to_idx,
            mode=mode,
            timestamp_col=timestamp_col,
            label_col=label_col,
            record_id_col=record_id_col,
            window_size=window_size,
            stride=stride,
            time_seconds=time_seconds,
            adaptive_min_size=adaptive_min_size,
            adaptive_max_size=adaptive_max_size,
        )
        if len(group_windows) == 0:
            continue

        group_windows.record_indices = group_positions[np.asarray(group_windows.record_indices, dtype=np.int64)]
        if group_windows.raw_starts is not None:
            group_windows.raw_starts = group_positions[np.asarray(group_windows.raw_starts, dtype=np.int64)]
        group_windows.group_ids = np.repeat(np.asarray([group_id]), len(group_windows))
        parts.append(group_windows)

    if parts:
        return concat_windowed(parts)

    mode_key = str(mode or "count").lower()
    window_len = adaptive_max_size if mode_key == "adaptive" and timestamp_col in work.columns else window_size
    return _empty_windowed(features, len(class_to_idx), window_len)


def filter_id_windows(windows: WindowedData) -> WindowedData:
    keep = ~windows.ood
    return WindowedData(
        x=windows.x[keep], y=windows.y[keep], record_indices=windows.record_indices[keep], record_ids=windows.record_ids[keep], ood=windows.ood[keep],
        record_y=windows.record_y[keep] if windows.record_y is not None else None,
        valid_mask=windows.valid_mask[keep] if windows.valid_mask is not None else None,
        timestamps=windows.timestamps[keep] if windows.timestamps is not None else None,
        raw_starts=windows.raw_starts[keep] if windows.raw_starts is not None else None,
        group_ids=windows.group_ids[keep] if windows.group_ids is not None else None,
        group_index=windows.group_index[keep] if windows.group_index is not None else None,
    )


def window_phase_labels(df: pd.DataFrame, windows: WindowedData, phase_col: str) -> np.ndarray:
    if phase_col not in df.columns or len(windows) == 0:
        return np.asarray([], dtype=object) if len(windows) == 0 else np.asarray([None] * len(windows), dtype=object)
    phases: List[Optional[str]] = []
    for i in range(len(windows)):
        idx = np.asarray(windows.record_indices[i], dtype=np.int64)
        valid = np.asarray(windows.valid_mask[i], dtype=bool) if windows.valid_mask is not None else np.ones(len(idx), dtype=bool)
        valid_idx = idx[valid]
        if len(valid_idx) == 0:
            phases.append(None)
            continue
        labels = [str(v).strip() for v in df.iloc[valid_idx][phase_col].tolist() if pd.notna(v) and str(v).strip()]
        if not labels:
            phases.append(None)
            continue
        counts = Counter(labels)
        best_count = max(counts.values())
        for label in labels:
            if counts[label] == best_count:
                phases.append(label)
                break
    return np.asarray(phases, dtype=object)
